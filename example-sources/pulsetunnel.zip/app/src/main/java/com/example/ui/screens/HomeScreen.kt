package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProfileEntity
import com.example.model.ProtocolType
import com.example.model.TunnelState
import com.example.model.TunnelStats
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.ui.theme.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    tunnelState: TunnelState,
    tunnelStats: TunnelStats,
    activeProfile: ProfileEntity?,
    allProfiles: List<ProfileEntity>,
    onToggleTunnel: () -> Unit,
    onSelectProfile: (Long) -> Unit,
    onPingActive: () -> Unit,
    onNavigateToProfiles: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Active Profile Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable { onNavigateToProfiles() }
                .testTag("active_profile_card"),
            color = if (isDark) MaterialTheme.colorScheme.surfaceContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(
                                when (tunnelState) {
                                    TunnelState.CONNECTED -> EmeraldSuccess
                                    TunnelState.CONNECTING -> MaterialTheme.colorScheme.primary
                                    TunnelState.ERROR -> MaterialTheme.colorScheme.error
                                    else -> MaterialTheme.colorScheme.outline
                                }
                            )
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.padding(end = 8.dp)) {
                        Text(
                            text = activeProfile?.name ?: "No Profile Selected",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 1
                        )
                        if (activeProfile != null) {
                            Text(
                                text = "${activeProfile.protocolType} • ${activeProfile.serverHost}:${activeProfile.serverPort}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        } else {
                            Text(
                                text = "Tap to choose or create a profile",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                }

                if (activeProfile != null) {
                    Surface(
                        onClick = onPingActive,
                        modifier = Modifier
                            .testTag("ping_button")
                            .padding(start = 6.dp),
                        shape = RoundedCornerShape(10.dp),
                        color = if (isDark) MaterialTheme.colorScheme.surfaceContainerHigh else MaterialTheme.colorScheme.surfaceContainerLowest,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isDark) MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                            else MaterialTheme.colorScheme.outlineVariant
                        ),
                        tonalElevation = 1.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = "Ping",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (activeProfile.lastPingMs >= 0) "${activeProfile.lastPingMs}ms" else "Ping",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Central Power / Reactor Orb
        Box(
            modifier = Modifier
                .size(230.dp)
                .testTag("power_orb_container"),
            contentAlignment = Alignment.Center
        ) {
            val isConnected = tunnelState == TunnelState.CONNECTED
            val isConnecting = tunnelState == TunnelState.CONNECTING
            val isError = tunnelState == TunnelState.ERROR

            // Pulsing animation ONLY when actively CONNECTING
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val pulseScale by infiniteTransition.animateFloat(
                initialValue = 1f,
                targetValue = if (isConnecting) 1.18f else 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1300, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "pulseScale"
            )

            val pulseAlpha by infiniteTransition.animateFloat(
                initialValue = if (isConnecting) 0.40f else 0f,
                targetValue = if (isConnecting) 0.05f else 0f,
                animationSpec = infiniteRepeatable(
                    animation = tween(1300, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "pulseAlpha"
            )

            // Outer pulse wave ring - active ONLY during CONNECTING
            if (isConnecting) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .scale(pulseScale)
                        .clip(CircleShape)
                        .background(
                            if (isDark) CyanPrimary.copy(alpha = pulseAlpha)
                            else ForestTeal.copy(alpha = pulseAlpha * 0.7f)
                        )
                )
            }

            // Outer decorative ring & ambient glow
            Box(
                modifier = Modifier
                    .size(200.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isDark) {
                                when {
                                    isConnected -> listOf(CyanPrimary.copy(alpha = 0.28f), Color.Transparent)
                                    isConnecting -> listOf(CyanPrimary.copy(alpha = 0.18f), Color.Transparent)
                                    isError -> listOf(CoralError.copy(alpha = 0.22f), Color.Transparent)
                                    else -> listOf(CyanPrimary.copy(alpha = 0.06f), Color.Transparent)
                                }
                            } else {
                                when {
                                    isConnected -> listOf(BrightCyan.copy(alpha = 0.55f), Color.Transparent)
                                    isConnecting -> listOf(BrightCyan.copy(alpha = 0.40f), Color.Transparent)
                                    isError -> listOf(Color(0xFFF0B9B5).copy(alpha = 0.50f), Color.Transparent)
                                    else -> listOf(Color(0xFFD0E7E9).copy(alpha = 0.35f), Color.Transparent)
                                }
                            }
                        )
                    )
                    .border(
                        width = if (isConnected) 3.dp else 2.dp,
                        brush = Brush.linearGradient(
                            colors = if (isDark) {
                                when {
                                    isConnected -> listOf(CyanPrimary, ForestTeal)
                                    isConnecting -> listOf(CyanPrimary, DeepTeal)
                                    isError -> listOf(CoralError, DarkErrorContainer)
                                    else -> listOf(DarkBorder, Color(0xFF282A2B))
                                }
                            } else {
                                when {
                                    isConnected -> listOf(ForestTeal, BrightCyan)
                                    isConnecting -> listOf(ForestTeal, Color(0xFF4D6264))
                                    isError -> listOf(Color(0xFF832D2C), Color(0xFFF0B9B5))
                                    else -> listOf(Color(0xFFBBC8C9), Color(0xFFD0E7E9))
                                }
                            }
                        ),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Interactive core button
                Box(
                    modifier = Modifier
                        .size(150.dp)
                        .clip(CircleShape)
                        .background(
                            if (isDark) {
                                when {
                                    isConnected -> Brush.verticalGradient(listOf(CyanPrimary, DeepTeal))
                                    isConnecting -> Brush.verticalGradient(listOf(DeepTeal, DarkBackground))
                                    isError -> Brush.verticalGradient(listOf(DarkErrorContainer, Color(0xFF450A0A)))
                                    else -> Brush.verticalGradient(listOf(Color(0xFF25292A), Color(0xFF16191A)))
                                }
                            } else {
                                when {
                                    isConnected -> Brush.verticalGradient(listOf(ForestTeal, DeepTeal))
                                    isConnecting -> Brush.verticalGradient(listOf(Color(0xFFE0F7FA), Color(0xFFB2EBF2)))
                                    isError -> Brush.verticalGradient(listOf(Color(0xFF832D2C), Color(0xFF71000D)))
                                    // Light Mode Standby: Clean frosted tactile look with subtle white-to-light-gray gradient
                                    else -> Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE9EEF0)))
                                }
                            }
                        )
                        .border(
                            width = 1.5.dp,
                            color = if (isDark) {
                                when {
                                    isConnected -> CyanPrimary.copy(alpha = 0.8f)
                                    isConnecting -> CyanPrimary.copy(alpha = 0.5f)
                                    isError -> CoralError
                                    else -> DarkBorder.copy(alpha = 0.7f)
                                }
                            } else {
                                when {
                                    isConnected -> ForestTeal
                                    isConnecting -> ForestTeal.copy(alpha = 0.6f)
                                    isError -> Color(0xFF832D2C)
                                    else -> Color(0xFFBBC8C9)
                                }
                            },
                            shape = CircleShape
                        )
                        .clickable { onToggleTunnel() }
                        .testTag("power_connect_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = when {
                                isConnected -> Icons.Default.CheckCircle
                                isError -> Icons.Default.ErrorOutline
                                else -> Icons.Default.PowerSettingsNew
                            },
                            contentDescription = "Toggle VPN",
                            tint = if (isDark) {
                                when {
                                    isConnected -> DarkTealOnPrimary
                                    isConnecting -> CyanPrimary
                                    isError -> Color(0xFFFFC3BF)
                                    else -> CyanPrimary.copy(alpha = 0.85f)
                                }
                            } else {
                                when {
                                    isConnected -> Color(0xFFD3FBFF)
                                    isConnecting -> ForestTeal
                                    isError -> Color(0xFFFFC3BF)
                                    // Light Mode Standby: High-contrast rich Deep Teal icon
                                    else -> ForestTeal
                                }
                            },
                            modifier = Modifier.size(52.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = when (tunnelState) {
                                TunnelState.CONNECTED -> "CONNECTED"
                                TunnelState.CONNECTING -> "CONNECTING…"
                                TunnelState.STOPPING -> "DISCONNECTING"
                                TunnelState.ERROR -> "RETRY"
                                TunnelState.DISCONNECTED -> "CONNECT"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (isDark) {
                                when {
                                    isConnected -> DarkTealOnPrimary
                                    isError -> Color(0xFFFFC3BF)
                                    isConnecting -> CyanPrimary
                                    else -> SlateTextSecondary
                                }
                            } else {
                                when {
                                    isConnected -> Color(0xFFD3FBFF)
                                    isError -> Color(0xFFFFC3BF)
                                    isConnecting -> ForestTeal
                                    // Light Mode Standby: High-contrast rich Deep Teal text
                                    else -> ForestTeal
                                }
                            },
                            letterSpacing = 1.2.sp
                        )
                    }
                }
            }
        }

        // Real-Time Telemetry Cards Grid
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .testTag("telemetry_grid_card"),
            color = if (isDark) MaterialTheme.colorScheme.surfaceContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
            tonalElevation = 2.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Upload speed
                    MetricCell(
                        icon = Icons.Default.ArrowUpward,
                        iconTint = if (isDark) CyanPrimary else ForestTeal,
                        title = "UPLOAD",
                        value = formatSpeed(tunnelStats.uploadSpeedBps),
                        subtitle = formatBytes(tunnelStats.uploadBytes),
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    // Download speed
                    MetricCell(
                        icon = Icons.Default.ArrowDownward,
                        iconTint = if (isDark) BrightCyan else Color(0xFF007A87),
                        title = "DOWNLOAD",
                        value = formatSpeed(tunnelStats.downloadSpeedBps),
                        subtitle = formatBytes(tunnelStats.downloadBytes),
                        modifier = Modifier.weight(1f)
                    )
                }

                HorizontalDivider(
                    modifier = Modifier.padding(vertical = 14.dp),
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // Connection Duration
                    MetricCell(
                        icon = Icons.Default.Timer,
                        iconTint = if (isDark) AmberWarning else Color(0xFFB45309),
                        title = "DURATION",
                        value = formatDuration(tunnelStats.connectedDurationSec),
                        subtitle = if (tunnelState == TunnelState.CONNECTED) "Active Session" else "Standby",
                        modifier = Modifier.weight(1f)
                    )

                    Spacer(modifier = Modifier.width(16.dp))

                    // Total Traffic
                    MetricCell(
                        icon = Icons.Default.DataUsage,
                        iconTint = if (isDark) EmeraldSuccess else Color(0xFF047857),
                        title = "TOTAL DATA",
                        value = formatBytes(tunnelStats.uploadBytes + tunnelStats.downloadBytes),
                        subtitle = "Sent & Received",
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Connect / Disconnect Action Button
        Button(
            onClick = onToggleTunnel,
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("main_action_button"),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (tunnelState == TunnelState.CONNECTED) {
                    MaterialTheme.colorScheme.error
                } else {
                    MaterialTheme.colorScheme.primary
                },
                contentColor = if (tunnelState == TunnelState.CONNECTED) {
                    MaterialTheme.colorScheme.onError
                } else {
                    MaterialTheme.colorScheme.onPrimary
                }
            )
        ) {
            Icon(
                imageVector = if (tunnelState == TunnelState.CONNECTED) Icons.Default.Close else Icons.Default.VpnKey,
                contentDescription = null,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = if (tunnelState == TunnelState.CONNECTED) "Disconnect Tunnel" else "Connect Tunnel",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun MetricCell(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    title: String,
    value: String,
    subtitle: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleLarge,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
        Text(
            text = subtitle,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun formatSpeed(bytesPerSec: Long): String {
    return when {
        bytesPerSec >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
        bytesPerSec >= 1024 -> String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
        else -> "$bytesPerSec B/s"
    }
}

private fun formatBytes(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }
}

private fun formatDuration(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return if (hrs > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }
}
