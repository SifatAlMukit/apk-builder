package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.activity.compose.BackHandler
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ProfileEntity
import com.example.model.ProtocolType
import com.example.ui.theme.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddConfigurationDialog(
    profile: ProfileEntity?,
    onDismiss: () -> Unit,
    onSave: (ProfileEntity) -> Unit,
    onImportLink: (String) -> Boolean
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    BackHandler(onBack = onDismiss)

    var isManualTab by remember { mutableStateOf(profile != null) }
    var linkInput by remember { mutableStateOf("") }

    // Protocol & Core Fields
    var protocol by remember { mutableStateOf(profile?.protocolType ?: ProtocolType.VLESS) }
    var protocolExpanded by remember { mutableStateOf(false) }

    var name by remember { mutableStateOf(profile?.name ?: "") }
    var host by remember { mutableStateOf(profile?.serverHost ?: "") }
    var port by remember { mutableStateOf(profile?.serverPort?.toString() ?: if (protocol == ProtocolType.SSH) "22" else "443") }
    var uuid by remember { mutableStateOf(profile?.uuid ?: "") }

    // SSH fields
    var username by remember { mutableStateOf(profile?.authUsername ?: "root") }
    var password by remember { mutableStateOf(profile?.authPassword ?: "") }
    var showPassword by remember { mutableStateOf(false) }
    var privateKey by remember { mutableStateOf(profile?.privateKey ?: "") }
    var showPrivateKeyDialog by remember { mutableStateOf(false) }

    // Transport & Security
    var network by remember { mutableStateOf(profile?.transportNetwork ?: "TCP") }
    var networkExpanded by remember { mutableStateOf(false) }
    var security by remember { mutableStateOf(if (profile?.transportSecurity.isNullOrBlank()) "None" else profile!!.transportSecurity.replaceFirstChar { it.uppercase() }) }
    var securityExpanded by remember { mutableStateOf(false) }
    var flowXtls by remember { mutableStateOf(profile?.flowXtls ?: "") }
    var sni by remember { mutableStateOf(profile?.sni ?: "") }
    var wsPath by remember { mutableStateOf(profile?.wsPath ?: "") }

    // DPI Bypass / Inject
    var useSslTls by remember { mutableStateOf(profile?.useSslTls ?: false) }
    var useCustomPayload by remember { mutableStateOf(profile?.useCustomPayload ?: false) }
    var customPayload by remember { mutableStateOf(profile?.customPayload ?: "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]") }
    var showPayloadDialog by remember { mutableStateOf(false) }

    var useProxy by remember { mutableStateOf(profile?.useProxy ?: false) }
    var proxyHost by remember { mutableStateOf(profile?.proxyHost ?: "") }
    var proxyPort by remember { mutableStateOf(profile?.proxyPort?.toString() ?: "8080") }

    // Enhance & SlowDNS
    var sshCompression by remember { mutableStateOf(profile?.sshCompression ?: false) }
    var tunnelOverDns by remember { mutableStateOf(profile?.tunnelOverDns ?: false) }
    var dnsttDomain by remember { mutableStateOf(profile?.dnsttDomain ?: "") }
    var dnsttResolver by remember { mutableStateOf(profile?.dnsttResolver ?: "1.1.1.1") }
    var dnsttPubKey by remember { mutableStateOf(profile?.dnsttPublicKey ?: "") }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                if (profile == null) "Add Configuration" else "Edit Configuration",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.background
                        )
                    )
                },
                bottomBar = {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding(),
                        color = MaterialTheme.colorScheme.background,
                        tonalElevation = 8.dp
                    ) {
                        Button(
                            onClick = {
                                if (!isManualTab) {
                                    val success = onImportLink(linkInput)
                                    if (success) {
                                        Toast.makeText(context, "Configuration imported successfully", Toast.LENGTH_SHORT).show()
                                        onDismiss()
                                    } else {
                                        Toast.makeText(context, "Invalid link format", Toast.LENGTH_SHORT).show()
                                    }
                                } else {
                                    val finalName = name.trim().ifEmpty {
                                        "${protocol.displayName} - ${host.trim().ifEmpty { "Server" }}"
                                    }
                                    val entity = ProfileEntity(
                                        id = profile?.id ?: 0L,
                                        name = finalName,
                                        protocolType = protocol,
                                        serverHost = host.trim(),
                                        serverPort = port.toIntOrNull() ?: if (protocol == ProtocolType.SSH) 22 else 443,
                                        authUsername = username.trim(),
                                        authPassword = password,
                                        privateKey = privateKey.trim(),
                                        uuid = uuid.trim(),
                                        sni = sni.trim(),
                                        wsPath = wsPath.trim(),
                                        transportSecurity = security.lowercase(),
                                        transportNetwork = network,
                                        flowXtls = flowXtls.trim(),
                                        useSslTls = useSslTls,
                                        useCustomPayload = useCustomPayload,
                                        customPayload = customPayload,
                                        useProxy = useProxy,
                                        proxyHost = proxyHost.trim(),
                                        proxyPort = proxyPort.toIntOrNull() ?: 8080,
                                        sshCompression = sshCompression,
                                        tunnelOverDns = tunnelOverDns,
                                        dnsttDomain = dnsttDomain.trim(),
                                        dnsttResolver = dnsttResolver.trim(),
                                        dnsttPublicKey = dnsttPubKey.trim(),
                                        isActive = profile?.isActive ?: false
                                    )
                                    onSave(entity)
                                    onDismiss()
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp)
                                .height(52.dp)
                                .testTag("save_config_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.SaveAlt, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                if (!isManualTab) "Import Configuration" else "Save Configuration",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            ) { padding ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Segmented Control: Import vs Manual
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(modifier = Modifier.fillMaxSize().padding(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (!isManualTab) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { isManualTab = false },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.ContentPaste,
                                        contentDescription = null,
                                        tint = if (!isManualTab) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "Import",
                                        color = if (!isManualTab) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isManualTab) MaterialTheme.colorScheme.primary else Color.Transparent)
                                    .clickable { isManualTab = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Tune,
                                        contentDescription = null,
                                        tint = if (isManualTab) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "Manual",
                                        color = if (isManualTab) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    if (!isManualTab) {
                        // Import Link View
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Paste Configuration Link", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text("Supports vmess://, vless://, trojan://, or ssh:// URIs.", style = MaterialTheme.typography.bodySmall, color = SlateTextSecondary)

                                OutlinedTextField(
                                    value = linkInput,
                                    onValueChange = { linkInput = it },
                                    label = { Text("Link") },
                                    maxLines = 6,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Button(
                                    onClick = {
                                        val clip = clipboardManager.getText()?.text
                                        if (!clip.isNullOrBlank()) linkInput = clip
                                    },
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Paste from Clipboard")
                                }
                            }
                        }
                    } else {
                        // Manual Configuration View
                        // 1. Protocol & Address Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                // Protocol Dropdown
                                Text("Protocol", style = MaterialTheme.typography.labelMedium, color = SlateTextSecondary)
                                Box {
                                    OutlinedTextField(
                                        value = protocol.displayName,
                                        onValueChange = {},
                                        readOnly = true,
                                        trailingIcon = {
                                            IconButton(onClick = { protocolExpanded = !protocolExpanded }) {
                                                Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth().clickable { protocolExpanded = true }
                                    )
                                    DropdownMenu(
                                        expanded = protocolExpanded,
                                        onDismissRequest = { protocolExpanded = false }
                                    ) {
                                        ProtocolType.values().forEach { p ->
                                            DropdownMenuItem(
                                                text = { Text(p.displayName) },
                                                onClick = {
                                                    protocol = p
                                                    if (port.isBlank() || port == "443" || port == "22") {
                                                        port = if (p == ProtocolType.SSH) "22" else "443"
                                                    }
                                                    protocolExpanded = false
                                                }
                                            )
                                        }
                                    }
                                }

                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = it },
                                    label = { Text("Profile Name (Optional)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(
                                        value = host,
                                        onValueChange = { host = it },
                                        label = { Text("Address (server.com / 1.2.3.4)") },
                                        singleLine = true,
                                        modifier = Modifier.weight(2.2f)
                                    )
                                    OutlinedTextField(
                                        value = port,
                                        onValueChange = { port = it },
                                        label = { Text("Port") },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                // Protocol Specific Identity
                                if (protocol == ProtocolType.VLESS || protocol == ProtocolType.VMESS) {
                                    OutlinedTextField(
                                        value = uuid,
                                        onValueChange = { uuid = it },
                                        label = { Text("UUID") },
                                        placeholder = { Text("xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx") },
                                        singleLine = true,
                                        trailingIcon = {
                                            IconButton(onClick = { uuid = UUID.randomUUID().toString() }) {
                                                Icon(Icons.Default.Casino, contentDescription = "Generate Random UUID", tint = MaterialTheme.colorScheme.primary)
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else if (protocol == ProtocolType.TROJAN) {
                                    OutlinedTextField(
                                        value = password,
                                        onValueChange = { password = it },
                                        label = { Text("Trojan Password") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                } else if (protocol == ProtocolType.SSH) {
                                    OutlinedTextField(
                                        value = username,
                                        onValueChange = { username = it },
                                        label = { Text("Username") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = password,
                                        onValueChange = { password = it },
                                        label = { Text("Password") },
                                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                        trailingIcon = {
                                            IconButton(onClick = { showPassword = !showPassword }) {
                                                Icon(if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                                            }
                                        },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    TextButton(
                                        onClick = { showPrivateKeyDialog = true },
                                        modifier = Modifier.align(Alignment.End)
                                    ) {
                                        Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (privateKey.isNotBlank()) "Private Key Configured (Edit)" else "Add Private Key")
                                    }
                                }
                            }
                        }

                        // 2. Transport & Security (For V2Ray)
                        if (protocol == ProtocolType.VLESS || protocol == ProtocolType.VMESS || protocol == ProtocolType.TROJAN) {
                            SectionLabel(icon = Icons.Default.SyncAlt, title = "TRANSPORT & SECURITY")
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    // Network
                                    Text("Network", style = MaterialTheme.typography.labelMedium, color = SlateTextSecondary)
                                    Box {
                                        OutlinedTextField(
                                            value = network,
                                            onValueChange = {},
                                            readOnly = true,
                                            trailingIcon = {
                                                IconButton(onClick = { networkExpanded = !networkExpanded }) {
                                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().clickable { networkExpanded = true }
                                        )
                                        DropdownMenu(expanded = networkExpanded, onDismissRequest = { networkExpanded = false }) {
                                            listOf("TCP", "WebSocket", "gRPC").forEach { n ->
                                                DropdownMenuItem(text = { Text(n) }, onClick = { network = n; networkExpanded = false })
                                            }
                                        }
                                    }

                                    // Security
                                    Text("Security", style = MaterialTheme.typography.labelMedium, color = SlateTextSecondary)
                                    Box {
                                        OutlinedTextField(
                                            value = security,
                                            onValueChange = {},
                                            readOnly = true,
                                            trailingIcon = {
                                                IconButton(onClick = { securityExpanded = !securityExpanded }) {
                                                    Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().clickable { securityExpanded = true }
                                        )
                                        DropdownMenu(expanded = securityExpanded, onDismissRequest = { securityExpanded = false }) {
                                            listOf("None", "TLS", "Reality").forEach { s ->
                                                DropdownMenuItem(text = { Text(s) }, onClick = { security = s; securityExpanded = false })
                                            }
                                        }
                                    }

                                    if (protocol == ProtocolType.VLESS) {
                                        OutlinedTextField(
                                            value = flowXtls,
                                            onValueChange = { flowXtls = it },
                                            label = { Text("Flow (XTLS)") },
                                            placeholder = { Text("xtls-rprx-vision — or leave empty") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }

                                    OutlinedTextField(
                                        value = sni,
                                        onValueChange = { sni = it },
                                        label = { Text("SNI (Server Name Indication)") },
                                        placeholder = { Text("e.g. domain.com") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )

                                    if (network == "WebSocket") {
                                        OutlinedTextField(
                                            value = wsPath,
                                            onValueChange = { wsPath = it },
                                            label = { Text("WebSocket Path") },
                                            placeholder = { Text("e.g. /ws") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }

                        // 3. DPI BYPASS / INJECT Section
                        SectionLabel(
                            icon = Icons.Default.Security,
                            title = if (protocol == ProtocolType.SSH) "DPI BYPASS" else "DPI BYPASS / INJECT"
                        )
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                if (protocol == ProtocolType.SSH) {
                                    ToggleRow(
                                        icon = Icons.Default.Lock,
                                        title = "Use SSL / TLS",
                                        subtitle = "Wrap the SSH stream in a TLS tunnel.",
                                        checked = useSslTls,
                                        onCheckedChange = { useSslTls = it }
                                    )
                                    if (useSslTls) {
                                        OutlinedTextField(
                                            value = sni,
                                            onValueChange = { sni = it },
                                            label = { Text("TLS SNI Host (optional)") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                ToggleRow(
                                    icon = Icons.Default.Http,
                                    title = "Use Custom Payload",
                                    subtitle = if (protocol == ProtocolType.SSH) "Inject a custom HTTP request before connecting."
                                    else "Send an HTTP request before the V2Ray handshake.",
                                    checked = useCustomPayload,
                                    onCheckedChange = { useCustomPayload = it }
                                )

                                if (useCustomPayload) {
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { showPayloadDialog = true }
                                            .padding(vertical = 4.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = customPayload.take(35) + "…",
                                                style = MaterialTheme.typography.bodySmall,
                                                fontFamily = FontFamily.Monospace,
                                                color = SlateTextSecondary
                                            )
                                            Text("Edit", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }

                                ToggleRow(
                                    icon = Icons.Default.AltRoute,
                                    title = "Use Proxy",
                                    subtitle = "Route through an HTTP proxy (bug host).",
                                    checked = useProxy,
                                    onCheckedChange = { useProxy = it }
                                )

                                if (useProxy) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedTextField(
                                            value = proxyHost,
                                            onValueChange = { proxyHost = it },
                                            label = { Text("Proxy Host") },
                                            placeholder = { Text("e.g. 10.0.0.1") },
                                            singleLine = true,
                                            modifier = Modifier.weight(2f)
                                        )
                                        OutlinedTextField(
                                            value = proxyPort,
                                            onValueChange = { proxyPort = it },
                                            label = { Text("Port") },
                                            placeholder = { Text("8080") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }

                        // 4. Enhance Section (For SSH)
                        if (protocol == ProtocolType.SSH) {
                            SectionLabel(icon = Icons.Default.Tune, title = "ENHANCE")
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    ToggleRow(
                                        icon = Icons.Default.Compress,
                                        title = "SSH Compression",
                                        subtitle = "zlib compression — helps on slow links.",
                                        checked = sshCompression,
                                        onCheckedChange = { sshCompression = it }
                                    )
                                }
                            }

                            // 5. SlowDNS (DNSTT) Section
                            SectionLabel(icon = Icons.Default.Dns, title = "SLOWDNS (DNSTT)")
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    ToggleRow(
                                        icon = Icons.Default.Waves,
                                        title = "Tunnel over DNS",
                                        subtitle = "Carry SSH inside DNS queries.",
                                        checked = tunnelOverDns,
                                        onCheckedChange = { tunnelOverDns = it }
                                    )

                                    if (tunnelOverDns) {
                                        OutlinedTextField(
                                            value = dnsttDomain,
                                            onValueChange = { dnsttDomain = it },
                                            label = { Text("Tunnel Domain (e.g. t.domain.com)") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = dnsttResolver,
                                            onValueChange = { dnsttResolver = it },
                                            label = { Text("DNS Resolver (1.1.1.1 / DoH)") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        OutlinedTextField(
                                            value = dnsttPubKey,
                                            onValueChange = { dnsttPubKey = it },
                                            label = { Text("Server Public Key (Hex)") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }

                        // 6. Direct DNSTT Configuration
                        if (protocol == ProtocolType.DNSTT) {
                            SectionLabel(icon = Icons.Default.Dns, title = "SLOWDNS (DNSTT) PARAMETERS")
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OutlinedTextField(
                                        value = dnsttDomain,
                                        onValueChange = { dnsttDomain = it },
                                        label = { Text("Tunnel Domain (e.g. t.example.com)") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = dnsttResolver,
                                        onValueChange = { dnsttResolver = it },
                                        label = { Text("Resolver (1.1.1.1 / DoH URL)") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    OutlinedTextField(
                                        value = dnsttPubKey,
                                        onValueChange = { dnsttPubKey = it },
                                        label = { Text("Public Key (Hex)") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }
                    }
                }
            }

    // Payload Editor Dialog
    if (showPayloadDialog) {
        var tempPayload by remember { mutableStateOf(customPayload) }
        AlertDialog(
            onDismissRequest = { showPayloadDialog = false },
            title = { Text("HTTP Custom Payload Editor") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Macros: [host], [port], [host_port], [crlf], [protocol], [ua]",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateTextSecondary
                    )
                    OutlinedTextField(
                        value = tempPayload,
                        onValueChange = { tempPayload = it },
                        label = { Text("Payload Template") },
                        maxLines = 6,
                        textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { tempPayload = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("CONNECT", fontSize = 11.sp)
                        }
                        Button(
                            onClick = { tempPayload = "GET / HTTP/1.1[crlf]Host: [host][crlf]Upgrade: websocket[crlf][crlf]" },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("GET WS", fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    customPayload = tempPayload
                    showPayloadDialog = false
                }) { Text("Apply") }
            },
            dismissButton = { TextButton(onClick = { showPayloadDialog = false }) { Text("Cancel") } }
        )
    }

    // Private Key Dialog
    if (showPrivateKeyDialog) {
        var tempKey by remember { mutableStateOf(privateKey) }
        AlertDialog(
            onDismissRequest = { showPrivateKeyDialog = false },
            title = { Text("OpenSSH Private Key") },
            text = {
                OutlinedTextField(
                    value = tempKey,
                    onValueChange = { tempKey = it },
                    label = { Text("RSA / ED25519 Private Key") },
                    placeholder = { Text("-----BEGIN OPENSSH PRIVATE KEY-----...") },
                    maxLines = 8,
                    textStyle = LocalTextStyle.current.copy(fontFamily = FontFamily.Monospace),
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    privateKey = tempKey
                    showPrivateKeyDialog = false
                }) { Text("Save Key") }
            },
            dismissButton = { TextButton(onClick = { showPrivateKeyDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionLabel(icon: ImageVector, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant, letterSpacing = 1.1.sp)
    }
}

@Composable
private fun ToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange(!checked) },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(modifier = Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                checkedTrackColor = MaterialTheme.colorScheme.primary
            )
        )
    }
}
