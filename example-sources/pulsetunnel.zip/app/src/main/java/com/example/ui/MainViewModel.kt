package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppSettingEntity
import com.example.data.ProfileEntity
import com.example.data.TunnelRepository
import com.example.model.InstalledAppInfo
import com.example.model.LogLevel
import com.example.model.TunnelState
import com.example.model.TunnelStats
import com.example.util.ConfigCrypto
import com.example.util.ConfigParser
import com.example.vpn.PulseVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TunnelRepository.getInstance(application)

    val allProfiles: StateFlow<List<ProfileEntity>> = repository.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfile: StateFlow<ProfileEntity?> = repository.activeProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val tunnelState: StateFlow<TunnelState> = repository.tunnelState
    val tunnelStats: StateFlow<TunnelStats> = repository.tunnelStats

    val appSettings: StateFlow<AppSettingEntity> = repository.appSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingEntity())

    val recentLogs = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestLogMessage: StateFlow<String> = repository.latestLogMessage

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage = _userMessage.asSharedFlow()

    init {
        loadInstalledApps()
    }

    fun toggleConnection(context: Context) {
        val currentState = tunnelState.value
        if (currentState == TunnelState.CONNECTED || currentState == TunnelState.CONNECTING) {
            val stopIntent = Intent(context, PulseVpnService::class.java).apply {
                action = PulseVpnService.ACTION_STOP
            }
            context.startService(stopIntent)
        } else {
            val profile = activeProfile.value
            if (profile == null) {
                viewModelScope.launch {
                    _userMessage.emit("Please select or create a profile first.")
                }
                return
            }
            val startIntent = Intent(context, PulseVpnService::class.java).apply {
                action = PulseVpnService.ACTION_START
                putExtra(PulseVpnService.EXTRA_PROFILE_ID, profile.id)
            }
            ContextCompat.startForegroundService(context, startIntent)
        }
    }

    fun selectActiveProfile(profileId: Long) {
        viewModelScope.launch {
            repository.setActiveProfile(profileId)
        }
    }

    fun saveProfile(profile: ProfileEntity) {
        viewModelScope.launch {
            if (profile.id == 0L) {
                repository.insertProfile(profile)
                _userMessage.emit("Profile created: ${profile.name}")
            } else {
                repository.updateProfile(profile)
                _userMessage.emit("Profile updated: ${profile.name}")
            }
        }
    }

    fun deleteProfile(profileId: Long) {
        viewModelScope.launch {
            repository.deleteProfile(profileId)
            _userMessage.emit("Profile deleted.")
        }
    }

    fun duplicateProfile(profile: ProfileEntity) {
        viewModelScope.launch {
            repository.duplicateProfile(profile)
            _userMessage.emit("Profile duplicated.")
        }
    }

    fun pingProfile(profileId: Long) {
        viewModelScope.launch {
            val latency = repository.pingServer(profileId)
            if (latency >= 0) {
                _userMessage.emit("Ping response: ${latency}ms")
            } else {
                _userMessage.emit("Server unreachable (timed out)")
            }
        }
    }

    fun importFromLink(link: String): Boolean {
        val profile = ConfigParser.parseLink(link)
        if (profile != null) {
            viewModelScope.launch {
                repository.insertProfile(profile)
                _userMessage.emit("Imported profile: ${profile.name} (${profile.protocolType})")
            }
            return true
        }
        return false
    }

    fun exportEncryptedBackup(password: String): String {
        val list = allProfiles.value
        return ConfigCrypto.exportEncrypted(list, password)
    }

    fun importEncryptedBackup(encrypted: String, password: String): Boolean {
        return try {
            val profiles = ConfigCrypto.importEncrypted(encrypted, password)
            viewModelScope.launch {
                profiles.forEach { repository.insertProfile(it) }
                _userMessage.emit("Successfully imported ${profiles.size} profiles.")
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun updateSettings(settings: AppSettingEntity) {
        viewModelScope.launch {
            repository.updateSettings(settings)
            _userMessage.emit("Settings saved.")
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _userMessage.emit("Logs cleared.")
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val list = packages.mapNotNull { appInfo ->
                try {
                    val appName = pm.getApplicationLabel(appInfo).toString()
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    InstalledAppInfo(
                        packageName = appInfo.packageName,
                        appName = appName,
                        isSystemApp = isSystem
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedBy { it.appName.lowercase() }
            _installedApps.value = list
        }
    }
}
