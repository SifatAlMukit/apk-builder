package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LogEntryEntity
import com.example.model.LogLevel
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LogsScreen(
    logs: List<LogEntryEntity>,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()

    var selectedLevelFilter by remember { mutableStateOf<LogLevel?>(null) }

    val filteredLogs = remember(logs, selectedLevelFilter) {
        if (selectedLevelFilter == null) logs
        else logs.filter { it.level == selectedLevelFilter }
    }

    val timeFormatter = remember { SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()) }

    // Auto-scroll to bottom (newest bottom entry)
    LaunchedEffect(filteredLogs.size) {
        if (filteredLogs.isNotEmpty()) {
            listState.animateScrollToItem(filteredLogs.size - 1)
        }
    }

    val isDark = MaterialTheme.colorScheme.background.luminance() < 0.5f

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        // Top action bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Connection Logs (${logs.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                    onClick = {
                        val text = filteredLogs.joinToString("\n") { log ->
                            "[${timeFormatter.format(Date(log.timestamp))}] [${log.level}] ${log.message}"
                        }
                        clipboardManager.setText(AnnotatedString(text))
                        Toast.makeText(context, "Logs copied to clipboard", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.testTag("copy_logs_button")
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Logs")
                }

                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier.testTag("clear_logs_button")
                ) {
                    Icon(Icons.Default.ClearAll, contentDescription = "Clear Logs")
                }
            }
        }

        // Level Filter Chips in horizontal scroll
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedLevelFilter == null,
                    onClick = { selectedLevelFilter = null },
                    label = { Text("ALL (${logs.size})", maxLines = 1) }
                )
            }
            item { itemsFilter(LogLevel.INFO, selectedLevelFilter) { selectedLevelFilter = it } }
            item { itemsFilter(LogLevel.DEBUG, selectedLevelFilter) { selectedLevelFilter = it } }
            item { itemsFilter(LogLevel.WARN, selectedLevelFilter) { selectedLevelFilter = it } }
            item { itemsFilter(LogLevel.ERROR, selectedLevelFilter) { selectedLevelFilter = it } }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Terminal Log Console
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(12.dp))
                .testTag("log_console"),
            color = if (isDark) Color(0xFF0F1416) else MaterialTheme.colorScheme.surfaceContainerLowest,
            border = BorderStroke(
                1.dp,
                if (isDark) Color(0xFF282A2B) else MaterialTheme.colorScheme.outlineVariant
            ),
            tonalElevation = 2.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Terminal Header Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = if (isDark) Color(0xFF1E2020) else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(if (isDark) CoralError else Color(0xFF832D2C)))
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(if (isDark) AmberWarning else Color(0xFFB45309)))
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.size(8.dp).clip(androidx.compose.foundation.shape.CircleShape).background(if (isDark) EmeraldSuccess else Color(0xFF047857)))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "pulsetunnel@vpn:~# tail -f session.log",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = if (isDark) SlateTextSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                        Text(
                            text = "${filteredLogs.size} lines",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = if (isDark) SlateTextSecondary else MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 10.sp
                        )
                    }
                }

                if (filteredLogs.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(
                            text = "No logs recorded yet. Tap CONNECT to start session.",
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = FontFamily.Monospace,
                            color = if (isDark) SlateTextSecondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(filteredLogs, key = { it.id }) { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = timeFormatter.format(Date(log.timestamp)),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isDark) Color(0xFF8F9190) else Color(0xFF6B7280),
                                    fontSize = 11.sp,
                                    modifier = Modifier.width(84.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))

                                val (tagColor, tagBg) = when (log.level) {
                                    LogLevel.INFO -> if (isDark) Pair(CyanPrimary, DeepTeal.copy(alpha = 0.35f)) else Pair(ForestTeal, Color(0xFFD0E7E9))
                                    LogLevel.DEBUG -> if (isDark) Pair(Color(0xFFB4CBCD), Color(0xFF364A4C).copy(alpha = 0.4f)) else Pair(Color(0xFF4D6264), Color(0xFFE3E6E6))
                                    LogLevel.WARN -> if (isDark) Pair(AmberWarning, Color(0xFF78350F).copy(alpha = 0.4f)) else Pair(Color(0xFFB45309), Color(0xFFFEF3C7))
                                    LogLevel.ERROR -> if (isDark) Pair(CoralError, Color(0xFF7F2828).copy(alpha = 0.4f)) else Pair(Color(0xFF832D2C), Color(0xFFF0B9B5))
                                }

                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(tagBg)
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = log.level.name,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        color = tagColor
                                    )
                                }

                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = log.message,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    color = if (isDark) {
                                        when (log.level) {
                                            LogLevel.ERROR -> Color(0xFFFECDD3)
                                            LogLevel.WARN -> Color(0xFFFDE68A)
                                            else -> Color(0xFFE2E3E2)
                                        }
                                    } else {
                                        when (log.level) {
                                            LogLevel.ERROR -> Color(0xFF832D2C)
                                            LogLevel.WARN -> Color(0xFFB45309)
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun itemsFilter(
    level: LogLevel,
    currentFilter: LogLevel?,
    onSelect: (LogLevel?) -> Unit
) {
    FilterChip(
        selected = currentFilter == level,
        onClick = { onSelect(if (currentFilter == level) null else level) },
        label = { Text(level.name, maxLines = 1) }
    )
}
