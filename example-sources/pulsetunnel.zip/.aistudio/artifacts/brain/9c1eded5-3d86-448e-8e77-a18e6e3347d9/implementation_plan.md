# Full App Theming & Reactor Orb Styling

Implement the custom M3 ColorScheme provided by the user across both Dark and Light modes, and upgrade the central Reactor Orb on the Home Screen with a custom Primary Cyan and Deep Teal energy gradient.

## User Review & Critical Decisions

> [!IMPORTANT]
> - **Confirmed Theme Choice**: Implement both Dark and Light color schemes using the exact tokens provided by the user.
> - **Confirmed Reactor Orb Style**: Style the central Reactor Orb with a luminous **Primary Cyan (`#7CD4DD`) to Deep Teal (`#004F55`)** gradient, harmonizing with the dark background atmosphere and providing tactile visual feedback across all connection states.

---

## 1. Overview & Core Concept

- **What It Delivers**: Replaces the legacy blue color tokens with the user's bespoke Material 3 Teal & Deep Charcoal design system across all screens (Home, Profiles, Settings, Logs, and Dialogs).
- **Aesthetic Direction**: High-tech, cybersecurity-focused dark UI with soft cyan illumination (`#7CD4DD`), rich deep teal containers (`#004F55`), and charcoal surfaces (`#111414`).
- **Reactor Orb Redesign**: The central power button transitions from standard flat blues to a multi-layered reactive orb that pulses with cyan energy when connecting, glows with steady deep teal and cyan radiance when connected, and gracefully dims into the background when idle.

---

## 2. Visual Identity & Theme Specification

### Color Tokens

#### Dark Color Scheme (Active Default)
- `background` & `surface`: `#111414` (Deep Charcoal)
- `primary`: `#7CD4DD` (Luminous Cyan)
- `primaryContainer`: `#004F55` (Deep Teal)
- `secondary`: `#B4CBCD` (Muted Metallic Teal)
- `secondaryContainer`: `#364A4C` (Dark Slate Teal)
- `tertiary`: `#BBC6E3` (Soft Lavender Blue)
- `tertiaryContainer`: `#3B475E` (Deep Midnight Blue)
- `surfaceContainer`: `#1E2020` / `surfaceContainerHigh`: `#282A2B`
- `surfaceVariant`: `#454747` / `outline`: `#8F9190`
- `error`: `#EC9A96` / `errorContainer`: `#7F2828`

#### Light Color Scheme
- `background` & `surface`: `#F6F6F6` (Crisp Off-White)
- `primary`: `#006970` (Deep Forest Teal)
- `primaryContainer`: `#99F1F9` (Bright Ice Cyan)
- `secondary`: `#4D6264` / `secondaryContainer`: `#D0E7E9`
- `tertiary`: `#535E77` / `tertiaryContainer`: `#D7E2FF`
- `surfaceVariant`: `#D1D5D6` / `outline`: `#757777`
- `error`: `#832D2C` / `errorContainer`: `#F0B9B5`

### Reactor Orb Visual States

```
┌─────────────────────────────────────────────────────────────┐
│                     REACTOR ORB STATES                      │
├─────────────────────────────────────────────────────────────┤
│ 1. CONNECTED:                                               │
│    • Outer Glow: Radial gradient (Cyan #7CD4DD @ 25% alpha) │
│    • Outer Ring: Linear gradient (#7CD4DD -> #006970)       │
│    • Core Button: Vertical gradient (#7CD4DD -> #004F55)    │
│    • Icon & Label: Deep contrasting Teal (#003B40)          │
│                                                             │
│ 2. CONNECTING:                                              │
│    • Pulse Ring: Expanding Cyan wave (#7CD4DD)              │
│    • Core Button: Deep Teal (#004F55) -> Charcoal (#111414) │
│    • Icon & Label: Pulsing Cyan (#7CD4DD)                   │
│                                                             │
│ 3. DISCONNECTED (Standby):                                  │
│    • Outer Ring: Surface outline (#404E4F)                  │
│    • Core Button: Gradient (#282A2B -> #1E2020)            │
│    • Icon & Label: Muted Slate (#8F9190)                    │
│                                                             │
│ 4. ERROR:                                                   │
│    • Outer Glow & Ring: Soft Coral Error (#EC9A96)          │
│    • Core Button: Dark Error (#7F2828 -> #450A0A)           │
│    • Icon & Label: Light Rose (#FFC3BF)                     │
└─────────────────────────────────────────────────────────────┘
```

---

## 3. Key Architectural Changes

1. **`Color.kt` & `Theme.kt`**:
   - Update `Color.kt` to define the new palette constants and semantic shades.
   - Update `Theme.kt` with the full `darkColorScheme` and `lightColorScheme` definitions provided by the user.
2. **`HomeScreen.kt`**:
   - Update the Reactor Orb (`power_orb_container` and `power_connect_button`) to use the selected Primary Cyan & Deep Teal gradient.
   - Update telemetry metric cards and active profile badges to harmonize with the new palette.
3. **Screens Consistency (`ProfilesScreen.kt`, `SettingsScreen.kt`, `LogsScreen.kt`, `AddConfigurationDialog.kt`)**:
   - Align buttons, active state outlines, icons, and switch toggles to use the new `primary` (`#7CD4DD`) and `primaryContainer` colors instead of legacy hardcoded blue constants.

---

## 4. Verification & Testing Strategy

- **Build Verification**: Run `compile_applet` to verify compilation with the new theme tokens.
- **Unit Testing**: Run `gradle :app:testDebugUnitTest` to guarantee all existing Robolectric test cases pass.
- **Visual Balance**: Verify contrast ratios between text/icons and container surfaces across both dark and light modes.
