# Home Screen Refinement & Adaptive Telemetry Layout Implementation Plan

Streamline the Home screen user experience with continuous 5-second auto-ping toggle on the active profile card, enlarged reactor orb within its outer frame, removal of the redundant bottom connect button, minimal text status indicator, bottom-anchored telemetry card, and **full tablet/foldable responsiveness**.

## User Review & Critical Decisions

> [!IMPORTANT]
> The user confirmed the following decisions and added tablet responsiveness:
> - **Tablet & Large Screen Responsiveness**: Enforce responsive constraints (`widthIn(max = 560.dp)` centered horizontally) so cards and the reactor orb never stretch awkwardly on wide tablet/foldable displays. Use `BoxWithConstraints` to ensure vertical proportions look balanced across both phone and tablet aspect ratios.
> - **Status Line**: Minimal text only without dot indicator (e.g. `"Tap to connect"`, `"Connecting…"`, `"Connected • tap to disconnect"`).
> - **Vertical Layout**: Push stats card to the bottom directly above the navigation bar, creating a balanced and visually anchored composition without awkward empty space.
> - **Ping Button**: Toggleable continuous ping every 5 seconds on the active profile card (Tap 1: starts continuous 5s pinging with live ms; Tap 2: stops and restores the standard "Ping" button).
> - **Reactor Orb**: Slightly enlarged interactive inner orb (from 150.dp to 170.dp) while keeping the outer circular frame at 200.dp.
> - **Bottom Button**: Completely remove the redundant "Connect Tunnel" button to eliminate dual-control confusion.

---

### 1. Overview & Core Concept

- **What It Does**: Transforms the Home screen into a clean, responsive connection console for phones, foldables, and tablets. Eliminates dual-button ambiguity by making the central reactor orb the sole connection control, provides real-time ping diagnostic toggles on the active configuration card, and anchors stats at the bottom within an adaptive container.
- **Target Persona**: Daily VPN users and tablet users who require a visually balanced, proportionate interface regardless of screen size or orientation.
- **Key Value**: Clean visual hierarchy, zero dual-action ambiguity, live 5-second ping tracking, and flawless tablet/phone responsiveness.

---

### 2. User Experience & Adaptive Visual Design

- **Adaptive Tablet & Phone Rules**:
  - **Fluid Max Width**: Content column constrained to `Modifier.widthIn(max = 560.dp)` and centered horizontally, preventing oversized stretched cards on 10-inch or 12-inch tablets.
  - **Orientation & Height Adaptability**: Wrapped in `BoxWithConstraints`. If available vertical height is abundant (portrait phones and tablets), flexible spacers (`weight(1f)`) distribute the top card, central orb, and bottom stats card harmoniously. If height is constrained (landscape tablets or split-screen multi-window), vertical scrolling seamlessly activates without clipping elements.
  - **Reactor Orb Proportions**: Outer circle fixed at `200.dp` with inner core enlarged to `170.dp`, maintaining ideal visual density across all devices.

- **Key User Flows**:
  1. **Continuous Auto-Ping Flow**:
     - User taps `"⚡ Ping"` on the Active Profile card.
     - The button enters continuous 5-second pinging mode with live latency feedback (`● 38ms`) and an animated icon.
     - Tapping again halts the ticker and restores `"⚡ Ping"`.
  2. **Central Reactor Orb & Minimal Status Text**:
     - Outer frame remains 200.dp with ambient glow and border gradients.
     - Inner interactive core expands to 170.dp.
     - Directly beneath the orb, minimal text displays connection intent:
       - Disconnected: `"Tap to connect"`
       - Connecting: `"Connecting…"`
       - Connected: `"Connected • tap to disconnect"`
  3. **Bottom-Anchored Telemetry Card**:
     - The redundant `"Connect Tunnel"` button is removed.
     - The 4-cell telemetry grid card settles cleanly at the bottom right above the system navigation bar.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Tablet Containment (`widthIn(max = 560.dp)`) vs Full Screen Stretch**
  - *Chosen Approach*: Center-constrained container with `max = 560.dp`.
  - *Why*: On large tablet displays (e.g. 800–1200dp width), full-bleed buttons and cards look distorted and create excessive horizontal eye travel. A 560dp centered column provides optimal ergonomics and visual elegance.

- **Decision 2: Adaptive Spacers vs Fixed Heights**
  - *Chosen Approach*: Dynamic vertical spacers (`weight(1f)`) inside a responsive `Column`.
  - *Why*: Ensures the stats card is always pinned just above the navigation bar on tall modern phones and tablets, eliminating awkward empty gaps.

- **Decision 3: Lifecycle-Safe Continuous Ping in ViewModel**
  - *Chosen Approach*: StateFlow-backed coroutine in `MainViewModel`.
  - *Why*: Cleanly cancels on app backgrounding or manual toggle, preventing battery drain and memory leaks.

---

### 4. Technical Architecture & Adaptive Hierarchy

```
┌────────────────────────────────────────────────────────┐
│                      HomeScreen                        │
│                [BoxWithConstraints]                    │
│                          │                             │
│        Column(widthIn(max = 560.dp), centered)         │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Active Profile Card                              │  │
│  │   ├─ Status Dot & Server Title                   │  │
│  │   └─ [⚡ Ping / 5s Auto-Ping Toggle]             │  │
│  └──────────────────────────────────────────────────┘  │
│                           │                            │
│                  Spacer(weight = 1f)                   │
│                           │                            │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Central Reactor Orb                              │  │
│  │   ├─ Outer Decorative Frame (200.dp)             │  │
│  │   └─ Enlarged Inner Core (170.dp, Clickable)     │  │
│  └──────────────────────────────────────────────────┘  │
│                           │                            │
│             Minimal Status: "Tap to connect"           │
│                           │                            │
│                  Spacer(weight = 1f)                   │
│                           │                            │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Telemetry Stats Card (Anchored to Bottom)        │  │
│  │   ├─ Upload (Speed & Total)                      │  │
│  │   ├─ Download (Speed & Total)                    │  │
│  │   ├─ Duration                                    │  │
│  │   └─ Total Data                                  │  │
│  └──────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────┘
```

- **Files to Modify**:
  - `app/src/main/java/com/example/ui/MainViewModel.kt`: Add `isContinuousPingActive: StateFlow<Boolean>`, `toggleContinuousPing()`, and 5-second polling coroutine.
  - `app/src/main/java/com/example/ui/screens/HomeScreen.kt`:
    - Wrap in `BoxWithConstraints` and `widthIn(max = 560.dp)` for tablet responsiveness.
    - Enlarge inner orb to 170.dp inside 200.dp outer frame.
    - Add minimal status text below orb.
    - Remove redundant bottom connect button.
    - Anchor telemetry stats card to bottom with flexible spacers.
    - Update ping button to reflect continuous polling state.
  - `app/src/main/java/com/example/MainActivity.kt`: Pass `isContinuousPingActive` and `onToggleContinuousPing` from `MainViewModel` to `HomeScreen`.
