package com.example.vpn

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.example.data.TunnelRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            val repository = TunnelRepository.getInstance(context)
            CoroutineScope(Dispatchers.IO).launch {
                val settings = repository.getSettingsSync()
                if (settings.startOnBoot) {
                    val active = repository.getActiveProfileSync()
                    if (active != null) {
                        val vpnIntent = Intent(context, PulseVpnService::class.java).apply {
                            action = PulseVpnService.ACTION_START
                            putExtra(PulseVpnService.EXTRA_PROFILE_ID, active.id)
                        }
                        ContextCompat.startForegroundService(context, vpnIntent)
                    }
                }
            }
        }
    }
}
