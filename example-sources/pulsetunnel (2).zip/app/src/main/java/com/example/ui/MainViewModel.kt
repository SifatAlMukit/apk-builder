package com.example.ui

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppSettingEntity
import com.example.data.ProfileEntity
import com.example.data.TunnelRepository
import com.example.model.InstalledAppInfo
import com.example.model.LatencySample
import com.example.model.LatencySummary
import com.example.model.LogLevel
import com.example.model.NetworkInfoState
import com.example.model.SpeedSample
import com.example.model.SpeedTimeWindow
import com.example.model.TunnelState
import com.example.model.TunnelStats
import com.example.util.ConfigCrypto
import com.example.util.ConfigParser
import com.example.util.NetworkInfoManager
import com.example.vpn.PulseVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TunnelRepository.getInstance(application)
    private val networkInfoManager = NetworkInfoManager.getInstance(application)

    val allProfiles: StateFlow<List<ProfileEntity>> = repository.allProfiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeProfile: StateFlow<ProfileEntity?> = repository.activeProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val tunnelState: StateFlow<TunnelState> = repository.tunnelState
    val tunnelStats: StateFlow<TunnelStats> = repository.tunnelStats

    val appSettings: StateFlow<AppSettingEntity> = repository.appSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettingEntity())

    val recentLogs = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestLogMessage: StateFlow<String> = repository.latestLogMessage

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage = _userMessage.asSharedFlow()

    // Status Tab Telemetry
    val networkInfo: StateFlow<NetworkInfoState> = networkInfoManager.networkInfo

    private val _selectedSpeedWindow = MutableStateFlow(SpeedTimeWindow.TEN_MIN)
    val selectedSpeedWindow: StateFlow<SpeedTimeWindow> = _selectedSpeedWindow.asStateFlow()

    private val _speedHistory = MutableStateFlow<List<SpeedSample>>(emptyList())
    val speedHistory: StateFlow<List<SpeedSample>> = _speedHistory.asStateFlow()

    private val _latencyHistory = MutableStateFlow<List<LatencySample>>(emptyList())
    val latencyHistory: StateFlow<List<LatencySample>> = _latencyHistory.asStateFlow()

    private val _latencySummary = MutableStateFlow(LatencySummary())
    val latencySummary: StateFlow<LatencySummary> = _latencySummary.asStateFlow()

    // 5-second Continuous Ping Toggle on Home Screen Active Profile Card
    private val _isContinuousPingActive = MutableStateFlow(false)
    val isContinuousPingActive: StateFlow<Boolean> = _isContinuousPingActive.asStateFlow()
    private var continuousPingJob: Job? = null

    init {
        loadInstalledApps()

        // Sync VPN connection state to event-based NetworkInfoManager
        viewModelScope.launch {
            tunnelState.collect { state ->
                networkInfoManager.onVpnStateChanged(state == TunnelState.CONNECTED)
            }
        }

        // Real Telemetry Loop for Speed and Ping tracking (every 10s)
        viewModelScope.launch(Dispatchers.IO) {
            recordTelemetrySample() // Immediate real sample on launch
            while (isActive) {
                delay(10_000L) // 10-second interval as chosen by user
                recordTelemetrySample()
            }
        }
    }

    private suspend fun recordTelemetrySample() {
        val now = System.currentTimeMillis()
        val stats = tunnelStats.value
        val isConnected = tunnelState.value == TunnelState.CONNECTED

        // Record real speed sample from tunnel stats
        val downloadBps = if (isConnected) stats.downloadSpeedBps else 0L
        val uploadBps = if (isConnected) stats.uploadSpeedBps else 0L

        val newSpeedSample = SpeedSample(
            timestampMs = now,
            downloadBps = downloadBps,
            uploadBps = uploadBps
        )

        val updatedSpeed = (_speedHistory.value + newSpeedSample).takeLast(360)
        _speedHistory.value = updatedSpeed

        // Measure real ping latency:
        // If connected and active profile has a valid host & port, ping that; otherwise ping 1.1.1.1
        val profile = activeProfile.value
        val pingTarget: String
        val pingPort: Int
        if (isConnected && profile != null && profile.serverHost.isNotBlank()) {
            pingTarget = profile.serverHost
            pingPort = if (profile.serverPort in 1..65535) profile.serverPort else 443
        } else {
            pingTarget = "1.1.1.1"
            pingPort = 53
        }

        val latency = networkInfoManager.measureSocketPing(host = pingTarget, port = pingPort, timeoutMs = 2000)
        val latencyValue = if (latency > 0) latency else -1L

        val newLatencySample = LatencySample(timestampMs = now, latencyMs = latencyValue)
        val updatedLatency = (_latencyHistory.value + newLatencySample).takeLast(60)
        _latencyHistory.value = updatedLatency
        _latencySummary.value = calculateLatencySummary(updatedLatency)
    }

    private fun calculateLatencySummary(samples: List<LatencySample>): LatencySummary {
        val valid = samples.filter { it.latencyMs > 0 }.map { it.latencyMs }
        if (valid.isEmpty()) {
            return LatencySummary(
                minMs = 0L,
                avgMs = 0L,
                maxMs = 0L,
                jitterMs = 0L,
                lossPercent = if (samples.isEmpty()) 0 else 100
            )
        }
        val min = valid.minOrNull() ?: 0L
        val max = valid.maxOrNull() ?: 0L
        val avg = valid.average().toLong()

        // Calculate jitter (mean deviation of consecutive packet delay)
        var jitterSum = 0L
        var jitterPairs = 0
        for (i in 1 until valid.size) {
            jitterSum += abs(valid[i] - valid[i - 1])
            jitterPairs++
        }
        val jitter = if (jitterPairs > 0) jitterSum / jitterPairs else 0L
        val lostCount = samples.count { it.latencyMs <= 0 }
        val lossPercent = (lostCount * 100) / samples.size

        return LatencySummary(
            minMs = min,
            avgMs = avg,
            maxMs = max,
            jitterMs = jitter,
            lossPercent = lossPercent
        )
    }

    fun toggleIpMasking() {
        networkInfoManager.toggleMasking()
    }

    fun refreshNetworkInfo() {
        networkInfoManager.refreshPublicIpInfo(force = true)
    }

    fun setSpeedTimeWindow(window: SpeedTimeWindow) {
        _selectedSpeedWindow.value = window
    }

    fun toggleConnection(context: Context) {
        val currentState = tunnelState.value
        if (currentState == TunnelState.CONNECTED || currentState == TunnelState.CONNECTING) {
            val stopIntent = Intent(context, PulseVpnService::class.java).apply {
                action = PulseVpnService.ACTION_STOP
            }
            context.startService(stopIntent)
        } else {
            val profile = activeProfile.value
            if (profile == null) {
                viewModelScope.launch {
                    _userMessage.emit("Please select or create a profile first.")
                }
                return
            }
            val startIntent = Intent(context, PulseVpnService::class.java).apply {
                action = PulseVpnService.ACTION_START
                putExtra(PulseVpnService.EXTRA_PROFILE_ID, profile.id)
            }
            ContextCompat.startForegroundService(context, startIntent)
        }
    }

    fun selectActiveProfile(profileId: Long) {
        viewModelScope.launch {
            repository.setActiveProfile(profileId)
        }
    }

    fun saveProfile(profile: ProfileEntity) {
        viewModelScope.launch {
            if (profile.id == 0L) {
                repository.insertProfile(profile)
                _userMessage.emit("Profile created: ${profile.name}")
            } else {
                repository.updateProfile(profile)
                _userMessage.emit("Profile updated: ${profile.name}")
            }
        }
    }

    fun deleteProfile(profileId: Long) {
        viewModelScope.launch {
            repository.deleteProfile(profileId)
            _userMessage.emit("Profile deleted.")
        }
    }

    fun duplicateProfile(profile: ProfileEntity) {
        viewModelScope.launch {
            repository.duplicateProfile(profile)
            _userMessage.emit("Profile duplicated.")
        }
    }

    fun pingProfile(profileId: Long) {
        viewModelScope.launch {
            val latency = repository.pingServer(profileId)
            if (latency >= 0) {
                _userMessage.emit("Ping response: ${latency}ms")
            } else {
                _userMessage.emit("Server unreachable (timed out)")
            }
        }
    }

    fun toggleContinuousPing() {
        if (_isContinuousPingActive.value) {
            stopContinuousPing()
        } else {
            startContinuousPing()
        }
    }

    private fun startContinuousPing() {
        val profile = activeProfile.value
        if (profile == null) {
            viewModelScope.launch {
                _userMessage.emit("Select a profile first to ping.")
            }
            return
        }

        continuousPingJob?.cancel()
        _isContinuousPingActive.value = true
        continuousPingJob = viewModelScope.launch(Dispatchers.IO) {
            while (isActive) {
                activeProfile.value?.let { currentProfile ->
                    repository.pingServer(currentProfile.id)
                }
                delay(5_000L) // 5 seconds interval as requested by user
            }
        }
    }

    private fun stopContinuousPing() {
        continuousPingJob?.cancel()
        continuousPingJob = null
        _isContinuousPingActive.value = false
    }

    fun importFromLink(link: String): Boolean {
        val profile = ConfigParser.parseLink(link)
        if (profile != null) {
            viewModelScope.launch {
                repository.insertProfile(profile)
                _userMessage.emit("Imported profile: ${profile.name} (${profile.protocolType})")
            }
            return true
        }
        return false
    }

    fun exportEncryptedBackup(password: String): String {
        val list = allProfiles.value
        return ConfigCrypto.exportEncrypted(list, password)
    }

    fun importEncryptedBackup(encrypted: String, password: String): Boolean {
        return try {
            val profiles = ConfigCrypto.importEncrypted(encrypted, password)
            viewModelScope.launch {
                profiles.forEach { repository.insertProfile(it) }
                _userMessage.emit("Successfully imported ${profiles.size} profiles.")
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    fun updateSettings(settings: AppSettingEntity) {
        viewModelScope.launch {
            repository.updateSettings(settings)
            _userMessage.emit("Settings saved.")
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
            _userMessage.emit("Logs cleared.")
        }
    }

    fun loadInstalledApps() {
        viewModelScope.launch(Dispatchers.IO) {
            val pm = getApplication<Application>().packageManager
            val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            val list = packages.mapNotNull { appInfo ->
                try {
                    val appName = pm.getApplicationLabel(appInfo).toString()
                    val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                    InstalledAppInfo(
                        packageName = appInfo.packageName,
                        appName = appName,
                        isSystemApp = isSystem
                    )
                } catch (_: Exception) {
                    null
                }
            }.sortedBy { it.appName.lowercase() }
            _installedApps.value = list
        }
    }
}
