package com.example.util

import android.net.Uri
import android.util.Base64
import com.example.data.ProfileEntity
import com.example.model.ProtocolType
import org.json.JSONObject
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

object ConfigParser {

    fun parseLink(link: String): ProfileEntity? {
        val trimmed = link.trim()
        return when {
            trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
            trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
            trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
            trimmed.startsWith("ssh://", ignoreCase = true) -> parseSsh(trimmed)
            else -> null
        }
    }

    private fun parseVmess(link: String): ProfileEntity? {
        return try {
            val base64Part = link.substringAfter("vmess://")
            val jsonStr = String(Base64.decode(base64Part, Base64.DEFAULT or Base64.URL_SAFE), StandardCharsets.UTF_8)
            val json = JSONObject(jsonStr)

            val name = json.optString("ps", "VMess Server").ifEmpty { "VMess Server" }
            val host = json.optString("add", "")
            val port = json.optInt("port", 443)
            val uuid = json.optString("id", "")
            val path = json.optString("path", "")
            val tls = json.optString("tls", "none")
            val sni = json.optString("sni", json.optString("host", ""))

            ProfileEntity(
                name = name,
                protocolType = ProtocolType.VMESS,
                serverHost = host,
                serverPort = port,
                uuid = uuid,
                wsPath = path,
                transportSecurity = tls,
                sni = sni
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parseVless(link: String): ProfileEntity? {
        return try {
            val uri = Uri.parse(link)
            val uuid = uri.userInfo ?: ""
            val host = uri.host ?: ""
            val port = if (uri.port > 0) uri.port else 443
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "VLESS Server"
            val sni = uri.getQueryParameter("sni") ?: uri.getQueryParameter("host") ?: ""
            val security = uri.getQueryParameter("security") ?: "none"
            val path = uri.getQueryParameter("path")?.let { URLDecoder.decode(it, "UTF-8") } ?: ""

            ProfileEntity(
                name = name,
                protocolType = ProtocolType.VLESS,
                serverHost = host,
                serverPort = port,
                uuid = uuid,
                sni = sni,
                transportSecurity = security,
                wsPath = path
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parseTrojan(link: String): ProfileEntity? {
        return try {
            val uri = Uri.parse(link)
            val password = uri.userInfo ?: ""
            val host = uri.host ?: ""
            val port = if (uri.port > 0) uri.port else 443
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "Trojan Server"
            val sni = uri.getQueryParameter("sni") ?: uri.getQueryParameter("peer") ?: host
            val security = uri.getQueryParameter("security") ?: "tls"

            ProfileEntity(
                name = name,
                protocolType = ProtocolType.TROJAN,
                serverHost = host,
                serverPort = port,
                authPassword = password,
                uuid = password,
                sni = sni,
                transportSecurity = security
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun parseSsh(link: String): ProfileEntity? {
        return try {
            val uri = Uri.parse(link)
            val userInfo = uri.userInfo ?: ""
            val parts = userInfo.split(":", limit = 2)
            val username = parts.getOrNull(0) ?: "root"
            val password = parts.getOrNull(1) ?: ""
            val host = uri.host ?: ""
            val port = if (uri.port > 0) uri.port else 22
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "SSH Server"

            ProfileEntity(
                name = name,
                protocolType = ProtocolType.SSH,
                serverHost = host,
                serverPort = port,
                authUsername = username,
                authPassword = password
            )
        } catch (_: Exception) {
            null
        }
    }

    fun toShareableLink(profile: ProfileEntity): String {
        return when (profile.protocolType) {
            ProtocolType.VMESS -> {
                val json = JSONObject().apply {
                    put("v", "2")
                    put("ps", profile.name)
                    put("add", profile.serverHost)
                    put("port", profile.serverPort)
                    put("id", profile.uuid)
                    put("aid", 0)
                    put("net", if (profile.wsPath.isNotBlank()) "ws" else "tcp")
                    put("path", profile.wsPath)
                    put("tls", profile.transportSecurity)
                    put("sni", profile.sni)
                }
                val encoded = Base64.encodeToString(json.toString().toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
                "vmess://$encoded"
            }
            ProtocolType.VLESS -> {
                val encodedName = URLEncoder.encode(profile.name, "UTF-8")
                val encodedPath = URLEncoder.encode(profile.wsPath, "UTF-8")
                "vless://${profile.uuid}@${profile.serverHost}:${profile.serverPort}?security=${profile.transportSecurity}&sni=${profile.sni}&path=$encodedPath#$encodedName"
            }
            ProtocolType.TROJAN -> {
                val pass = profile.authPassword.ifEmpty { profile.uuid }
                val encodedName = URLEncoder.encode(profile.name, "UTF-8")
                "trojan://$pass@${profile.serverHost}:${profile.serverPort}?security=${profile.transportSecurity}&sni=${profile.sni}#$encodedName"
            }
            ProtocolType.SSH -> {
                val encodedName = URLEncoder.encode(profile.name, "UTF-8")
                if (profile.authPassword.isNotBlank()) {
                    "ssh://${profile.authUsername}:${profile.authPassword}@${profile.serverHost}:${profile.serverPort}#$encodedName"
                } else {
                    "ssh://${profile.authUsername}@${profile.serverHost}:${profile.serverPort}#$encodedName"
                }
            }
            ProtocolType.DNSTT -> {
                "dnstt://${profile.dnsttDomain}?resolver=${profile.dnsttResolver}&pubkey=${profile.dnsttPublicKey}#${URLEncoder.encode(profile.name, "UTF-8")}"
            }
        }
    }
}
