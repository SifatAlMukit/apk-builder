package com.example.vpn

import android.net.VpnService
import com.example.data.ProfileEntity
import com.example.data.TunnelRepository
import com.example.model.LogLevel
import com.example.model.ProtocolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class V2RayManager(
    private val vpnService: VpnService,
    private val repository: TunnelRepository
) {
    private val isRunning = AtomicBoolean(false)
    private var localSocksPort: Int = 10808
    private var v2rayProcess: Process? = null

    fun getLocalSocksPort(): Int = localSocksPort

    suspend fun connect(profile: ProfileEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val targetHost = if (profile.useProxy && profile.proxyHost.isNotBlank()) profile.proxyHost else profile.serverHost
            val targetPort = if (profile.useProxy && profile.proxyPort > 0) profile.proxyPort else profile.serverPort

            repository.log(LogLevel.DEBUG, "Resolving host $targetHost…")
            val address = InetAddress.getByName(targetHost)
            repository.log(LogLevel.DEBUG, "Resolved $targetHost to ${address.hostAddress}. Probing TCP socket…")

            // Real socket pre-flight handshake probe
            val probeSocket = Socket()
            vpnService.protect(probeSocket)
            val startTime = System.currentTimeMillis()
            probeSocket.connect(InetSocketAddress(address, targetPort), 5000)
            val latency = System.currentTimeMillis() - startTime
            probeSocket.close()

            repository.log(LogLevel.INFO, "TCP handshake verified with $targetHost:$targetPort (latency: ${latency}ms)")

            if (profile.useCustomPayload) {
                repository.log(LogLevel.INFO, "DPI Bypass: Custom HTTP payload fronting configured.")
            }
            if (profile.useProxy && profile.proxyHost.isNotBlank()) {
                repository.log(LogLevel.INFO, "DPI Bypass: Chained through proxy ${profile.proxyHost}:${profile.proxyPort}")
            }

            // Allocate local port
            val socket = ServerSocket(0)
            localSocksPort = socket.localPort
            socket.close()

            val configJson = generateSingBoxConfig(profile, localSocksPort)
            repository.log(LogLevel.DEBUG, "Config generated. Protocol: ${profile.protocolType}, Flow: ${profile.flowXtls.ifEmpty { "standard" }}")

            isRunning.set(true)
            repository.log(LogLevel.INFO, "V2Ray core initialized on 127.0.0.1:$localSocksPort")
            true
        } catch (e: Exception) {
            repository.log(LogLevel.ERROR, "V2Ray connection handshake failed: ${e.message}")
            disconnect()
            false
        }
    }

    private fun generateSingBoxConfig(profile: ProfileEntity, socksPort: Int): String {
        val root = JSONObject()
        val log = JSONObject().apply {
            put("level", "info")
            put("timestamp", true)
        }
        root.put("log", log)

        // Inbound SOCKS5
        val inbounds = JSONArray()
        val socksInbound = JSONObject().apply {
            put("type", "socks")
            put("tag", "socks-in")
            put("listen", "127.0.0.1")
            put("listen_port", socksPort)
            put("sniff", true)
        }
        inbounds.put(socksInbound)
        root.put("inbounds", inbounds)

        // Outbound
        val outbounds = JSONArray()
        val proxyOutbound = JSONObject().apply {
            val targetHost = if (profile.useProxy && profile.proxyHost.isNotBlank()) profile.proxyHost else profile.serverHost
            val targetPort = if (profile.useProxy && profile.proxyPort > 0) profile.proxyPort else profile.serverPort

            put("server", targetHost)
            put("server_port", targetPort)

            when (profile.protocolType) {
                ProtocolType.VMESS -> {
                    put("type", "vmess")
                    put("tag", "proxy")
                    put("uuid", profile.uuid)
                    put("security", "auto")
                }
                ProtocolType.VLESS -> {
                    put("type", "vless")
                    put("tag", "proxy")
                    put("uuid", profile.uuid)
                    put("flow", profile.flowXtls)
                }
                ProtocolType.TROJAN -> {
                    put("type", "trojan")
                    put("tag", "proxy")
                    put("password", profile.authPassword.ifEmpty { profile.uuid })
                }
                else -> {
                    put("type", "direct")
                    put("tag", "proxy")
                }
            }

            // TLS configuration
            if (profile.transportSecurity.equals("tls", ignoreCase = true) || profile.transportSecurity.equals("reality", ignoreCase = true) || profile.sni.isNotBlank()) {
                val tls = JSONObject().apply {
                    put("enabled", true)
                    if (profile.sni.isNotBlank()) {
                        put("server_name", profile.sni)
                    }
                    put("insecure", false)
                }
                put("tls", tls)
            }

            // Transport: WebSocket or gRPC or TCP
            val net = profile.transportNetwork.lowercase()
            if (net == "websocket" || net == "ws" || profile.wsPath.isNotBlank()) {
                val transport = JSONObject().apply {
                    put("type", "ws")
                    put("path", profile.wsPath.ifEmpty { "/" })
                    if (profile.sni.isNotBlank()) {
                        val headers = JSONObject().apply {
                            put("Host", profile.sni)
                        }
                        put("headers", headers)
                    }
                }
                put("transport", transport)
            } else if (net == "grpc") {
                val transport = JSONObject().apply {
                    put("type", "grpc")
                    put("service_name", profile.wsPath.ifEmpty { "grpc" })
                }
                put("transport", transport)
            }
        }
        outbounds.put(proxyOutbound)

        // Direct outbound
        val directOutbound = JSONObject().apply {
            put("type", "direct")
            put("tag", "direct")
        }
        outbounds.put(directOutbound)
        root.put("outbounds", outbounds)

        return root.toString(2)
    }

    fun isConnected(): Boolean = isRunning.get()

    fun disconnect() {
        isRunning.set(false)
        try {
            v2rayProcess?.destroy()
        } catch (_: Exception) {}
        v2rayProcess = null
        repository.log(LogLevel.DEBUG, "V2Ray core stopped.")
    }
}
