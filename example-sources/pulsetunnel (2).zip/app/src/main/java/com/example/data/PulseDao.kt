package com.example.data

import androidx.room.*
import com.example.model.LogLevel
import com.example.model.ProtocolType
import com.example.model.SplitTunnelMode
import kotlinx.coroutines.flow.Flow

class DatabaseConverters {
    @TypeConverter
    fun fromProtocolType(value: ProtocolType): String = value.name

    @TypeConverter
    fun toProtocolType(value: String): ProtocolType = try {
        ProtocolType.valueOf(value)
    } catch (_: Exception) {
        ProtocolType.SSH
    }

    @TypeConverter
    fun fromLogLevel(value: LogLevel): String = value.name

    @TypeConverter
    fun toLogLevel(value: String): LogLevel = try {
        LogLevel.valueOf(value)
    } catch (_: Exception) {
        LogLevel.INFO
    }

    @TypeConverter
    fun fromSplitTunnelMode(value: SplitTunnelMode): String = value.name

    @TypeConverter
    fun toSplitTunnelMode(value: String): SplitTunnelMode = try {
        SplitTunnelMode.valueOf(value)
    } catch (_: Exception) {
        SplitTunnelMode.ALL_APPS
    }
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM profiles ORDER BY createdAt DESC")
    fun getAllProfiles(): Flow<List<ProfileEntity>>

    @Query("SELECT COUNT(*) FROM profiles")
    suspend fun getProfileCount(): Int

    @Query("SELECT * FROM profiles ORDER BY createdAt DESC")
    suspend fun getAllProfilesSync(): List<ProfileEntity>

    @Query("SELECT * FROM profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: Long): ProfileEntity?

    @Query("SELECT * FROM profiles WHERE isActive = 1 LIMIT 1")
    fun getActiveProfile(): Flow<ProfileEntity?>

    @Query("SELECT * FROM profiles WHERE isActive = 1 LIMIT 1")
    suspend fun getActiveProfileSync(): ProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: ProfileEntity): Long

    @Update
    suspend fun updateProfile(profile: ProfileEntity)

    @Query("UPDATE profiles SET isActive = CASE WHEN id = :profileId THEN 1 ELSE 0 END")
    suspend fun setActiveProfile(profileId: Long)

    @Query("UPDATE profiles SET isActive = 0")
    suspend fun clearActiveProfile()

    @Query("UPDATE profiles SET lastPingMs = :pingMs WHERE id = :profileId")
    suspend fun updateLastPing(profileId: Long, pingMs: Long)

    @Delete
    suspend fun deleteProfile(profile: ProfileEntity)

    @Query("DELETE FROM profiles WHERE id = :id")
    suspend fun deleteProfileById(id: Long)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    fun getSettings(): Flow<AppSettingEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1 LIMIT 1")
    suspend fun getSettingsSync(): AppSettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AppSettingEntity)
}

@Dao
interface LogDao {
    @Query("SELECT * FROM tunnel_logs ORDER BY timestamp ASC LIMIT 1000")
    fun getRecentLogs(): Flow<List<LogEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LogEntryEntity)

    @Query("DELETE FROM tunnel_logs")
    suspend fun clearAllLogs()
}
