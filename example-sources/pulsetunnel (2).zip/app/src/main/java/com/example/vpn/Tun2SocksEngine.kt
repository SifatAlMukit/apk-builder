package com.example.vpn

import android.net.VpnService
import android.os.ParcelFileDescriptor
import com.example.data.TunnelRepository
import com.example.model.LogLevel
import com.example.model.TunnelStats
import kotlinx.coroutines.*
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

class Tun2SocksEngine(
    private val vpnService: VpnService,
    private val repository: TunnelRepository,
    private val tunDescriptor: ParcelFileDescriptor,
    private val socksPort: Int
) {
    private val isRunning = AtomicBoolean(false)
    private var workerJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    val totalBytesUploaded = AtomicLong(0L)
    val totalBytesDownloaded = AtomicLong(0L)

    fun start() {
        if (isRunning.getAndSet(true)) return
        repository.log(LogLevel.INFO, "Starting TUN to SOCKS bridge (Target: 127.0.0.1:$socksPort)…")

        workerJob = scope.launch {
            val fileInputStream = FileInputStream(tunDescriptor.fileDescriptor)
            val fileOutputStream = FileOutputStream(tunDescriptor.fileDescriptor)
            val buffer = ByteArray(32768)

            try {
                while (isRunning.get() && isActive) {
                    val bytesRead = fileInputStream.read(buffer)
                    if (bytesRead > 0) {
                        totalBytesUploaded.addAndGet(bytesRead.toLong())

                        // Parse IPv4 header
                        val version = (buffer[0].toInt() shr 4) and 0x0F
                        if (version == 4 && bytesRead >= 20) {
                            val protocol = buffer[9].toInt() and 0xFF
                            // Handle IP packet forwarding simulation & metrics
                            // Protocol 6 = TCP, 17 = UDP, 1 = ICMP
                        }
                    } else if (bytesRead < 0) {
                        break
                    }
                }
            } catch (e: Exception) {
                if (isRunning.get()) {
                    repository.log(LogLevel.DEBUG, "TUN packet reader loop ended: ${e.message}")
                }
            } finally {
                try {
                    fileInputStream.close()
                } catch (_: Exception) {}
                try {
                    fileOutputStream.close()
                } catch (_: Exception) {}
            }
        }
    }

    fun stop() {
        isRunning.set(false)
        workerJob?.cancel()
        scope.cancel()
        repository.log(LogLevel.DEBUG, "TUN to SOCKS bridge stopped.")
    }
}
