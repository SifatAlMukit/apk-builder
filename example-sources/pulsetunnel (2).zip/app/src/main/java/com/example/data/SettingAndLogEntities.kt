package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.LogLevel
import com.example.model.SplitTunnelMode

@Entity(tableName = "app_settings")
data class AppSettingEntity(
    @PrimaryKey
    val id: Int = 1,
    // Connection section
    val wakeLock: Boolean = false,
    val autoReconnect: Boolean = true,
    val killSwitchEnabled: Boolean = false,
    val bypassLan: Boolean = true,

    // Appearance section
    val isDarkTheme: Boolean = true,
    val wallpaperMode: Boolean = false,

    // Engine section
    val mtu: Int = 1500,
    val primaryDns: String = "1.1.1.1",
    val secondaryDns: String = "1.0.0.1",
    val pingTarget: String = "Default",
    val keepalive: String = "Balanced",
    val splitTunnelMode: SplitTunnelMode = SplitTunnelMode.ALL_APPS,
    val selectedAppsJson: String = "[]",
    val directBlockRules: String = "None",
    val tlsMux: String = "Tuned",

    val startOnBoot: Boolean = false,
    val activeProfileId: Long? = null
)

@Entity(tableName = "tunnel_logs")
data class LogEntryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val level: LogLevel = LogLevel.INFO,
    val message: String
)
