package com.example.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppSettingEntity
import com.example.model.InstalledAppInfo
import com.example.model.SplitTunnelMode
import com.example.ui.theme.*
import org.json.JSONArray

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    settings: AppSettingEntity,
    installedApps: List<InstalledAppInfo>,
    onSaveSettings: (AppSettingEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    // Dialog states for Engine detail cards
    var showMtuDialog by remember { mutableStateOf(false) }
    var showDnsDialog by remember { mutableStateOf(false) }
    var showPingTargetDialog by remember { mutableStateOf(false) }
    var showKeepaliveDialog by remember { mutableStateOf(false) }
    var showAppPickerDialog by remember { mutableStateOf(false) }
    var showDirectBlockDialog by remember { mutableStateOf(false) }
    var showTlsMuxDialog by remember { mutableStateOf(false) }
    var showWallpaperDialog by remember { mutableStateOf(false) }

    val selectedPackages = remember(settings.selectedAppsJson) {
        try {
            val arr = JSONArray(settings.selectedAppsJson)
            (0 until arr.length()).map { arr.getString(it) }.toSet()
        } catch (_: Exception) {
            emptySet()
        }
    }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // Section Header: CONNECTION
        item(span = { GridItemSpan(2) }) {
            SectionHeader(icon = Icons.Default.Link, title = "CONNECTION")
        }

        // Wake Lock
        item {
            ToggleCard(
                icon = Icons.Default.Bolt,
                title = "Wake Lock",
                subtitle = "Keep the CPU awake while connected",
                checked = settings.wakeLock,
                onCheckedChange = { onSaveSettings(settings.copy(wakeLock = it)) }
            )
        }

        // Auto Reconnect
        item {
            ToggleCard(
                icon = Icons.Default.Sync,
                title = "Auto Reconnect",
                subtitle = "Reconnect automatically if the tunnel drops",
                checked = settings.autoReconnect,
                onCheckedChange = { onSaveSettings(settings.copy(autoReconnect = it)) }
            )
        }

        // Kill Switch
        item {
            ToggleCard(
                icon = Icons.Default.Block,
                title = "Kill Switch",
                subtitle = "Block all traffic if the VPN drops",
                checked = settings.killSwitchEnabled,
                onCheckedChange = {
                    onSaveSettings(settings.copy(killSwitchEnabled = it))
                    if (it) {
                        try {
                            context.startActivity(Intent(Settings.ACTION_VPN_SETTINGS))
                        } catch (_: Exception) {}
                    }
                }
            )
        }

        // Bypass LAN
        item {
            ToggleCard(
                icon = Icons.Default.Hub,
                title = "Bypass LAN",
                subtitle = "Keep local network traffic outside the tunnel",
                checked = settings.bypassLan,
                onCheckedChange = { onSaveSettings(settings.copy(bypassLan = it)) }
            )
        }

        // Section Header: APPEARANCE
        item(span = { GridItemSpan(2) }) {
            SectionHeader(icon = Icons.Default.Palette, title = "APPEARANCE")
        }

        // Theme Toggle Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 100.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outlineVariant))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.DarkMode, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }

                        // Day/Night Pill
                        Row(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.surface)
                                .clickable {
                                    onSaveSettings(settings.copy(isDarkTheme = !settings.isDarkTheme))
                                }
                                .padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(if (settings.isDarkTheme) MaterialTheme.colorScheme.primary else Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.DarkMode, contentDescription = null, tint = if (settings.isDarkTheme) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(12.dp))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(if (!settings.isDarkTheme) MaterialTheme.colorScheme.primary else Color.Transparent),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LightMode, contentDescription = null, tint = if (!settings.isDarkTheme) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(12.dp))
                            }
                        }
                    }

                    Column {
                        Text("Theme", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Text("Switch between dark and light", style = MaterialTheme.typography.bodySmall, color = SlateTextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        // Wallpaper Mode Card
        item {
            DetailCard(
                icon = Icons.Default.Wallpaper,
                title = "Wallpaper Mode",
                subtitle = "Device wallpaper behind glass UI",
                value = if (settings.wallpaperMode) "On" else "Off",
                onClick = { showWallpaperDialog = true }
            )
        }

        // Section Header: ENGINE
        item(span = { GridItemSpan(2) }) {
            SectionHeader(icon = Icons.Default.Memory, title = "ENGINE")
        }

        // MTU Card
        item {
            DetailCard(
                icon = Icons.Default.CompareArrows,
                title = "MTU",
                subtitle = "Lower if pages stall on mobile data",
                value = "${settings.mtu}",
                onClick = { showMtuDialog = true }
            )
        }

        // DNS Servers Card
        item {
            DetailCard(
                icon = Icons.Default.Dns,
                title = "DNS Servers",
                subtitle = "Resolvers used inside tunnel",
                value = settings.primaryDns,
                onClick = { showDnsDialog = true }
            )
        }

        // Ping Target Card
        item {
            DetailCard(
                icon = Icons.Default.Speed,
                title = "Ping Target",
                subtitle = "What the latency probe requests",
                value = settings.pingTarget,
                onClick = { showPingTargetDialog = true }
            )
        }

        // Keepalive Card
        item {
            DetailCard(
                icon = Icons.Default.Shield,
                title = "Keepalive",
                subtitle = "Balance battery & idle drops",
                value = settings.keepalive,
                onClick = { showKeepaliveDialog = true }
            )
        }

        // Split Tunnel Card
        item {
            DetailCard(
                icon = Icons.Default.CallSplit,
                title = "Split Tunnel",
                subtitle = "Choose which apps use tunnel",
                value = when (settings.splitTunnelMode) {
                    SplitTunnelMode.ALL_APPS -> "Off"
                    SplitTunnelMode.INCLUDE_ONLY -> "${selectedPackages.size} apps"
                    SplitTunnelMode.EXCLUDE_SELECTED -> "Bypass (${selectedPackages.size})"
                },
                onClick = { showAppPickerDialog = true }
            )
        }

        // Direct / Block Card
        item {
            DetailCard(
                icon = Icons.Default.AltRoute,
                title = "Direct / Block",
                subtitle = "Send domains around or drop",
                value = settings.directBlockRules,
                onClick = { showDirectBlockDialog = true }
            )
        }

        // TLS & Mux Card
        item(span = { GridItemSpan(2) }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showTlsMuxDialog = true },
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outlineVariant))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("TLS & Mux", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("Fragment ClientHello, reuse connections", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(settings.tlsMux, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }

    // MTU Dialog
    if (showMtuDialog) {
        var mtuInput by remember { mutableStateOf(settings.mtu.toString()) }
        AlertDialog(
            onDismissRequest = { showMtuDialog = false },
            title = { Text("Set TUN MTU") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Standard MTU is 1500. Lower to 1400 or 1280 if pages stall on cellular.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf(1280, 1400, 1500).forEach { preset ->
                            FilterChip(
                                selected = mtuInput == preset.toString(),
                                onClick = { mtuInput = preset.toString() },
                                label = { Text("$preset") }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = mtuInput,
                        onValueChange = { mtuInput = it },
                        label = { Text("MTU (1280 - 1500)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val v = mtuInput.toIntOrNull() ?: 1500
                    onSaveSettings(settings.copy(mtu = v.coerceIn(1280, 1500)))
                    showMtuDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showMtuDialog = false }) { Text("Cancel") } }
        )
    }

    // DNS Dialog
    if (showDnsDialog) {
        var dnsInput by remember { mutableStateOf(settings.primaryDns) }
        AlertDialog(
            onDismissRequest = { showDnsDialog = false },
            title = { Text("DNS Resolvers") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("1.1.1.1", "8.8.8.8", "9.9.9.9").forEach { preset ->
                            FilterChip(
                                selected = dnsInput == preset,
                                onClick = { dnsInput = preset },
                                label = { Text(preset) }
                            )
                        }
                    }
                    OutlinedTextField(
                        value = dnsInput,
                        onValueChange = { dnsInput = it },
                        label = { Text("Primary DNS") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onSaveSettings(settings.copy(primaryDns = dnsInput.trim().ifEmpty { "1.1.1.1" }))
                    showDnsDialog = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showDnsDialog = false }) { Text("Cancel") } }
        )
    }

    // Ping Target Dialog
    if (showPingTargetDialog) {
        val targets = listOf("Default", "1.1.1.1", "8.8.8.8", "connectivitycheck.gstatic.com")
        AlertDialog(
            onDismissRequest = { showPingTargetDialog = false },
            title = { Text("Select Ping Target") },
            text = {
                Column {
                    targets.forEach { target ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSaveSettings(settings.copy(pingTarget = target))
                                    showPingTargetDialog = false
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            RadioButton(selected = settings.pingTarget == target, onClick = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(target)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showPingTargetDialog = false }) { Text("Close") } }
        )
    }

    // Keepalive Dialog
    if (showKeepaliveDialog) {
        val options = listOf("Off", "Low (60s)", "Balanced (30s)", "Aggressive (15s)")
        AlertDialog(
            onDismissRequest = { showKeepaliveDialog = false },
            title = { Text("Keepalive Profile") },
            text = {
                Column {
                    options.forEach { opt ->
                        val label = opt.substringBefore(" ")
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSaveSettings(settings.copy(keepalive = label))
                                    showKeepaliveDialog = false
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            RadioButton(selected = settings.keepalive == label, onClick = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(opt)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showKeepaliveDialog = false }) { Text("Close") } }
        )
    }

    // Direct / Block Dialog
    if (showDirectBlockDialog) {
        val rules = listOf("None", "Bypass Domestic (CN/Local)", "Block Ads & Trackers", "Custom Routing")
        AlertDialog(
            onDismissRequest = { showDirectBlockDialog = false },
            title = { Text("Direct / Block Routing") },
            text = {
                Column {
                    rules.forEach { rule ->
                        val key = rule.substringBefore(" ")
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSaveSettings(settings.copy(directBlockRules = key))
                                    showDirectBlockDialog = false
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            RadioButton(selected = settings.directBlockRules == key, onClick = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(rule)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showDirectBlockDialog = false }) { Text("Close") } }
        )
    }

    // TLS & Mux Dialog
    if (showTlsMuxDialog) {
        val muxModes = listOf("Tuned (Recommended)", "Enabled", "Disabled")
        AlertDialog(
            onDismissRequest = { showTlsMuxDialog = false },
            title = { Text("TLS & Mux Multiplexing") },
            text = {
                Column {
                    Text("ClientHello packet fragmentation circumvents SNI inspection. Multiplexing reduces connection handshakes.", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(10.dp))
                    muxModes.forEach { mode ->
                        val key = mode.substringBefore(" ")
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSaveSettings(settings.copy(tlsMux = key))
                                    showTlsMuxDialog = false
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            RadioButton(selected = settings.tlsMux == key, onClick = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(mode)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { showTlsMuxDialog = false }) { Text("Close") } }
        )
    }

    // Wallpaper Mode Dialog
    if (showWallpaperDialog) {
        AlertDialog(
            onDismissRequest = { showWallpaperDialog = false },
            title = { Text("Wallpaper Glass UI") },
            text = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Enable Glassmorphic Backdrop")
                    Switch(
                        checked = settings.wallpaperMode,
                        onCheckedChange = {
                            onSaveSettings(settings.copy(wallpaperMode = it))
                        }
                    )
                }
            },
            confirmButton = {
                Button(onClick = { showWallpaperDialog = false }) { Text("Done") }
            }
        )
    }

    // Split Tunnel App Picker Dialog
    if (showAppPickerDialog) {
        var currentMode by remember { mutableStateOf(settings.splitTunnelMode) }
        val currentSelected = remember { mutableStateListOf<String>().apply { addAll(selectedPackages) } }
        var searchQuery by remember { mutableStateOf("") }

        val filtered = remember(installedApps, searchQuery) {
            if (searchQuery.isBlank()) installedApps
            else installedApps.filter {
                it.appName.contains(searchQuery, ignoreCase = true) || it.packageName.contains(searchQuery, ignoreCase = true)
            }
        }

        AlertDialog(
            onDismissRequest = { showAppPickerDialog = false },
            title = { Text("Split Tunneling (Per-App Proxy)") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Mode selector
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = currentMode == SplitTunnelMode.ALL_APPS,
                            onClick = { currentMode = SplitTunnelMode.ALL_APPS },
                            label = { Text("All") }
                        )
                        FilterChip(
                            selected = currentMode == SplitTunnelMode.INCLUDE_ONLY,
                            onClick = { currentMode = SplitTunnelMode.INCLUDE_ONLY },
                            label = { Text("Only Selected") }
                        )
                        FilterChip(
                            selected = currentMode == SplitTunnelMode.EXCLUDE_SELECTED,
                            onClick = { currentMode = SplitTunnelMode.EXCLUDE_SELECTED },
                            label = { Text("Bypass Selected") }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (currentMode != SplitTunnelMode.ALL_APPS) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search apps…") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            TextButton(onClick = { currentSelected.clear() }) { Text("Clear All") }
                            Text("${currentSelected.size} selected", style = MaterialTheme.typography.labelSmall, modifier = Modifier.align(Alignment.CenterVertically))
                        }

                        androidx.compose.foundation.lazy.LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            items(filtered.size) { idx ->
                                val app = filtered[idx]
                                val isChecked = currentSelected.contains(app.packageName)
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            if (isChecked) currentSelected.remove(app.packageName)
                                            else currentSelected.add(app.packageName)
                                        }
                                        .padding(horizontal = 6.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            if (checked) currentSelected.add(app.packageName)
                                            else currentSelected.remove(app.packageName)
                                        }
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(app.appName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text(app.packageName, style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val json = JSONArray(currentSelected.toSet()).toString()
                    onSaveSettings(settings.copy(splitTunnelMode = currentMode, selectedAppsJson = json))
                    showAppPickerDialog = false
                }) { Text("Confirm") }
            },
            dismissButton = { TextButton(onClick = { showAppPickerDialog = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SectionHeader(icon: ImageVector, title: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.2.sp
        )
    }
}

@Composable
private fun ToggleCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 100.dp)
            .clickable { onCheckedChange(!checked) },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (checked) MaterialTheme.colorScheme.surfaceVariant
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ),
        border = if (checked) {
            CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary), width = 1.5.dp)
        } else {
            CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outlineVariant))
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.20f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Switch(
                    checked = checked,
                    onCheckedChange = onCheckedChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                        checkedTrackColor = MaterialTheme.colorScheme.primary
                    ),
                    modifier = Modifier.scale(0.85f)
                )
            }

            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

@Composable
private fun DetailCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    value: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 100.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outlineVariant))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = value,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                }
            }

            Column {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, lineHeight = 14.sp)
            }
        }
    }
}
