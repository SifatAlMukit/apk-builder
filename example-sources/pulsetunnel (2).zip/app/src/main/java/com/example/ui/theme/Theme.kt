package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val LightColorScheme = ColorScheme(
    background = Color(0xfff6f6f6),
    error = Color(0xff832d2c),
    errorContainer = Color(0xfff0b9b5),
    inverseOnSurface = Color(0xfff0f1f1),
    inversePrimary = Color(0xff7cd4dd),
    inverseSurface = Color(0xff2e3131),
    onBackground = Color(0xff1a1c1c),
    onError = Color(0xffffc3bf),
    onErrorContainer = Color(0xff71000d),
    onPrimary = Color(0xffd3fbff),
    onPrimaryContainer = Color(0xff004f55),
    onSecondary = Color(0xffe1f8fa),
    onSecondaryContainer = Color(0xff364a4c),
    onSurface = Color(0xff1a1c1c),
    onSurfaceVariant = Color(0xff454747),
    onTertiary = Color(0xfff1f3ff),
    onTertiaryContainer = Color(0xff3b475e),
    outline = Color(0xff757777),
    outlineVariant = Color(0xffbbc8c9),
    primary = Color(0xff006970),
    primaryContainer = Color(0xff99f1f9),
    scrim = Color(0xff000000),
    secondary = Color(0xff4d6264),
    secondaryContainer = Color(0xffd0e7e9),
    surface = Color(0xfff6f6f6),
    surfaceTint = Color(0xff006970),
    surfaceVariant = Color(0xffd1d5d6),
    tertiary = Color(0xff535e77),
    tertiaryContainer = Color(0xffd7e2ff),
    surfaceBright = Color(0xfffcfcfc),
    surfaceDim = Color(0xffc8cdce),
    surfaceContainer = Color(0xffe3e6e6),
    surfaceContainerHigh = Color(0xffdaddde),
    surfaceContainerHighest = Color(0xffd1d5d6),
    surfaceContainerLow = Color(0xffedeeee),
    surfaceContainerLowest = Color(0xffffffff),
)

val DarkColorScheme = ColorScheme(
    background = Color(0xff111414),
    error = Color(0xffec9a96),
    errorContainer = Color(0xff7f2828),
    inverseOnSurface = Color(0xff2e3131),
    inversePrimary = Color(0xff006970),
    inverseSurface = Color(0xffe2e3e2),
    onBackground = Color(0xffe2e3e2),
    onError = Color(0xff71000d),
    onErrorContainer = Color(0xffffc3bf),
    onPrimary = Color(0xff003b40),
    onPrimaryContainer = Color(0xff99f1f9),
    onSecondary = Color(0xff23383a),
    onSecondaryContainer = Color(0xffd0e7e9),
    onSurface = Color(0xffe2e3e2),
    onSurfaceVariant = Color(0xffc5c7c6),
    onTertiary = Color(0xff2a354c),
    onTertiaryContainer = Color(0xffd7e2ff),
    outline = Color(0xff8f9190),
    outlineVariant = Color(0xff404e4f),
    primary = Color(0xff7cd4dd),
    primaryContainer = Color(0xff004f55),
    scrim = Color(0xff000000),
    secondary = Color(0xffb4cbcd),
    secondaryContainer = Color(0xff364a4c),
    surface = Color(0xff111414),
    surfaceTint = Color(0xff7cd4dd),
    surfaceVariant = Color(0xff454747),
    tertiary = Color(0xffbbc6e3),
    tertiaryContainer = Color(0xff3b475e),
    surfaceBright = Color(0xff373a3a),
    surfaceDim = Color(0xff111414),
    surfaceContainer = Color(0xff1e2020),
    surfaceContainerHigh = Color(0xff282a2b),
    surfaceContainerHighest = Color(0xff333535),
    surfaceContainerLow = Color(0xff1a1c1c),
    surfaceContainerLowest = Color(0xff0c0f0f),
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
