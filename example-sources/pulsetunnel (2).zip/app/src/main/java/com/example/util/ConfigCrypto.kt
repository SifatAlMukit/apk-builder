package com.example.util

import android.util.Base64
import com.example.data.ProfileEntity
import com.example.model.ProtocolType
import org.json.JSONArray
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

object ConfigCrypto {
    private const val ITERATIONS = 10000
    private const val KEY_LENGTH = 256
    private const val GCM_TAG_LENGTH = 128
    private const val SALT_LENGTH = 16
    private const val IV_LENGTH = 12

    fun exportEncrypted(profiles: List<ProfileEntity>, password: String): String {
        val jsonArray = JSONArray()
        profiles.forEach { p ->
            val obj = JSONObject().apply {
                put("name", p.name)
                put("protocolType", p.protocolType.name)
                put("serverHost", p.serverHost)
                put("serverPort", p.serverPort)
                put("authUsername", p.authUsername)
                put("authPassword", p.authPassword)
                put("privateKey", p.privateKey)
                put("publicKey", p.publicKey)
                put("uuid", p.uuid)
                put("sni", p.sni)
                put("wsPath", p.wsPath)
                put("transportSecurity", p.transportSecurity)
                put("transportNetwork", p.transportNetwork)
                put("flowXtls", p.flowXtls)
                put("useSslTls", p.useSslTls)
                put("useCustomPayload", p.useCustomPayload)
                put("customPayload", p.customPayload)
                put("useProxy", p.useProxy)
                put("proxyHost", p.proxyHost)
                put("proxyPort", p.proxyPort)
                put("sshCompression", p.sshCompression)
                put("tunnelOverDns", p.tunnelOverDns)
                put("dnsttDomain", p.dnsttDomain)
                put("dnsttResolver", p.dnsttResolver)
                put("dnsttPublicKey", p.dnsttPublicKey)
                put("udpgwPort", p.udpgwPort)
                put("customDns", p.customDns)
            }
            jsonArray.put(obj)
        }

        val plainBytes = jsonArray.toString().toByteArray(StandardCharsets.UTF_8)
        val salt = ByteArray(SALT_LENGTH).also { SecureRandom().nextBytes(it) }
        val iv = ByteArray(IV_LENGTH).also { SecureRandom().nextBytes(it) }

        val keySpec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val secretKey = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(keySpec)
        val key = SecretKeySpec(secretKey.encoded, "AES")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH, iv))
        val cipherBytes = cipher.doFinal(plainBytes)

        val byteBuffer = ByteBuffer.allocate(SALT_LENGTH + IV_LENGTH + cipherBytes.size)
        byteBuffer.put(salt)
        byteBuffer.put(iv)
        byteBuffer.put(cipherBytes)

        return Base64.encodeToString(byteBuffer.array(), Base64.NO_WRAP)
    }

    fun importEncrypted(encryptedData: String, password: String): List<ProfileEntity> {
        val allBytes = Base64.decode(encryptedData.trim(), Base64.DEFAULT)
        val byteBuffer = ByteBuffer.wrap(allBytes)

        val salt = ByteArray(SALT_LENGTH)
        byteBuffer.get(salt)

        val iv = ByteArray(IV_LENGTH)
        byteBuffer.get(iv)

        val cipherBytes = ByteArray(byteBuffer.remaining())
        byteBuffer.get(cipherBytes)

        val keySpec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val secretKey = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(keySpec)
        val key = SecretKeySpec(secretKey.encoded, "AES")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_LENGTH, iv))
        val plainBytes = cipher.doFinal(cipherBytes)

        val jsonStr = String(plainBytes, StandardCharsets.UTF_8)
        val jsonArray = JSONArray(jsonStr)
        val result = mutableListOf<ProfileEntity>()

        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)
            val p = ProfileEntity(
                name = obj.optString("name", "Imported Profile"),
                protocolType = try {
                    ProtocolType.valueOf(obj.optString("protocolType", "SSH"))
                } catch (_: Exception) {
                    ProtocolType.SSH
                },
                serverHost = obj.optString("serverHost", ""),
                serverPort = obj.optInt("serverPort", 22),
                authUsername = obj.optString("authUsername", ""),
                authPassword = obj.optString("authPassword", ""),
                privateKey = obj.optString("privateKey", ""),
                publicKey = obj.optString("publicKey", ""),
                uuid = obj.optString("uuid", ""),
                sni = obj.optString("sni", ""),
                wsPath = obj.optString("wsPath", ""),
                transportSecurity = obj.optString("transportSecurity", "none"),
                transportNetwork = obj.optString("transportNetwork", "TCP"),
                flowXtls = obj.optString("flowXtls", ""),
                useSslTls = obj.optBoolean("useSslTls", false),
                useCustomPayload = obj.optBoolean("useCustomPayload", false),
                customPayload = obj.optString("customPayload", "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]"),
                useProxy = obj.optBoolean("useProxy", false),
                proxyHost = obj.optString("proxyHost", ""),
                proxyPort = obj.optInt("proxyPort", 8080),
                sshCompression = obj.optBoolean("sshCompression", false),
                tunnelOverDns = obj.optBoolean("tunnelOverDns", false),
                dnsttDomain = obj.optString("dnsttDomain", ""),
                dnsttResolver = obj.optString("dnsttResolver", "1.1.1.1"),
                dnsttPublicKey = obj.optString("dnsttPublicKey", ""),
                udpgwPort = obj.optInt("udpgwPort", 7300),
                customDns = obj.optString("customDns", "")
            )
            result.add(p)
        }
        return result
    }
}
