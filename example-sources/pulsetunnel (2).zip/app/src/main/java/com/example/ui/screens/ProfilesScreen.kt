package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProfileEntity
import com.example.model.ProtocolType
import com.example.ui.theme.*
import com.example.util.ConfigParser

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfilesScreen(
    profiles: List<ProfileEntity>,
    activeProfileId: Long?,
    onSelectActiveProfile: (Long) -> Unit,
    onSaveProfile: (ProfileEntity) -> Unit,
    onDeleteProfile: (Long) -> Unit,
    onDuplicateProfile: (ProfileEntity) -> Unit,
    onPingProfile: (Long) -> Unit,
    onImportLink: (String) -> Boolean,
    onExportBackup: (String) -> String,
    onImportBackup: (String, String) -> Boolean,
    onAddProfile: () -> Unit = {},
    onEditProfile: (ProfileEntity) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    var selectedProtocolFilter by remember { mutableStateOf<ProtocolType?>(null) }
    var showPasteLinkDialog by remember { mutableStateOf(false) }
    var showBackupDialog by remember { mutableStateOf(false) }

    val filteredProfiles = remember(profiles, selectedProtocolFilter) {
        if (selectedProtocolFilter == null) profiles
        else profiles.filter { it.protocolType == selectedProtocolFilter }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End) {
                SmallFloatingActionButton(
                    onClick = { showPasteLinkDialog = true },
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("paste_link_fab")
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = "Paste Link")
                }
                Spacer(modifier = Modifier.height(10.dp))
                SmallFloatingActionButton(
                    onClick = { showBackupDialog = true },
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("backup_fab")
                ) {
                    Icon(Icons.Default.Security, contentDescription = "Backup/Restore")
                }
                Spacer(modifier = Modifier.height(10.dp))
                FloatingActionButton(
                    onClick = onAddProfile,
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.testTag("add_profile_fab")
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add Profile")
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            // Protocol Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(
                        selected = selectedProtocolFilter == null,
                        onClick = { selectedProtocolFilter = null },
                        label = { Text("All (${profiles.size})") },
                        modifier = Modifier.testTag("filter_all")
                    )
                }
                items(ProtocolType.values()) { protocol ->
                    val count = profiles.count { it.protocolType == protocol }
                    FilterChip(
                        selected = selectedProtocolFilter == protocol,
                        onClick = { selectedProtocolFilter = protocol },
                        label = { Text("${protocol.displayName} ($count)") },
                        modifier = Modifier.testTag("filter_${protocol.name.lowercase()}")
                    )
                }
            }

            if (filteredProfiles.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.VpnLock,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (profiles.isEmpty()) "No VPN Profiles" else "No matching profiles",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Tap + to create a profile or paste a vmess/vless/ssh link",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(filteredProfiles, key = { it.id }) { profile ->
                        ProfileCard(
                            profile = profile,
                            isActive = profile.id == activeProfileId,
                            onSelect = { onSelectActiveProfile(profile.id) },
                            onEdit = { onEditProfile(profile) },
                            onDuplicate = { onDuplicateProfile(profile) },
                            onDelete = { onDeleteProfile(profile.id) },
                            onPing = { onPingProfile(profile.id) },
                            onShare = {
                                val link = ConfigParser.toShareableLink(profile)
                                clipboardManager.setText(AnnotatedString(link))
                                Toast.makeText(context, "Link copied to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }

    // Paste Link Import Dialog
    if (showPasteLinkDialog) {
        PasteLinkDialog(
            onDismiss = { showPasteLinkDialog = false },
            onImport = { linkText ->
                val success = onImportLink(linkText)
                if (success) {
                    Toast.makeText(context, "Profile imported successfully", Toast.LENGTH_SHORT).show()
                    showPasteLinkDialog = false
                } else {
                    Toast.makeText(context, "Unrecognized configuration link format", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Encrypted Backup Dialog
    if (showBackupDialog) {
        BackupRestoreDialog(
            onDismiss = { showBackupDialog = false },
            onExport = { pass -> onExportBackup(pass) },
            onImport = { data, pass -> onImportBackup(data, pass) }
        )
    }
}

@Composable
private fun ProfileCard(
    profile: ProfileEntity,
    isActive: Boolean,
    onSelect: () -> Unit,
    onEdit: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onPing: () -> Unit,
    onShare: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("profile_card_${profile.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        border = if (isActive) CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary)) else null
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                RadioButton(
                    selected = isActive,
                    onClick = onSelect,
                    colors = RadioButtonDefaults.colors(selectedColor = MaterialTheme.colorScheme.primary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = profile.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(profile.protocolType.badgeColorHex).copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = profile.protocolType.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(profile.protocolType.badgeColorHex)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${profile.serverHost}:${profile.serverPort}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Ping latency pill
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.clickable { onPing() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Ping",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = if (profile.lastPingMs >= 0) "${profile.lastPingMs}ms" else "--",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Box {
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Options")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Edit") },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onEdit()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Duplicate") },
                            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onDuplicate()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Share Link") },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) },
                            onClick = {
                                showMenu = false
                                onShare()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Delete", color = RoseError) },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = RoseError) },
                            onClick = {
                                showMenu = false
                                onDelete()
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ProfileEditDialog(
    profile: ProfileEntity?,
    onDismiss: () -> Unit,
    onSave: (ProfileEntity) -> Unit
) {
    var protocol by remember { mutableStateOf(profile?.protocolType ?: ProtocolType.SSH) }
    var name by remember { mutableStateOf(profile?.name ?: "My Server") }
    var host by remember { mutableStateOf(profile?.serverHost ?: "") }
    var port by remember { mutableStateOf(profile?.serverPort?.toString() ?: if (protocol == ProtocolType.SSH) "22" else "443") }
    var username by remember { mutableStateOf(profile?.authUsername ?: "root") }
    var password by remember { mutableStateOf(profile?.authPassword ?: "") }
    var privateKey by remember { mutableStateOf(profile?.privateKey ?: "") }
    var uuid by remember { mutableStateOf(profile?.uuid ?: "") }
    var sni by remember { mutableStateOf(profile?.sni ?: "") }
    var wsPath by remember { mutableStateOf(profile?.wsPath ?: "") }
    var tlsEnabled by remember { mutableStateOf(profile?.transportSecurity == "tls") }
    var dnsttDomain by remember { mutableStateOf(profile?.dnsttDomain ?: "") }
    var dnsttResolver by remember { mutableStateOf(profile?.dnsttResolver ?: "1.1.1.1") }
    var dnsttPubKey by remember { mutableStateOf(profile?.dnsttPublicKey ?: "") }
    var udpgwPort by remember { mutableStateOf(profile?.udpgwPort?.toString() ?: "7300") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (profile == null) "New Tunnel Profile" else "Edit Profile")
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Protocol selector
                Text("Protocol", style = MaterialTheme.typography.labelMedium)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(ProtocolType.values()) { p ->
                        FilterChip(
                            selected = protocol == p,
                            onClick = {
                                protocol = p
                                if (profile == null) {
                                    port = when (p) {
                                        ProtocolType.SSH -> "22"
                                        ProtocolType.DNSTT -> "53"
                                        else -> "443"
                                    }
                                }
                            },
                            label = { Text(p.displayName) }
                        )
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Profile Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        label = { Text("Server Host / IP") },
                        singleLine = true,
                        modifier = Modifier.weight(2f)
                    )
                    OutlinedTextField(
                        value = port,
                        onValueChange = { port = it },
                        label = { Text("Port") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                when (protocol) {
                    ProtocolType.SSH -> {
                        OutlinedTextField(
                            value = username,
                            onValueChange = { username = it },
                            label = { Text("Username") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Password (optional if using key)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = privateKey,
                            onValueChange = { privateKey = it },
                            label = { Text("Private Key (OpenSSH RSA/ED25519)") },
                            maxLines = 4,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = udpgwPort,
                            onValueChange = { udpgwPort = it },
                            label = { Text("UDPGW Port") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    ProtocolType.VMESS, ProtocolType.VLESS -> {
                        OutlinedTextField(
                            value = uuid,
                            onValueChange = { uuid = it },
                            label = { Text("UUID / User ID") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = sni,
                            onValueChange = { sni = it },
                            label = { Text("SNI (Server Name Indication)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = wsPath,
                            onValueChange = { wsPath = it },
                            label = { Text("WebSocket Path (e.g. /ws)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Checkbox(checked = tlsEnabled, onCheckedChange = { tlsEnabled = it })
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Enable TLS")
                        }
                    }
                    ProtocolType.TROJAN -> {
                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it },
                            label = { Text("Trojan Password") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = sni,
                            onValueChange = { sni = it },
                            label = { Text("SNI / Peer Hostname") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    ProtocolType.DNSTT -> {
                        OutlinedTextField(
                            value = dnsttDomain,
                            onValueChange = { dnsttDomain = it },
                            label = { Text("DNSTT Tunnel Domain (e.g. t.domain.com)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = dnsttResolver,
                            onValueChange = { dnsttResolver = it },
                            label = { Text("Resolver (e.g. 1.1.1.1 or DoH URL)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = dnsttPubKey,
                            onValueChange = { dnsttPubKey = it },
                            label = { Text("Server Public Key (Hex)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val entity = ProfileEntity(
                        id = profile?.id ?: 0L,
                        name = name.ifEmpty { "Server ${protocol.displayName}" },
                        protocolType = protocol,
                        serverHost = host.trim(),
                        serverPort = port.toIntOrNull() ?: 22,
                        authUsername = username.trim(),
                        authPassword = password,
                        privateKey = privateKey.trim(),
                        uuid = uuid.trim(),
                        sni = sni.trim(),
                        wsPath = wsPath.trim(),
                        transportSecurity = if (tlsEnabled) "tls" else "none",
                        dnsttDomain = dnsttDomain.trim(),
                        dnsttResolver = dnsttResolver.trim(),
                        dnsttPublicKey = dnsttPubKey.trim(),
                        udpgwPort = udpgwPort.toIntOrNull() ?: 7300,
                        isActive = profile?.isActive ?: false
                    )
                    onSave(entity)
                },
                enabled = host.isNotBlank() || (protocol == ProtocolType.DNSTT && dnsttDomain.isNotBlank())
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
private fun PasteLinkDialog(
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var linkText by remember { mutableStateOf("") }
    val clipboardManager = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Import from Link") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Paste a vmess://, vless://, trojan://, or ssh:// configuration link:",
                    style = MaterialTheme.typography.bodyMedium
                )
                OutlinedTextField(
                    value = linkText,
                    onValueChange = { linkText = it },
                    label = { Text("Configuration Link") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        val clip = clipboardManager.getText()?.text
                        if (!clip.isNullOrBlank()) linkText = clip
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Paste from Clipboard")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onImport(linkText) },
                enabled = linkText.isNotBlank()
            ) {
                Text("Import")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun BackupRestoreDialog(
    onDismiss: () -> Unit,
    onExport: (String) -> String,
    onImport: (String, String) -> Boolean
) {
    var tabIndex by remember { mutableStateOf(0) }
    var password by remember { mutableStateOf("") }
    var exportResult by remember { mutableStateOf("") }
    var importData by remember { mutableStateOf("") }
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Encrypted Backup & Restore") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                TabRow(selectedTabIndex = tabIndex) {
                    Tab(selected = tabIndex == 0, onClick = { tabIndex = 0 }, text = { Text("Export") })
                    Tab(selected = tabIndex == 1, onClick = { tabIndex = 1 }, text = { Text("Import") })
                }

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Encryption Password") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (tabIndex == 0) {
                    Text(
                        "Encrypts your profiles with AES-256-GCM using your password.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (exportResult.isNotBlank()) {
                        OutlinedTextField(
                            value = exportResult,
                            onValueChange = {},
                            readOnly = true,
                            maxLines = 4,
                            label = { Text("Encrypted Config String") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Button(
                            onClick = {
                                clipboard.setText(AnnotatedString(exportResult))
                                Toast.makeText(context, "Copied backup to clipboard", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Copy Backup")
                        }
                    } else {
                        Button(
                            onClick = { exportResult = onExport(password) },
                            enabled = password.isNotBlank(),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Generate Encrypted Backup")
                        }
                    }
                } else {
                    OutlinedTextField(
                        value = importData,
                        onValueChange = { importData = it },
                        label = { Text("Paste Encrypted Backup String") },
                        maxLines = 4,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        onClick = {
                            val clip = clipboard.getText()?.text
                            if (!clip.isNullOrBlank()) importData = clip
                        },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Paste")
                    }
                }
            }
        },
        confirmButton = {
            if (tabIndex == 1) {
                Button(
                    onClick = {
                        val success = onImport(importData, password)
                        if (success) {
                            Toast.makeText(context, "Profiles imported successfully!", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        } else {
                            Toast.makeText(context, "Failed to decrypt! Check password.", Toast.LENGTH_LONG).show()
                        }
                    },
                    enabled = importData.isNotBlank() && password.isNotBlank()
                ) {
                    Text("Decrypt & Import")
                }
            } else {
                TextButton(onClick = onDismiss) { Text("Done") }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}
