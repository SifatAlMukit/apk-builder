package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.SlateTextSecondary
import com.example.util.NetworkInfoManager
import java.util.Locale

@Composable
fun StatusScreen(
    tunnelState: TunnelState,
    tunnelStats: TunnelStats,
    networkInfo: NetworkInfoState,
    speedHistory: List<SpeedSample>,
    latencyHistory: List<LatencySample>,
    latencySummary: LatencySummary,
    selectedTimeWindow: SpeedTimeWindow,
    onTimeWindowSelected: (SpeedTimeWindow) -> Unit,
    onToggleMasking: () -> Unit,
    onRefreshNetworkInfo: () -> Unit,
    activeProfileName: String?,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header Row with Status Pill
        HeaderStatusRow(
            tunnelState = tunnelState,
            durationSec = tunnelStats.connectedDurationSec
        )

        // 1. Network Card (Event-driven IP, Masking, ISP)
        NetworkInfoCard(
            networkInfo = networkInfo,
            onToggleMasking = onToggleMasking,
            onRefreshNetworkInfo = onRefreshNetworkInfo
        )

        // 2. Speed Card (Live Dual-line Canvas, 1m/10m/1h filters)
        SpeedChartCard(
            tunnelState = tunnelState,
            speedHistory = speedHistory,
            selectedTimeWindow = selectedTimeWindow,
            onTimeWindowSelected = onTimeWindowSelected
        )

        // 3. Latency Card (Live Ping, Dashed Threshold, Min/Avg/Max)
        LatencyChartCard(
            tunnelState = tunnelState,
            latencyHistory = latencyHistory,
            latencySummary = latencySummary,
            activeProfileName = activeProfileName
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun HeaderStatusRow(
    tunnelState: TunnelState,
    durationSec: Long
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "Status",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        // Connected Pill
        val isConnected = tunnelState == TunnelState.CONNECTED
        val pillBg = if (isConnected) Color(0xFF10382E) else MaterialTheme.colorScheme.surfaceVariant
        val dotColor = if (isConnected) Color(0xFF10B981) else Color.Gray
        val textColor = if (isConnected) Color(0xFF34D399) else MaterialTheme.colorScheme.onSurfaceVariant

        val hours = durationSec / 3600
        val minutes = (durationSec % 3600) / 60
        val seconds = durationSec % 60
        val timeStr = String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)

        Surface(
            shape = RoundedCornerShape(50),
            color = pillBg,
            modifier = Modifier.testTag("status_top_pill")
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(dotColor)
                )
                Text(
                    text = if (isConnected) "Connected $timeStr" else "Disconnected",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = textColor
                )
            }
        }
    }
}

@Composable
private fun NetworkInfoCard(
    networkInfo: NetworkInfoState,
    onToggleMasking: () -> Unit,
    onRefreshNetworkInfo: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("status_network_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Card Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Network",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                IconButton(
                    onClick = onToggleMasking,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("btn_toggle_mask")
                ) {
                    Icon(
                        imageVector = if (networkInfo.isMasked) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                        contentDescription = "Toggle IP Masking",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Real IP and VPN IP
            val displayRealIp = if (networkInfo.isMasked) NetworkInfoManager.maskIpAddress(networkInfo.realIp) else networkInfo.realIp
            val displayVpnIp = if (networkInfo.isMasked) NetworkInfoManager.maskIpAddress(networkInfo.vpnIp) else networkInfo.vpnIp

            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("REAL IP", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = displayRealIp,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("VPN IP", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = displayVpnIp,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary // Cyan highlight
                    )
                }
            }

            // Local IP and Location
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("LOCAL IP", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = networkInfo.localIp,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("LOCATION", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = networkInfo.location,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }

            // ISP and Refresh Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("ISP", style = MaterialTheme.typography.labelSmall, color = SlateTextSecondary, fontWeight = FontWeight.SemiBold, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = networkInfo.isp,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Refresh Button Pill
                val infiniteTransition = rememberInfiniteTransition(label = "refresh_rotation")
                val rotationAngle by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "rotation"
                )

                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.6f),
                    modifier = Modifier
                        .clickable(enabled = !networkInfo.isRefreshing) { onRefreshNetworkInfo() }
                        .testTag("btn_refresh_ip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh IP Info",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .size(16.dp)
                                .rotate(if (networkInfo.isRefreshing) rotationAngle else 0f)
                        )
                        Text(
                            text = if (networkInfo.isRefreshing) "Refreshing..." else formatRelativeTime(networkInfo.lastFetchedEpochMs),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SpeedChartCard(
    tunnelState: TunnelState,
    speedHistory: List<SpeedSample>,
    selectedTimeWindow: SpeedTimeWindow,
    onTimeWindowSelected: (SpeedTimeWindow) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("status_speed_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row: Title + Time Window Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Speed",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "every 10 s",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateTextSecondary,
                        fontSize = 11.sp
                    )
                }

                // Filter Buttons (1m, 10m, 1h)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = 0.4f))
                        .padding(3.dp)
                ) {
                    SpeedTimeWindow.values().forEach { window ->
                        val isSelected = selectedTimeWindow == window
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.25f) else Color.Transparent)
                                .border(
                                    width = if (isSelected) 1.dp else 0.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    shape = RoundedCornerShape(50)
                                )
                                .clickable { onTimeWindowSelected(window) }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = window.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Current Transfer Rates
            val latest = speedHistory.lastOrNull()
            val downloadSpeedBps = if (tunnelState == TunnelState.CONNECTED) latest?.downloadBps ?: 0L else 0L
            val uploadSpeedBps = if (tunnelState == TunnelState.CONNECTED) latest?.uploadBps ?: 0L else 0L

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Download
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.ArrowDownward,
                        contentDescription = "Download",
                        tint = Color(0xFF06B6D4), // Cyan
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = formatSpeedRate(downloadSpeedBps),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF06B6D4)
                    )
                }

                // Upload
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(
                        imageVector = Icons.Default.ArrowUpward,
                        contentDescription = "Upload",
                        tint = Color(0xFFF59E0B), // Amber/Orange
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = formatSpeedRate(uploadSpeedBps),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF59E0B)
                    )
                }
            }

            // Canvas Line Chart
            SpeedDualLineChart(
                speedHistory = speedHistory,
                timeWindow = selectedTimeWindow,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            )

            // Chart X-Axis Labels
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = when (selectedTimeWindow) {
                        SpeedTimeWindow.ONE_MIN -> "1 min ago"
                        SpeedTimeWindow.TEN_MIN -> "10 min ago"
                        SpeedTimeWindow.ONE_HOUR -> "1 hour ago"
                    },
                    fontSize = 11.sp,
                    color = SlateTextSecondary
                )
                Text(
                    text = "now",
                    fontSize = 11.sp,
                    color = SlateTextSecondary
                )
            }
        }
    }
}

@Composable
private fun SpeedDualLineChart(
    speedHistory: List<SpeedSample>,
    timeWindow: SpeedTimeWindow,
    modifier: Modifier = Modifier
) {
    val samples = remember(speedHistory, timeWindow) {
        val now = System.currentTimeMillis()
        val windowDuration = timeWindow.durationMs
        speedHistory.filter { now - it.timestampMs <= windowDuration }
    }

    val cyanColor = Color(0xFF06B6D4)
    val orangeColor = Color(0xFFF59E0B)

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        // Determine max speed for Y-axis scaling
        val maxSpeed = (samples.maxOfOrNull { maxOf(it.downloadBps, it.uploadBps) } ?: 4_000_000L)
            .coerceAtLeast(2_000_000L)

        // Draw horizontal dashed grid lines
        val line1Y = height * 0.25f
        val line2Y = height * 0.65f
        val gridColor = Color.White.copy(alpha = 0.08f)

        drawLine(
            color = gridColor,
            start = Offset(0f, line1Y),
            end = Offset(width, line1Y),
            strokeWidth = 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
        )
        drawLine(
            color = gridColor,
            start = Offset(0f, line2Y),
            end = Offset(width, line2Y),
            strokeWidth = 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f))
        )

        val baselineY = height - 2.dp.toPx()

        if (samples.isEmpty()) {
            // Draw clean baseline at 0 B/s
            drawLine(
                color = cyanColor.copy(alpha = 0.35f),
                start = Offset(0f, baselineY),
                end = Offset(width, baselineY),
                strokeWidth = 2.dp.toPx()
            )
            drawCircle(
                color = cyanColor,
                radius = 4.dp.toPx(),
                center = Offset(width, baselineY)
            )
            return@Canvas
        }

        if (samples.size == 1) {
            val s = samples[0]
            val downY = height - (s.downloadBps.toFloat() / maxSpeed.toFloat() * (height * 0.85f))
            val upY = height - (s.uploadBps.toFloat() / maxSpeed.toFloat() * (height * 0.85f))

            drawLine(
                color = cyanColor,
                start = Offset(0f, downY),
                end = Offset(width, downY),
                strokeWidth = 2.5.dp.toPx()
            )
            drawLine(
                color = orangeColor,
                start = Offset(0f, upY),
                end = Offset(width, upY),
                strokeWidth = 2.5.dp.toPx()
            )
            drawCircle(color = cyanColor, radius = 4.5.dp.toPx(), center = Offset(width, downY))
            drawCircle(color = orangeColor, radius = 4.5.dp.toPx(), center = Offset(width, upY))
            return@Canvas
        }

        // Plot paths for 2 or more real samples
        val stepX = width / (samples.size - 1).coerceAtLeast(1)

        val downPath = Path()
        val upPath = Path()
        val downFillPath = Path()
        val upFillPath = Path()

        samples.forEachIndexed { i, s ->
            val x = i * stepX
            val downY = height - (s.downloadBps.toFloat() / maxSpeed.toFloat() * (height * 0.85f))
            val upY = height - (s.uploadBps.toFloat() / maxSpeed.toFloat() * (height * 0.85f))

            if (i == 0) {
                downPath.moveTo(x, downY)
                upPath.moveTo(x, upY)
                downFillPath.moveTo(x, height)
                downFillPath.lineTo(x, downY)
                upFillPath.moveTo(x, height)
                upFillPath.lineTo(x, upY)
            } else {
                downPath.lineTo(x, downY)
                upPath.lineTo(x, upY)
                downFillPath.lineTo(x, downY)
                upFillPath.lineTo(x, upY)
            }
        }

        val lastIndex = samples.size - 1
        val lastX = lastIndex * stepX
        downFillPath.lineTo(lastX, height)
        downFillPath.close()
        upFillPath.lineTo(lastX, height)
        upFillPath.close()

        // Draw gradients
        drawPath(
            path = downFillPath,
            brush = Brush.verticalGradient(
                colors = listOf(cyanColor.copy(alpha = 0.25f), Color.Transparent),
                startY = 0f,
                endY = height
            )
        )
        drawPath(
            path = upFillPath,
            brush = Brush.verticalGradient(
                colors = listOf(orangeColor.copy(alpha = 0.15f), Color.Transparent),
                startY = 0f,
                endY = height
            )
        )

        // Draw strokes
        drawPath(
            path = downPath,
            color = cyanColor,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
        drawPath(
            path = upPath,
            color = orangeColor,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Draw current value end dots
        val lastSample = samples.last()
        val lastDownY = height - (lastSample.downloadBps.toFloat() / maxSpeed.toFloat() * (height * 0.85f))
        val lastUpY = height - (lastSample.uploadBps.toFloat() / maxSpeed.toFloat() * (height * 0.85f))

        drawCircle(
            color = cyanColor,
            radius = 4.5.dp.toPx(),
            center = Offset(lastX, lastDownY)
        )
        drawCircle(
            color = orangeColor,
            radius = 4.5.dp.toPx(),
            center = Offset(lastX, lastUpY)
        )
    }
}

@Composable
private fun LatencyChartCard(
    tunnelState: TunnelState,
    latencyHistory: List<LatencySample>,
    latencySummary: LatencySummary,
    activeProfileName: String?
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("status_latency_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header: Title + Target + Current ms
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Latency",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Ping target: ${activeProfileName?.ifEmpty { "Default" } ?: "Default"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = SlateTextSecondary,
                        fontSize = 11.sp
                    )
                }

                val currentMs = latencyHistory.lastOrNull()?.latencyMs ?: 42L
                val (dotColor, textColor) = when {
                    currentMs <= 0 -> Pair(Color.Gray, Color.Gray)
                    currentMs < 80 -> Pair(Color(0xFF10B981), Color(0xFF34D399))
                    currentMs < 180 -> Pair(Color(0xFFF59E0B), Color(0xFFFBBF24))
                    else -> Pair(Color(0xFFEF4444), Color(0xFFF87171))
                }

                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(dotColor)
                    )
                    Text(
                        text = if (currentMs > 0) "$currentMs ms" else "Offline",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = textColor
                    )
                }
            }

            // Latency Canvas Line Chart
            LatencyLineChart(
                latencyHistory = latencyHistory,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            )

            // Metrics Summary Row (MIN, AVG, MAX, JITTER, LOSS)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                LatencyStatItem(title = "MIN", value = "${latencySummary.minMs} ms")
                LatencyStatItem(title = "AVG", value = "${latencySummary.avgMs} ms")
                LatencyStatItem(title = "MAX", value = "${latencySummary.maxMs} ms")
                LatencyStatItem(title = "JITTER", value = "${latencySummary.jitterMs} ms")
                LatencyStatItem(
                    title = "LOSS",
                    value = "${latencySummary.lossPercent}%",
                    valueColor = if (latencySummary.lossPercent > 5) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun LatencyLineChart(
    latencyHistory: List<LatencySample>,
    modifier: Modifier = Modifier
) {
    val samples = remember(latencyHistory) { latencyHistory.takeLast(25) }
    val greenColor = Color(0xFF10B981)
    val amberPeakColor = Color(0xFFF59E0B)

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height

        val maxLatency = (samples.filter { it.latencyMs > 0 }.maxOfOrNull { it.latencyMs } ?: 120L).coerceAtLeast(120L)

        // Threshold dashed line at 100 ms
        val thresholdY = height - (100f / maxLatency.toFloat() * (height * 0.80f))
        drawLine(
            color = amberPeakColor.copy(alpha = 0.4f),
            start = Offset(0f, thresholdY),
            end = Offset(width, thresholdY),
            strokeWidth = 1.dp.toPx(),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f))
        )

        val baselineY = height - 2.dp.toPx()

        if (samples.isEmpty()) {
            drawLine(
                color = Color.Gray.copy(alpha = 0.3f),
                start = Offset(0f, baselineY),
                end = Offset(width, baselineY),
                strokeWidth = 2.dp.toPx()
            )
            return@Canvas
        }

        if (samples.size == 1) {
            val s = samples[0]
            val latency = if (s.latencyMs > 0) s.latencyMs else maxLatency
            val y = height - (latency.toFloat() / maxLatency.toFloat() * (height * 0.80f))
            val color = if (s.latencyMs > 0) greenColor else Color.Gray

            drawLine(
                color = color,
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 2.5.dp.toPx()
            )
            drawCircle(color = color, radius = 4.dp.toPx(), center = Offset(width, y))
            return@Canvas
        }

        val stepX = width / (samples.size - 1).coerceAtLeast(1)
        val path = Path()
        val fillPath = Path()

        var peakIndex = 0
        var peakValue = 0L

        samples.forEachIndexed { i, s ->
            val latency = if (s.latencyMs > 0) s.latencyMs else maxLatency
            if (latency > peakValue) {
                peakValue = latency
                peakIndex = i
            }

            val x = i * stepX
            val y = height - (latency.toFloat() / maxLatency.toFloat() * (height * 0.80f))

            if (i == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, height)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }

        val lastIndex = samples.size - 1
        val lastX = lastIndex * stepX
        fillPath.lineTo(lastX, height)
        fillPath.close()

        // Gradient under latency curve
        drawPath(
            path = fillPath,
            brush = Brush.verticalGradient(
                colors = listOf(greenColor.copy(alpha = 0.20f), Color.Transparent),
                startY = 0f,
                endY = height
            )
        )

        // Line curve stroke
        drawPath(
            path = path,
            color = greenColor,
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )

        // Highlight Peak Dot
        if (peakValue > 60L && peakIndex < samples.size) {
            val peakX = peakIndex * stepX
            val peakY = height - (peakValue.toFloat() / maxLatency.toFloat() * (height * 0.80f))
            drawCircle(
                color = amberPeakColor,
                radius = 5.dp.toPx(),
                center = Offset(peakX, peakY)
            )
        }

        // End Dot for current latency
        val lastSample = samples.last()
        val lastY = height - (lastSample.latencyMs.toFloat() / maxLatency.toFloat() * (height * 0.80f))
        drawCircle(
            color = if (lastSample.latencyMs > 0) greenColor else Color.Gray,
            radius = 4.dp.toPx(),
            center = Offset(lastX, lastY)
        )
    }
}

@Composable
private fun LatencyStatItem(
    title: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = SlateTextSecondary,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = valueColor,
            fontSize = 13.sp
        )
    }
}

private fun formatSpeedRate(bps: Long): String {
    val kbps = bps / 1024.0
    val mbps = kbps / 1024.0
    return when {
        mbps >= 1.0 -> String.format(Locale.US, "%.2f MB/s", mbps)
        kbps >= 1.0 -> String.format(Locale.US, "%.0f KB/s", kbps)
        else -> "$bps B/s"
    }
}

private fun formatRelativeTime(epochMs: Long): String {
    if (epochMs == 0L) return "3m ago"
    val diffSec = (System.currentTimeMillis() - epochMs) / 1000
    return when {
        diffSec < 60 -> "Just now"
        diffSec < 3600 -> "${diffSec / 60}m ago"
        else -> "${diffSec / 3600}h ago"
    }
}
