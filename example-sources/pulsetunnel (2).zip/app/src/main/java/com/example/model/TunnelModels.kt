package com.example.model

enum class ProtocolType(val displayName: String, val badgeColorHex: Long) {
    SSH("SSH", 0xFF0EA5E9),
    VMESS("VMess", 0xFF8B5CF6),
    VLESS("VLESS", 0xFF06B6D4),
    TROJAN("Trojan", 0xFFEC4899),
    DNSTT("DNSTT", 0xFF10B981)
}

enum class TunnelState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    STOPPING,
    ERROR
}

data class TunnelStats(
    val uploadBytes: Long = 0L,
    val downloadBytes: Long = 0L,
    val uploadSpeedBps: Long = 0L,
    val downloadSpeedBps: Long = 0L,
    val connectedDurationSec: Long = 0L,
    val pingLatencyMs: Long = -1L
)

enum class LogLevel {
    INFO,
    DEBUG,
    WARN,
    ERROR
}

enum class SplitTunnelMode {
    ALL_APPS,
    INCLUDE_ONLY,
    EXCLUDE_SELECTED
}

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isSystemApp: Boolean
)
