package com.example.data

import android.content.Context
import com.example.model.LogLevel
import com.example.model.TunnelState
import com.example.model.TunnelStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class TunnelRepository(private val database: PulseDatabase) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val allProfiles: Flow<List<ProfileEntity>> = database.profileDao().getAllProfiles()
    val activeProfile: Flow<ProfileEntity?> = database.profileDao().getActiveProfile()
    val recentLogs: Flow<List<LogEntryEntity>> = database.logDao().getRecentLogs()

    val appSettings: Flow<AppSettingEntity> = database.settingsDao().getSettings()
        .map { it ?: AppSettingEntity() }

    private val _tunnelState = MutableStateFlow(TunnelState.DISCONNECTED)
    val tunnelState: StateFlow<TunnelState> = _tunnelState.asStateFlow()

    private val _tunnelStats = MutableStateFlow(TunnelStats())
    val tunnelStats: StateFlow<TunnelStats> = _tunnelStats.asStateFlow()

    private val _latestLogMessage = MutableStateFlow("Ready to connect")
    val latestLogMessage: StateFlow<String> = _latestLogMessage.asStateFlow()

    fun updateTunnelState(state: TunnelState) {
        _tunnelState.value = state
    }

    fun updateTunnelStats(stats: TunnelStats) {
        _tunnelStats.value = stats
    }

    suspend fun getActiveProfileSync(): ProfileEntity? {
        return database.profileDao().getActiveProfileSync()
    }

    suspend fun getProfileByIdSync(id: Long): ProfileEntity? {
        return database.profileDao().getProfileById(id)
    }

    suspend fun seedInitialProfileIfEmpty() {
        val count = database.profileDao().getProfileCount()
        if (count == 0) {
            val defaultProfile = ProfileEntity(
                name = "My SSH Server",
                protocolType = com.example.model.ProtocolType.SSH,
                serverHost = "127.0.0.1",
                serverPort = 22,
                authUsername = "root",
                authPassword = "",
                isActive = true
            )
            val id = database.profileDao().insertProfile(defaultProfile)
            database.profileDao().setActiveProfile(id)
            log(LogLevel.INFO, "Initialized default SSH profile (127.0.0.1:22)")
        }
    }

    suspend fun getSettingsSync(): AppSettingEntity {
        return database.settingsDao().getSettingsSync() ?: AppSettingEntity()
    }

    suspend fun insertProfile(profile: ProfileEntity): Long {
        val id = database.profileDao().insertProfile(profile)
        // If this is the only profile, set it active
        val count = database.profileDao().getActiveProfileSync()
        if (count == null) {
            database.profileDao().setActiveProfile(id)
        }
        log(LogLevel.INFO, "Profile created: ${profile.name} (${profile.protocolType})")
        return id
    }

    suspend fun updateProfile(profile: ProfileEntity) {
        database.profileDao().updateProfile(profile)
        log(LogLevel.INFO, "Profile updated: ${profile.name}")
    }

    suspend fun deleteProfile(id: Long) {
        database.profileDao().deleteProfileById(id)
        log(LogLevel.INFO, "Profile deleted (ID: $id)")
    }

    suspend fun duplicateProfile(profile: ProfileEntity): Long {
        val copy = profile.copy(
            id = 0,
            name = "${profile.name} (Copy)",
            isActive = false,
            createdAt = System.currentTimeMillis()
        )
        val newId = database.profileDao().insertProfile(copy)
        log(LogLevel.INFO, "Profile duplicated: ${copy.name}")
        return newId
    }

    suspend fun setActiveProfile(profileId: Long) {
        database.profileDao().setActiveProfile(profileId)
        val profile = database.profileDao().getProfileById(profileId)
        log(LogLevel.INFO, "Active profile selected: ${profile?.name ?: profileId}")
    }

    suspend fun updateSettings(settings: AppSettingEntity) {
        database.settingsDao().saveSettings(settings)
    }

    fun log(level: LogLevel, message: String) {
        _latestLogMessage.value = message
        scope.launch {
            try {
                database.logDao().insertLog(
                    LogEntryEntity(
                        level = level,
                        message = message
                    )
                )
            } catch (_: Exception) {}
        }
    }

    suspend fun clearLogs() {
        database.logDao().clearAllLogs()
    }

    suspend fun pingServer(profileId: Long): Long = withContext(Dispatchers.IO) {
        val profile = database.profileDao().getProfileById(profileId) ?: return@withContext -1L
        val latency = measureLatency(profile.serverHost, profile.serverPort)
        database.profileDao().updateLastPing(profileId, latency)
        latency
    }

    private fun measureLatency(host: String, port: Int, timeoutMs: Int = 3000): Long {
        return try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            System.currentTimeMillis() - start
        } catch (_: Exception) {
            -1L
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: TunnelRepository? = null

        fun getInstance(context: Context): TunnelRepository {
            return INSTANCE ?: synchronized(this) {
                val db = PulseDatabase.getInstance(context)
                val instance = TunnelRepository(db)
                INSTANCE = instance
                instance
            }
        }
    }
}
