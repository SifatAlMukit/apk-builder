package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import com.example.model.NetworkInfoState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.TimeUnit

class NetworkInfoManager private constructor(private val context: Context) {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val prefs: SharedPreferences = context.getSharedPreferences("pulse_network_cache", Context.MODE_PRIVATE)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    private val _networkInfo = MutableStateFlow(loadCachedNetworkInfo())
    val networkInfo: StateFlow<NetworkInfoState> = _networkInfo.asStateFlow()

    private var lastObservedNetworkType: String? = null
    private var isVpnActive: Boolean = false

    init {
        registerNetworkCallback()
        // Check if cached info is stale (> 20 mins)
        val elapsed = System.currentTimeMillis() - _networkInfo.value.lastFetchedEpochMs
        if (elapsed > 20 * 60 * 1000L || _networkInfo.value.realIp == "•••") {
            refreshPublicIpInfo(force = false)
        }
    }

    private fun registerNetworkCallback() {
        try {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()

            connectivityManager.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onLinkPropertiesChanged(network: Network, linkProperties: LinkProperties) {
                    val localIp = extractLocalIpv4(linkProperties)
                    if (localIp != null && localIp != _networkInfo.value.localIp) {
                        _networkInfo.value = _networkInfo.value.copy(localIp = localIp)
                        saveCache()
                    }
                }

                override fun onAvailable(network: Network) {
                    val caps = connectivityManager.getNetworkCapabilities(network)
                    val newType = when {
                        caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true -> "WIFI"
                        caps?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true -> "CELLULAR"
                        caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true -> "ETHERNET"
                        else -> "OTHER"
                    }

                    if (lastObservedNetworkType != null && lastObservedNetworkType != newType) {
                        Log.d(TAG, "Network switched from $lastObservedNetworkType to $newType - triggering IP refresh")
                        refreshPublicIpInfo(force = true)
                    }
                    lastObservedNetworkType = newType

                    // Check local IP on active network
                    connectivityManager.getLinkProperties(network)?.let { lp ->
                        extractLocalIpv4(lp)?.let { ip ->
                            _networkInfo.value = _networkInfo.value.copy(localIp = ip)
                        }
                    }
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register network callback", e)
        }
    }

    private fun extractLocalIpv4(linkProperties: LinkProperties): String? {
        return linkProperties.linkAddresses
            .map { it.address }
            .firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    }

    fun onVpnStateChanged(connected: Boolean) {
        if (isVpnActive != connected) {
            isVpnActive = connected
            Log.d(TAG, "VPN state changed to connected=$connected. Triggering IP refresh.")
            refreshPublicIpInfo(force = true)
        }
    }

    fun toggleMasking() {
        val current = _networkInfo.value
        _networkInfo.value = current.copy(isMasked = !current.isMasked)
        prefs.edit().putBoolean(KEY_MASKED, _networkInfo.value.isMasked).apply()
    }

    fun refreshPublicIpInfo(force: Boolean = true) {
        scope.launch {
            val now = System.currentTimeMillis()
            if (!force && (now - _networkInfo.value.lastFetchedEpochMs < 15 * 60 * 1000L)) {
                return@launch
            }

            _networkInfo.value = _networkInfo.value.copy(isRefreshing = true)

            val result = fetchPublicIp()
            if (result != null) {
                val current = _networkInfo.value
                val updated = if (isVpnActive) {
                    current.copy(
                        vpnIp = result.ip,
                        location = result.location,
                        isp = result.isp,
                        lastFetchedEpochMs = now,
                        isRefreshing = false
                    )
                } else {
                    current.copy(
                        realIp = result.ip,
                        vpnIp = if (current.vpnIp != "•••" && current.vpnIp.isNotEmpty()) current.vpnIp else result.ip,
                        location = result.location,
                        isp = result.isp,
                        lastFetchedEpochMs = now,
                        isRefreshing = false
                    )
                }
                _networkInfo.value = updated
                saveCache()
            } else {
                _networkInfo.value = _networkInfo.value.copy(isRefreshing = false)
            }
        }
    }

    private data class IpLookupResult(
        val ip: String,
        val location: String,
        val isp: String
    )

    private fun fetchPublicIp(): IpLookupResult? {
        // Try primary HTTPS endpoint: ipwho.is (Free, HTTPS, IP + City + Country + ISP)
        try {
            val request = Request.Builder()
                .url("https://ipwho.is/")
                .header("User-Agent", "PulseTunnel/1.0")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: return null
                    val json = JSONObject(bodyString)
                    if (json.optBoolean("success", true)) {
                        val ip = json.optString("ip", "")
                        val city = json.optString("city", "")
                        val countryCode = json.optString("country_code", "")
                        val location = if (city.isNotEmpty() && countryCode.isNotEmpty()) "$city, $countryCode" else (city.ifEmpty { countryCode.ifEmpty { "Unknown" } })

                        val connection = json.optJSONObject("connection")
                        val isp = connection?.optString("isp")?.ifEmpty { null }
                            ?: connection?.optString("org")?.ifEmpty { null }
                            ?: json.optString("isp").ifEmpty { "Unknown ISP" }

                        if (ip.isNotEmpty()) {
                            return IpLookupResult(ip = ip, location = location, isp = isp)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ipwho.is fetch failed: ${e.message}")
        }

        // Fallback endpoint: ipapi.co/json/
        try {
            val fallbackRequest = Request.Builder()
                .url("https://ipapi.co/json/")
                .header("User-Agent", "PulseTunnel/1.0")
                .build()

            httpClient.newCall(fallbackRequest).execute().use { response ->
                if (response.isSuccessful) {
                    val bodyString = response.body?.string() ?: return null
                    val json = JSONObject(bodyString)
                    val ip = json.optString("ip", "")
                    val city = json.optString("city", "")
                    val country = json.optString("country_code", "")
                    val location = if (city.isNotEmpty() && country.isNotEmpty()) "$city, $country" else "Unknown"
                    val org = json.optString("org", "Unknown ISP")

                    if (ip.isNotEmpty()) {
                        return IpLookupResult(ip = ip, location = location, isp = org)
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "ipapi.co fallback fetch failed: ${e.message}")
        }

        return null
    }

    suspend fun measureSocketPing(host: String = "1.1.1.1", port: Int = 53, timeoutMs: Int = 2000): Long = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(host, port), timeoutMs)
            }
            val elapsed = System.currentTimeMillis() - startTime
            if (elapsed > 0) elapsed else 1L
        } catch (e: Exception) {
            -1L // Timeout or packet loss
        }
    }

    private fun loadCachedNetworkInfo(): NetworkInfoState {
        val realIp = prefs.getString(KEY_REAL_IP, "•••") ?: "•••"
        val vpnIp = prefs.getString(KEY_VPN_IP, "•••") ?: "•••"
        val localIp = prefs.getString(KEY_LOCAL_IP, "192.168.1.1") ?: "192.168.1.1"
        val location = prefs.getString(KEY_LOCATION, "Detecting...") ?: "Detecting..."
        val isp = prefs.getString(KEY_ISP, "Detecting...") ?: "Detecting..."
        val lastFetched = prefs.getLong(KEY_LAST_FETCHED, 0L)
        val isMasked = prefs.getBoolean(KEY_MASKED, true)

        return NetworkInfoState(
            realIp = realIp,
            vpnIp = vpnIp,
            localIp = localIp,
            location = location,
            isp = isp,
            lastFetchedEpochMs = lastFetched,
            isMasked = isMasked,
            isRefreshing = false
        )
    }

    private fun saveCache() {
        val info = _networkInfo.value
        prefs.edit()
            .putString(KEY_REAL_IP, info.realIp)
            .putString(KEY_VPN_IP, info.vpnIp)
            .putString(KEY_LOCAL_IP, info.localIp)
            .putString(KEY_LOCATION, info.location)
            .putString(KEY_ISP, info.isp)
            .putLong(KEY_LAST_FETCHED, info.lastFetchedEpochMs)
            .apply()
    }

    companion object {
        private const val TAG = "NetworkInfoManager"
        private const val KEY_REAL_IP = "key_real_ip"
        private const val KEY_VPN_IP = "key_vpn_ip"
        private const val KEY_LOCAL_IP = "key_local_ip"
        private const val KEY_LOCATION = "key_location"
        private const val KEY_ISP = "key_isp"
        private const val KEY_LAST_FETCHED = "key_last_fetched"
        private const val KEY_MASKED = "key_masked"

        fun maskIpAddress(ip: String): String {
            if (ip.contains("•••") || ip.isEmpty() || ip == "Unavailable") return ip
            val parts = ip.split(".")
            return if (parts.size == 4) {
                "${parts[0]}.${parts[1]}.•••.•••"
            } else {
                "•••.•••"
            }
        }

        @Volatile
        private var instance: NetworkInfoManager? = null

        fun getInstance(context: Context): NetworkInfoManager {
            return instance ?: synchronized(this) {
                instance ?: NetworkInfoManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
