package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Brand Colors (Cyan & Teal Cyber Theme)
val CyanPrimary = Color(0xFF7CD4DD)
val DeepTeal = Color(0xFF004F55)
val ForestTeal = Color(0xFF006970)
val BrightCyan = Color(0xFF99F1F9)
val DarkTealOnPrimary = Color(0xFF003B40)

// Secondary & Tertiary
val MetallicTeal = Color(0xFFB4CBCD)
val SlateTeal = Color(0xFF364A4C)
val LavenderBlue = Color(0xFFBBC6E3)
val MidnightBlue = Color(0xFF3B475E)

// Surfaces & Backgrounds
val DarkBackground = Color(0xFF111414)
val DarkSurface = Color(0xFF111414)
val DarkSurfaceContainer = Color(0xFF1E2020)
val DarkSurfaceContainerHigh = Color(0xFF282A2B)
val DarkSurfaceVariant = Color(0xFF454747)
val DarkBorder = Color(0xFF404E4F)

val LightBackground = Color(0xFFF6F6F6)
val LightSurface = Color(0xFFF6F6F6)
val LightSurfaceVariant = Color(0xFFD1D5D6)
val LightBorder = Color(0xFF757777)

// Status & Accents
val EmeraldSuccess = Color(0xFF10B981)
val CoralError = Color(0xFFEC9A96)
val DarkErrorContainer = Color(0xFF7F2828)
val AmberWarning = Color(0xFFF59E0B)

val SlateTextPrimary = Color(0xFFE2E3E2)
val SlateTextSecondary = Color(0xFF8F9190)
val LightTextPrimary = Color(0xFF1A1C1C)
val LightTextSecondary = Color(0xFF454747)

// Compatibility aliases mapped directly to new palette
val CobaltPrimary = CyanPrimary
val ElectricCyanSecondary = CyanPrimary
val AquaAccent = MetallicTeal
val RoseError = CoralError
