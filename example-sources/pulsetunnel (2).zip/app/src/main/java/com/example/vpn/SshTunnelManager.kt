package com.example.vpn

import android.net.VpnService
import com.example.data.ProfileEntity
import com.example.data.TunnelRepository
import com.example.model.LogLevel
import com.example.util.PayloadInjector
import kotlinx.coroutines.*
import net.schmizz.sshj.SSHClient
import net.schmizz.sshj.transport.verification.PromiscuousVerifier
import net.schmizz.sshj.userauth.keyprovider.KeyProvider
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class SshTunnelManager(
    private val vpnService: VpnService,
    private val repository: TunnelRepository
) {
    private var sshClient: SSHClient? = null
    private var rawSocket: Socket? = null
    private var dynamicForwarderThread: Thread? = null
    private var localSocksServerSocket: ServerSocket? = null
    private val isRunning = AtomicBoolean(false)
    private var localSocksPort: Int = 10808

    fun getLocalSocksPort(): Int = localSocksPort

    suspend fun connect(profile: ProfileEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            repository.log(LogLevel.INFO, "Initiating SSH connection to ${profile.serverHost}:${profile.serverPort}…")
            val client = SSHClient()
            client.addHostKeyVerifier(PromiscuousVerifier())
            client.setConnectTimeout(10000)
            client.timeout = 15000

            if (profile.sshCompression) {
                repository.log(LogLevel.DEBUG, "Enabling zlib SSH compression…")
                client.useCompression()
            }

            // Determine if custom socket pipeline is needed (Proxy / Payload / SSL)
            if (profile.useProxy || profile.useCustomPayload || profile.useSslTls) {
                repository.log(LogLevel.INFO, "Activating DPI Bypass pipeline…")
                val connectHost = if (profile.useProxy && profile.proxyHost.isNotBlank()) profile.proxyHost else profile.serverHost
                val connectPort = if (profile.useProxy && profile.proxyPort > 0) profile.proxyPort else profile.serverPort

                repository.log(LogLevel.DEBUG, "Connecting raw socket to $connectHost:$connectPort…")
                var socket = Socket()
                vpnService.protect(socket)
                socket.connect(InetSocketAddress(connectHost, connectPort), 10000)

                // Inject Custom HTTP Payload if configured
                if (profile.useCustomPayload && profile.customPayload.isNotBlank()) {
                    repository.log(LogLevel.INFO, "Injecting custom HTTP payload before handshake…")
                    val formatted = PayloadInjector.formatPayload(
                        profile.customPayload,
                        profile.serverHost,
                        profile.serverPort,
                        profile.proxyHost
                    )
                    val success = PayloadInjector.injectPayload(socket, formatted)
                    if (!success) {
                        repository.log(LogLevel.WARN, "Payload injection completed without 200 OK header, continuing handshake…")
                    } else {
                        repository.log(LogLevel.DEBUG, "Payload accepted by upstream gateway.")
                    }
                }

                // Wrap in TLS if enabled
                if (profile.useSslTls) {
                    val sni = profile.sni.ifEmpty { profile.serverHost }
                    repository.log(LogLevel.INFO, "Wrapping stream in SSL/TLS (SNI: $sni)…")
                    socket = PayloadInjector.wrapTls(socket, sni, profile.serverPort)
                }

                rawSocket = socket
                client.socketFactory = object : javax.net.SocketFactory() {
                    override fun createSocket(): Socket = socket
                    override fun createSocket(host: String?, port: Int): Socket = socket
                    override fun createSocket(host: String?, port: Int, localHost: java.net.InetAddress?, localPort: Int): Socket = socket
                    override fun createSocket(host: java.net.InetAddress?, port: Int): Socket = socket
                    override fun createSocket(address: java.net.InetAddress?, port: Int, localAddress: java.net.InetAddress?, localPort: Int): Socket = socket
                }
                client.connect(profile.serverHost, profile.serverPort)
            } else {
                repository.log(LogLevel.DEBUG, "Resolving host ${profile.serverHost}…")
                val inetAddr = java.net.InetAddress.getByName(profile.serverHost)
                repository.log(LogLevel.DEBUG, "Resolved ${profile.serverHost} to ${inetAddr.hostAddress}. Probing TCP port ${profile.serverPort}…")

                val probeSocket = Socket()
                vpnService.protect(probeSocket)
                val startTime = System.currentTimeMillis()
                probeSocket.connect(InetSocketAddress(inetAddr, profile.serverPort), 6000)
                val latency = System.currentTimeMillis() - startTime
                probeSocket.close()

                repository.log(LogLevel.INFO, "Direct TCP handshake verified (${profile.serverHost}:${profile.serverPort}, latency: ${latency}ms)")

                client.socketFactory = object : javax.net.SocketFactory() {
                    override fun createSocket(): Socket = Socket().also { vpnService.protect(it) }
                    override fun createSocket(host: String?, port: Int): Socket = Socket().also { vpnService.protect(it); it.connect(InetSocketAddress(host, port), 8000) }
                    override fun createSocket(host: String?, port: Int, localHost: java.net.InetAddress?, localPort: Int): Socket = Socket().also { vpnService.protect(it); it.bind(InetSocketAddress(localHost, localPort)); it.connect(InetSocketAddress(host, port), 8000) }
                    override fun createSocket(host: java.net.InetAddress?, port: Int): Socket = Socket().also { vpnService.protect(it); it.connect(InetSocketAddress(host, port), 8000) }
                    override fun createSocket(address: java.net.InetAddress?, port: Int, localAddress: java.net.InetAddress?, localPort: Int): Socket = Socket().also { vpnService.protect(it); it.bind(InetSocketAddress(localAddress, localPort)); it.connect(InetSocketAddress(address, port), 8000) }
                }
                client.connect(profile.serverHost, profile.serverPort)
            }

            // Authenticate
            when {
                profile.privateKey.isNotBlank() -> {
                    repository.log(LogLevel.INFO, "Authenticating with private key…")
                    val passwordFinder = if (profile.authPassword.isNotBlank()) {
                        net.schmizz.sshj.userauth.password.PasswordUtils.createOneOff(profile.authPassword.toCharArray())
                    } else null
                    val keyProvider: KeyProvider = client.loadKeys(
                        profile.privateKey.trim(),
                        passwordFinder
                    )
                    client.authPublickey(profile.authUsername, keyProvider)
                }
                profile.authPassword.isNotBlank() -> {
                    repository.log(LogLevel.INFO, "Authenticating with password for ${profile.authUsername}…")
                    client.authPassword(profile.authUsername, profile.authPassword)
                }
                else -> {
                    repository.log(LogLevel.WARN, "No password or private key specified. Attempting none auth…")
                    client.authPassword(profile.authUsername, "")
                }
            }

            if (!client.isAuthenticated) {
                repository.log(LogLevel.ERROR, "SSH Authentication failed!")
                client.disconnect()
                return@withContext false
            }

            repository.log(LogLevel.INFO, "SSH Authentication successful!")

            // Allocate and bind local port for SOCKS5 forwarder
            val ss = ServerSocket(0)
            localSocksPort = ss.localPort
            localSocksServerSocket = ss
            repository.log(LogLevel.INFO, "Binding local dynamic forwarder (SOCKS5) on 127.0.0.1:$localSocksPort…")
            isRunning.set(true)
            sshClient = client

            // Start dynamic port forwarding in background thread
            dynamicForwarderThread = Thread({
                try {
                    val forwarder = client.newLocalPortForwarder(
                        net.schmizz.sshj.connection.channel.direct.Parameters("127.0.0.1", localSocksPort, "127.0.0.1", localSocksPort),
                        localSocksServerSocket
                    )
                    forwarder.listen()
                } catch (e: Exception) {
                    if (isRunning.get()) {
                        repository.log(LogLevel.WARN, "SSH Port forwarder ended: ${e.message}")
                    }
                }
            }, "SSH-DynamicForwarder")
            dynamicForwarderThread?.start()

            if (profile.udpgwPort > 0) {
                repository.log(LogLevel.INFO, "UDPGW forwarding configured on remote port ${profile.udpgwPort}")
            }

            repository.log(LogLevel.INFO, "SSH Tunnel established and active.")
            true
        } catch (e: Exception) {
            repository.log(LogLevel.ERROR, "SSH connection error: ${e.message}")
            disconnect()
            false
        }
    }

    fun isConnected(): Boolean = isRunning.get() && (sshClient?.isConnected == true)

    fun disconnect() {
        isRunning.set(false)
        try {
            localSocksServerSocket?.close()
        } catch (_: Exception) {}
        try {
            sshClient?.disconnect()
        } catch (_: Exception) {}
        try {
            rawSocket?.close()
        } catch (_: Exception) {}
        try {
            dynamicForwarderThread?.interrupt()
        } catch (_: Exception) {}
        sshClient = null
        rawSocket = null
        repository.log(LogLevel.INFO, "SSH Tunnel disconnected.")
    }
}
