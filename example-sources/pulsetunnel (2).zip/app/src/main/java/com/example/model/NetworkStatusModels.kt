package com.example.model

data class NetworkInfoState(
    val realIp: String = "•••",
    val vpnIp: String = "•••",
    val localIp: String = "•••",
    val location: String = "Unavailable",
    val isp: String = "Unavailable",
    val lastFetchedEpochMs: Long = 0L,
    val isMasked: Boolean = true,
    val isRefreshing: Boolean = false
)

data class SpeedSample(
    val timestampMs: Long,
    val downloadBps: Long,
    val uploadBps: Long
)

data class LatencySample(
    val timestampMs: Long,
    val latencyMs: Long
)

data class LatencySummary(
    val minMs: Long = 0L,
    val avgMs: Long = 0L,
    val maxMs: Long = 0L,
    val jitterMs: Long = 0L,
    val lossPercent: Int = 0
)

enum class SpeedTimeWindow(val label: String, val durationMs: Long) {
    ONE_MIN("1m", 60_000L),
    TEN_MIN("10m", 600_000L),
    ONE_HOUR("1h", 3_600_000L)
}
