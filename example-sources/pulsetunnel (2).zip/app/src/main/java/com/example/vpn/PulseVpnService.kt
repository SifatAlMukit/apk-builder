package com.example.vpn

import android.app.Notification
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.PulseApplication
import com.example.R
import com.example.data.ProfileEntity
import com.example.data.TunnelRepository
import com.example.model.LogLevel
import com.example.model.ProtocolType
import com.example.model.SplitTunnelMode
import com.example.model.TunnelState
import com.example.model.TunnelStats
import kotlinx.coroutines.*
import org.json.JSONArray
import java.util.Locale

class PulseVpnService : VpnService() {
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private lateinit var repository: TunnelRepository

    private var tunInterface: ParcelFileDescriptor? = null
    private var sshManager: SshTunnelManager? = null
    private var v2rayManager: V2RayManager? = null
    private var dnsttManager: DnsttManager? = null
    private var tun2SocksEngine: Tun2SocksEngine? = null

    private var statsJob: Job? = null
    private var activeProfile: ProfileEntity? = null
    private var connectionStartTime: Long = 0L
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        repository = TunnelRepository.getInstance(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START
        when (action) {
            ACTION_STOP -> {
                stopTunnel()
                stopSelf()
            }
            ACTION_START -> {
                val profileId = intent?.getLongExtra(EXTRA_PROFILE_ID, -1L) ?: -1L
                startTunnel(profileId)
            }
        }
        return START_NOT_STICKY
    }

    private fun startTunnel(profileId: Long) {
        serviceScope.launch {
            repository.updateTunnelState(TunnelState.CONNECTING)
            val settings = repository.getSettingsSync()

            // Handle Wake Lock
            if (settings.wakeLock) {
                try {
                    val pm = getSystemService(POWER_SERVICE) as? android.os.PowerManager
                    wakeLock = pm?.newWakeLock(android.os.PowerManager.PARTIAL_WAKE_LOCK, "PulseTunnel:VpnLock")?.apply {
                        acquire(60 * 60 * 1000L)
                    }
                    repository.log(LogLevel.DEBUG, "WakeLock acquired: keeping CPU active.")
                } catch (_: Exception) {}
            }

            val profile = if (profileId > 0) {
                repository.getProfileByIdSync(profileId) ?: repository.getActiveProfileSync()
            } else {
                repository.getActiveProfileSync()
            }

            if (profile == null) {
                repository.log(LogLevel.ERROR, "No active profile selected to connect!")
                stopTunnel(TunnelState.ERROR, "No profile selected")
                stopSelf()
                return@launch
            }

            activeProfile = profile
            startForegroundServiceWithNotification(profile.name, "Connecting…")

            val maxAttempts = 5
            var attempt = 0
            var connectedOk = false
            var allocatedSocksPort = 10808
            var lastError = "Handshake timed out or rejected"

            while (isActive && attempt < maxAttempts && !connectedOk) {
                attempt++
                val attemptTag = "[Attempt $attempt/$maxAttempts]"
                repository.log(LogLevel.INFO, "$attemptTag Connecting to ${profile.name} (${profile.protocolType}) at ${profile.serverHost}:${profile.serverPort}…")
                updateNotification(profile.name, "$attemptTag Connecting…")

                // Clean up previous instances before retry attempt
                cleanupEngines()

                val handshakeSuccess = try {
                    when (profile.protocolType) {
                        ProtocolType.SSH -> {
                            val mgr = SshTunnelManager(this@PulseVpnService, repository)
                            sshManager = mgr
                            val ok = mgr.connect(profile)
                            if (ok) allocatedSocksPort = mgr.getLocalSocksPort()
                            ok
                        }
                        ProtocolType.VMESS, ProtocolType.VLESS, ProtocolType.TROJAN -> {
                            val mgr = V2RayManager(this@PulseVpnService, repository)
                            v2rayManager = mgr
                            val ok = mgr.connect(profile)
                            if (ok) allocatedSocksPort = mgr.getLocalSocksPort()
                            ok
                        }
                        ProtocolType.DNSTT -> {
                            val mgr = DnsttManager(this@PulseVpnService, repository)
                            dnsttManager = mgr
                            val ok = mgr.connect(profile)
                            if (ok) allocatedSocksPort = mgr.getLocalSocksPort()
                            ok
                        }
                    }
                } catch (e: Exception) {
                    lastError = e.message ?: "Network unreachable"
                    repository.log(LogLevel.WARN, "$attemptTag Handshake exception: $lastError")
                    false
                }

                if (handshakeSuccess) {
                    repository.log(LogLevel.INFO, "$attemptTag Remote handshake verified! Establishing Android TUN virtual interface…")
                    val established = setupTunInterface(profile)
                    if (established) {
                        tun2SocksEngine = Tun2SocksEngine(this@PulseVpnService, repository, tunInterface!!, allocatedSocksPort)
                        tun2SocksEngine!!.start()
                        connectedOk = true
                        connectionStartTime = System.currentTimeMillis()
                        repository.updateTunnelState(TunnelState.CONNECTED)
                        repository.log(LogLevel.INFO, "Tunnel successfully established! PulseTunnel is actively routing device traffic.")
                        updateNotification(profile.name, "Connected")
                        startTelemetryLoop()
                        break
                    } else {
                        lastError = "Failed to establish Android TUN virtual interface"
                        repository.log(LogLevel.ERROR, "$attemptTag $lastError")
                        cleanupEngines()
                    }
                } else {
                    lastError = "Server at ${profile.serverHost}:${profile.serverPort} did not respond or rejected handshake"
                    repository.log(LogLevel.WARN, "$attemptTag Handshake failed: $lastError")
                    cleanupEngines()
                }

                if (!connectedOk) {
                    if (attempt < maxAttempts) {
                        repository.log(LogLevel.WARN, "$attemptTag Attempt $attempt failed. Retrying in 3 seconds (${attempt + 1}/$maxAttempts)…")
                        updateNotification(profile.name, "Retrying in 3s (${attempt + 1}/$maxAttempts)…")
                        delay(3000L)
                    }
                }
            }

            if (!connectedOk) {
                repository.log(LogLevel.ERROR, "Connection failed after $maxAttempts attempts. Reason: $lastError")
                stopTunnel(TunnelState.ERROR, "Failed after $maxAttempts attempts: $lastError")
                stopSelf()
            }
        }
    }

    private suspend fun setupTunInterface(profile: ProfileEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            val settings = repository.getSettingsSync()
            val mtuToUse = if (settings.mtu in 1280..1500) settings.mtu else 1500
            val builder = Builder()
                .setSession("PulseTunnel - ${profile.name}")
                .setMtu(mtuToUse)
                .addAddress("10.0.0.2", 32)

            // Routing: Full VPN vs Bypass LAN
            if (settings.bypassLan) {
                val publicCidrs = listOf(
                    Pair("1.0.0.0", 8), Pair("2.0.0.0", 7), Pair("4.0.0.0", 6), Pair("8.0.0.0", 7),
                    Pair("11.0.0.0", 8), Pair("12.0.0.0", 6), Pair("16.0.0.0", 4), Pair("32.0.0.0", 3),
                    Pair("64.0.0.0", 2), Pair("128.0.0.0", 3), Pair("160.0.0.0", 5), Pair("168.0.0.0", 6),
                    Pair("172.0.0.0", 12), Pair("172.32.0.0", 11), Pair("172.64.0.0", 10), Pair("172.128.0.0", 9),
                    Pair("173.0.0.0", 8), Pair("174.0.0.0", 7), Pair("176.0.0.0", 4), Pair("192.0.0.0", 9),
                    Pair("192.128.0.0", 11), Pair("192.160.0.0", 13), Pair("192.169.0.0", 16), Pair("192.170.0.0", 15),
                    Pair("192.172.0.0", 14), Pair("192.176.0.0", 12), Pair("192.192.0.0", 10), Pair("193.0.0.0", 8),
                    Pair("194.0.0.0", 7), Pair("196.0.0.0", 6), Pair("200.0.0.0", 5), Pair("208.0.0.0", 4)
                )
                for ((ip, prefix) in publicCidrs) {
                    try { builder.addRoute(ip, prefix) } catch (_: Exception) {}
                }
                repository.log(LogLevel.DEBUG, "Bypass LAN active: local network traffic kept outside tunnel.")
            } else {
                builder.addRoute("0.0.0.0", 0)
            }

            // DNS Configuration
            val dnsToUse = when {
                profile.customDns.isNotBlank() -> profile.customDns
                settings.primaryDns.isNotBlank() -> settings.primaryDns
                else -> "1.1.1.1"
            }
            try {
                builder.addDnsServer(dnsToUse)
                if (settings.secondaryDns.isNotBlank()) {
                    builder.addDnsServer(settings.secondaryDns)
                }
            } catch (_: Exception) {
                builder.addDnsServer("1.1.1.1")
            }

            // Split tunneling (per-app proxy)
            val selectedApps = try {
                val jsonArray = JSONArray(settings.selectedAppsJson)
                (0 until jsonArray.length()).map { jsonArray.getString(it) }
            } catch (_: Exception) {
                emptyList()
            }

            if (selectedApps.isNotEmpty()) {
                when (settings.splitTunnelMode) {
                    SplitTunnelMode.INCLUDE_ONLY -> {
                        selectedApps.forEach { pkg ->
                            try {
                                builder.addAllowedApplication(pkg)
                            } catch (_: Exception) {}
                        }
                        repository.log(LogLevel.DEBUG, "Split tunneling: including ${selectedApps.size} apps.")
                    }
                    SplitTunnelMode.EXCLUDE_SELECTED -> {
                        selectedApps.forEach { pkg ->
                            try {
                                builder.addDisallowedApplication(pkg)
                            } catch (_: Exception) {}
                        }
                        repository.log(LogLevel.DEBUG, "Split tunneling: excluding ${selectedApps.size} apps.")
                    }
                    SplitTunnelMode.ALL_APPS -> {}
                }
            }

            // Ensure our own app does not loop back into the VPN
            try {
                builder.addDisallowedApplication(packageName)
            } catch (_: Exception) {}

            tunInterface = builder.establish()
            tunInterface != null
        } catch (e: Exception) {
            repository.log(LogLevel.ERROR, "TUN establish error: ${e.message}")
            false
        }
    }

    private fun startTelemetryLoop() {
        statsJob?.cancel()
        statsJob = serviceScope.launch {
            var prevUp = 0L
            var prevDown = 0L

            while (isActive) {
                delay(1000L)
                val currentUp = tun2SocksEngine?.totalBytesUploaded?.get() ?: 0L
                val currentDown = tun2SocksEngine?.totalBytesDownloaded?.get() ?: 0L

                val upSpeed = currentUp - prevUp
                val downSpeed = currentDown - prevDown
                prevUp = currentUp
                prevDown = currentDown

                val duration = if (connectionStartTime > 0) (System.currentTimeMillis() - connectionStartTime) / 1000L else 0L

                val stats = TunnelStats(
                    uploadBytes = currentUp,
                    downloadBytes = currentDown,
                    uploadSpeedBps = upSpeed,
                    downloadSpeedBps = downSpeed,
                    connectedDurationSec = duration
                )
                repository.updateTunnelStats(stats)

                // Update notification text
                val profileName = activeProfile?.name ?: "PulseTunnel"
                val speedText = "↑ ${formatSpeed(upSpeed)}  ↓ ${formatSpeed(downSpeed)}"
                updateNotification(profileName, speedText)
            }
        }
    }

    private fun formatSpeed(bytesPerSec: Long): String {
        return when {
            bytesPerSec >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB/s", bytesPerSec / (1024.0 * 1024.0))
            bytesPerSec >= 1024 -> String.format(Locale.US, "%.1f KB/s", bytesPerSec / 1024.0)
            else -> "$bytesPerSec B/s"
        }
    }

    private fun startForegroundServiceWithNotification(title: String, statusText: String) {
        val notification = buildNotification(title, statusText)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                PulseApplication.NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(PulseApplication.NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(title: String, statusText: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as? android.app.NotificationManager
        manager?.notify(PulseApplication.NOTIFICATION_ID, buildNotification(title, statusText))
    }

    private fun buildNotification(title: String, statusText: String): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, PulseVpnService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, PulseApplication.VPN_CHANNEL_ID)
            .setContentTitle("PulseTunnel: $title")
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(R.drawable.ic_launcher_foreground, getString(R.string.action_disconnect), disconnectIntent)
            .build()
    }

    private fun cleanupEngines() {
        tun2SocksEngine?.stop()
        tun2SocksEngine = null

        sshManager?.disconnect()
        sshManager = null

        v2rayManager?.disconnect()
        v2rayManager = null

        dnsttManager?.disconnect()
        dnsttManager = null

        try {
            tunInterface?.close()
        } catch (_: Exception) {}
        tunInterface = null
    }

    private fun stopTunnel(finalState: TunnelState = TunnelState.DISCONNECTED, reason: String = "PulseTunnel service stopped.") {
        statsJob?.cancel()
        statsJob = null
        cleanupEngines()

        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
        wakeLock = null

        connectionStartTime = 0L
        repository.updateTunnelState(finalState)
        repository.updateTunnelStats(TunnelStats())
        repository.log(if (finalState == TunnelState.ERROR) LogLevel.ERROR else LogLevel.INFO, reason)
    }

    override fun onDestroy() {
        stopTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.vpn.ACTION_START"
        const val ACTION_STOP = "com.example.vpn.ACTION_STOP"
        const val EXTRA_PROFILE_ID = "extra_profile_id"
    }
}
