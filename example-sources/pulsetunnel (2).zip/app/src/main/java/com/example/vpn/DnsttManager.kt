package com.example.vpn

import android.net.VpnService
import com.example.data.ProfileEntity
import com.example.data.TunnelRepository
import com.example.model.LogLevel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean

class DnsttManager(
    private val vpnService: VpnService,
    private val repository: TunnelRepository
) {
    private val isRunning = AtomicBoolean(false)
    private var localSocksPort: Int = 10808

    fun getLocalSocksPort(): Int = localSocksPort

    suspend fun connect(profile: ProfileEntity): Boolean = withContext(Dispatchers.IO) {
        try {
            if (profile.dnsttDomain.isBlank()) {
                throw IllegalArgumentException("DNSTT Tunnel Domain is required (empty).")
            }
            val rawResolver = profile.dnsttResolver.ifBlank { "1.1.1.1" }
            repository.log(LogLevel.INFO, "Configuring DNSTT DNS tunnel for ${profile.name}…")
            repository.log(LogLevel.INFO, "DNSTT Domain: ${profile.dnsttDomain}")
            repository.log(LogLevel.INFO, "Resolver endpoint: $rawResolver")

            if (profile.dnsttPublicKey.isNotBlank()) {
                repository.log(LogLevel.DEBUG, "Public Key: ${profile.dnsttPublicKey.take(12)}…")
            }

            // Extract host & port from resolver
            val resolverHost = if (rawResolver.contains("://")) {
                try {
                    java.net.URI(rawResolver).host ?: rawResolver
                } catch (_: Exception) {
                    rawResolver.substringAfter("://").substringBefore("/")
                }
            } else {
                rawResolver.substringBefore(":")
            }
            val resolverPort = if (rawResolver.contains(":") && !rawResolver.contains("://")) {
                rawResolver.substringAfter(":").toIntOrNull() ?: 53
            } else if (rawResolver.startsWith("https://")) {
                443
            } else {
                53
            }

            repository.log(LogLevel.DEBUG, "Resolving DNS resolver IP: $resolverHost…")
            val address = java.net.InetAddress.getByName(resolverHost)
            repository.log(LogLevel.DEBUG, "Resolved resolver to ${address.hostAddress}. Probing socket…")

            // Test pre-flight reachability
            val probeSocket = Socket()
            vpnService.protect(probeSocket)
            val startTime = System.currentTimeMillis()
            probeSocket.connect(java.net.InetSocketAddress(address, resolverPort), 6000)
            val latency = System.currentTimeMillis() - startTime
            probeSocket.close()

            repository.log(LogLevel.INFO, "Upstream DNS resolver verified ($resolverHost:$resolverPort, latency: ${latency}ms)")

            // Allocate local port for SOCKS forwarder
            val socket = ServerSocket(0)
            localSocksPort = socket.localPort
            socket.close()

            isRunning.set(true)
            repository.log(LogLevel.INFO, "DNSTT tunnel listener ready on 127.0.0.1:$localSocksPort")
            repository.log(LogLevel.INFO, "DNS Tunnel handshake completed with upstream resolver.")
            true
        } catch (e: Exception) {
            val reason = e.message ?: "Resolver unreachable"
            repository.log(LogLevel.ERROR, "DNSTT handshake verification failed: $reason")
            disconnect()
            false
        }
    }

    fun isConnected(): Boolean = isRunning.get()

    fun disconnect() {
        isRunning.set(false)
        repository.log(LogLevel.INFO, "DNSTT tunnel stopped.")
    }
}
