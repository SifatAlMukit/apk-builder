package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ProtocolType

@Entity(tableName = "profiles")
data class ProfileEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val protocolType: ProtocolType,
    val serverHost: String,
    val serverPort: Int,
    val authUsername: String = "",
    val authPassword: String = "",
    val privateKey: String = "",
    val publicKey: String = "",

    // V2Ray / TLS specific
    val uuid: String = "",
    val sni: String = "",
    val wsPath: String = "",
    val transportSecurity: String = "none", // none, tls, reality
    val transportNetwork: String = "TCP", // TCP, WebSocket, gRPC
    val flowXtls: String = "", // e.g. xtls-rprx-vision

    // DPI Bypass & Inject
    val useSslTls: Boolean = false,
    val useCustomPayload: Boolean = false,
    val customPayload: String = "CONNECT [host_port] HTTP/1.1[crlf]Host: [host][crlf]Connection: Keep-Alive[crlf][crlf]",
    val useProxy: Boolean = false,
    val proxyHost: String = "",
    val proxyPort: Int = 8080,

    // Enhancements
    val sshCompression: Boolean = false,
    val tunnelOverDns: Boolean = false,

    // DNSTT / SlowDNS specific
    val dnsttDomain: String = "",
    val dnsttResolver: String = "1.1.1.1",
    val dnsttPublicKey: String = "",

    // Advanced options
    val udpgwPort: Int = 7300,
    val customDns: String = "",
    val isActive: Boolean = false,
    val lastPingMs: Long = -1L,
    val createdAt: Long = System.currentTimeMillis()
)
