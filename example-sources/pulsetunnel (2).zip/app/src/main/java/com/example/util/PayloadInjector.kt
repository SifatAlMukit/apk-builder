package com.example.util

import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.charset.StandardCharsets
import javax.net.ssl.SNIHostName
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

object PayloadInjector {
    private const val DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

    fun formatPayload(
        template: String,
        targetHost: String,
        targetPort: Int,
        proxyHost: String = ""
    ): String {
        val hostToUse = if (proxyHost.isNotBlank()) proxyHost else targetHost
        var result = template
            .replace("[host_port]", "$targetHost:$targetPort", ignoreCase = true)
            .replace("[host]", hostToUse, ignoreCase = true)
            .replace("[port]", targetPort.toString(), ignoreCase = true)
            .replace("[protocol]", "HTTP/1.1", ignoreCase = true)
            .replace("[ua]", DEFAULT_UA, ignoreCase = true)
            .replace("[crlf]", "\r\n", ignoreCase = true)
            .replace("[lf]", "\n", ignoreCase = true)
            .replace("[cr]", "\r", ignoreCase = true)

        if (!result.endsWith("\r\n\r\n")) {
            result += "\r\n\r\n"
        }
        return result
    }

    fun injectPayload(
        socket: Socket,
        formattedPayload: String
    ): Boolean {
        return try {
            val outputStream: OutputStream = socket.getOutputStream()
            val inputStream: InputStream = socket.getInputStream()

            // Handle packet splitting if requested
            if (formattedPayload.contains("[split]", ignoreCase = true)) {
                val parts = formattedPayload.split("(?i)\\[split\\]".toRegex())
                for (part in parts) {
                    outputStream.write(part.toByteArray(StandardCharsets.UTF_8))
                    outputStream.flush()
                    Thread.sleep(50)
                }
            } else {
                outputStream.write(formattedPayload.toByteArray(StandardCharsets.UTF_8))
                outputStream.flush()
            }

            // Read proxy response headers (up to double CRLF)
            val buffer = ByteArray(4096)
            val bytesRead = inputStream.read(buffer)
            if (bytesRead > 0) {
                val response = String(buffer, 0, bytesRead, StandardCharsets.UTF_8)
                // HTTP/1.0 200 OK or HTTP/1.1 200 Connection established
                response.contains("200") || response.contains("HTTP/")
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun wrapTls(
        socket: Socket,
        sniHost: String,
        targetPort: Int
    ): SSLSocket {
        val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
        val sslSocket = sslFactory.createSocket(socket, sniHost, targetPort, true) as SSLSocket
        val sslParams = SSLParameters()
        if (sniHost.isNotBlank()) {
            sslParams.serverNames = listOf(SNIHostName(sniHost))
        }
        sslSocket.sslParameters = sslParams
        sslSocket.startHandshake()
        return sslSocket
    }
}
