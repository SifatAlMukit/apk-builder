package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.SpeedTimeWindow
import com.example.util.NetworkInfoManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class StatusTabTest {

    @Test
    fun testIpMasking() {
        val publicIp = "203.0.113.195"
        val masked = NetworkInfoManager.maskIpAddress(publicIp)
        assertEquals("203.0.•••.•••", masked)

        val vpnIp = "198.51.100.42"
        val maskedVpn = NetworkInfoManager.maskIpAddress(vpnIp)
        assertEquals("198.51.•••.•••", maskedVpn)

        // Idempotent or fallback handling
        assertEquals("•••", NetworkInfoManager.maskIpAddress("•••"))
    }

    @Test
    fun testNetworkInfoManagerInitialization() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = NetworkInfoManager.getInstance(context)
        assertNotNull(manager)
        val info = manager.networkInfo.value
        assertNotNull(info)
    }

    @Test
    fun testSpeedTimeWindowDurations() {
        assertEquals("1m", SpeedTimeWindow.ONE_MIN.label)
        assertEquals(60_000L, SpeedTimeWindow.ONE_MIN.durationMs)
        assertEquals("10m", SpeedTimeWindow.TEN_MIN.label)
        assertEquals(600_000L, SpeedTimeWindow.TEN_MIN.durationMs)
        assertEquals("1h", SpeedTimeWindow.ONE_HOUR.label)
        assertEquals(3_600_000L, SpeedTimeWindow.ONE_HOUR.durationMs)
    }
}
