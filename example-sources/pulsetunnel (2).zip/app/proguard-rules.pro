# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# SSHJ and BouncyCastle rules
-keep class net.schmizz.sshj.** { *; }
-dontwarn net.schmizz.sshj.**
-dontwarn org.bouncycastle.**
-dontwarn com.hierynomus.**
-dontwarn org.slf4j.**
-dontwarn org.conscrypt.**
-dontwarn org.openjsse.**
-dontwarn sun.security.**
-dontwarn net.i2p.crypto.eddsa.**

# Keep Moshi models
-keepclassmembers class * {
    @com.squareup.moshi.Json <fields>;
}
-keep class * {
    @com.squareup.moshi.JsonClass public *;
}
-dontwarn com.squareup.moshi.**

# PulseTunnel data models and entities
-keep class com.example.model.** { *; }
-keep class com.example.data.** { *; }
