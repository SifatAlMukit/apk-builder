# HSC C Programming Companion 📱💻
> **এইচএসসি আইসিটি সি প্রোগ্রামিং (HSC ICT Chapter 5) শেখার পূর্ণাঙ্গ ও ইন্টারেক্টিভ সহায়িকা**

[![Android](https://img.shields.io/badge/Platform-Android-green.svg)](https://developer.android.com/)
[![Kotlin](https://img.shields.io/badge/Language-Kotlin-purple.svg)](https://kotlinlang.org/)
[![Compose](https://img.shields.io/badge/UI-Jetpack%20Compose%20M3-blue.svg)](https://developer.android.com/jetpack/compose)
[![Offline First](https://img.shields.io/badge/Offline-100%25%20Functional-brightgreen.svg)]()
[![License](https://img.shields.io/badge/License-MIT-orange.svg)]()

**HSC C Programming Companion** is an offline-first Android application purpose-built for Bangladeshi Higher Secondary Certificate (HSC) students to master Chapter 5 (Programming Language - C) of the ICT curriculum. 

The app features structured bilingual lessons (Bengali & English), past board questions with model solutions, interactive quizzes, flashcards, and a **complete, custom C Compiler & Interpreter written 100% from scratch in Kotlin**—allowing students to code, compile, and execute C programs directly on their smartphones without requiring an internet connection or external servers.

---

## 🌟 Key Features

### 1. ⚡ Built-in C Compiler & Code Playground (100% Pure Kotlin)
* **Custom AST Interpreter:** Includes a hand-crafted Lexer, Recursive-Descent Parser, and Coroutine-based Tree-Walking AST Interpreter.
* **Interactive I/O:** Fully supports `printf()` with format specifiers (`%d`, `%f`, `%c`, `%s`) and interactive `scanf()` prompts that pause execution for user keyboard input.
* **Standard Library Support:** Includes arithmetic operations, relational/logical operators, conditionals (`if`, `if-else`), loops (`for`, `while`, `do-while`), user-defined functions, multi-parameter recursion, 1D/2D arrays, and math utilities (`sqrt`, `pow`, `abs`, `rand`).
* **Infinite Loop & Memory Protection:** Sandboxed execution engine with a configurable safety instruction threshold (up to 10,000 steps) to prevent device freezing.
* **Localized Bengali Error Messages:** Syntax and runtime errors are translated into student-friendly Bengali with exact line numbers for effortless debugging.
* **Code Editor Utilities:** Quick code insertion buttons (brackets, semicolons, quotes, operators), template loading, terminal clear, and code reset.

### 2. 📚 Comprehensive Curriculum & Lessons
* **12 Core HSC Board Curriculum Chapters:**
  * Introduction to C & Basic Structure
  * Data Types, Variables & Constants
  * Operators & Expressions
  * Input & Output (`printf`, `scanf`, format specifiers)
  * Conditional Statements (`if`, `else if`, `switch-case`)
  * Loops & Iterations (`for`, `while`, `do-while`)
  * Nested Loops & Pattern Printing
  * One-Dimensional & Multi-Dimensional Arrays
  * Strings & Character Arrays
  * User-Defined Functions & Parameters
  * Recursion Basics
  * Practical Laboratory Problems (Leap year, Prime check, Fibonacci, Armstrong number, Factorial)
* **4 Extra Enrichment Modules (Non-Syllabus):**
  * Linear & Binary Search
  * Bubble Sort & Selection Sort
  * Number Theory (Euclidean GCD, LCM & Prime Sieve)
  * Mini Projects (Interactive Number Guessing Game & Calculator)
  * *Clearly identified with purple tags and filter chips so students are never confused about board exam requirements.*

### 3. 🎯 Board Exam Questions & Solutions (CQ & MCQ)
* Comprehensive collection of creative questions (CQ) and multiple-choice questions (MCQ) from previous Dhaka, Rajshahi, Chittagong, Comilla, Sylhet, Barisal, Jessore, and Dinajpur Education Board exams.
* Detailed Bengali explanations, step-by-step logic breakdowns, and full working source code.

### 4. 🧠 Revision Quizzes & Flashcards
* Topic-wise interactive quizzes with instant score tracking, correct answer explanations, and progress metrics.
* Smooth flip-card animations for quick formula, header file, and syntax recall.

### 5. 🛡️ 100% Offline & Private
* Powered by local **Room Database** and Android DataStore.
* No account registration, telemetry, or internet access required.

---

## 🏗️ Architecture & Technical Stack

The project follows modern Android architecture guidelines (MVVM + Clean Architecture) with reactive UI state management:

```
app/src/main/java/com/example/
├── compiler/              # Custom C Compiler / Interpreter Engine
│   ├── CToken.kt          # Token definitions & TokenType enum
│   ├── CLexer.kt          # Lexical analyzer / Tokenizer
│   ├── CAST.kt            # Abstract Syntax Tree nodes (Expressions & Statements)
│   ├── CParser.kt         # Recursive descent parser with operator precedence
│   ├── CInterpreter.kt    # AST Tree-walking evaluator with Kotlin Coroutines
│   └── CRuntimeEngine.kt  # High-level execution coordinator
├── data/
│   ├── database/          # Room DB entities (Lessons, Quizzes, Flashcards, Progress)
│   ├── repository/        # Data repositories & syllabus data sources
│   └── model/             # Domain data models
├── ui/
│   ├── components/        # Reusable Compose UI components (CodeView, Cards, Chips)
│   ├── screens/           # Main navigation screens
│   │   ├── HomeScreen.kt
│   │   ├── LessonListScreen.kt
│   │   ├── LessonDetailScreen.kt
│   │   ├── PlaygroundScreen.kt
│   │   ├── BoardQuestionsScreen.kt
│   │   ├── QuizScreen.kt
│   │   └── FlashcardScreen.kt
│   ├── theme/             # Material 3 ColorScheme, Typography & Shapes
│   └── viewmodel/         # Screen ViewModels managing StateFlow
└── MainActivity.kt        # App entry point with Jetpack Navigation
```

### Tech Stack Details:
| Component | Technology |
|---|---|
| **Language** | Kotlin 2.x |
| **UI Framework** | Jetpack Compose (Material Design 3) |
| **Architecture** | MVVM + Repository Pattern |
| **Local Persistence** | AndroidX Room Database 2.6+ with KSP |
| **Concurrency** | Kotlin Coroutines & `StateFlow` |
| **Secrets Management**| Google Secrets Gradle Plugin + `.env.example` |
| **Target SDK** | Android 15 / 16 (API Level 36) |
| **Minimum SDK** | Android 7.0 (API Level 24) |
| **Application ID** | `com.hsc.c.prog` |

---

## ⚙️ How the Custom C Interpreter Works

Unlike traditional mobile IDEs that require native C binaries (like GCC, Clang, or TinyCC via Android NDK) or external cloud servers, this app includes a **pure Kotlin AST interpreter**:

```
[ C Source Code ]
       │
       ▼
 [ CLexer.kt ]         ──> Breaks source code into a stream of tokens
       │                   (Keywords, Identifiers, Operators, Literals)
       ▼
 [ CParser.kt ]        ──> Validates C grammar using Recursive Descent and
       │                   builds an Abstract Syntax Tree (AST)
       ▼
[ CInterpreter.kt ]    ──> Evaluates AST nodes using an execution environment,
       │                   symbol tables, and call stacks
       ▼
[ Jetpack Compose UI ] ──> Streams output chunks to interactive terminal and
                           pauses/resumes for `scanf()` dialogs via Coroutines
```

### Advantages of this Architecture:
1. **Zero NDK / JNI Overhead:** No native `.so` binaries for ARM/x86 architectures, resulting in a lightweight APK.
2. **First-Class Coroutine Suspension:** Enables smooth interactive input handling for `scanf()` without blocking the Android UI thread.
3. **Sandbox Safety:** Immune to buffer overflows, malicious memory corruption, or unauthorized system access.
4. **Localized Error Diagnostics:** Produces human-friendly Bengali diagnostic messages specifically targeted at common student mistakes.

---

## 🚀 Getting Started

### Prerequisites
* **Android Studio** Ladybug (2024.2.1) or newer.
* **JDK:** Version 17 or higher.
* **Android SDK:** Platform API 36 with Build-Tools.

### Installation & Build

1. **Clone the repository:**
   ```bash
   git clone https://github.com/your-username/hsc-c-programming.git
   cd hsc-c-programming
   ```

2. **Verify Environment Configuration:**
   Ensure the root directory contains `.env.example`:
   ```bash
   # This template file is required by the Secrets Gradle Plugin
   ls -la .env.example
   ```

3. **Open in Android Studio:**
   * Launch Android Studio.
   * Select **Open** and choose the project directory.
   * Allow Gradle to sync dependencies automatically.

4. **Run on Device or Emulator:**
   * Connect an Android device (USB Debugging enabled) or start an Android Virtual Device (AVD).
   * Click **Run (Shift + F10)**.

---

## 🧪 Testing

The project includes an extensive suite of local JVM unit tests validating all compiler phases, language features, and algorithms without requiring an emulator:

```bash
gradle :app:testDebugUnitTest
```

### Verified Test Cases:
* **Lexer & Parser Grammar:** Tokenization of keywords, numbers, string literals, and complex expressions.
* **Arithmetic & Precedence:** Operator evaluation order (`+`, `-`, `*`, `/`, `%`).
* **Control Flow:** `if-else` branching, nested `for`, and `while` loops.
* **Function Calls & Recursion:** Call stack frames, return values, recursive Fibonacci and Factorial.
* **Array Memory & Initializers:** Array indexing (`arr[i]`), bounds checking, and `{10, 20, 30}` initializer lists.
* **Algorithms:** Bubble sort and Euclidean GCD verification.
* **Interactive I/O:** Coroutine suspension during chained `scanf()` input requests.

---

## 📄 License

This project is licensed under the **MIT License**. You are free to use, modify, and distribute this application for educational purposes.

---

*Made with ❤️ for HSC students across Bangladesh.*
