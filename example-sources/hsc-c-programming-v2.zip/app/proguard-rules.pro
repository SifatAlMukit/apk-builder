# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Preserve line numbers and source file names for crash reporting and stack traces
-keepattributes SourceFile,LineNumberTable
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Android Architecture Components - ViewModel reflection
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    public <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel {
    public <init>(...);
}

# Room Database rules
-keep class * extends androidx.room.RoomDatabase {
    <init>();
    <methods>;
}
-keep class * extends androidx.room.RoomDatabase_Impl { *; }
-keep @androidx.room.Entity class * { *; }
-keep @androidx.room.Dao interface * { *; }
-keep class * implements com.example.data.local.AppDao { *; }
-dontwarn androidx.room.paging.**

# Data Models, Repositories, and Local Storage
-keep class com.example.core.model.** { *; }
-keep class com.example.data.local.** { *; }
-keep class com.example.data.repository.** { *; }

# C Compiler AST, Tokenizer, and Interpreter
-keep class com.example.compiler.** { *; }

# Kotlin Enums - preserve values() and valueOf()
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}

# Kotlin Coroutines
-keepclassmembers class kotlinx.coroutines.internal.MainDispatcherFactory {
    public *;
}
-keepclassmembers class kotlinx.coroutines.CoroutineExceptionHandler {
    public *;
}
-dontwarn kotlinx.coroutines.**

# Compose Rules
-keepclassmembers class * extends androidx.compose.runtime.State { *; }
-keepclassmembers class androidx.compose.runtime.Recomposer { *; }

# Firebase & Google Services
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# DataStore
-dontwarn androidx.datastore.**


