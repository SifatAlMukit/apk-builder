package com.example

import com.example.compiler.CRuntimeEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testCInterpreter_helloWorld() {
    val code = """
      #include <stdio.h>
      int main() {
          printf("Hello HSC C");
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue(result.isSuccess)
    assertEquals("Hello HSC C", result.output.trim())
    assertEquals(0, result.exitCode)
  }

  @Test
  fun testCInterpreter_forLoopAndSum() {
    val code = """
      #include <stdio.h>
      int main() {
          int sum = 0;
          for (int i = 1; i <= 5; i++) {
              sum += i;
          }
          printf("Sum=%d", sum);
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue(result.isSuccess)
    assertEquals("Sum=15", result.output.trim())
  }

  @Test
  fun testCInterpreter_conditionals() {
    val code = """
      #include <stdio.h>
      int main() {
          int a = 10, b = 20;
          if (a > b) {
              printf("A");
          } else {
              printf("B");
          }
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue(result.isSuccess)
    assertEquals("B", result.output.trim())
  }

  @Test
  fun testCInterpreter_recursionFactorial() {
    val code = """
      #include <stdio.h>
      int fact(int n) {
          if (n <= 1) return 1;
          return n * fact(n - 1);
      }
      int main() {
          printf("Fact=%d", fact(5));
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue(result.isSuccess)
    assertEquals("Fact=120", result.output.trim())
  }

  @Test
  fun testCInterpreter_interactiveScanf() {
    runBlocking {
      val code = """
        #include <stdio.h>
        int main() {
            int a, b;
            printf("Enter A: ");
            scanf("%d", &a);
            printf("Enter B: ");
            scanf("%d", &b);
            printf("Total=%d\n", a + b);
            return 0;
        }
      """.trimIndent()

      val outputStream = StringBuilder()
      val inputQueue = mutableListOf("12", "30")

      val result = CRuntimeEngine.compileAndExecuteInteractive(
          sourceCode = code,
          onOutput = { chunk -> outputStream.append(chunk) },
          onInputRequest = {
              val nextVal = inputQueue.removeFirst()
              outputStream.append("$nextVal\n")
              nextVal
          }
      )

      assertTrue(result.isSuccess)
      val fullOutput = outputStream.toString()
      assertTrue(fullOutput.contains("Enter A: 12"))
      assertTrue(fullOutput.contains("Enter B: 30"))
      assertTrue(fullOutput.contains("Total=42"))
    }
  }

  @Test
  fun testCInterpreter_arrayInitializerAndSearch() {
    val code = """
      #include <stdio.h>
      int main() {
          int arr[5] = {10, 25, 42, 68, 99};
          int target = 42;
          int found = 0;
          for (int i = 0; i < 5; i++) {
              if (arr[i] == target) {
                  found = 1;
                  printf("Found at %d", i);
                  break;
              }
          }
          if (!found) printf("Not found");
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue("Execution should succeed. Error: ${result.error}", result.isSuccess)
    assertTrue("Output: ${result.output}", result.output.contains("Found at 2"))
  }

  @Test
  fun testCInterpreter_bubbleSort() {
    val code = """
      #include <stdio.h>
      int main() {
          int arr[4] = {40, 10, 30, 20};
          for (int i = 0; i < 3; i++) {
              for (int j = 0; j < 3 - i; j++) {
                  if (arr[j] > arr[j + 1]) {
                      int temp = arr[j];
                      arr[j] = arr[j + 1];
                      arr[j + 1] = temp;
                  }
              }
          }
          for (int i = 0; i < 4; i++) {
              printf("%d ", arr[i]);
          }
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue("Execution should succeed. Error: ${result.error}", result.isSuccess)
    assertEquals("10 20 30 40", result.output.trim())
  }

  @Test
  fun testCInterpreter_euclideanGcd() {
    val code = """
      #include <stdio.h>
      int findGCD(int a, int b) {
          while (b != 0) {
              int r = a % b;
              a = b;
              b = r;
          }
          return a;
      }
      int main() {
          printf("GCD=%d", findGCD(56, 98));
          return 0;
      }
    """.trimIndent()
    val result = CRuntimeEngine.compileAndExecute(code)
    assertTrue("Execution should succeed. Error: ${result.error}", result.isSuccess)
    assertEquals("GCD=14", result.output.trim())
  }
}
