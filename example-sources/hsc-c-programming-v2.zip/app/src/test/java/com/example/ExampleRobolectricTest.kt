package com.example

import android.content.Context
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.ComposeNavigator
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.test.core.app.ApplicationProvider
import com.example.presentation.navigation.Screen
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @get:Rule
  val composeTestRule = createComposeRule()

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("HSC C প্রোগ্রামিং", appName)
  }

  @Test
  fun testAllBottomNavScenarios() {
    var currentNav: androidx.navigation.NavHostController? = null
    composeTestRule.setContent {
      val navController = rememberNavController()
      currentNav = navController
      NavHost(navController = navController, startDestination = "home") {
        composable("home") {}
        composable("course") {}
        composable("playground") {}
        composable("lesson/{lessonId}") {}
      }
    }

    composeTestRule.runOnIdle {
      val nav = currentNav!!

      fun navigateTab(route: String) {
        if (nav.currentDestination?.route != route) {
          val isStart = route == "home"
          nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) {
              saveState = !isStart
            }
            launchSingleTop = true
            restoreState = !isStart
          }
        }
      }

      // Scenario 1: Open playground from bottom bar, then click home
      navigateTab("playground")
      assertEquals("playground", nav.currentDestination?.route)
      navigateTab("home")
      assertEquals("home", nav.currentDestination?.route)

      // Scenario 2: Open playground from card (without any options), then click home in bottom bar
      nav.navigate("playground")
      assertEquals("playground", nav.currentDestination?.route)
      navigateTab("home")
      assertEquals("home", nav.currentDestination?.route)

      // Scenario 3: Open lesson detail (nested screen), then click home in bottom bar
      nav.navigate("lesson/lesson_1")
      assertEquals("lesson/{lessonId}", nav.currentDestination?.route)
      navigateTab("home")
      assertEquals("home", nav.currentDestination?.route)

      // Scenario 4: Open playground via card with tab navigation semantics, then click home in bottom bar
      navigateTab("playground")
      assertEquals("playground", nav.currentDestination?.route)
      navigateTab("home")
      assertEquals("home", nav.currentDestination?.route)

      // Scenario 5: Switch between tabs (playground -> course -> home)
      navigateTab("playground")
      assertEquals("playground", nav.currentDestination?.route)
      navigateTab("course")
      assertEquals("course", nav.currentDestination?.route)
      navigateTab("home")
      assertEquals("home", nav.currentDestination?.route)
    }
  }
}


