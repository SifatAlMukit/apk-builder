package com.example.presentation.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.compiler.CSyntaxHighlighter
import com.example.ui.theme.CodeBackgroundDark

@Composable
fun CodeBlockView(
    title: String,
    code: String,
    expectedOutput: String? = null,
    explanation: String? = null,
    onRunInPlayground: ((String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    var copied by remember { mutableStateOf(false) }
    var showOutput by remember { mutableStateOf(true) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        border = if (!isDark) androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)) else null,
        colors = CardDefaults.cardColors(containerColor = if (isDark) CodeBackgroundDark else Color(0xFFF8FAFC))
    ) {
        Column {
            // Header bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isDark) Color(0xFF1E222D) else Color(0xFFEDF2F7))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFFFF5F56))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFFFFBD2E))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFF27C93F))
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        color = if (isDark) Color(0xFFE0E0E0) else Color(0xFF334155),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Copy button
                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("C Code", code)
                            clipboard.setPrimaryClip(clip)
                            copied = true
                            Toast.makeText(context, "কোড কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("copy_code_btn")
                    ) {
                        Icon(
                            imageVector = if (copied) Icons.Outlined.Check else Icons.Default.ContentCopy,
                            contentDescription = "কোড কপি করুন",
                            tint = if (copied) Color(0xFF4CAF50) else (if (isDark) Color(0xFFB0BEC5) else Color(0xFF64748B)),
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    if (onRunInPlayground != null) {
                        Spacer(modifier = Modifier.width(4.dp))
                        FilledTonalButton(
                            onClick = { onRunInPlayground(code) },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("run_in_playground_btn"),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF0077B6),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("রান করুন", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }

            // Code lines with gutter
            val lines = remember(code) { code.lines() }
            val highlightedCode = remember(code, isDark) { CSyntaxHighlighter.highlight(code, isDarkTheme = isDark) }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .horizontalScroll(rememberScrollState())
            ) {
                // Line numbers
                Column(
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .widthIn(min = 24.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    lines.indices.forEach { index ->
                        Text(
                            text = "${index + 1}",
                            color = if (isDark) Color(0xFF5C6B73) else Color(0xFF94A3B8),
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace,
                            lineHeight = 20.sp
                        )
                    }
                }

                // Code text
                Text(
                    text = highlightedCode,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    lineHeight = 20.sp,
                    color = if (isDark) Color(0xFFECEFF1) else Color(0xFF0F172A)
                )
            }

            // Expected Output box
            if (!expectedOutput.isNullOrBlank()) {
                HorizontalDivider(color = if (isDark) Color(0xFF2C3240) else Color(0xFFE2E8F0))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (isDark) Color(0xFF0D1117) else Color(0xFFF1F5F9))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "প্রত্যাশিত আউটপুট:",
                        color = if (isDark) Color(0xFF81D4FA) else Color(0xFF0284C7),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = expectedOutput,
                        color = if (isDark) Color(0xFFA5D6A7) else Color(0xFF1B5E20),
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 18.sp
                    )

                    if (!explanation.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "ব্যাখ্যা: $explanation",
                            color = if (isDark) Color(0xFFB0BEC5) else Color(0xFF475569),
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
