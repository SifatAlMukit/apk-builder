package com.example.compiler

enum class TokenType {
    // Keywords
    INT, FLOAT, DOUBLE, CHAR, VOID,
    RETURN, IF, ELSE, FOR, WHILE, DO, SWITCH, CASE, DEFAULT, BREAK, CONTINUE,
    
    // Preprocessor
    INCLUDE, DEFINE,
    
    // Literals & Identifiers
    IDENTIFIER,
    INT_LITERAL,
    FLOAT_LITERAL,
    CHAR_LITERAL,
    STRING_LITERAL,
    
    // Operators
    PLUS, MINUS, STAR, SLASH, PERCENT,
    PLUS_PLUS, MINUS_MINUS,
    EQUAL_EQUAL, NOT_EQUAL, LESS, LESS_EQUAL, GREATER, GREATER_EQUAL,
    AMP_AMP, PIPE_PIPE, BANG,
    AMP, PIPE, CARET,
    QUESTION, COLON,
    ASSIGN, PLUS_ASSIGN, MINUS_ASSIGN, STAR_ASSIGN, SLASH_ASSIGN, PERCENT_ASSIGN,
    
    // Delimiters
    SEMICOLON, COMMA, DOT,
    LPAREN, RPAREN,
    LBRACE, RBRACE,
    LBRACKET, RBRACKET,
    
    EOF
}

data class Token(
    val type: TokenType,
    val text: String,
    val line: Int,
    val col: Int,
    val literal: Any? = null
)

class CLexer(private val source: String) {
    private var start = 0
    private var current = 0
    private var line = 1
    private var col = 1
    private val tokens = mutableListOf<Token>()

    companion object {
        private val keywords = mapOf(
            "int" to TokenType.INT,
            "float" to TokenType.FLOAT,
            "double" to TokenType.DOUBLE,
            "char" to TokenType.CHAR,
            "void" to TokenType.VOID,
            "return" to TokenType.RETURN,
            "if" to TokenType.IF,
            "else" to TokenType.ELSE,
            "for" to TokenType.FOR,
            "while" to TokenType.WHILE,
            "do" to TokenType.DO,
            "switch" to TokenType.SWITCH,
            "case" to TokenType.CASE,
            "default" to TokenType.DEFAULT,
            "break" to TokenType.BREAK,
            "continue" to TokenType.CONTINUE
        )
    }

    fun scanTokens(): List<Token> {
        while (!isAtEnd()) {
            start = current
            scanToken()
        }
        tokens.add(Token(TokenType.EOF, "", line, col))
        return tokens
    }

    private fun scanToken() {
        when (val c = advance()) {
            ' ', '\r', '\t' -> { /* ignore whitespace */ }
            '\n' -> {
                line++
                col = 1
            }
            '(' -> addToken(TokenType.LPAREN)
            ')' -> addToken(TokenType.RPAREN)
            '{' -> addToken(TokenType.LBRACE)
            '}' -> addToken(TokenType.RBRACE)
            '[' -> addToken(TokenType.LBRACKET)
            ']' -> addToken(TokenType.RBRACKET)
            ';' -> addToken(TokenType.SEMICOLON)
            ',' -> addToken(TokenType.COMMA)
            '.' -> addToken(TokenType.DOT)
            '?' -> addToken(TokenType.QUESTION)
            ':' -> addToken(TokenType.COLON)
            '+' -> {
                when {
                    match('+') -> addToken(TokenType.PLUS_PLUS)
                    match('=') -> addToken(TokenType.PLUS_ASSIGN)
                    else -> addToken(TokenType.PLUS)
                }
            }
            '-' -> {
                when {
                    match('-') -> addToken(TokenType.MINUS_MINUS)
                    match('=') -> addToken(TokenType.MINUS_ASSIGN)
                    else -> addToken(TokenType.MINUS)
                }
            }
            '*' -> {
                if (match('=')) addToken(TokenType.STAR_ASSIGN)
                else addToken(TokenType.STAR)
            }
            '/' -> {
                if (match('/')) {
                    // Single line comment
                    while (peek() != '\n' && !isAtEnd()) advance()
                } else if (match('*')) {
                    // Multi-line comment
                    while (!isAtEnd() && !(peek() == '*' && peekNext() == '/')) {
                        if (peek() == '\n') {
                            line++
                            col = 1
                        }
                        advance()
                    }
                    if (!isAtEnd()) {
                        advance() // '*'
                        advance() // '/'
                    }
                } else if (match('=')) {
                    addToken(TokenType.SLASH_ASSIGN)
                } else {
                    addToken(TokenType.SLASH)
                }
            }
            '%' -> {
                if (match('=')) addToken(TokenType.PERCENT_ASSIGN)
                else addToken(TokenType.PERCENT)
            }
            '=' -> {
                if (match('=')) addToken(TokenType.EQUAL_EQUAL)
                else addToken(TokenType.ASSIGN)
            }
            '!' -> {
                if (match('=')) addToken(TokenType.NOT_EQUAL)
                else addToken(TokenType.BANG)
            }
            '<' -> {
                if (match('=')) addToken(TokenType.LESS_EQUAL)
                else addToken(TokenType.LESS)
            }
            '>' -> {
                if (match('=')) addToken(TokenType.GREATER_EQUAL)
                else addToken(TokenType.GREATER)
            }
            '&' -> {
                if (match('&')) addToken(TokenType.AMP_AMP)
                else addToken(TokenType.AMP)
            }
            '|' -> {
                if (match('|')) addToken(TokenType.PIPE_PIPE)
                else addToken(TokenType.PIPE)
            }
            '^' -> addToken(TokenType.CARET)
            '#' -> preprocessor()
            '"' -> stringLiteral()
            '\'' -> charLiteral()
            else -> {
                if (c.isDigit()) {
                    numberLiteral()
                } else if (c.isLetter() || c == '_') {
                    identifier()
                } else {
                    // Unknown character, skip gracefully
                }
            }
        }
    }

    private fun preprocessor() {
        while (peek().isLetter()) advance()
        val directive = source.substring(start, current)
        if (directive == "#include") {
            // Read until end of line
            while (peek() != '\n' && !isAtEnd()) advance()
            addToken(TokenType.INCLUDE, source.substring(start, current))
        } else if (directive == "#define") {
            while (peek() != '\n' && !isAtEnd()) advance()
            addToken(TokenType.DEFINE, source.substring(start, current))
        }
    }

    private fun stringLiteral() {
        val sb = StringBuilder()
        while (peek() != '"' && !isAtEnd()) {
            if (peek() == '\n') {
                line++
                col = 1
            }
            if (peek() == '\\') {
                advance()
                when (peek()) {
                    'n' -> sb.append('\n')
                    't' -> sb.append('\t')
                    '\\' -> sb.append('\\')
                    '"' -> sb.append('"')
                    '0' -> sb.append('\u0000')
                    else -> sb.append(peek())
                }
                advance()
            } else {
                sb.append(advance())
            }
        }
        if (!isAtEnd()) advance() // Closing quote
        addToken(TokenType.STRING_LITERAL, sb.toString())
    }

    private fun charLiteral() {
        var ch = ' '
        if (peek() == '\\') {
            advance()
            ch = when (advance()) {
                'n' -> '\n'
                't' -> '\t'
                '0' -> '\u0000'
                '\\' -> '\\'
                '\'' -> '\''
                else -> ' '
            }
        } else if (!isAtEnd()) {
            ch = advance()
        }
        if (peek() == '\'') advance() // Closing single quote
        addToken(TokenType.CHAR_LITERAL, ch)
    }

    private fun numberLiteral() {
        while (peek().isDigit()) advance()
        if (peek() == '.' && peekNext().isDigit()) {
            advance() // Consume '.'
            while (peek().isDigit()) advance()
            val text = source.substring(start, current)
            addToken(TokenType.FLOAT_LITERAL, text.toDoubleOrNull() ?: 0.0)
        } else {
            val text = source.substring(start, current)
            addToken(TokenType.INT_LITERAL, text.toLongOrNull() ?: 0L)
        }
    }

    private fun identifier() {
        while (peek().isLetterOrDigit() || peek() == '_') advance()
        val text = source.substring(start, current)
        val type = keywords[text] ?: TokenType.IDENTIFIER
        addToken(type)
    }

    private fun advance(): Char {
        col++
        return source[current++]
    }

    private fun match(expected: Char): Boolean {
        if (isAtEnd() || source[current] != expected) return false
        current++
        col++
        return true
    }

    private fun peek(): Char = if (isAtEnd()) '\u0000' else source[current]
    private fun peekNext(): Char = if (current + 1 >= source.length) '\u0000' else source[current + 1]
    private fun isAtEnd(): Boolean = current >= source.length

    private fun addToken(type: TokenType, literal: Any? = null) {
        val text = source.substring(start, current)
        tokens.add(Token(type, text, line, col - (current - start), literal))
    }
}
