package com.example.core.model

data class Lesson(
    val id: String,
    val chapterNumber: Int,
    val titleBn: String,
    val titleEn: String,
    val subtitle: String,
    val durationMinutes: Int,
    val objectives: List<String>,
    val sections: List<LessonSection>,
    val flowcharts: List<FlowchartData> = emptyList(),
    val commonMistakes: List<MistakeItem> = emptyList(),
    val tips: List<String> = emptyList(),
    val practiceQuestions: List<PracticeQuestion> = emptyList(),
    val isExtra: Boolean = false
)

data class LessonSection(
    val title: String,
    val content: String,
    val codeExample: CodeExample? = null,
    val note: String? = null
)

data class CodeExample(
    val title: String,
    val code: String,
    val expectedOutput: String,
    val explanation: String
)

data class MistakeItem(
    val wrongCode: String,
    val correctCode: String,
    val explanation: String
)

data class PracticeQuestion(
    val question: String,
    val hint: String,
    val solutionCode: String
)

data class QuizQuestion(
    val id: String,
    val chapterId: String,
    val questionBn: String,
    val optionsBn: List<String>,
    val correctOptionIndex: Int,
    val explanationBn: String
)

data class GlossaryItem(
    val id: String,
    val termEn: String,
    val termBn: String,
    val category: String,
    val definitionBn: String,
    val example: String? = null
)

data class CheatSheetItem(
    val category: String,
    val titleBn: String,
    val items: List<CheatSheetEntry>
)

data class CheatSheetEntry(
    val symbolOrKeyword: String,
    val nameBn: String,
    val syntax: String,
    val descriptionBn: String,
    val example: String
)

data class MiniProject(
    val id: String,
    val titleBn: String,
    val titleEn: String,
    val difficulty: String,
    val overviewBn: String,
    val conceptsUsed: List<String>,
    val sourceCode: String,
    val sampleInput: String,
    val sampleOutput: String,
    val exercises: List<String>
)

data class FlowchartData(
    val id: String,
    val titleBn: String,
    val descriptionBn: String,
    val nodes: List<FlowchartNode>,
    val edges: List<FlowchartEdge>,
    val executionTrace: List<ExecutionStep>
)

data class FlowchartNode(
    val id: String,
    val labelBn: String,
    val subText: String? = null,
    val type: FlowchartNodeType,
    val x: Float,
    val y: Float
)

enum class FlowchartNodeType {
    START_END,
    INPUT_OUTPUT,
    PROCESS,
    DECISION
}

data class FlowchartEdge(
    val fromId: String,
    val toId: String,
    val labelBn: String? = null
)

data class ExecutionStep(
    val stepNumber: Int,
    val activeNodeId: String,
    val variableStateBn: String,
    val explanationBn: String
)
