package com.example.data.repository

import com.example.core.model.MiniProject

object ProjectsData {

    val projects: List<MiniProject> = listOf(
        MiniProject(
            id = "proj_student_result",
            titleBn = "HSC জিপিএ ও গ্রেডিং সিস্টেম",
            titleEn = "Student Result & GPA Calculator",
            difficulty = "সহজ (Beginner)",
            overviewBn = "৫টি বিষয়ের প্রাপ্ত নম্বর থেকে মোট নম্বর, শতকরা হার, লেটার গ্রেড এবং জিপিএ (GPA) হিসাব করার সম্পূর্ণ সি অ্যাপ্লিকেশন। বাংলাদেশ শিক্ষাবোর্ডের গ্রেডিং স্কেল অনুসরণ করা হয়েছে।",
            conceptsUsed = listOf("if-else ladder", "float ডেটা টাইপ", "গাণিতিক হিসাব", "ইনপুট/আউটপুট"),
            sourceCode = """
#include <stdio.h>

int main() {
    // বিষয়ভিত্তিক নম্বর
    int bangla = 82;
    int english = 75;
    int ict = 95;
    int physics = 88;
    int chemistry = 79;
    
    int total = bangla + english + ict + physics + chemistry;
    float avg = total / 5.0;
    
    printf("====================================\n");
    printf("     HSC ফলাফল ও গ্রেডিং শিট       \n");
    printf("====================================\n");
    printf("বাংলা:     %d\n", bangla);
    printf("ইংরেজি:    %d\n", english);
    printf("আইসিটি:    %d\n", ict);
    printf("পদার্থবিজ্ঞান: %d\n", physics);
    printf("রসায়ন:    %d\n", chemistry);
    printf("------------------------------------\n");
    printf("মোট প্রাপ্ত নম্বর: %d / 500\n", total);
    printf("গড় নম্বর:        %.2f%%\n", avg);
    
    // গ্রেড ও জিপিএ মূল্যায়ন
    if (avg >= 80) {
        printf("ফলাফল: A+ (GPA: 5.00) - অসাধারণ সাফল্য!\n");
    } else if (avg >= 70) {
        printf("ফলাফল: A  (GPA: 4.00) - চমৎকার\n");
    } else if (avg >= 60) {
        printf("ফলাফল: A- (GPA: 3.50) - ভালো\n");
    } else if (avg >= 50) {
        printf("ফলাফল: B  (GPA: 3.00) - সন্তোষজনক\n");
    } else if (avg >= 40) {
        printf("ফলাফল: C  (GPA: 2.00) - সাধারণ\n");
    } else if (avg >= 33) {
        printf("ফলাফল: D  (GPA: 1.00) - উত্তীর্ণ\n");
    } else {
        printf("ফলাফল: F  (GPA: 0.00) - অকৃতকার্য\n");
    }
    printf("====================================\n");
    return 0;
}
            """.trimIndent(),
            sampleInput = "",
            sampleOutput = """
====================================
     HSC ফলাফল ও গ্রেডিং শিট       
====================================
বাংলা:     82
ইংরেজি:    75
আইসিটি:    95
পদার্থবিজ্ঞান: 88
রসায়ন:    79
------------------------------------
মোট প্রাপ্ত নম্বর: 419 / 500
গড় নম্বর:        83.80%
ফলাফল: A+ (GPA: 5.00) - অসাধারণ সাফল্য!
====================================
            """.trimIndent(),
            exercises = listOf(
                "কোনো বিষয়ে ৩৩ এর কম পেলে সার্বিক ফলাফল F দেখানোর লজিক যোগ করো।",
                "অ্যারে ব্যবহার করে ব্যবহারকারীর কাছ থেকে যেকোনো সংখ্যক বিষয়ের নম্বর ইনপুট নাও।"
            )
        ),
        MiniProject(
            id = "proj_atm_simulator",
            titleBn = "ব্যাংক এটিএম (ATM) বুথ সিমুলেটর",
            titleEn = "Bank ATM Simulator",
            difficulty = "মাঝারি (Intermediate)",
            overviewBn = "বাস্তব এটিএম বুথের মতোই ৪ অঙ্কের পিন ভেরিফিকেশন, ব্যালেন্স চেক, টাকা উত্তোলন (Withdraw), টাকা জমা (Deposit) এবং মিনি স্টেটমেন্ট দেখার ইন্টারেক্টিভ কনসোল সিস্টেম।",
            conceptsUsed = listOf("while loop", "switch-case", "চলক অবস্থা সংরক্ষণ", "কন্ডিশনাল লজিক"),
            sourceCode = """
#include <stdio.h>

int main() {
    int pin = 1234;
    int enteredPin = 1234; // সিমুলেশনে পিন যাচাই
    int balance = 25000;
    
    printf("======================================\n");
    printf("       সোনালী ব্যাংক এটিএম বুথ       \n");
    printf("======================================\n");
    
    if (enteredPin != pin) {
        printf("ভুল পিন নম্বর! কার্ড ব্লক হতে পারে।\n");
        return 0;
    }
    
    printf("পিন যাচাই সফল! স্বাগতম।\n");
    printf("বর্তমান ব্যালেন্স: %d টাকা\n\n", balance);
    
    // উত্তোলন সিমুলেশন
    int withdrawAmount = 5000;
    printf("[লেনদেন ১] টাকা উত্তোলন অনুরোধ: %d টাকা\n", withdrawAmount);
    if (withdrawAmount <= balance) {
        balance -= withdrawAmount;
        printf("লেনদেন সফল! টাকা গ্রহণ করুন।\n");
        printf("অবশিষ্ট ব্যালেন্স: %d টাকা\n\n", balance);
    } else {
        printf("পর্যাপ্ত ব্যালেন্স নেই!\n\n");
    }
    
    // জমা সিমুলেশন
    int depositAmount = 10000;
    printf("[লেনদেন ২] টাকা জমা প্রদান: %d টাকা\n", depositAmount);
    balance += depositAmount;
    printf("টাকা সফলভাবে জমা হয়েছে।\n");
    printf("সর্বশেষ আপডেট ব্যালেন্স: %d টাকা\n", balance);
    printf("======================================\n");
    printf("  এটিএম বুথ ব্যবহারের জন্য ধন্যবাদ!   \n");
    printf("======================================\n");
    return 0;
}
            """.trimIndent(),
            sampleInput = "",
            sampleOutput = """
======================================
       সোনালী ব্যাংক এটিএম বুথ       
======================================
পিন যাচাই সফল! স্বাগতম।
বর্তমান ব্যালেন্স: 25000 টাকা

[লেনদেন ১] টাকা উত্তোলন অনুরোধ: 5000 টাকা
লেনদেন সফল! টাকা গ্রহণ করুন।
অবশিষ্ট ব্যালেন্স: 20000 টাকা

[লেনদেন ২] টাকা জমা প্রদান: 10000 টাকা
টাকা সফলভাবে জমা হয়েছে।
সর্বশেষ আপডেট ব্যালেন্স: 30000 টাকা
======================================
  এটিএম বুথ ব্যবহারের জন্য ধন্যবাদ!   
======================================
            """.trimIndent(),
            exercises = listOf(
                "সর্বোচ্চ ৩ বার ভুল পিন দিলে অ্যাকাউন্ট লক হওয়ার কাউন্টার লজিক যোগ করো।",
                "৫০০ ও ১০০০ টাকার নোটের সংখ্যা আলাদাভাবে গণনা করে প্রদর্শন করো।"
            )
        ),
        MiniProject(
            id = "proj_scientific_calculator",
            titleBn = "মাল্টি-ফাংশনাল ক্যালকুলেটর",
            titleEn = "Multi-Functional Calculator",
            difficulty = "মাঝারি (Intermediate)",
            overviewBn = "মৌলিক চার নিয়ম (+, -, *, /) ছাড়াও বর্গমূল (sqrt), ঘাত (power), পরমমান (abs) এবং শতকরা বের করার পূর্ণাঙ্গ সি ক্যালকুলেটর।",
            conceptsUsed = listOf("<math.h> লাইব্রেরি", "switch-case", "ফাংশন", "টাইপ কাস্টিং"),
            sourceCode = """
#include <stdio.h>
#include <math.h>

void showMenu() {
    printf("--- বৈজ্ঞানিক ক্যালকুলেটর ---\n");
    printf("১. যোগ (+)    ২. বিয়োগ (-)\n");
    printf("৩. গুণ (*)     ৪. ভাগ (/)\n");
    printf("৫. বর্গমূল (√) ৬. ঘাত (Power ^)\n");
    printf("-------------------------------\n");
}

int main() {
    showMenu();
    
    double a = 16.0;
    double b = 3.0;
    
    printf("সংখ্যাদ্বয়: a = %.1f, b = %.1f\n\n", a, b);
    
    printf("যোগফল:   %.1f + %.1f = %.2f\n", a, b, a + b);
    printf("বিয়োগফল: %.1f - %.1f = %.2f\n", a, b, a - b);
    printf("গুণফল:   %.1f * %.1f = %.2f\n", a, b, a * b);
    printf("ভাগফল:   %.1f / %.1f = %.2f\n", a, b, a / b);
    printf("বর্গমূল:  √%.1f = %.2f\n", a, sqrt(a));
    printf("ঘাত:     %.1f ^ %.1f = %.2f\n", a, b, pow(a, b));
    
    return 0;
}
            """.trimIndent(),
            sampleInput = "",
            sampleOutput = """
--- বৈজ্ঞানিক ক্যালকুলেটর ---
১. যোগ (+)    ২. বিয়োগ (-)
৩. গুণ (*)     ৪. ভাগ (/)
৫. বর্গমূল (√) ৬. ঘাত (Power ^)
-------------------------------
সংখ্যাদ্বয়: a = 16.0, b = 3.0

যোগফল:   16.0 + 3.0 = 19.00
বিয়োগফল: 16.0 - 3.0 = 13.00
গুণফল:   16.0 * 3.0 = 48.00
ভাগফল:   16.0 / 3.0 = 5.33
বর্গমূল:  √16.0 = 4.00
ঘাত:     16.0 ^ 3.0 = 4096.00
            """.trimIndent(),
            exercises = listOf(
                "ত্রিকোণমিতিক sin(), cos() এবং tan() অনুপাত গণনার অপশন যুক্ত করো।",
                "লগারিদম (log10) ফাংশন যুক্ত করো।"
            )
        ),
        MiniProject(
            id = "proj_guess_game",
            titleBn = "সংখ্যা অনুমানের রোমাঞ্চকর খেলা",
            titleEn = "Number Guessing Game",
            difficulty = "সহজ (Beginner)",
            overviewBn = "কম্পিউটার ১ থেকে ১০০ এর মধ্যে একটি গোপন সংখ্যা নির্ধারণ করে। খেলোয়াড় সংখ্যাটি অনুমান করার চেষ্টা করে এবং কম্পিউটার 'খুব বড়' বা 'খুব ছোট' ইঙ্গিত দিয়ে সাহায্য করে।",
            conceptsUsed = listOf("র‍্যান্ডম সংখ্যা", "while লুপ", "if-else", "কাউন্টার ট্র্যাকিং"),
            sourceCode = """
#include <stdio.h>

int main() {
    int secret = 42; // গোপন নির্ধারিত সংখ্যা
    int guesses[] = {20, 65, 38, 42}; // সিমুলেটেড খেলোয়াড়ের অনুমান
    int totalGuesses = 4;
    
    printf("=========================================\n");
    printf("     সংখ্যা অনুমানের খেলা (১ থেকে ১০০)    \n");
    printf("=========================================\n");
    
    for (int i = 0; i < totalGuesses; i++) {
        int guess = guesses[i];
        printf("চেষ্টা %d: খেলোয়াড় অনুমান করেছে %d\n", i + 1, guess);
        
        if (guess == secret) {
            printf(">>> অভিনন্দন! আপনি %d তম চেষ্টায় সঠিক সংখ্যা ধরেছেন! <<<\n", i + 1);
            break;
        } else if (guess < secret) {
            printf("ইঙ্গিত: গোপন সংখ্যাটি এর চেয়ে বড়! (Higher)\n\n");
        } else {
            printf("ইঙ্গিত: গোপন সংখ্যাটি এর চেয়ে ছোট! (Lower)\n\n");
        }
    }
    printf("=========================================\n");
    return 0;
}
            """.trimIndent(),
            sampleInput = "",
            sampleOutput = """
=========================================
     সংখ্যা অনুমানের খেলা (১ থেকে ১০০)    
=========================================
চেষ্টা 1: খেলোয়াড় অনুমান করেছে 20
ইঙ্গিত: গোপন সংখ্যাটি এর চেয়ে বড়! (Higher)

চেষ্টা 2: খেলোয়াড় অনুমান করেছে 65
ইঙ্গিত: গোপন সংখ্যাটি এর চেয়ে ছোট! (Lower)

চেষ্টা 3: খেলোয়াড় অনুমান করেছে 38
ইঙ্গিত: গোপন সংখ্যাটি এর চেয়ে বড়! (Higher)

চেষ্টা 4: খেলোয়াড় অনুমান করেছে 42
>>> অভিনন্দন! আপনি 4 তম চেষ্টায় সঠিক সংখ্যা ধরেছেন! <<<
=========================================
            """.trimIndent(),
            exercises = listOf(
                "সর্বোচ্চ ৭ বারের মধ্যে অনুমান করতে না পারলে Game Over দেখাও।",
                "চেষ্টার সংখ্যার উপর ভিত্তি করে স্কোর (যেমন: ১০০ - চেষ্টা * ১০) হিসাব করো।"
            )
        ),
        MiniProject(
            id = "proj_billing_system",
            titleBn = "সুপারশপ ক্যাশ মেমো ও বিলিং সিস্টেম",
            titleEn = "Supermarket Billing System",
            difficulty = "উন্নত (Advanced)",
            overviewBn = "গ্রাহকের একাধিক পণ্যের পরিমাণ ও একক মূল্য দিয়ে সাবটোটাল, ভ্যাট (১৫%), বিশেষ ছাড় (Discount) এবং নেট পরিশোধযোগ্য বিল সম্বলিত প্রিন্টেড ক্যাশ মেমো তৈরি।",
            conceptsUsed = listOf("অ্যারে", "স্ট্রাকচার (struct)", "লুপ", "ট্যাবুলার আউটপুট ফরম্যাটিং"),
            sourceCode = """
#include <stdio.h>

struct Product {
    int id;
    int qty;
    float unitPrice;
};

int main() {
    struct Product items[3] = {
        {101, 2, 120.0}, // পণ্য ১
        {102, 5, 45.0},  // পণ্য ২
        {103, 1, 350.0}  // পণ্য ৩
    };
    
    float subtotal = 0;
    
    printf("===================================================\n");
    printf("              স্বপ্ন সুপারশপ ক্যাশ মেমো            \n");
    printf("===================================================\n");
    printf("আইডি    পরিমাণ      একক মূল্য(টাকা)     মোট(টাকা)\n");
    printf("---------------------------------------------------\n");
    
    for (int i = 0; i < 3; i++) {
        float itemTotal = items[i].qty * items[i].unitPrice;
        subtotal += itemTotal;
        printf("#%d\t  %d\t\t%.2f\t\t%.2f\n", 
               items[i].id, items[i].qty, items[i].unitPrice, itemTotal);
    }
    
    float discount = 0.0;
    if (subtotal >= 500) {
        discount = subtotal * 0.10; // ১০% ছাড়
    }
    
    float vat = (subtotal - discount) * 0.05; // ৫% ভ্যাট
    float netPayable = (subtotal - discount) + vat;
    
    printf("---------------------------------------------------\n");
    printf("উপমোট (Subtotal):                 %.2f টাকা\n", subtotal);
    printf("বিশেষ ছাড় (10%% Discount):       -%.2f টাকা\n", discount);
    printf("ভ্যাট (5%% VAT):                   +%.2f টাকা\n", vat);
    printf("===================================================\n");
    printf("সর্বমোট প্রদেয় বিল (Net Total):   %.2f টাকা\n", netPayable);
    printf("===================================================\n");
    printf("           আমাদের সাথে কেনাকাটায় ধন্যবাদ!         \n");
    return 0;
}
            """.trimIndent(),
            sampleInput = "",
            sampleOutput = """
===================================================
              স্বপ্ন সুপারশপ ক্যাশ মেমো            
===================================================
আইডি    পরিমাণ      একক মূল্য(টাকা)     মোট(টাকা)
---------------------------------------------------
#101	  2		120.00		240.00
#102	  5		45.00		225.00
#103	  1		350.00		350.00
---------------------------------------------------
উপমোট (Subtotal):                 815.00 টাকা
বিশেষ ছাড় (10% Discount):       -81.50 টাকা
ভ্যাট (5% VAT):                   +36.68 টাকা
===================================================
সর্বমোট প্রদেয় বিল (Net Total):   770.18 টাকা
===================================================
           আমাদের সাথে কেনাকাটায় ধন্যবাদ!         
            """.trimIndent(),
            exercises = listOf(
                "কুপন কোড (যেমন: \"EID2024\") মিললে অতিরিক্ত ৫% ছাড় যোগ করো।",
                "গ্রাহকের দেওয়া নগদ টাকা থেকে ফেরতযোগ্য খুচরা টাকা হিসাব করো।"
            )
        )
    )
}
