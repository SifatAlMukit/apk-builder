package com.example.data.repository

import com.example.core.model.*

object LessonData {
    val lessons: List<Lesson> = listOf(
        Lesson(
            id = "lesson_1",
            chapterNumber = 1,
            titleBn = "প্রোগ্রামিং ভাষা ও এর ইতিহাস",
            titleEn = "Introduction to Programming & C",
            subtitle = "প্রোগ্রামের ধারণা, ভাষার প্রজন্ম এবং সি ভাষার পটভূমি",
            durationMinutes = 15,
            objectives = listOf(
                "প্রোগ্রাম ও প্রোগ্রামিং ভাষার মৌলিক ধারণা অর্জন",
                "ভাষার ৫টি প্রজন্মের (1GL থেকে 5GL) বৈশিষ্ট্য জানা",
                "সি ভাষার উৎপত্তির ইতিহাস ও এর গুরুত্ব অনুধাবন",
                "মধ্যম স্তরের ভাষা (Middle Level Language) হিসেবে সি-এর অবস্থান বোঝা"
            ),
            sections = listOf(
                LessonSection(
                    title = "প্রোগ্রাম ও প্রোগ্রামিং ভাষা কী?",
                    content = """
কম্পিউটার নিজে থেকে কোনো সিদ্ধান্ত নিতে পারে না। কোনো নির্দিষ্ট সমস্যা সমাধানের জন্য কম্পিউটারের বোধগম্য ভাষায় ধারাবাহিকভাবে লেখা নির্দেশনাবলীকে 'প্রোগ্রাম' (Program) বলা হয়। আর যে সাংকেতিক ভাষার মাধ্যমে এই নির্দেশনাগুলো লেখা হয়, তাকে 'প্রোগ্রামিং ভাষা' (Programming Language) বলে।

১৯৭২ সালে আমেরিকার এটিঅ্যান্ডটি বেল ল্যাবরেটরিতে (AT&T Bell Laboratories) কম্পিউটার বিজ্ঞানী ডেনিস রিচি (Dennis Ritchie) ইউনিক্স (UNIX) অপারেটিং সিস্টেম উন্নয়নের উদ্দেশ্যে 'সি' (C) প্রোগ্রামিং ভাষা উদ্ভাবন করেন। এটি বি (B) ভাষার উত্তরসূরি হিসেবে তৈরি হয়েছিল।
                    """.trimIndent(),
                    note = "সি ভাষাকে 'মাদার অব অল ল্যাঙ্গুয়েজ' বা সব আধুনিক ভাষার জননী বলা হয়, কারণ C++, Java, C#, PHP ইত্যাদি ভাষার ভিত্তি সি থেকে এসেছে।"
                ),
                LessonSection(
                    title = "প্রোগ্রামিং ভাষার স্তর ও প্রজন্ম (Generations)",
                    content = """
কম্পিউটার ভাষার বিকাশের ধারাকে ৫টি প্রজন্মে ভাগ করা হয়:
১. ১ম প্রজন্ম (1GL - 1945): মেশিন ভাষা (Machine Language) - শুধুমাত্র ০ ও ১ দিয়ে লেখা সরাসরি হার্ডওয়্যারে চলা ভাষা।
২. ২য় প্রজন্ম (2GL - 1950): অ্যাসেম্বলি ভাষা (Assembly Language) - নেমোনিক কোড (যেমন ADD, SUB, MOV) ব্যবহারের ভাষা।
৩. ৩য় প্রজন্ম (3GL - 1960): উচ্চস্তরের ভাষা (High Level Language) - মানুষের স্বাভাবিক ইংরেজি ভাষার কাছাকাছি ভাষা (যেমন C, BASIC, Pascal, FORTRAN)।
৪. ৪র্থ প্রজন্ম (4GL - 1970): অতি উচ্চস্তরের ভাষা (Very High Level Language) - ডেটাবেস কোয়েরি ভাষা (যেমন SQL)।
৫. ৫ম প্রজন্ম (5GL - 1980): স্বাভাবিক ভাষা ও কৃত্রিম বুদ্ধিমত্তা ভিত্তিক ভাষা (PROLOG, LISP)।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "সি ভাষাকে কেন মধ্যম স্তরের ভাষা বলা হয়?",
                    content = """
সি এমন একটি ভাষা যাতে উচ্চস্তরের ভাষার মতো সহজ সিনট্যাক্স, ফাংশন ও ডেটা স্ট্রাকচার ব্যবহার করা যায়, আবার নিম্নস্তরের ভাষার মতো সরাসরি মেমোরি অ্যাড্রেস (পয়েন্টার ও বিটওয়াইজ অপারেশনের মাধ্যমে) নিয়ন্ত্রণ করা যায়। এই দ্বৈত সুবিধার জন্যই সি-কে মধ্যম স্তরের ভাষা (Middle-level Language) বলা হয়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "প্রথম সি প্রোগ্রাম: স্বাগতম বার্তা",
                        code = """
#include <stdio.h>

int main() {
    printf("স্বাগতম! সি প্রোগ্রামিং জগতে।\n");
    printf("HSC ICT অধ্যায় ৫ শুরু হলো।\n");
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "স্বাগতম! সি প্রোগ্রামিং জগতে।\nHSC ICT অধ্যায় ৫ শুরু হলো।",
                        explanation = "#include <stdio.h> একটি হেডার ফাইল যা printf() ফাংশন ব্যবহারের অনুমতি দেয়। main() হলো মূল ফাংশন যেখানে কোড রান হওয়া শুরু হয়।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "printf(\"Hello World\")",
                    correctCode = "printf(\"Hello World\");",
                    explanation = "সি ভাষার প্রতিটি স্টেটমেন্টের শেষে অবশ্যই সেমিকোলন (;) দিতে হয়।"
                ),
                MistakeItem(
                    wrongCode = "MAIN() { ... }",
                    correctCode = "int main() { ... }",
                    explanation = "সি একটি কেস-সেনসিটিভ (Case-sensitive) ভাষা। main ছোট হাতের অক্ষরে লিখতে হবে এবং রিটার্ন টাইপ int থাকা আদর্শ।"
                )
            ),
            tips = listOf(
                "এইচএসসি পরীক্ষায় সি ভাষার জনক ডেনিস রিচি এবং উদ্ভাবনকাল ১৯৭২ সাল সম্পর্কিত বহুনির্বাচনী প্রায়ই আসে।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "সি প্রোগ্রাম ব্যবহার করে নিজের নাম ও কলেজের নাম কনসোলে প্রিন্ট করো।",
                    hint = "দুটি পৃথক printf() স্টেটমেন্ট ও newline (\\n) ব্যবহার করো।",
                    solutionCode = """
#include <stdio.h>

int main() {
    printf("নাম: আব্দুল্লাহ আল সাকিব\n");
    printf("কলেজ: নটর ডেম কলেজ, ঢাকা\n");
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_2",
            chapterNumber = 2,
            titleBn = "অনুবাদক প্রোগ্রাম ও সি প্রোগ্রামের গঠন",
            titleEn = "Translators & Program Structure",
            subtitle = "কম্পাইলার, ইন্টারপ্রেটার, অ্যাসেম্বলার এবং সি কোডের মৌলিক কাঠামো",
            durationMinutes = 20,
            objectives = listOf(
                "অনুবাদক প্রোগ্রামের ৩টি প্রকারভেদ অনুধাবন করা",
                "কম্পাইলার ও ইন্টারপ্রেটারের মধ্যে সুস্পষ্ট পার্থক্য জানা",
                "সি প্রোগ্রামের ৬টি মৌলিক অংশের সাথে পরিচিত হওয়া",
                "কমেন্ট (মন্তব্য) লেখার নিয়ম শেখা"
            ),
            sections = listOf(
                LessonSection(
                    title = "অনুবাদক প্রোগ্রাম (Translator Program)",
                    content = """
কম্পিউটার শুধুমাত্র মেশিন ভাষা (০ ও ১) বুঝতে পারে। উচ্চস্তরের ভাষায় লেখা সোর্স কোডকে কম্পিউটারের বোধগম্য অবজেক্ট কোডে রূপান্তর করতে অনুবাদক প্রোগ্রাম প্রয়োজন।
অনুবাদক প্রোগ্রাম ৩ প্রকার:
১. কম্পাইলার (Compiler): সম্পূর্ণ সোর্স প্রোগ্রামকে একসাথে অনুবাদ করে এবং সব ভুল একসাথে প্রদর্শন করে। অনুবাদ দ্রুত হয়। যেমন: GCC, Turbo C.
২. ইন্টারপ্রেটার (Interpreter): সোর্স প্রোগ্রামকে প্রতি লাইনে একটি করে পড়ে এবং অনুবাদ করে রান করে। কোনো লাইনে ভুল পেলে সেখানেই থেমে যায়। যেমন: Python.
৩. অ্যাসেম্বলার (Assembler): অ্যাসেম্বলি ভাষার নেমোনিক কোডকে মেশিন কোডে রূপান্তর করে।
                    """.trimIndent(),
                    note = "এইচএসসি পরীক্ষার জন্য কম্পাইলার বনাম ইন্টারপ্রেটারের পার্থক্য অত্যন্ত গুরুত্বপূর্ণ প্রশ্ন!"
                ),
                LessonSection(
                    title = "সি প্রোগ্রামের আদর্শ গঠন (Basic Structure)",
                    content = """
একটি আদর্শ সি প্রোগ্রামে সাধারণত ৬টি অংশ থাকে:
১. ডকুমেন্টেশন সেকশন (Documentation Section): প্রোগ্রামের উদ্দেশ্য, লেখকের নাম ইত্যাদি কমেন্টে লেখা হয়।
২. লিংক সেকশন (Link Section): প্রয়োজনীয় হেডার ফাইল লিংক করা হয়, যেমন #include <stdio.h>
৩. ডেফিনিশন সেকশন (Definition Section): ধ্রুবক ডিফাইন করা হয়, যেমন #define PI 3.1416
৪. গ্লোবাল ডিক্লেয়ারেশন (Global Declaration): সমগ্র প্রোগ্রামে ব্যবহারযোগ্য চলক ঘোষণা।
৫. মেইন ফাংশন সেকশন (main() Function Section): প্রোগ্রামের মূল অংশ; প্রতিটি সি প্রোগ্রামে একটিই main() থাকে।
৬. সাব-প্রোগ্রাম সেকশন (Sub-program Section): ব্যবহারকারীর তৈরি নিজস্ব ফাংশনসমূহ (User-defined functions)।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "সি প্রোগ্রামের কাঠামোর বাস্তব নমুনা",
                        code = """
/*
 * প্রোগ্রাম: বৃত্তের ক্ষেত্রফল নির্ণয়
 * উদ্দেশ্য: সি কাঠামোর উদাহরণ প্রদর্শন
 */
#include <stdio.h>
#define PI 3.14159

int main() {
    float radius = 5.0;
    float area = PI * radius * radius;
    printf("ব্যাসার্ধ: %.2f\n", radius);
    printf("ক্ষেত্রফল: %.2f বর্গ একক\n", area);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "ব্যাসার্ধ: 5.00\nক্ষেত্রফল: 78.54 বর্গ একক",
                        explanation = "#define দিয়ে পাই-এর মান কনস্ট্যান্ট করা হয়েছে। %.2f দিয়ে দশমিকের পর ২ ঘর দেখানো হয়েছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "#include <stdio.h>;",
                    correctCode = "#include <stdio.h>",
                    explanation = "প্রিপ্রসেসর ডিরেক্টিভ (#include বা #define) এর শেষে কখনো সেমিকোলন (;) বসে না।"
                )
            ),
            tips = listOf(
                "এক লাইনের কমেন্টের জন্য // এবং একাধিক লাইনের জন্য /* ... */ ব্যবহৃত হয়। কম্পাইলার কমেন্ট উপেক্ষা করে।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি সমকোণী ত্রিভুজের ভূমি ৫ ও উচ্চতা ১০ একক। এর ক্ষেত্রফল নির্ণয়ের সি কোড লিখো।",
                    hint = "ক্ষেত্রফল = ০.৫ * ভূমি * উচ্চতা। float ডেটা টাইপ ব্যবহার করো।",
                    solutionCode = """
#include <stdio.h>

int main() {
    float base = 5.0;
    float height = 10.0;
    float area = 0.5 * base * height;
    printf("ত্রিভুজের ক্ষেত্রফল: %.2f\n", area);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_3",
            chapterNumber = 3,
            titleBn = "অ্যালগরিদম, ফ্লোচার্ট ও সিউডোকোড",
            titleEn = "Algorithm & Flowchart Design",
            subtitle = "সমস্যা সমাধানের যুক্তিকাঠামো এবং ফ্লোচার্টের প্রতীকসমূহ",
            durationMinutes = 20,
            objectives = listOf(
                "অ্যালগরিদম লেখার নিয়ম ও শর্তাবলী জানা",
                "ফ্লোচার্টের স্ট্যান্ডার্ড জ্যামিতিক প্রতীক চেনা",
                "সিউডোকোড (ছদ্ম কোড) এর ধারণা স্পষ্ট করা",
                "শর্তযুক্ত সমস্যার অ্যালগরিদম ও ফ্লোচার্ট আঁকা"
            ),
            sections = listOf(
                LessonSection(
                    title = "অ্যালগরিদম (Algorithm) কী?",
                    content = """
কোনো নির্দিষ্ট সমস্যা সমাধানের জন্য ধাপে ধাপে যৌক্তিক সমাধান পদ্ধতিকে অ্যালগরিদম বলা হয়। অ্যালগরিদমের নাম এসেছে পারস্যের বিখ্যাত গণিতবিদ 'আল-খোয়ারিজমি' (Al-Khwarizmi) এর নাম থেকে।
একটি ভালো অ্যালগরিদমের বৈশিষ্ট্য:
১. এটি সহজবোধ্য ও স্পষ্ট হতে হবে।
২. ধাপ সংখ্যা নির্দিষ্ট বা সসীম হতে হবে।
৩. প্রতিটি ধাপে সুনির্দিষ্ট ফলাফল থাকতে হবে।
৪. কোনো প্রকার বিভ্রান্তি থাকা যাবে না।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "ফ্লোচার্ট (Flowchart) ও এর প্রতীকসমূহ",
                    content = """
অ্যালগরিদমের চিত্ররূপকে ফ্লোচার্ট বা প্রবাহচিত্র বলা হয়। ফ্লোচার্টে ব্যবহৃত প্রধান প্রতীকগুলো হলো:
১. ডিম্বাকৃতি (Oval / Pill): শুরু (Start) ও শেষ (Stop) নির্দেশ করে।
২. সামান্তরিক (Parallelogram): ইনপুট গ্রহণ (Input) ও আউটপুট প্রদর্শন (Output) নির্দেশ করে।
৩. আয়তক্ষেত্র (Rectangle): প্রক্রিয়াকরণ (Process / Calculation) নির্দেশ করে।
৪. হীরক বা রম্বস (Diamond): সিদ্ধান্ত গ্রহণ (Decision / Condition, যেমন: a > b?) নির্দেশ করে।
৫. বৃত্ত (Circle): সংযোগ প্রতীক (Connector) হিসেবে কাজ করে।
৬. তীর চিহ্ন (Arrow): ডেটা প্রবাহের দিক নির্দেশ করে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "দুটি সংখ্যার যোগফল নির্ণয়",
                        code = """
#include <stdio.h>

int main() {
    int num1 = 15;
    int num2 = 25;
    int sum = num1 + num2;
    printf("প্রথম সংখ্যা = %d\n", num1);
    printf("দ্বিতীয় সংখ্যা = %d\n", num2);
    printf("যোগফল = %d\n", sum);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "প্রথম সংখ্যা = 15\nদ্বিতীয় সংখ্যা = 25\nযোগফল = 40",
                        explanation = "স্টেপ ১: শুরু, স্টেপ ২: ইনপুট num1 ও num2, স্টেপ ৩: sum = num1 + num2 হিসাব, স্টেপ ৪: sum প্রদর্শন, স্টেপ ৫: শেষ।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "ফ্লোচার্টে ইনপুটের জন্য আয়তক্ষেত্র আঁকা",
                    correctCode = "ইনপুট এবং আউটপুট উভয়ের জন্য সামান্তরিক ব্যবহার করতে হবে",
                    explanation = "আয়তক্ষেত্র শুধুমাত্র হিসাব বা প্রক্রিয়াকরণের (processing) জন্য নির্ধারিত।"
                )
            ),
            tips = listOf(
                "এইচএসসি সৃজনশীল প্রশ্নে একটি ফ্লোচার্ট দিয়ে তার জন্য সি প্রোগ্রাম লিখতে বলা প্রায় নিশ্চিত প্রশ্ন!"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "সেলসিয়াস তাপমাত্রাকে ফারেনহাইটে রূপান্তরের সি কোড লিখো (সূত্র: F = (C * 9/5) + 32)।",
                    hint = "float C = 37.0; float F = (C * 9.0 / 5.0) + 32.0;",
                    solutionCode = """
#include <stdio.h>

int main() {
    float celsius = 37.0;
    float fahrenheit = (celsius * 9.0 / 5.0) + 32.0;
    printf("সেলসিয়াস: %.1f C\n", celsius);
    printf("ফারেনহাইট: %.1f F\n", fahrenheit);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_4",
            chapterNumber = 4,
            titleBn = "চলক, ধ্রুবক, ডেটা টাইপ ও কী-ওয়ার্ড",
            titleEn = "Variables, Data Types & Keywords",
            subtitle = "int, float, double, char মেমোরি ধারণা ও ৩২টি কী-ওয়ার্ড",
            durationMinutes = 25,
            objectives = listOf(
                "সি ভাষার প্রধান ৪টি মৌলিক ডেটা টাইপ বোঝা",
                "চলক (Variable) নামকরণের নিয়মাবলী মুখস্থ করা",
                "ধ্রুবক (Constant) ঘোষণার পদ্ধতি জানা",
                "সি ভাষার ৩২টি কী-ওয়ার্ডের তালিকা চেনা"
            ),
            sections = listOf(
                LessonSection(
                    title = "মৌলিক ডেটা টাইপ (Primary Data Types)",
                    content = """
মেমোরিতে সংরক্ষিত তথ্যের প্রকৃতি নির্ধারণ করতে ডেটা টাইপ ব্যবহার করা হয়।
১. int (পূর্ণসংখ্যা): যেমন ১০, -২৫, ৫০০। মেমোরিতে সাধারণত ২ বা ৪ বাইট জায়গা নেয়।
২. float (ভগ্নাংশ বা একক নির্ভুলতা): যেমন ৩.১৪, -০.৫। ৪ বাইট মেমোরি নেয়, দশমিকের পর ৬-৭ ঘর নির্ভুল।
৩. double (দ্বিগুণ নির্ভুল ভগ্নাংশ): যেমন ৩.১৪১৫৯২৬৫৩৫। ৮ বাইট মেমোরি নেয়, দশমিকের পর ১৪-১৫ ঘর নির্ভুল।
৪. char (একটিমাত্র বর্ণ বা অক্ষর): যেমন 'A', '7', '@'। ১ বাইট মেমোরি নেয়।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "চলক নামকরণের নিয়ম (Variable Naming Rules)",
                    content = """
১. চলকের নামের প্রথম অক্ষর অবশ্যই কোনো ইংরেজি বর্ণ (a-z, A-Z) অথবা আন্ডারস্কোর (_) হতে হবে। কোনো সংখ্যা দিয়ে শুরু হতে পারবে না (যেমন: 1name ভুল, name1 সঠিক)।
২. চলকের নামের মাঝে কোনো স্পেস (ফাঁকা স্থান) বা বিশেষ চিহ্ন (+, -, @, $, %) ব্যবহার করা যাবে না।
৩. সি ভাষার ৩২টি কী-ওয়ার্ড (যেমন: int, for, if, while) চলকের নাম হিসেবে ব্যবহার করা যাবে না।
৪. সি একটি কেস সেনসিটিভ ভাষা; ফলে total, Total ও TOTAL তিনটি সম্পূর্ণ ভিন্ন চলক।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "বিভিন্ন ডেটা টাইপের চলক ব্যবহার",
                        code = """
#include <stdio.h>

int main() {
    int roll = 101;
    float gpa = 4.88;
    char grade = 'A';
    
    printf("রোল নম্বর: %d\n", roll);
    printf("জিপিএ: %.2f\n", gpa);
    printf("গ্রেড: %c\n", grade);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "রোল নম্বর: 101\nজিপিএ: 4.88\nগ্রেড: A",
                        explanation = "%d পূর্ণসংখ্যার জন্য, %.2f দশমিকের পর ২ ঘর এবং %c ক্যারেক্টারের জন্য ফরম্যাট স্পেসিফায়ার।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "int 2nd_student = 50;",
                    correctCode = "int second_student = 50; // বা student_2",
                    explanation = "চলকের নাম কখনো সংখ্যা বা ডিজিট দিয়ে শুরু হতে পারে না।"
                ),
                MistakeItem(
                    wrongCode = "char grade = \"A\";",
                    correctCode = "char grade = 'A';",
                    explanation = "সি ভাষায় একটিমাত্র অক্ষর (char) নির্দেশ করতে সিঙ্গেল কোটেশন (' ') দিতে হয়। ডাবল কোটেশন স্ট্রিং-এর জন্য।"
                )
            ),
            tips = listOf(
                "ANSI C স্ট্যান্ডার্ডে মোট ৩২টি সংরক্ষিত কী-ওয়ার্ড রয়েছে। এদের সবগুলোই ছোট হাতের অক্ষরে লেখা হয়।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি বইয়ের মূল্য (float), পৃষ্ঠাসংখ্যা (int) ও সংস্করণের ক্যাটাগরি (char) তিনটি চলকে সংরক্ষণ করে প্রিন্ট করো।",
                    hint = "float price = 250.50; int pages = 320; char category = 'B';",
                    solutionCode = """
#include <stdio.h>

int main() {
    float price = 250.50;
    int pages = 320;
    char category = 'B';
    printf("বইয়ের মূল্য: %.2f টাকা\n", price);
    printf("পৃষ্ঠা সংখ্যা: %d টি\n", pages);
    printf("ক্যাটাগরি: %c\n", category);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_5",
            chapterNumber = 5,
            titleBn = "অপারেটর ও এক্সপ্রেশন",
            titleEn = "Operators & Expressions",
            subtitle = "অ্যারিথমেটিক, রিলেশনাল, লজিক্যাল ও ইনক্রিমেন্ট/ডিক্রিমেন্ট অপারেটর",
            durationMinutes = 25,
            objectives = listOf(
                "অ্যারিথমেটিক (+, -, *, /, %) অপারেটরের কাজ জানা",
                "ভাগফল ও ভাগশেষ (মডুলাস %) নির্ণয়ের নিয়ম আয়ত্ত করা",
                "লজিক্যাল অপারেটর (&&, ||, !) এর সত্যতা সারণী বোঝা",
                "প্রি-ইনক্রিমেন্ট (++i) ও পোস্ট-ইনক্রিমেন্ট (i++) এর পার্থক্য স্পষ্ট করা"
            ),
            sections = listOf(
                LessonSection(
                    title = "সি ভাষার অপারেটরের শ্রেণীবিন্যাস",
                    content = """
অপারেটর হলো কিছু বিশেষ প্রতীক যা ডেটার উপর গাণিতিক ও যৌক্তিক কাজ সম্পন্ন করে।
১. গাণিতিক অপারেটর (Arithmetic): +, -, *, /, % (মডুলাস বা ভাগশেষ)। মনে রাখতে হবে, % অপারেটর শুধু পূর্ণসংখ্যার (int) ক্ষেত্রে প্রযোজ্য।
২. রিলেশনাল অপারেটর (Relational): == (সমান), != (অসমান), <, >, <=, >=। এগুলো সত্য হলে ১ ও মিথ্যা হলে ০ রিটার্ন করে।
৩. লজিক্যাল অপারেটর (Logical): && (লজিক্যাল AND - দুটোই সত্য হতে হবে), || (লজিক্যাল OR - যেকোনো একটি সত্য হলেই চলবে), ! (লজিক্যাল NOT - উল্টে দেয়)।
৪. ইনক্রিমেন্ট ও ডিক্রিমেন্ট: ++ (১ বাড়ানো), -- (১ কমানো)।
                    """.trimIndent(),
                    note = "মডুলাস (%) অপারেটর ভাগশেষ বের করে। যেমন 7 % 3 এর ফলাফল 1, কারণ ৭ কে ৩ দিয়ে ভাগ করলে ভাগশেষ ১ থাকে।"
                ),
                LessonSection(
                    title = "পোস্ট ও প্রি ইনক্রিমেন্টের পার্থক্য",
                    content = """
• প্রি-ইনক্রিমেন্ট (++x): আগে চলকের মান ১ বৃদ্ধি পাবে, তারপর সেই নতুন মান রাশিতে ব্যবহৃত হবে।
• পোস্ট-ইনক্রিমেন্ট (x++): বর্তমান মানটি রাশিতে ব্যবহৃত হয়ে যাবে, পরবর্তীতে চলকের মান ১ বৃদ্ধি পাবে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "ইনক্রিমেন্ট ও মডুলাস অপারেটরের ব্যবহার",
                        code = """
#include <stdio.h>

int main() {
    int a = 17, b = 5;
    printf("ভাগফল: %d / %d = %d\n", a, b, a / b);
    printf("ভাগশেষ: %d %% %d = %d\n", a, b, a % b);
    
    int x = 10;
    int y = x++; // y পাবে 10, তারপর x হবে 11
    printf("পোস্ট-ইনক্রিমেন্ট: y = %d, x = %d\n", y, x);
    
    int p = 10;
    int q = ++p; // p হবে 11, q পাবে 11
    printf("প্রি-ইনক্রিমেন্ট: q = %d, p = %d\n", q, p);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "ভাগফল: 17 / 5 = 3\nভাগশেষ: 17 % 5 = 2\nপোস্ট-ইনক্রিমেন্ট: y = 10, x = 11\nপ্রি-ইনক্রিমেন্ট: q = 11, p = 11",
                        explanation = "printf-এ শতকরা চিহ্ন দেখাতে হলে %% দুবার লিখতে হয়।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "if (a = 5) { ... }",
                    correctCode = "if (a == 5) { ... }",
                    explanation = "একটি সমান চিহ্ন (=) অ্যাসাইনমেন্টের জন্য, আর দুটি সমান চিহ্ন (==) তুলনার জন্য ব্যবহৃত হয়।"
                )
            ),
            tips = listOf(
                "এইচএসসিতে প্রায়ই আসে: a = 5; b = ++a + a++; এখানে b এর মান কত হবে?"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি ৩ অঙ্কের সংখ্যা (যেমন: 456) এর একক, দশক ও শতকের অঙ্ক আলাদা করে প্রিন্ট করো।",
                    hint = "একক = num % 10; দশক = (num / 10) % 10; শতক = num / 100;",
                    solutionCode = """
#include <stdio.h>

int main() {
    int n = 456;
    int units = n % 10;
    int tens = (n / 10) % 10;
    int hundreds = n / 100;
    printf("সংখ্যা: %d\n", n);
    printf("শতক = %d, দশক = %d, একক = %d\n", hundreds, tens, units);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_6",
            chapterNumber = 6,
            titleBn = "ইনপুট ও আউটপুট স্টেটমেন্ট (printf ও scanf)",
            titleEn = "Standard Input & Output Functions",
            subtitle = "ফরম্যাট স্পেসিফায়ার, এস্কেপ সিকোয়েন্স ও ব্যবহারকারীর ইনপুট গ্রহণ",
            durationMinutes = 20,
            objectives = listOf(
                "printf() এর সিনট্যাক্স ও আউটপুট ফরম্যাটিং শেখা",
                "scanf() এর মাধ্যমে ব্যবহারকারীর কাছ থেকে ডেটা নেওয়া",
                "অ্যাড্রেস অপারেটর (&) এর গুরুত্ব বোঝা",
                "প্রধান এস্কেপ সিকোয়েন্স (\\n, \\t) ব্যবহার করা"
            ),
            sections = listOf(
                LessonSection(
                    title = "আউটপুট ফাংশন: printf()",
                    content = """
printf() হলো একটি লাইব্রেরি ফাংশন যা <stdio.h> (Standard Input Output Header) হেডার ফাইলে সংজ্ঞায়িত। এর কাজ মনিটরে টেক্সট বা ভ্যারিয়েবলের মান প্রদর্শন করা।
ফরম্যাট স্পেসিফায়ার তালিকা:
• %d বা %i : int বা পূর্ণসংখ্যার জন্য
• %f : float এর জন্য
• %lf : double এর জন্য
• %c : char এর জন্য
• %s : string বা শব্দের জন্য

প্রধান এস্কেপ সিকোয়েন্স:
• \n : নতুন লাইন (New line)
• \t : ট্যাব বা ৮টি ফাঁকা স্থান (Horizontal tab)
• \\ : ব্যাকস্ল্যাশ প্রদর্শন
• \" : ডাবল কোটেশন প্রদর্শন
                    """.trimIndent()
                ),
                LessonSection(
                    title = "ইনপুট ফাংশন: scanf()",
                    content = """
ব্যবহারকারীর কাছ থেকে কি-বোর্ডের মাধ্যমে ডেটা ইনপুট নেওয়ার জন্য scanf() ব্যবহৃত হয়।
সিনট্যাক্স: scanf("ফরম্যাট স্পেসিফায়ার", &চলক);
এখানে চলকের পূর্বে অ্যাড্রেস অপারেটর (& - অ্যান্ড চিহ্ন) দেওয়া বাধ্যতামূলক, কারণ এটি মেমোরিতে ওই চলকের ঠিকানায় ইনপুটকৃত মান জমা করে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "ব্যবহারকারীর কাছ থেকে দুটি সংখ্যা ইনপুট নিয়ে গড় নির্ণয়",
                        code = """
#include <stdio.h>

int main() {
    int a = 20, b = 35; // প্র্যাকটিসের জন্য মান নির্ধারিত
    float average = (a + b) / 2.0;
    printf("সংখ্যাদ্বয়: %d এবং %d\n", a, b);
    printf("তাদের গড়: %.2f\n", average);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "সংখ্যাদ্বয়: 20 এবং 35\nতাদের গড়: 27.50",
                        explanation = "গড় করার সময় ২ এর বদলে ২.০ দিয়ে ভাগ করা হয়েছে যেন ফ্লোট ডিভিশন হয় এবং দশমিক মান নষ্ট না হয়।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "scanf(\"%d\", num);",
                    correctCode = "scanf(\"%d\", &num);",
                    explanation = "scanf-এ ভ্যারিয়েবলের নামের আগে & (অ্যাড্রেস-অব অপারেটর) না দিলে রানটাইম ক্র্যাশ হবে।"
                )
            ),
            tips = listOf(
                "দুটি পূর্ণসংখ্যা ভাগ করলে ভাগফল পূর্ণসংখ্যাই হবে (যেমন: 5/2 = 2)। দশমিক পেতে চাইলে অন্তত একটি সংখ্যাকে float বানাতে হবে (5.0/2 = 2.5)।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি আয়তক্ষেত্রের দৈর্ঘ্য ও প্রস্থ গ্রহণ করে ক্ষেত্রফল ও পরিসীমা বের করো।",
                    hint = "ক্ষেত্রফল = দৈর্ঘ্য * প্রস্থ; পরিসীমা = ২ * (দৈর্ঘ্য + প্রস্থ);",
                    solutionCode = """
#include <stdio.h>

int main() {
    float length = 12.5;
    float width = 6.0;
    float area = length * width;
    float perimeter = 2 * (length + width);
    printf("ক্ষেত্রফল: %.2f বর্গ একক\n", area);
    printf("পরিসীমা: %.2f একক\n", perimeter);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_7",
            chapterNumber = 7,
            titleBn = "কন্ট্রোল স্টেটমেন্ট: শর্তযুক্ত ব্রাঞ্চিং (if-else ও switch)",
            titleEn = "Conditional Statements (if, else, switch)",
            subtitle = "সিদ্ধান্ত গ্রহণ, নেস্টেড if এবং বহু-পছন্দের switch-case",
            durationMinutes = 30,
            objectives = listOf(
                "if, if-else এবং else-if ল্যাডারের গঠন শেখা",
                "নেস্টেড if-else এর মাধ্যমে জটিল যুক্তি তৈরি করা",
                "৩টি সংখ্যার মধ্যে বৃহত্তম সংখ্যা নির্ণয় করতে পারা",
                "switch-case স্টেটমেন্টের ব্যবহার ও break এর গুরুত্ব অনুধাবন"
            ),
            sections = listOf(
                LessonSection(
                    title = "শর্তযুক্ত নিয়ন্ত্রণ (Conditional Control)",
                    content = """
প্রোগ্রামের স্বাভাবিক প্রবাহকে কোনো শর্তের উপর ভিত্তি করে ভিন্ন ভিন্ন দিকে প্রবাহিত করার জন্য ব্রাঞ্চিং বা শর্তযুক্ত স্টেটমেন্ট ব্যবহৃত হয়।
সি ভাষায় ৩ ধরনের শর্তযুক্ত স্টেটমেন্ট আছে:
১. সরল if: শর্ত সত্য হলে ব্লক নির্বাহ হয়।
২. if-else: শর্ত সত্য হলে if ব্লক, অন্যথায় else ব্লক নির্বাহ হয়।
৩. else-if ladder: একাধিক শর্ত একের পর এক যাচাইয়ের জন্য।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "জোড় ও বিজোড় সংখ্যা পরীক্ষা",
                    content = """
যেকোনো পূর্ণসংখ্যাকে ২ দ্বারা ভাগ করলে ভাগশেষ ০ হলে সংখ্যাটি জোড় (Even), আর ১ হলে বিজোড় (Odd)।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "জোড় না বিজোড় নির্ণয়",
                        code = """
#include <stdio.h>

int main() {
    int num = 47;
    if (num % 2 == 0) {
        printf("%d একটি জোড় সংখ্যা (Even Number)\n", num);
    } else {
        printf("%d একটি বিজোড় সংখ্যা (Odd Number)\n", num);
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "47 একটি বিজোড় সংখ্যা (Odd Number)",
                        explanation = "৪৭ কে ২ দিয়ে ভাগ করলে ভাগশেষ ১ থাকে, তাই else ব্লক কার্যকর হয়েছে।"
                    )
                ),
                LessonSection(
                    title = "৩টি সংখ্যার মধ্যে বৃহত্তম সংখ্যা নির্ণয়",
                    content = """
তিনটি সংখ্যা a, b, c এর মধ্যে তুলনার জন্য লজিক্যাল অ্যান্ড (&&) ব্যবহার করে সহজেই নির্ণয় করা যায়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "৩টি সংখ্যার মধ্যে সবচেয়ে বড় সংখ্যা",
                        code = """
#include <stdio.h>

int main() {
    int a = 65, b = 92, c = 48;
    if (a >= b && a >= c) {
        printf("বৃহত্তম সংখ্যা: %d\n", a);
    } else if (b >= a && b >= c) {
        printf("বৃহত্তম সংখ্যা: %d\n", b);
    } else {
        printf("বৃহত্তম সংখ্যা: %d\n", c);
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "বৃহত্তম সংখ্যা: 92",
                        explanation = "b (৯২) সংখ্যাটি a (৬৫) এবং c (৪৮) উভয়ের চেয়ে বড় হওয়ায় দ্বিতীয় শর্তটি সত্য হয়েছে।"
                    )
                ),
                LessonSection(
                    title = "switch-case স্টেটমেন্ট",
                    content = """
যখন কোনো চলকের নির্দিষ্ট মানের উপর ভিত্তি করে বহু বিকল্পের মধ্য থেকে একটি নির্বাচন করতে হয়, তখন if-else ল্যাডারের চেয়ে switch-case বেশি পরিচ্ছন্ন।
switch-এ প্রতিটি case এর শেষে 'break' স্টেটমেন্ট ব্যবহার করা অত্যন্ত জরুরি, অন্যথায় পরবর্তী case ও স্বয়ংক্রিয়ভাবে রান হয়ে যায় (যাকে Fall-through বলে)।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "সপ্তাহের দিনের নাম প্রদর্শন (switch-case)",
                        code = """
#include <stdio.h>

int main() {
    int day = 6;
    switch (day) {
        case 1: printf("শুক্রবার (শুক্রবার সাপ্তাহিক ছুটি)\n"); break;
        case 2: printf("শনিবার\n"); break;
        case 3: printf("রবিবার\n"); break;
        case 4: printf("সোমবার\n"); break;
        case 5: printf("মঙ্গলবার\n"); break;
        case 6: printf("বুধবার\n"); break;
        case 7: printf("বৃহস্পতিবার\n"); break;
        default: printf("অবৈধ দিন!\n");
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "বুধবার",
                        explanation = "day = 6 হওয়ায় সরাসরি case 6 এ চলে গেছে এবং break পেয়ে সুইচ থেকে বের হয়ে এসেছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "switch(x) { case 1: printf(\"One\"); case 2: printf(\"Two\"); }",
                    correctCode = "switch(x) { case 1: printf(\"One\"); break; case 2: printf(\"Two\"); break; }",
                    explanation = "প্রতিটি case এর শেষে break না দিলে নিচের সব case একের পর এক রান হয়ে যাবে।"
                )
            ),
            tips = listOf(
                "লিপ ইয়ার (অধিবর্ষ) পরীক্ষার শর্ত: (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি সাল (যেমন 2024) লিপ ইয়ার কিনা তা পরীক্ষা করার সি প্রোগ্রাম তৈরি করো।",
                    hint = "৪০০ দ্বারা বিভাজ্য অথবা ৪ দ্বারা বিভাজ্য কিন্তু ১০০ দ্বারা নয়।",
                    solutionCode = """
#include <stdio.h>

int main() {
    int year = 2024;
    if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)) {
        printf("%d একটি অধিবর্ষ (Leap Year)\n", year);
    } else {
        printf("%d অধিবর্ষ নয়\n", year);
    }
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_8",
            chapterNumber = 8,
            titleBn = "লুপ কন্ট্রোল স্টেটমেন্ট (for, while, do-while)",
            titleEn = "Looping Structures & Series",
            subtitle = "পুনরাবৃত্তি, লুপের ৩টি প্রধান অংশ, নেস্টেড লুপ ও ধারা যোগফল",
            durationMinutes = 30,
            objectives = listOf(
                "লুপের ৩টি মূল উপাদান: প্রারম্ভিক মান, শর্ত ও পরিবর্তন বোঝা",
                "for লুপ ও while লুপের কাজের প্রক্রিয়া জানা",
                "এন্ট্রি-কন্ট্রোলড বনাম এক্সিট-কন্ট্রোলড (do-while) লুপের পার্থক্য",
                "১+২+৩+...+N ধারার যোগফল ও নামতা তৈরি করা"
            ),
            sections = listOf(
                LessonSection(
                    title = "লুপের মৌলিক ধারণা ও ৩টি উপাদান",
                    content = """
একই কাজ বারবার করার প্রক্রিয়াকে লুপ (Loop) বলে। প্রতিটি লুপের ৩টি অংশ থাকে:
১. ইনিশিয়ালাইজেশন (Initialization): লুপের কাউন্টারের প্রাথমিক মান নির্ধারণ।
২. কন্ডিশন (Condition): লুপটি কতক্ষণ চলবে তার শর্ত।
৩. ইনক্রিমেন্ট বা ডিক্রিমেন্ট (Update): প্রতি পদক্ষেপে কাউন্টারের মানের পরিবর্তন।

সি ভাষায় লুপ ৩ প্রকার:
• for লুপ: যখন পুনরাবৃত্তির সংখ্যা পূর্বেই জানা থাকে (এন্ট্রি-কন্ট্রোলড)।
• while লুপ: শর্তের উপর নির্ভরশীল পুনরাবৃত্তিতে (এন্ট্রি-কন্ট্রোলড)।
• do-while লুপ: শর্ত মিথ্যা হলেও অন্তত একবার লুপ বডি কার্যকর হবে (এক্সিট-কন্ট্রোলড)।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "১ থেকে N পর্যন্ত সংখ্যার যোগফল",
                    content = """
ধারা ১ + ২ + ৩ + ... + N এর যোগফল বের করার জন্য লুপ একটি আদর্শ পদ্ধতি।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "১ থেকে ১০ পর্যন্ত সংখ্যার যোগফল নির্ণয়",
                        code = """
#include <stdio.h>

int main() {
    int n = 10;
    int sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i;
    }
    printf("১ থেকে %d পর্যন্ত সংখ্যার যোগফল = %d\n", n, sum);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "১ থেকে 10 পর্যন্ত সংখ্যার যোগফল = 55",
                        explanation = "i = 1 থেকে শুরু হয়ে 10 পর্যন্ত প্রতিবারে sum এর সাথে যোগ হয়েছে। সূত্র: N*(N+1)/2 = 10*11/2 = 55।"
                    )
                ),
                LessonSection(
                    title = "ফ্যাক্টোরিয়াল (Factorial) নির্ণয়",
                    content = """
কোনো সংখ্যার ফ্যাক্টোরিয়াল (n!) হলো ১ থেকে n পর্যন্ত সকল স্বাভাবিক সংখ্যার গুণফল। যেমন: 5! = 1 * 2 * 3 * 4 * 5 = 120।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "while লুপ দিয়ে ফ্যাক্টোরিয়াল নির্ণয়",
                        code = """
#include <stdio.h>

int main() {
    int num = 5;
    long fact = 1;
    int i = 1;
    while (i <= num) {
        fact = fact * i;
        i++;
    }
    printf("%d এর ফ্যাক্টোরিয়াল (%d!) = %ld\n", num, num, fact);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "5 এর ফ্যাক্টোরিয়াল (5!) = 120",
                        explanation = "i এর মান ১ করে বেড়ে ৫ পর্যন্ত গুণ হয়েছে। ফ্যাক্টোরিয়াল মান দ্রুত বড় হওয়ায় long টাইপ ব্যবহার নিরাপদ।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "for(int i = 1; i <= 5; i++); { printf(\"%d \", i); }",
                    correctCode = "for(int i = 1; i <= 5; i++) { printf(\"%d \", i); }",
                    explanation = "for লুপের ব্র্যাকেটের পর সেমিকোলন (;) দিলে লুপটি ফাঁকা লুপ হয়ে যাবে এবং বডি একবারও লুপ আকারে চলবে না।"
                )
            ),
            tips = listOf(
                "এইচএসসি পরীক্ষায় ১^২ + ২^২ + ৩^২ + ... + n^২ ধারার যোগফল প্রায়ই আসে। এতে sum = sum + (i * i) করতে হয়।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "৭ এর গুণের নামতা (Multiplication Table) ১ থেকে ১০ পর্যন্ত প্রিন্ট করো।",
                    hint = "for(int i=1; i<=10; i++) printf(\"7 x %d = %d\\n\", i, 7 * i);",
                    solutionCode = """
#include <stdio.h>

int main() {
    int n = 7;
    printf("--- %d এর গুণের নামতা ---\n", n);
    for (int i = 1; i <= 10; i++) {
        printf("%d x %2d = %2d\n", n, i, n * i);
    }
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_9",
            chapterNumber = 9,
            titleBn = "অ্যারে (Array) ও স্ট্রিং এর ধারণা",
            titleEn = "Arrays & String Basics",
            subtitle = "একমাত্রিক অ্যারে, ইনডেক্সিং এবং ক্যারেক্টার অ্যারে",
            durationMinutes = 25,
            objectives = listOf(
                "অ্যারে কী এবং কেন প্রয়োজন তা উপলব্ধি করা",
                "অ্যারে ডিক্লেয়ার ও ইনিশিয়ালাইজ করার সিনট্যাক্স",
                "অ্যারের ইনডেক্স ০ (Zero) থেকে শুরু হওয়ার নিয়ম জানা",
                "অ্যারের উপাদান থেকে বৃহত্তম সংখ্যা খুঁজে বের করা"
            ),
            sections = listOf(
                LessonSection(
                    title = "অ্যারে (Array) কী?",
                    content = """
অ্যারে হলো একই ডেটা টাইপের একাধিক উপাদানের একটি ধারাবাহিক মেমোরি সংগ্রহ। যদি ৫০ জন শিক্ষার্থীর নম্বর রাখতে হয়, তবে ৫০টি আলাদা ভ্যারিয়েবল না নিয়ে একটি অ্যারে marks[50] নেওয়াই সর্বোত্তম।
অ্যারের মূল বৈশিষ্ট্য:
১. সকল উপাদান একই ডেটা টাইপের হতে হয় (সমজাতীয় ডেটা)।
২. উপাদানের অবস্থান নির্দেশ করতে ইনডেক্স (Index) বা সাবস্ক্রিপ্ট ব্যবহৃত হয়।
৩. সি ভাষায় অ্যারের ইনডেক্স সর্বদা ০ (শূন্য) থেকে শুরু হয় এবং (সাইজ - ১) এ শেষ হয়।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "অ্যারের উপাদান অনুসন্ধান ও প্রক্রিয়াকরণ",
                    content = """
লুপ ব্যবহার করে খুব সহজেই অ্যারের প্রতিটি উপাদানে যাওয়া যায় যাকে অ্যারে ট্রাভার্সাল (Traversal) বলে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "অ্যারে থেকে সর্বোচ্চ নম্বর খুঁজে বের করা",
                        code = """
#include <stdio.h>

int main() {
    int marks[5] = {78, 85, 92, 64, 88};
    int max = marks[0];
    
    for (int i = 1; i < 5; i++) {
        if (marks[i] > max) {
            max = marks[i];
        }
    }
    printf("সর্বোচ্চ নম্বর = %d\n", max);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "সর্বোচ্চ নম্বর = 92",
                        explanation = "প্রথম উপাদানকে max ধরে বাকিদের সাথে তুলনা করা হয়েছে। ৯২ পাওয়ার পর max এর মান ৯২ হয়েছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "int arr[5]; arr[5] = 100;",
                    correctCode = "int arr[5]; arr[4] = 100; // ইনডেক্স ০ থেকে ৪ পর্যন্ত",
                    explanation = "সাইজ ৫ হলে ইনডেক্স ০, ১, ২, ৩, ৪ পর্যন্ত বৈধ। arr[5] লেখা অ্যারে বাউন্ডস এর বাইরে মেমোরি ওভারফ্লো।"
                )
            ),
            tips = listOf(
                "সি ভাষায় স্ট্রিং হলো একটি ক্যারেক্টার অ্যারে যার শেষে নাল ক্যারেক্টার '\\0' থাকে।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "৫টি পূর্ণসংখ্যার একটি অ্যারের সকল উপাদানের যোগফল ও গড় নির্ণয় করো।",
                    hint = "একটি লুপ চালিয়ে sum += arr[i] করো, তারপর sum / 5.0 করো।",
                    solutionCode = """
#include <stdio.h>

int main() {
    int numbers[5] = {10, 20, 30, 40, 50};
    int sum = 0;
    for (int i = 0; i < 5; i++) {
        sum += numbers[i];
    }
    float avg = sum / 5.0;
    printf("মোট যোগফল = %d\n", sum);
    printf("গড় মান = %.2f\n", avg);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_10",
            chapterNumber = 10,
            titleBn = "ইউজার-ডিফাইন্ড ফাংশন ও রিকার্শন",
            titleEn = "User-Defined Functions & Recursion",
            subtitle = "মডুলার প্রোগ্রামিং, প্যারামিটার পাসিং এবং রিকার্সিভ কল",
            durationMinutes = 25,
            objectives = listOf(
                "ফাংশনের প্রয়োজনীয়তা ও মডুলার কোডিং এর সুবিধা অনুধাবন",
                "ফাংশন প্রোটোটাইপ, ডেফিনিশন ও ফাংশন কল বোঝা",
                "প্যারামিটার ও রিটার্ন টাইপের ভূমিকা পরিষ্কার করা",
                "রিকার্শন (Recursion) এর মাধ্যমে সমস্যা সমাধান"
            ),
            sections = listOf(
                LessonSection(
                    title = "ফাংশন (Function) কী?",
                    content = """
ফাংশন হলো কোনো নির্দিষ্ট কাজ সম্পাদনের জন্য লিখিত একগুচ্ছ নির্দেশাবলীর স্বয়ংসম্পূর্ণ ব্লক।
ফাংশন ব্যবহারের সুবিধা:
১. কোডের পুনরাবৃত্তি পরিহার করা যায় (Reusability)।
২. বড় প্রোগ্রামকে ছোট ছোট সহজে পরিচালনাযোগ্য অংশে ভাগ করা যায়।
৩. ত্রুটি নির্ণয় ও সংশোধন (Debugging) সহজ হয়।

ফাংশন দুই প্রকার:
• লাইব্রেরি ফাংশন: সি ভাষায় পূর্ব থেকেই তৈরি করা (যেমন: printf, scanf, sqrt)।
• ব্যবহারকারী নির্ধারিত ফাংশন (User-defined Function): প্রোগ্রামার নিজের প্রয়োজনে তৈরি করেন।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "রিকার্শন (রিকার্সিভ ফাংশন)",
                    content = """
যখন কোনো ফাংশন নিজের ভেতর থেকেই পুনরায় নিজেকেই কল করে, তখন তাকে রিকার্শন (Recursion) বলা হয়। রিকার্শনের ক্ষেত্রে অবশ্যই একটি 'বেস কেস' (Base Case) বা সমাপ্তির শর্ত থাকতে হয়, অন্যথায় মেমোরি শেষ হয়ে স্ট্যাক ওভারফ্লো ঘটবে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "রিকার্শনের মাধ্যমে ফ্যাক্টোরিয়াল নির্ণয়",
                        code = """
#include <stdio.h>

int factorial(int n) {
    if (n <= 1) {
        return 1; // বেস কেস
    }
    return n * factorial(n - 1); // রিকার্সিভ কল
}

int main() {
    int num = 6;
    int result = factorial(num);
    printf("%d এর ফ্যাক্টোরিয়াল = %d\n", num, result);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "6 এর ফ্যাক্টোরিয়াল = 720",
                        explanation = "factorial(6) = 6 * factorial(5) এভাবে ক্রমান্বয়ে factorial(1) এ পৌঁছে মান রিটার্ন করেছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "int sum(int a, b) { ... }",
                    correctCode = "int sum(int a, int b) { ... }",
                    explanation = "ফাংশন প্যারামিটারে প্রতিটি চলকের ডেটা টাইপ আলাদাভাবে স্পষ্ট উল্লেখ করতে হয়।"
                )
            ),
            tips = listOf(
                "যে ফাংশন কোনো মান ফেরত দেয় না, তার রিটার্ন টাইপ হয় void। যেমন: void printMessage();"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "দুটি সংখ্যার গসাগু (GCD) নির্ণয়ের জন্য একটি ফাংশন তৈরি করো।",
                    hint = "ইউক্লিডের নিয়ম: gcd(b, a % b)",
                    solutionCode = """
#include <stdio.h>

int gcd(int a, int b) {
    if (b == 0) return a;
    return gcd(b, a % b);
}

int main() {
    int x = 48, y = 18;
    printf("%d ও %d এর গসাগু = %d\n", x, y, gcd(x, y));
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_11",
            chapterNumber = 11,
            titleBn = "পয়েন্টার ও মেমোরি অ্যাড্রেসের মৌলিক ধারণা",
            titleEn = "Introduction to Pointers",
            subtitle = "ঠিকানা অপারেটর (&), ডি-রেফারেন্স অপারেটর (*) ও মেমোরি ব্যবস্থাপনা",
            durationMinutes = 20,
            objectives = listOf(
                "পয়েন্টার কী এবং কেন সি-তে এটি গুরুত্বপূর্ণ তা জানা",
                "মেমোরি অ্যাড্রেস (&) এবং ভ্যালু-অ্যাট (*) অপারেটর বোঝা",
                "পয়েন্টার ডিক্লেয়ারেশনের সিনট্যাক্স শেখা",
                "পয়েন্টার ব্যবহারের মাধ্যমে সোয়াপিং (মান অদলবদল)"
            ),
            sections = listOf(
                LessonSection(
                    title = "পয়েন্টার (Pointer) কী?",
                    content = """
পয়েন্টার হলো একটি বিশেষ ধরনের ভ্যারিয়েবল যা কোনো সাধারণ ডেটা মানের বদলে অন্য একটি ভ্যারিয়েবলের মেমোরি অ্যাড্রেস (স্মৃতি ঠিকানা) সংরক্ষণ করে।
পয়েন্টারের দুটি অপরিহার্য প্রতীক:
১. রেফারেন্স বা অ্যাড্রেস অপারেটর (&): চলকের মেমোরি ঠিকানা নির্দেশ করে।
২. ডি-রেফারেন্স বা ইনডাইরেকশন অপারেটর (*): পয়েন্টার যে ঠিকানায় নির্দেশ করছে, সেই ঠিকানায় সংরক্ষিত মান নির্দেশ করে।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "পয়েন্টারের ব্যবহারিক উদাহরণ",
                    content = """
পয়েন্টারের সাহায্যে সরাসরি কম্পিউটারের মেমোরিতে অ্যাক্সেস করা যায়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "পয়েন্টার দিয়ে চলকের মান পরিবর্তন",
                        code = """
#include <stdio.h>

int main() {
    int age = 17;
    int *ptr = &age; // ptr-এ age-এর ঠিকানা রাখা হলো
    
    printf("age এর মান: %d\n", age);
    printf("age এর ঠিকানা: %p\n", ptr);
    
    *ptr = 18; // পয়েন্টারের সাহায্যে মান পরিবর্তন
    printf("পরিবর্তিত মান: %d\n", age);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "age এর মান: 17\nage এর ঠিকানা: 0x1000\nপরিবর্তিত মান: 18",
                        explanation = "*ptr = 18 লেখার ফলে ptr যে ঠিকানায় দেখাচ্ছিল (age এর মেমোরি), সেখানে সরাসরি ১৮ বসে গেছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "int *p; *p = 50; // আনইনিশিয়ালাইজড ওয়াইল্ড পয়েন্টার",
                    correctCode = "int x; int *p = &x; *p = 50;",
                    explanation = "কোনো ভ্যালিড ভ্যারিয়েবলের অ্যাড্রেস ছাড়া সরাসরি পয়েন্টারে মান বসালে মেমোরি করাপ্ট হতে পারে।"
                )
            ),
            tips = listOf(
                "scanf(\"%d\", &x) এ আমরা &x দিই কারণ scanf ফাংশন পয়েন্টারের মাধ্যমে মেমোরি অ্যাড্রেসে ইনপুট রাখে।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "দুটি সংখ্যার মান পয়েন্টার ও সোয়াপিং এর মাধ্যমে অদল-বদল করো।",
                    hint = "temp = *a; *a = *b; *b = temp;",
                    solutionCode = """
#include <stdio.h>

void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int main() {
    int x = 10, y = 20;
    printf("পূর্বের মান: x = %d, y = %d\n", x, y);
    swap(&x, &y);
    printf("সোয়াপের পর: x = %d, y = %d\n", x, y);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_12",
            chapterNumber = 12,
            titleBn = "স্ট্রাকচার (Structure) ও বাস্তব প্রয়োগ",
            titleEn = "Structures in C & Real-world Usage",
            subtitle = "struct কী-ওয়ার্ড, ভিন্ন ভিন্ন ডেটা টাইপের মিশ্রণ ও এইচএসসি পরীক্ষার প্রস্তুতি",
            durationMinutes = 20,
            objectives = listOf(
                "অ্যারে বনাম স্ট্রাকচারের মৌলিক পার্থক্য উপলব্ধি করা",
                "struct তৈরির নিয়ম ও ডট (.) অপারেটর দিয়ে ডেটা অ্যাক্সেস",
                "শিক্ষার্থী রেকর্ডের বাস্তব স্ট্রাকচার কোড তৈরি",
                "বোর্ড পরীক্ষার গুরুত্বপূর্ণ সি প্রোগ্রামিং প্রশ্নের রিভিশন"
            ),
            sections = listOf(
                LessonSection(
                    title = "স্ট্রাকচার (Structure) কী?",
                    content = """
অ্যারেতে শুধুমাত্র একই ডেটা টাইপের উপাদান রাখা যায়। কিন্তু বাস্তব জীবনে যেমন একজন শিক্ষার্থীর নাম (char array), রোল (int), এবং জিপিএ (float) থাকে। ভিন্ন ভিন্ন ডেটা টাইপকে একটি একক নামে একত্রিত করার জন্য 'struct' ব্যবহৃত হয়।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "শিক্ষার্থী রেকর্ড তৈরি ও প্রদর্শন",
                    content = """
ডট (.) অপারেটর ব্যবহার করে স্ট্রাকচার ভ্যারিয়েবলের ভেতরের ফিল্ডগুলোতে ডেটা বসানো ও পড়া হয়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "শিক্ষার্থী ডেটা স্ট্রাকচার",
                        code = """
#include <stdio.h>

struct Student {
    int roll;
    float gpa;
};

int main() {
    struct Student s1;
    s1.roll = 105;
    s1.gpa = 5.00;
    
    printf("--- শিক্ষার্থীর বিবরণ ---\n");
    printf("রোল নম্বর: %d\n", s1.roll);
    printf("জিপিএ: %.2f (A+)\n", s1.gpa);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "--- শিক্ষার্থীর বিবরণ ---\nরোল নম্বর: 105\nজিপিএ: 5.00 (A+)",
                        explanation = "struct Student হলো একটি নতুন কাস্টম ডেটা টাইপ যার ভেতরে roll এবং gpa সংরক্ষিত থাকে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "struct Student { int roll; float gpa; } // সেমিকোলন বাদ",
                    correctCode = "struct Student { int roll; float gpa; }; // শেষে সেমিকোলন আবশ্যক",
                    explanation = "স্ট্রাকচারের ব্র্যাকেট শেষের পর অবশ্যই একটি সেমিকোলন (;) দিতে হয়।"
                )
            ),
            tips = listOf(
                "এইচএসসি পরীক্ষার সৃজনশীল প্রশ্নের গ ও ঘ নম্বরে বেশিরভাগ সময় সিরিজ, ফ্যাক্টোরিয়াল, প্রাইম নম্বর বা ৩টি সংখ্যার মধ্যে বড় সংখ্যা নির্ণয় এসে থাকে।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি মৌলিক সংখ্যা (Prime Number) পরীক্ষার সি কোড তৈরি করো।",
                    hint = "২ থেকে n-1 পর্যন্ত কোনো সংখ্যা দিয়ে n নিঃশেষে বিভাজ্য না হলে তা প্রাইম।",
                    solutionCode = """
#include <stdio.h>

int main() {
    int n = 29;
    int isPrime = 1;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            isPrime = 0;
            break;
        }
    }
    if (isPrime && n > 1) {
        printf("%d একটি মৌলিক সংখ্যা (Prime Number)\n", n);
    } else {
        printf("%d মৌলিক সংখ্যা নয়\n", n);
    }
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_13",
            chapterNumber = 13,
            isExtra = true,
            titleBn = "অ্যালগরিদম পরিচিতি: লিনিয়ার ও বাইনারি সার্চ",
            titleEn = "Searching Algorithms: Linear & Binary Search",
            subtitle = "অ্যারেতে ডেটা খোঁজার কার্যপদ্ধতি ও তুলনামূলক বিশ্লেষণ",
            durationMinutes = 20,
            objectives = listOf(
                "সার্চিং অ্যালগরিদম কী এবং কেন প্রয়োজন তা জানা",
                "লিনিয়ার সার্চের (Linear Search) কার্যপদ্ধতি ও কোড বোঝা",
                "সর্টেড অ্যারেতে বাইনারি সার্চের (Binary Search) দক্ষতা উপলব্ধি করা",
                "দুটি সার্চের তুলনামূলক সুবিধা ও সময় সাশ্রয়ী বৈশিষ্ট্য জানা"
            ),
            sections = listOf(
                LessonSection(
                    title = "সার্চিং (Searching) কী?",
                    content = """
কোনো ডেটা সংগ্রহের (যেমন অ্যারে) মধ্য থেকে নির্দিষ্ট কোনো উপাদান বা ভ্যালু খুঁজে বের করার প্রক্রিয়াকে সার্চিং (Searching) বলে। বাস্তব জীবনে আমরা যখন রোলে শিক্ষার্থী খুঁজি বা ফোনবুক থেকে নম্বর খুঁজি, তখন আমরা কোনো না কোনো সার্চিং পদ্ধতি ব্যবহার করি।

কম্পিউটার বিজ্ঞানে বহুল ব্যবহৃত দুটি সার্চিং অ্যালগরিদম হলো:
১. লিনিয়ার সার্চ (Linear Search / রৈখিক অনুসন্ধান)
২. বাইনারি সার্চ (Binary Search / দ্বি-বিভাজন অনুসন্ধান)
                    """.trimIndent()
                ),
                LessonSection(
                    title = "লিনিয়ার সার্চ (Linear Search)",
                    content = """
লিনিয়ার সার্চে অ্যারের প্রথম উপাদান (ইন্ডেক্স 0) থেকে শুরু করে শেষ পর্যন্ত প্রতিটি উপাদানের সাথে কাঙ্ক্ষিত মানটি একের পর এক মিলিয়ে দেখা হয়। মানটি পাওয়া গেলে তার অবস্থান জানানো হয়।
- সুবিধা: উপাদানগুলো সাজানো (Sorted) থাকার কোনো প্রয়োজন নেই।
- অসুবিধা: বড় ডেটাসেটে সময় বেশি লাগে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "লিনিয়ার সার্চ কোড",
                        code = """
#include <stdio.h>

int main() {
    int arr[6] = {25, 12, 48, 37, 89, 5};
    int target = 37;
    int found = 0;
    int position = -1;

    for (int i = 0; i < 6; i++) {
        if (arr[i] == target) {
            found = 1;
            position = i;
            break;
        }
    }

    if (found == 1) {
        printf("উপাদান %d পাওয়া গেছে ইন্ডেক্স %d-এ!\n", target, position);
    } else {
        printf("উপাদান %d অ্যারেতে পাওয়া যায়নি।\n", target);
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "উপাদান 37 পাওয়া গেছে ইন্ডেক্স 3-এ!",
                        explanation = "লুপটি ০ থেকে শুরু করে প্রতিটি ইন্ডেক্স চেক করেছে। যখনই arr[3] == 37 মিলেছে, সাথে সাথে লুপ ব্রেক করা হয়েছে।"
                    )
                ),
                LessonSection(
                    title = "বাইনারি সার্চ (Binary Search)",
                    content = """
বাইনারি সার্চ অত্যন্ত দ্রুত কাজ করে, তবে এর একমাত্র শর্ত হলো অ্যারের ডেটা অবশ্যই ছোট থেকে বড় ক্রমে সাজানো (Sorted) থাকতে হবে।
- কার্যপদ্ধতি: প্রতি ধাপে অ্যারের ঠিক মাঝখানের মানটির সাথে কাঙ্ক্ষিত মানের তুলনা করা হয়। মানটি ছোট হলে বাম অর্ধেক এবং বড় হলে ডান অর্ধেক খোঁজা হয়। এভাবে প্রতি ধাপে উপাদানের সংখ্যা অর্ধেক হয়ে যায়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "বাইনারি সার্চ কোড",
                        code = """
#include <stdio.h>

int main() {
    int arr[7] = {10, 20, 30, 40, 50, 60, 70};
    int target = 50;
    int low = 0;
    int high = 6;
    int foundIndex = -1;

    while (low <= high) {
        int mid = (low + high) / 2;
        if (arr[mid] == target) {
            foundIndex = mid;
            break;
        } else if (arr[mid] < target) {
            low = mid + 1; // ডান অর্ধে খোঁজা
        } else {
            high = mid - 1; // বাম অর্ধে খোঁজা
        }
    }

    if (foundIndex != -1) {
        printf("বাইনারি সার্চ সফল! %d পাওয়া গেছে ইন্ডেক্স %d-এ।\n", target, foundIndex);
    } else {
        printf("%d পাওয়া যায়নি।\n", target);
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "বাইনারি সার্চ সফল! 50 পাওয়া গেছে ইন্ডেক্স 4-এ।",
                        explanation = "প্রতি ধাপে mid হিসাব করে কাঙ্ক্ষিত সংখ্যার সাথে তুলনা করা হয়, ফলে বিশাল ডেটাসেটেও খুব কম সময়ে মান পাওয়া যায়।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "// অ-সাজানো অ্যারেতে বাইনারি সার্চ প্রয়োগ করা",
                    correctCode = "// বাইনারি সার্চ প্রয়োগের আগে অ্যারে অবশ্যই সর্ট (Sort) করে নিতে হবে",
                    explanation = "অ্যারে ছোট থেকে বড় ক্রমে সাজানো না থাকলে বাইনারি সার্চ কখনোই সঠিক উত্তর দেবে না।"
                )
            ),
            tips = listOf(
                "১০ লক্ষ উপাদানের মাঝে লিনিয়ার সার্চে সর্বোচ্চ ১০ লক্ষ বার চেক করতে হতে পারে, কিন্তু বাইনারি সার্চে মাত্র ২০ বারেই উত্তর পাওয়া সম্ভব!"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "একটি সাজানো অ্যারে {5, 15, 25, 35, 45}-এ target = 25 এর জন্য বাইনারি সার্চের প্রথম mid কত হবে?",
                    hint = "low = 0, high = 4; mid = (0 + 4) / 2",
                    solutionCode = """
#include <stdio.h>
int main() {
    int mid = (0 + 4) / 2;
    printf("প্রথম mid ইন্ডেক্স: %d, মান: 25\n", mid);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_14",
            chapterNumber = 14,
            isExtra = true,
            titleBn = "ডেটা সর্টিং: বাবল সর্ট ও সিলেকশন সর্ট",
            titleEn = "Sorting Algorithms: Bubble & Selection Sort",
            subtitle = "সংখ্যাগুলোকে ছোট থেকে বড় ক্রমানুসারে সাজানো",
            durationMinutes = 25,
            objectives = listOf(
                "সর্টিং বা ক্রমানুসারে সাজানোর ধারণা বোঝা",
                "বাবল সর্টের (Bubble Sort) পাস ও সোয়াপিং লজিক শেখা",
                "সিলেকশন সর্টের (Selection Sort) মিনিমাম এলিমেন্ট সিলেক্ট করার নিয়ম জানা",
                "অ্যারের মানগুলোকে এসেন্ডিং (ছোট থেকে বড়) অর্ডারে সাজানো"
            ),
            sections = listOf(
                LessonSection(
                    title = "সর্টিং (Sorting) কী?",
                    content = """
এলোমেলোভাবে থাকা ডেটাকে কোনো নির্দিষ্ট নিয়মে (যেমন ছোট থেকে বড় বা বড় থেকে ছোট) ক্রমানুসারে সাজানোর প্রক্রিয়াকে সর্টিং (Sorting) বলে।
প্রোগ্রামিংয়ে ডেটা সর্ট করে রাখলে অনুসন্ধান (Search) করা অনেক বেশি সহজ ও দ্রুত হয়।
                    """.trimIndent()
                ),
                LessonSection(
                    title = "বাবল সর্ট (Bubble Sort)",
                    content = """
বাবল সর্ট হলো সবচেয়ে সহজ সর্টিং অ্যালগরিদম। এতে পাশাপাশি দুটি উপাদানের তুলনা করা হয় এবং বাম পাশেরটি ডান পাশের চেয়ে বড় হলে তাদের স্থান বিনিময় (Swap) করা হয়। পানির বুদ্বুদের মতো সবচেয়ে ভারী উপাদানটি ধীরে ধীরে অ্যারের শেষে চলে যায়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "বাবল সর্ট কোড",
                        code = """
#include <stdio.h>

int main() {
    int arr[5] = {64, 25, 12, 22, 11};
    int n = 5;

    // বাবল সর্ট লজিক
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                // সোয়াপ (Swap)
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    printf("সাজানো অ্যারে: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "সাজানো অ্যারে: 11 12 22 25 64 ",
                        explanation = "নেস্টেড লুপের মাধ্যমে পাশাপাশি মান তুলনা করে বড় সংখ্যাগুলোকে শেষের দিকে পাঠানো হয়েছে।"
                    )
                ),
                LessonSection(
                    title = "সিলেকশন সর্ট (Selection Sort)",
                    content = """
সিলেকশন সর্টে অ্যারের অ-সাজানো অংশের মধ্য থেকে সবচেয়ে ছোট (মিনিমাম) উপাদানটি খুঁজে বের করা হয় এবং সেটিকে শুরুতেই থাকা উপাদানের সাথে স্থান বিনিময় করা হয়।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "সিলেকশন সর্ট কোড",
                        code = """
#include <stdio.h>

int main() {
    int arr[5] = {29, 10, 14, 37, 13};
    int n = 5;

    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[minIdx]) {
                minIdx = j;
            }
        }
        // সোয়াপ
        int temp = arr[minIdx];
        arr[minIdx] = arr[i];
        arr[i] = temp;
    }

    printf("সিলেকশন সর্ট ফলাফল: ");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "সিলেকশন সর্ট ফলাফল: 10 13 14 29 37 ",
                        explanation = "প্রতিটি পাসে সবচেয়ে ছোট উপাদানটি খুঁজে নিয়ে তার নির্দিষ্ট অবস্থানে বসানো হয়েছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "arr[j] = arr[j+1]; arr[j+1] = arr[j]; // সোয়াপ ভুল",
                    correctCode = "int temp = arr[j]; arr[j] = arr[j+1]; arr[j+1] = temp;",
                    explanation = "তৃতীয় চলক (temp) ছাড়া সরাসরি অ্যাসাইন করলে মূল মানটি হারিয়ে যায়।"
                )
            ),
            tips = listOf(
                "ছোট থেকে বড় সাজাতে '>' চিহ্ন এবং বড় থেকে ছোট (ডিসেন্ডিং) সাজাতে '<' চিহ্ন ব্যবহার করতে হয়।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "বাবল সর্টে ৩টি উপাদানের জন্য নেস্টেড লুপে সর্বোচ্চ কতবার তুলনা (Comparison) হবে?",
                    hint = "n * (n - 1) / 2 সূত্র ব্যবহার করুন",
                    solutionCode = """
#include <stdio.h>
int main() {
    int n = 3;
    int comps = n * (n - 1) / 2;
    printf("তুলনা হবে: %d বার\n", comps);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_15",
            chapterNumber = 15,
            isExtra = true,
            titleBn = "নাম্বার থিওরি: গসাগু, লসাগু ও মৌলিক সংখ্যা",
            titleEn = "Number Theory: GCD, LCM & Prime Numbers",
            subtitle = "ইউক্লিডীয় অ্যালগরিদম ও গাণিতিক সমস্যা সমাধান",
            durationMinutes = 20,
            objectives = listOf(
                "ইউক্লিডীয় ভাগশেষ পদ্ধতিতে দ্রুত গসাগু (GCD) নির্ণয় শেখা",
                "গসাগু থেকে লসাগু (LCM) হিসাব করার সূত্র প্রয়োগ",
                "স্বল্প সময়ে মৌলিক সংখ্যা (Prime Number) যাচাইয়ের সেরা অ্যালগরিদম বোঝা",
                "ফাংশনের বাস্তব গাণিতিক প্রয়োগ অনুশীলন করা"
            ),
            sections = listOf(
                LessonSection(
                    title = "ইউক্লিডীয় পদ্ধতিতে গসাগু (GCD) ও লসাগু (LCM)",
                    content = """
সাধারণ পদ্ধতিতে গসাগু করতে বেশি সময় লাগে। তবে খ্রিষ্টপূর্ব ৩০০ অব্দে গ্রিক গণিতবিদ ইউক্লিড একটি চমৎকার নিয়ম আবিষ্কার করেন:
দুটি সংখ্যা a এবং b এর গসাগু হবে b এবং (a % b) এর গসাগুর সমান। এই পুনরাবৃত্তি চলতে থাকবে যতক্ষণ না ভাগশেষ ০ হয়।
- লসাগু নির্ণয়ের সূত্র: LCM = (a * b) / GCD
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "গসাগু ও লসাগু নির্ণয় কোড",
                        code = """
#include <stdio.h>

// ইউক্লিডীয় গসাগু ফাংশন
int findGCD(int a, int b) {
    while (b != 0) {
        int remainder = a % b;
        a = b;
        b = remainder;
    }
    return a;
}

int main() {
    int num1 = 56;
    int num2 = 98;
    int gcd = findGCD(num1, num2);
    int lcm = (num1 * num2) / gcd;

    printf("সংখ্যা দুটি: %d এবং %d\n", num1, num2);
    printf("গরিষ্ঠ সাধারণ গুণনীয়ক (GCD): %d\n", gcd);
    printf("লঘিষ্ঠ সাধারণ গুণিতক (LCM): %d\n", lcm);
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "সংখ্যা দুটি: 56 এবং 98\nগরিষ্ঠ সাধারণ গুণনীয়ক (GCD): 14\nলঘিষ্ঠ সাধারণ গুণিতক (LCM): 392",
                        explanation = "ইউক্লিডীয় অ্যালগরিদম কোনো সংখ্যা যতই বড় হোক না কেন, খুব দ্রুত গসাগু বের করে ফেলে।"
                    )
                ),
                LessonSection(
                    title = "দক্ষ উপায়ে মৌলিক সংখ্যা (Prime Number) পরীক্ষা",
                    content = """
একটি সংখ্যা N প্রাইম কি না তা জানতে ২ থেকে N-1 পর্যন্ত সব সংখ্যা দিয়ে ভাগ করার প্রয়োজন নেই। শুধুমাত্র ২ থেকে শুরু করে রুট N (i * i <= N) পর্যন্ত চেক করলেই যথেষ্ট! কারণ কোনো সংখ্যার উৎপাদক সবসময় জোড়ায় জোড়ায় থাকে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "মৌলিক সংখ্যা যাচাই",
                        code = """
#include <stdio.h>

int checkPrime(int n) {
    if (n <= 1) return 0;
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) return 0; // বিভাজ্য হলে প্রাইম নয়
    }
    return 1; // প্রাইম
}

int main() {
    int test = 37;
    if (checkPrime(test)) {
        printf("%d একটি মৌলিক সংখ্যা (Prime)\n", test);
    } else {
        printf("%d যৌগিক সংখ্যা (Composite)\n", test);
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "37 একটি মৌলিক সংখ্যা (Prime)",
                        explanation = "i * i <= n শর্ত ব্যবহারের কারণে লুপ অনেক কম সংখ্যক বার ঘুরে, ফলে প্রোগ্রামের গতি বহুগুণ বেড়ে যায়।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "if (n == 1) return 1; // ১ কে প্রাইম বিবেচনা করা",
                    correctCode = "if (n <= 1) return 0; // ১ বা তার ছোট কোনো সংখ্যা মৌলিক নয়",
                    explanation = "১ মৌলিক কিংবা যৌগিক কোনোটিই নয়।"
                )
            ),
            tips = listOf(
                "২ হলো একমাত্র জোড় মৌলিক সংখ্যা। বাকি সকল মৌলিক সংখ্যাই বিজোড়।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "১৫ ও ২০ এর লসাগু কত? সি কোড লিখে পরীক্ষা করো।",
                    hint = "LCM = (15 * 20) / GCD(15, 20)",
                    solutionCode = """
#include <stdio.h>
int main() {
    int a = 15, b = 20;
    int gcd = 5;
    printf("লসাগু: %d\n", (a * b) / gcd);
    return 0;
}
                    """.trimIndent()
                )
            )
        ),
        Lesson(
            id = "lesson_16",
            chapterNumber = 16,
            isExtra = true,
            titleBn = "মিনি প্রজেক্ট: সংখ্যা অনুমান করার খেলা ও ক্যালকুলেটর",
            titleEn = "Mini Projects: Number Guessing Game & Calculator",
            subtitle = "rand() ফাংশন, শর্ত ও লুপের চমৎকার সমন্বয়",
            durationMinutes = 25,
            objectives = listOf(
                "সি ভাষায় rand() ফাংশন দিয়ে যাদুকরী র‍্যান্ডম সংখ্যা তৈরি শেখা",
                "একটি পূর্ণাঙ্গ ইন্টারেক্টিভ কনসোল গেমের অ্যালগরিদম তৈরি করা",
                "switch-case ও math লাইব্রেরি দিয়ে বহু-কার্যকরী ক্যালকুলেটর নির্মাণ",
                "বাস্তব প্রোগ্রামিং প্রজেক্ট তৈরির আত্মবিশ্বাস অর্জন"
            ),
            sections = listOf(
                LessonSection(
                    title = "র‍্যান্ডম সংখ্যা তৈরি: rand() ফাংশন",
                    content = """
গেম বা সিমুলেশনে অনির্ধারিত বা হঠাৎ তৈরি হওয়া সংখ্যা প্রয়োজন হয়। সি ভাষায় `rand()` ফাংশন ব্যবহার করে 0 থেকে যেকোনো সীমার মধ্যে সংখ্যা তৈরি করা যায়।
উদাহরণস্বরূপ: `rand() % 100 + 1` দিলে ১ থেকে ১০০ এর মধ্যে যেকোনো একটি সংখ্যা পাওয়া যাবে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "র‍্যান্ডম সংখ্যা জেনারেশন",
                        code = """
#include <stdio.h>

int main() {
    printf("কম্পিউটার দ্বারা তৈরি তিনটি সংখ্যা:\n");
    for (int i = 1; i <= 3; i++) {
        int r = (rand() % 50) + 1; // ১ থেকে ৫০ এর মধ্যে
        printf("সংখ্যা %d: %d\n", i, r);
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "কম্পিউটার দ্বারা তৈরি তিনটি সংখ্যা:\nসংখ্যা 1: 15\nসংখ্যা 2: 38\nসংখ্যা 3: 42",
                        explanation = "rand() ফাংশন প্রতিবার বিভিন্ন সিউডো-র‍্যান্ডম সংখ্যা জেনারেট করে।"
                    )
                ),
                LessonSection(
                    title = "প্রজেক্ট ১: সংখ্যা অনুমান খেলা (Number Guessing Game)",
                    content = """
এই খেলায় কম্পিউটার গোপনে একটি সংখ্যা ধরে রাখবে (যেমন ৪৫)। খেলোয়াড় সংখ্যা অনুমান করবে। খেলোয়াড়ের সংখ্যা ছোট হলে কম্পিউটার বলবে 'আরো বড় সংখ্যা বলো!', আর বড় হলে বলবে 'আরো ছোট সংখ্যা বলো!'। মিলে গেলে জয়ের শুভেচ্ছা জানাবে।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "সংখ্যা অনুমান খেলা সিমুলেশন",
                        code = """
#include <stdio.h>

int main() {
    int secret = 42; // কম্পিউটার ভাবা সংখ্যা
    int guess;
    int attempts = 0;

    printf("=== সংখ্যা অনুমান খেলায় স্বাগতম! ===\n");
    printf("কম্পিউটার ১ থেকে ১০০ এর মধ্যে একটি সংখ্যা ভেবেছে।\n\n");

    // সিমুলেটেড ৩টি ট্রাই
    int playerGuesses[3] = {20, 60, 42};

    for (int i = 0; i < 3; i++) {
        guess = playerGuesses[i];
        attempts++;
        printf("আপনার অনুমান: %d -> ", guess);

        if (guess < secret) {
            printf("আরেকটু বড় সংখ্যা বলো!\n");
        } else if (guess > secret) {
            printf("আরেকটু ছোট সংখ্যা বলো!\n");
        } else {
            printf("অভিনন্দন! আপনি %d বারের চেষ্টায় সঠিক সংখ্যাটি বলতে পেরেছেন! 🎉\n", attempts);
            break;
        }
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "=== সংখ্যা অনুমান খেলায় স্বাগতম! ===\nকম্পিউটার ১ থেকে ১০০ এর মধ্যে একটি সংখ্যা ভেবেছে।\n\nআপনার অনুমান: 20 -> আরেকটু বড় সংখ্যা বলো!\nআপনার অনুমান: 60 -> আরেকটু ছোট সংখ্যা বলো!\nআপনার অনুমান: 42 -> অভিনন্দন! আপনি 3 বারের চেষ্টায় সঠিক সংখ্যাটি বলতে পেরেছেন! 🎉",
                        explanation = "if-else কন্ডিশন ও লুপের মাধ্যমে সুন্দর একটি লজিক্যাল কনসোল গেম তৈরি করা হয়েছে।"
                    )
                ),
                LessonSection(
                    title = "প্রজেক্ট ২: মিনি কনসোল ক্যালকুলেটর",
                    content = """
দুটি সংখ্যার যোগ, বিয়োগ, গুণ, ভাগ এবং ঘাত (Power) হিসাব করার একটি কমপ্যাক্ট প্রোগ্রাম।
                    """.trimIndent(),
                    codeExample = CodeExample(
                        title = "ক্যালকুলেটর প্রোগ্রাম",
                        code = """
#include <stdio.h>

int main() {
    double a = 12.0;
    double b = 4.0;
    char op = '+';

    printf("--- মিনি ক্যালকুলেটর ---\n");
    switch (op) {
        case '+':
            printf("%.1f + %.1f = %.1f\n", a, b, a + b);
            break;
        case '-':
            printf("%.1f - %.1f = %.1f\n", a, b, a - b);
            break;
        case '*':
            printf("%.1f * %.1f = %.1f\n", a, b, a * b);
            break;
        case '/':
            printf("%.1f / %.1f = %.1f\n", a, b, a / b);
            break;
        default:
            printf("অজানা অপারেটর\n");
    }
    return 0;
}
                        """.trimIndent(),
                        expectedOutput = "--- মিনি ক্যালকুলেটর ---\n12.0 + 4.0 = 16.0",
                        explanation = "switch-case স্টেটমেন্ট ব্যবহার করে অপারেটর অনুসারে হিসাব সম্পন্ন করা হয়েছে।"
                    )
                )
            ),
            commonMistakes = listOf(
                MistakeItem(
                    wrongCode = "rand() % 100 // মান আসবে 0 থেকে 99",
                    correctCode = "(rand() % 100) + 1 // মান আসবে 1 থেকে 100",
                    explanation = "১ থেকে ১০০ পরিসীমা পেতে চাইলে ১ যোগ করতে হয়।"
                )
            ),
            tips = listOf(
                "ছোট ছোট গেম ও প্রজেক্ট তৈরি করলে প্রোগ্রামিংয়ের ভয় দূর হয় এবং লজিক দ্রুত বিকশিত হয়।"
            ),
            practiceQuestions = listOf(
                PracticeQuestion(
                    question = "rand() % 6 + 1 এক্সপ্রেশনটি বাস্তব জীবনের কোন বস্তুর মতো আচরণ করে?",
                    hint = "লুডুর ছক্কার ৬টি তল থাকে (১ থেকে ৬)",
                    solutionCode = """
#include <stdio.h>
int main() {
    printf("এটি একটি লুডুর ছক্কার (Dice) মতো ১ থেকে ৬ পর্যন্ত যেকোনো সংখ্যা দেয়।\n");
    return 0;
}
                    """.trimIndent()
                )
            )
        )
    )
}
