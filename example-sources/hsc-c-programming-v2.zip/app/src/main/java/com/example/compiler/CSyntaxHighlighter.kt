package com.example.compiler

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import java.util.regex.Pattern

object CSyntaxHighlighter {

    // Dark Theme Colors (VS Code / One Dark aesthetic)
    private val KEYWORD_DARK = Color(0xFF64B5F6)          // Bright Sky Blue
    private val PREPROCESSOR_DARK = Color(0xFFCE93D8)     // Soft Orchid Purple
    private val STRING_DARK = Color(0xFFA5D6A7)           // Crisp Mint Green
    private val NUMBER_DARK = Color(0xFFFFCC80)           // Warm Amber
    private val FUNCTION_DARK = Color(0xFF80DEEA)         // Fresh Cyan
    private val COMMENT_DARK = Color(0xFF90A4AE)          // Slate Gray
    private val FORMAT_SPECIFIER_DARK = Color(0xFFFFD54F) // Golden Yellow

    // Light Theme Colors (GitHub / Xcode Light aesthetic)
    private val KEYWORD_LIGHT = Color(0xFF0969DA)          // Vibrant Deep Blue
    private val PREPROCESSOR_LIGHT = Color(0xFFA01B73)     // Deep Royal Magenta / Berry
    private val STRING_LIGHT = Color(0xFF116329)           // Rich Forest Green
    private val NUMBER_LIGHT = Color(0xFFB45309)           // Burnt Amber / Terracotta
    private val FUNCTION_LIGHT = Color(0xFF6F42C1)         // Regal Purple
    private val COMMENT_LIGHT = Color(0xFF57606A)          // Neutral Slate Gray
    private val FORMAT_SPECIFIER_LIGHT = Color(0xFFD97706) // Rich Orange

    private val KEYWORDS = setOf(
        "int", "float", "double", "char", "void", "long", "short", "unsigned", "signed",
        "return", "if", "else", "for", "while", "do", "switch", "case", "default",
        "break", "continue", "goto", "sizeof", "typedef", "struct", "union", "enum",
        "const", "static", "volatile", "extern", "auto", "register"
    )

    private val BUILT_IN_FUNCTIONS = setOf(
        "printf", "scanf", "main", "sqrt", "pow", "abs", "fabs", "ceil", "floor",
        "strlen", "strcpy", "strcmp", "strcat", "rand", "srand", "exit", "malloc", "free"
    )

    fun highlight(code: String, isDarkTheme: Boolean = true): AnnotatedString {
        return buildAnnotatedString {
            append(code)

            // 1. Words (Keywords, Function calls, Identifiers)
            val wordPattern = Pattern.compile("\\b([a-zA-Z_]\\w*)\\b")
            val wordMatcher = wordPattern.matcher(code)
            while (wordMatcher.find()) {
                val word = wordMatcher.group(1) ?: continue
                val start = wordMatcher.start()
                val end = wordMatcher.end()

                if (KEYWORDS.contains(word)) {
                    addStyle(
                        SpanStyle(
                            color = if (isDarkTheme) KEYWORD_DARK else KEYWORD_LIGHT,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        ),
                        start,
                        end
                    )
                } else if (BUILT_IN_FUNCTIONS.contains(word)) {
                    addStyle(
                        SpanStyle(
                            color = if (isDarkTheme) FUNCTION_DARK else FUNCTION_LIGHT,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        ),
                        start,
                        end
                    )
                }
            }

            // 2. Pattern for Numbers
            val numberPattern = Pattern.compile("\\b(\\d+(\\.\\d+)?)\\b")
            val numberMatcher = numberPattern.matcher(code)
            while (numberMatcher.find()) {
                addStyle(
                    SpanStyle(
                        color = if (isDarkTheme) NUMBER_DARK else NUMBER_LIGHT,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace
                    ),
                    numberMatcher.start(),
                    numberMatcher.end()
                )
            }

            // 3. Pattern for Preprocessors: #include ...
            val preprocessorPattern = Pattern.compile("#\\s*\\w+(\\s*<.*?>)?")
            val preprocessorMatcher = preprocessorPattern.matcher(code)
            while (preprocessorMatcher.find()) {
                addStyle(
                    SpanStyle(
                        color = if (isDarkTheme) PREPROCESSOR_DARK else PREPROCESSOR_LIGHT,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    ),
                    preprocessorMatcher.start(),
                    preprocessorMatcher.end()
                )
            }

            // 4. Pattern for Strings: "..." and '...'
            val stringPattern = Pattern.compile("\".*?\"|'.*?'")
            val stringMatcher = stringPattern.matcher(code)
            while (stringMatcher.find()) {
                addStyle(
                    SpanStyle(
                        color = if (isDarkTheme) STRING_DARK else STRING_LIGHT,
                        fontFamily = FontFamily.Monospace
                    ),
                    stringMatcher.start(),
                    stringMatcher.end()
                )
            }

            // 5. Pattern for Format Specifiers inside strings (%d, %f, %s, %c, \n, \t)
            val formatSpecifierPattern = Pattern.compile("(%[dfcsulL]|\\\\n|\\\\t)")
            val formatMatcher = formatSpecifierPattern.matcher(code)
            while (formatMatcher.find()) {
                addStyle(
                    SpanStyle(
                        color = if (isDarkTheme) FORMAT_SPECIFIER_DARK else FORMAT_SPECIFIER_LIGHT,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    formatMatcher.start(),
                    formatMatcher.end()
                )
            }

            // 6. Pattern for Comments: //... and /* ... */ (applied last so comments override inside code)
            val commentPattern = Pattern.compile("(//.*)|(/\\*[\\s\\S]*?\\*/)")
            val commentMatcher = commentPattern.matcher(code)
            while (commentMatcher.find()) {
                addStyle(
                    SpanStyle(
                        color = if (isDarkTheme) COMMENT_DARK else COMMENT_LIGHT,
                        fontFamily = FontFamily.Monospace
                    ),
                    commentMatcher.start(),
                    commentMatcher.end()
                )
            }
        }
    }
}
