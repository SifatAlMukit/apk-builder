package com.example.presentation.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.random.Random

data class ConfettiParticle(
    val initialX: Float,
    val speedY: Float,
    val size: Float,
    val color: Color
)

@Composable
fun ConfettiView(modifier: Modifier = Modifier) {
    val particles = remember {
        List(60) {
            ConfettiParticle(
                initialX = Random.nextFloat(),
                speedY = Random.nextFloat() * 0.5f + 0.5f,
                size = Random.nextFloat() * 12f + 6f,
                color = listOf(
                    Color(0xFFFF5252),
                    Color(0xFFFFD740),
                    Color(0xFF69F0AE),
                    Color(0xFF40C4FF),
                    Color(0xFFE040FB),
                    Color(0xFFFF6E40)
                ).random()
            )
        }
    }

    val transition = rememberInfiniteTransition(label = "confetti")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "progress"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height

        particles.forEach { p ->
            val y = (progress * p.speedY * height * 1.2f) % (height + 50f) - 50f
            val x = (p.initialX * width) + kotlin.math.sin((progress * 4 * Math.PI + p.initialX * 10).toFloat()) * 30f
            drawCircle(
                color = p.color,
                radius = p.size / 2,
                center = Offset(x, y)
            )
        }
    }
}
