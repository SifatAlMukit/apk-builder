package com.example.presentation

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.compiler.CRuntimeEngine
import com.example.compiler.ExecutionResult
import com.example.core.model.*
import com.example.data.local.AppDatabase
import com.example.data.local.LessonProgressEntity
import com.example.data.local.SnippetEntity
import com.example.data.repository.ContentRepository
import com.example.data.repository.GlobalSearchResult
import com.example.data.repository.UserDataRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "hsc_c_programming.db"
    ).fallbackToDestructiveMigration().build()

    val userRepo = UserDataRepository(db.appDao())

    // Progress map: lessonId -> isCompleted
    val progressMap: StateFlow<Map<String, Boolean>> = userRepo.allProgress
        .map { list -> list.associate { it.lessonId to it.isCompleted } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    val bookmarks = userRepo.allBookmarks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedSnippets = userRepo.allSnippets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quizScores = userRepo.allQuizScores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Playground state
    private val _playgroundCode = MutableStateFlow(
        """#include <stdio.h>

int main() {
    printf("স্বাগতম! সি প্রোগ্রামিং জগতে।\n");
    printf("HSC ICT অধ্যায় ৫ শুরু হলো।\n");
    return 0;
}"""
    )
    val playgroundCode: StateFlow<String> = _playgroundCode.asStateFlow()

    private val _playgroundStdin = MutableStateFlow("")
    val playgroundStdin: StateFlow<String> = _playgroundStdin.asStateFlow()

    private val _executionResult = MutableStateFlow<ExecutionResult?>(null)
    val executionResult: StateFlow<ExecutionResult?> = _executionResult.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    private val _liveTerminalOutput = MutableStateFlow("")
    val liveTerminalOutput: StateFlow<String> = _liveTerminalOutput.asStateFlow()

    private val _isWaitingForInput = MutableStateFlow(false)
    val isWaitingForInput: StateFlow<Boolean> = _isWaitingForInput.asStateFlow()

    // Editor word wrap state (default false: wrap off)
    private val _isWordWrapEnabled = MutableStateFlow(false)
    val isWordWrapEnabled: StateFlow<Boolean> = _isWordWrapEnabled.asStateFlow()

    private var pendingInputDeferred: kotlinx.coroutines.CompletableDeferred<String>? = null
    private var executionJob: kotlinx.coroutines.Job? = null

    // Global Search
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<GlobalSearchResult>>(emptyList())
    val searchResults: StateFlow<List<GlobalSearchResult>> = _searchResults.asStateFlow()

    fun setPlaygroundCode(code: String) {
        _playgroundCode.value = code
    }

    fun setPlaygroundStdin(stdin: String) {
        _playgroundStdin.value = stdin
    }

    fun runCode() {
        executionJob?.cancel()
        pendingInputDeferred?.cancel()
        pendingInputDeferred = null
        _liveTerminalOutput.value = ""
        _executionResult.value = null
        _isWaitingForInput.value = false
        _isExecuting.value = true

        executionJob = viewModelScope.launch(kotlinx.coroutines.Dispatchers.Default) {
            val result = CRuntimeEngine.compileAndExecuteInteractive(
                sourceCode = _playgroundCode.value,
                stdinInput = _playgroundStdin.value,
                onOutput = { chunk ->
                    _liveTerminalOutput.value += chunk
                },
                onInputRequest = {
                    _isWaitingForInput.value = true
                    val deferred = kotlinx.coroutines.CompletableDeferred<String>()
                    pendingInputDeferred = deferred
                    val input = deferred.await()
                    _isWaitingForInput.value = false
                    input
                }
            )
            _executionResult.value = result
            _isExecuting.value = false
            _isWaitingForInput.value = false
        }
    }

    fun sendTerminalInput(input: String) {
        val trimmed = input.trim()
        _liveTerminalOutput.value += "$trimmed\n"
        pendingInputDeferred?.complete(trimmed)
        pendingInputDeferred = null
        _isWaitingForInput.value = false
    }

    fun stopExecution() {
        executionJob?.cancel()
        executionJob = null
        pendingInputDeferred?.cancel()
        pendingInputDeferred = null
        _isExecuting.value = false
        _isWaitingForInput.value = false
        _liveTerminalOutput.value += "\n[প্রসেস জোরপূর্বক থামানো হয়েছে (Process terminated)]\n"
    }

    fun clearExecution() {
        executionJob?.cancel()
        pendingInputDeferred?.cancel()
        _liveTerminalOutput.value = ""
        _executionResult.value = null
        _isExecuting.value = false
        _isWaitingForInput.value = false
    }

    fun toggleWordWrap() {
        _isWordWrapEnabled.value = !_isWordWrapEnabled.value
    }

    fun setWordWrap(enabled: Boolean) {
        _isWordWrapEnabled.value = enabled
    }

    fun toggleLessonCompleted(lessonId: String) {
        viewModelScope.launch {
            val current = progressMap.value[lessonId] ?: false
            userRepo.toggleLessonProgress(lessonId, current)
        }
    }

    fun setLessonProgress(lessonId: String, isCompleted: Boolean) {
        viewModelScope.launch {
            userRepo.setLessonProgress(lessonId, isCompleted)
        }
    }

    fun toggleBookmark(id: String, type: String, title: String, subtitle: String, targetId: String) {
        viewModelScope.launch {
            val isBookmarked = bookmarks.value.any { it.id == id }
            userRepo.toggleBookmark(id, type, title, subtitle, targetId, isBookmarked)
        }
    }

    fun saveCurrentSnippet(title: String) {
        viewModelScope.launch {
            userRepo.saveSnippet(title, _playgroundCode.value)
        }
    }

    fun deleteSnippet(id: Long) {
        viewModelScope.launch {
            userRepo.deleteSnippet(id)
        }
    }

    fun saveQuizResult(chapterId: String, score: Int, total: Int) {
        viewModelScope.launch {
            userRepo.saveQuizScore(chapterId, score, total)
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        _searchResults.value = ContentRepository.globalSearch(query)
    }

    fun resetAllProgress() {
        viewModelScope.launch {
            userRepo.resetAllProgress()
        }
    }
}
