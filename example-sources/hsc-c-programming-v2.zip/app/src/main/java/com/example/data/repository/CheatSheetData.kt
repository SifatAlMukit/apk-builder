package com.example.data.repository

import com.example.core.model.CheatSheetEntry
import com.example.core.model.CheatSheetItem

object CheatSheetData {

    val cheatSheets: List<CheatSheetItem> = listOf(
        CheatSheetItem(
            category = "KEYWORDS",
            titleBn = "সি ভাষার সংরক্ষিত ৩২টি কী-ওয়ার্ড",
            items = listOf(
                CheatSheetEntry("auto", "স্বয়ংক্রিয় চলক", "auto int x;", "ফাংশনের ভেতরের লোকাল চলকের ডিফল্ট স্টোরেজ ক্লাস।", "auto int a = 10;"),
                CheatSheetEntry("break", "লুপ বা সুইচ ভঙ্গ", "break;", "লুপ অথবা switch থেকে তাৎক্ষণিকভাবে বাইরে আসার নির্দেশ।", "if (i == 5) break;"),
                CheatSheetEntry("case", "সুইচ কেস লেবেল", "case মান:", "switch স্টেটমেন্টের বিকল্প শাখার মান নির্দিষ্ট করা।", "case 1: printf(\"One\"); break;"),
                CheatSheetEntry("char", "ক্যারেক্টার টাইপ", "char c = 'A';", "একটিমাত্র ক্যারেক্টার সংরক্ষণে (১ বাইট মেমোরি)।", "char ch = 'Z';"),
                CheatSheetEntry("const", "অপরিবর্তনীয় ধ্রুবক", "const float PI = 3.14;", "যে চলকের মান প্রোগ্রামে কখনো পরিবর্তন করা যায় না।", "const int MAX = 100;"),
                CheatSheetEntry("continue", "লুপের পরের পুনরাবৃত্তি", "continue;", "লুপের বাকি অংশ বাদ দিয়ে পরবর্তী পুনরাবৃত্তিতে যাওয়া।", "if (i % 2 == 0) continue;"),
                CheatSheetEntry("default", "সুইচ ডিফল্ট শাখা", "default:", "switch-এ কোনো case না মিললে এটি নির্বাহ হয়।", "default: printf(\"Invalid\");"),
                CheatSheetEntry("do", "ডু-হোয়াইল লুপ", "do { ... } while (শর্ত);", "শর্ত মিথ্যা হলেও অন্তত একবার লুপ বডি নির্বাহ করে।", "do { i++; } while(i < 5);"),
                CheatSheetEntry("double", "দ্বিগুণ নির্ভুল ভগ্নাংশ", "double d = 3.14159;", "৮ বাইট মেমোরি ধারণকারী উচ্চ নির্ভুলতার ভগ্নাংশ।", "double pi = 3.14159265;"),
                CheatSheetEntry("else", "বিকল্প শর্তের শাখা", "if (...) { ... } else { ... }", "if এর শর্ত মিথ্যা হলে else ব্লক কার্যকর হয়।", "else { printf(\"Odd\"); }"),
                CheatSheetEntry("enum", "গণনাকৃত টাইপ", "enum Day { SAT, SUN };", "ব্যবহারকারী নির্ধারিত পূর্ণসংখ্যা ধ্রুবকের তালিকা।", "enum Color { RED, GREEN };"),
                CheatSheetEntry("float", "একক নির্ভুল ভগ্নাংশ", "float f = 5.75f;", "৪ বাইট মেমোরি নিয়ে দশমিকযুক্ত সংখ্যা সংরক্ষণ।", "float gpa = 4.88;"),
                CheatSheetEntry("for", "নির্দিষ্ট পুনরাবৃত্তি লুপ", "for (শুরু; শর্ত; বৃদ্ধি) { }", "পূর্বনির্ধারিত সংখ্যক বার কোনো কাজ সম্পন্ন করতে।", "for(int i=0; i<10; i++)"),
                CheatSheetEntry("if", "শর্তযুক্ত সিদ্ধান্ত", "if (শর্ত) { ... }", "শর্ত সত্য হলে ভেতরের কোড রান করে।", "if (score >= 80)"),
                CheatSheetEntry("int", "পূর্ণসংখ্যা টাইপ", "int x = 25;", "ধনাত্মক বা ঋণাত্মক পূর্ণসংখ্যা (সাধারণত ৪ বাইট)।", "int age = 17;"),
                CheatSheetEntry("return", "মান ফেরত ও সমাপ্তি", "return মান;", "ফাংশন থেকে ফলাফল ফেরত দিয়ে ফাংশন শেষ করা।", "return 0;"),
                CheatSheetEntry("sizeof", "মেমোরি আকার পরিমাপ", "sizeof(টাইপ)", "কোনো ডেটা টাইপ বা চলকের মেমোরি সাইজ (বাইটে) দেয়।", "printf(\"%lu\", sizeof(int));"),
                CheatSheetEntry("struct", "স্ট্রাকচার ডিফাইন", "struct নাম { ... };", "ভিন্ন ভিন্ন ডেটা টাইপকে একক ইউনিটে একত্রিত করা।", "struct Student { int r; };"),
                CheatSheetEntry("switch", "বহু-বিকল্প ব্রাঞ্চিং", "switch (মান) { ... }", "একটি ভ্যারিয়েবলের বিভিন্ন মানের উপর ভিত্তি করে শাখা।", "switch (choice) { ... }"),
                CheatSheetEntry("void", "ফাঁকা বা মানহীন টাইপ", "void myFunction()", "ফাংশন কোনো মান রিটার্ন না করলে void ব্যবহার হয়।", "void display();"),
                CheatSheetEntry("while", "শর্তযুক্ত লুপ", "while (শর্ত) { ... }", "শর্ত যতক্ষণ সত্য থাকবে ততক্ষণ লুপ চলতে থাকবে।", "while (count < 10)")
            )
        ),
        CheatSheetItem(
            category = "OPERATORS",
            titleBn = "অপারেটর ও অগ্রাধিকার ক্রম (Precedence)",
            items = listOf(
                CheatSheetEntry("() []", "প্যারেন্থেসিস ও অ্যারে সাবস্ক্রিপ্ট", "(a + b) * c", "সর্বোচ্চ অগ্রাধিকার (বাম থেকে ডানে মূল্যায়ন)।", "int x = (2 + 3) * 4; // 20"),
                CheatSheetEntry("++ --", "ইনক্রিমেন্ট ও ডিক্রিমেন্ট", "x++ বা ++x", "মান ১ বৃদ্ধি বা হ্রাস করে।", "int y = ++x;"),
                CheatSheetEntry("! ~ + -", "ইউনারি অপারেটর", "!flag, -num", "লজিক্যাল নট, বিটওয়াইজ নট, ঋণাত্মক চিহ্ন।", "if (!isFound) { ... }"),
                CheatSheetEntry("* / %", "গুণ, ভাগ ও মডুলাস", "a * b, a / b, a % b", "যোগ ও বিয়োগের পূর্বে গুণ-ভাগ-ভাগশেষ সম্পন্ন হয়।", "int r = 17 % 5; // 2"),
                CheatSheetEntry("+ -", "যোগ ও বিয়োগ", "a + b, a - b", "সাধারণ গাণিতিক যোগ ও বিয়োগ।", "int sum = a + b;"),
                CheatSheetEntry("< <= > >=", "রিলেশনাল তুলনা", "a < b, a >= b", "ছোট-বড় তুলনা করে ১ (সত্য) বা ০ (মিথ্যা) দেয়।", "if (age >= 18)"),
                CheatSheetEntry("== !=", "সমতা ও অসমতা", "a == b, a != b", "দুটি মান পুরোপুরি সমান কিনা বা অসমান কিনা।", "if (x == 0)"),
                CheatSheetEntry("&&", "লজিক্যাল AND", "cond1 && cond2", "উভয় শর্ত সত্য হলেই কেবল সত্য রিটার্ন করে।", "if (a > 0 && b > 0)"),
                CheatSheetEntry("||", "লজিক্যাল OR", "cond1 || cond2", "যেকোনো একটি শর্ত সত্য হলেই ফলাফল সত্য।", "if (day == 1 || day == 7)"),
                CheatSheetEntry("? :", "টারনারি (শর্তযুক্ত) অপারেটর", "শর্ত ? সত্য_মান : মিথ্যা_মান", "এক লাইনে if-else লেখার সংক্ষিপ্ত রূপ।", "int max = (a > b) ? a : b;"),
                CheatSheetEntry("= += -=", "অ্যাসাইনমেন্ট অপারেটর", "x += 5 (অর্থাৎ x = x + 5)", "সর্বনিম্ন অগ্রাধিকার (ডান থেকে বামে কাজ করে)।", "total += price;")
            )
        ),
        CheatSheetItem(
            category = "FORMAT_SPECIFIERS",
            titleBn = "ফরম্যাট স্পেসিফায়ার রেফারেন্স",
            items = listOf(
                CheatSheetEntry("%d বা %i", "দশমিক পূর্ণসংখ্যা (Signed int)", "printf(\"%d\", n);", "সাধারণ int টাইপের পূর্ণসংখ্যা প্রিন্ট বা ইনপুটে।", "int x = 25; printf(\"%d\", x);"),
                CheatSheetEntry("%f", "ভগ্নাংশ (float)", "printf(\"%.2f\", f);", "float ভগ্নাংশ প্রিন্টে; %.2f দশমিকের পর ২ ঘর দেখায়।", "printf(\"%.2f\", 3.1416); // 3.14"),
                CheatSheetEntry("%lf", "ডাবল প্রিসিশন (double)", "scanf(\"%lf\", &d);", "double টাইপ ইনপুট নেওয়ার সময় %lf আবশ্যক।", "double pi; scanf(\"%lf\", &pi);"),
                CheatSheetEntry("%c", "একক ক্যারেক্টার (char)", "printf(\"%c\", ch);", "একটিমাত্র ইংরেজি বর্ণ বা প্রতীক প্রদর্শনে।", "char c = 'A'; printf(\"%c\", c);"),
                CheatSheetEntry("%s", "স্ট্রিং (ক্যারেক্টার অ্যারে)", "printf(\"%s\", str);", "সম্পূর্ণ বাক্য বা শব্দ আউটপুটে।", "char name[] = \"HSC\"; printf(\"%s\", name);"),
                CheatSheetEntry("%u", "চিহ্নহীন পূর্ণসংখ্যা (unsigned int)", "printf(\"%u\", u);", "শুধুমাত্র অঋণাত্মক পূর্ণসংখ্যার জন্য (০ থেকে ৬৫৫৩৫)।", "unsigned int u = 40000;"),
                CheatSheetEntry("%p", "মেমোরি পয়েন্টার অ্যাড্রেস", "printf(\"%p\", ptr);", "কোনো চলকের হেক্সাডেসিমেল মেমোরি ঠিকানা দেখাতে।", "printf(\"%p\", &x);"),
                CheatSheetEntry("%%", "শতকরা প্রতীক (%) প্রিন্ট", "printf(\"100%%\");", "কনসোলে শতকরা চিহ্ন দেখানোর জন্য দুবার %% লিখতে হয়।", "printf(\"Discount: 15%%\");")
            )
        ),
        CheatSheetItem(
            category = "ESCAPE_SEQUENCES",
            titleBn = "এস্কেপ সিকোয়েন্স রেফারেন্স",
            items = listOf(
                CheatSheetEntry("\\n", "নতুন লাইন (Newline)", "printf(\"\\n\");", "কার্সারকে পরবর্তী লাইনের শুরুতে নিয়ে যায়।", "printf(\"Line 1\\nLine 2\");"),
                CheatSheetEntry("\\t", "অনুভূমিক ট্যাব (Tab)", "printf(\"\\t\");", "সাধারণত ৮টি অক্ষরের সমান ফাঁকা স্থান তৈরি করে।", "printf(\"Roll\\tName\\n\");"),
                CheatSheetEntry("\\\\", "ব্যাকস্ল্যাশ প্রতীক", "printf(\"\\\\\");", "আউটপুটে একটি '\\' চিহ্ন প্রিন্ট করতে।", "printf(\"C:\\\\Program\");"),
                CheatSheetEntry("\\\"", "ডাবল কোটেশন চিহ্ন", "printf(\"\\\"\");", "আউটপুট টেক্সটের ভেতরে কোটেশন দেখাতে।", "printf(\"He said \\\"Hello\\\"\");"),
                CheatSheetEntry("\\'", "সিঙ্গেল কোটেশন চিহ্ন", "printf(\"\\'\");", "সিঙ্গেল কোটেশন প্রতীক প্রদর্শন।", "printf(\"It\\'s easy\");"),
                CheatSheetEntry("\\a", "সতর্কবার্তা বেল বা বিপ", "printf(\"\\a\");", "কম্পিউটারের ইন্টারনাল স্পিকার থেকে অ্যালার্ম শব্দ বাজায়।", "printf(\"Alert!\\a\");"),
                CheatSheetEntry("\\0", "নাল ক্যারেক্টার (Null terminator)", "char s[] = \"Hi\\0\";", "স্ট্রিং এর সমাপ্তি নির্দেশক ক্যারেক্টার।", "str[length] = '\\0';")
            )
        ),
        CheatSheetItem(
            category = "HEADER_FILES",
            titleBn = "স্ট্যান্ডার্ড হেডার ফাইল ও গুরুত্বপূর্ণ ফাংশন",
            items = listOf(
                CheatSheetEntry("<stdio.h>", "স্ট্যান্ডার্ড ইনপুট আউটপুট", "#include <stdio.h>", "printf(), scanf(), getchar(), putchar() ইত্যাদি ফাংশন।", "printf(\"Hello\");"),
                CheatSheetEntry("<math.h>", "গাণিতিক লাইব্রেরি", "#include <math.h>", "sqrt() বর্গমূল, pow() ঘাত, abs() পরমমান, sin(), cos()।", "double r = sqrt(25.0); // 5.0"),
                CheatSheetEntry("<string.h>", "স্ট্রিং অপারেশন", "#include <string.h>", "strlen() দৈর্ঘ্য, strcpy() কপি, strcmp() তুলনা, strcat() জোড়া।", "int len = strlen(\"Dhaka\"); // 5"),
                CheatSheetEntry("<stdlib.h>", "সাধারণ ইউটিলিটি", "#include <stdlib.h>", "abs() পূর্ণসংখ্যার পরমমান, rand() দৈব সংখ্যা, exit() প্রস্থান।", "int n = rand() % 100;"),
                CheatSheetEntry("<ctype.h>", "ক্যারেক্টার পরীক্ষণ", "#include <ctype.h>", "isalpha() বর্ণ কিনা, isdigit() অঙ্ক কিনা, toupper() বড় হাতের।", "if (isdigit('5')) { ... }")
            )
        )
    )
}
