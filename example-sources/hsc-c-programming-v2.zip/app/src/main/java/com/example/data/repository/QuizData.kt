package com.example.data.repository

import com.example.core.model.QuizQuestion

object QuizData {

    val questions: List<QuizQuestion> = listOf(
        QuizQuestion(
            id = "q1",
            chapterId = "lesson_1",
            questionBn = "সি (C) প্রোগ্রামিং ভাষার জনক কে?",
            optionsBn = listOf("বিল গেটস", "ডেনিস রিচি", "টিম বার্নার্স লি", "চার্লস ব্যাবেজ"),
            correctOptionIndex = 1,
            explanationBn = "১৯৭২ সালে আমেরিকার এটিঅ্যান্ডটি বেল ল্যাবরেটরিতে বিজ্ঞানী ডেনিস রিচি (Dennis Ritchie) সি প্রোগ্রামিং ভাষা উদ্ভাবন করেন।"
        ),
        QuizQuestion(
            id = "q2",
            chapterId = "lesson_1",
            questionBn = "সি ভাষাকে কোন স্তরের ভাষা বলা হয়?",
            optionsBn = listOf("নিম্নস্তরের ভাষা", "মধ্যম স্তরের ভাষা", "৪র্থ প্রজন্মের ভাষা", "৫ম প্রজন্মের ভাষা"),
            correctOptionIndex = 1,
            explanationBn = "উচ্চস্তরের ভাষার সহজবোধ্যতা এবং নিম্নস্তরের ভাষার মতো সরাসরি মেমোরি নিয়ন্ত্রণের সুবিধার জন্য সি-কে মধ্যম স্তরের ভাষা (Middle Level Language) বলা হয়।"
        ),
        QuizQuestion(
            id = "q3",
            chapterId = "lesson_2",
            questionBn = "সম্পূর্ণ সোর্স কোডকে একসাথে অবজেক্ট কোডে রূপান্তর করে কোনটি?",
            optionsBn = listOf("ইন্টারপ্রেটার", "কম্পাইলার", "অ্যাসেম্বলার", "ডিবাগার"),
            correctOptionIndex = 1,
            explanationBn = "কম্পাইলার পুরো প্রোগ্রামকে একসাথে স্ক্যান করে অনুবাদ করে। অপরদিকে ইন্টারপ্রেটার লাইন বাই লাইন অনুবাদ করে।"
        ),
        QuizQuestion(
            id = "q4",
            chapterId = "lesson_2",
            questionBn = "সি প্রোগ্রামে এক লাইনের মন্তব্য (Single line comment) লেখার জন্য কোনটি ব্যবহৃত হয়?",
            optionsBn = listOf("/* ... */", "//", "#", "<!-- -->"),
            correctOptionIndex = 1,
            explanationBn = "সি ভাষায় এক লাইনের কমেন্টের জন্য // এবং বহু লাইনের জন্য /* ... */ ব্যবহৃত হয়।"
        ),
        QuizQuestion(
            id = "q5",
            chapterId = "lesson_3",
            questionBn = "ফ্লোচার্টে সিদ্ধান্ত বা শর্ত (Decision) প্রকাশের জন্য কোন প্রতীক ব্যবহৃত হয়?",
            optionsBn = listOf("আয়তক্ষেত্র", "ডিম্বাকৃতি", "হীরক বা রম্বস", "সামান্তরিক"),
            correctOptionIndex = 2,
            explanationBn = "হীরক বা রম্বস (Diamond) আকৃতির প্রতীকটি শর্ত যাচাই বা সিদ্ধান্ত গ্রহণের প্রতীক হিসেবে ব্যবহৃত হয়।"
        ),
        QuizQuestion(
            id = "q6",
            chapterId = "lesson_4",
            questionBn = "নিচের কোনটি সি ভাষার একটি বৈধ চলক (Variable)?",
            optionsBn = listOf("2nd_name", "total mark", "sum_1", "float"),
            correctOptionIndex = 2,
            explanationBn = "চলকের নাম ডিজিট দিয়ে শুরু হতে পারে না (2nd_name অবৈধ), স্পেস থাকতে পারে না (total mark অবৈধ) এবং কী-ওয়ার্ড হতে পারে না (float অবৈধ)। তাই sum_1 বৈধ।"
        ),
        QuizQuestion(
            id = "q7",
            chapterId = "lesson_5",
            questionBn = "সি ভাষায় 19 % 4 এর ফলাফল কত হবে?",
            optionsBn = listOf("4", "3", "4.75", "0"),
            correctOptionIndex = 1,
            explanationBn = "মডুলাস (%) অপারেটর ভাগশেষ বের করে। ১৯ কে ৪ দিয়ে ভাগ করলে ৪ চারে ১৬ হয় এবং ভাগশেষ ৩ থাকে।"
        ),
        QuizQuestion(
            id = "q8",
            chapterId = "lesson_5",
            questionBn = "int a = 5; int b = ++a; এখানে b এর মান কত?",
            optionsBn = listOf("5", "6", "4", "7"),
            correctOptionIndex = 1,
            explanationBn = "প্রি-ইনক্রিমেন্টে (++a) প্রথমে a এর মান ১ বৃদ্ধি পেয়ে ৬ হয়, তারপর সেই মান b তে জমা হয়।"
        ),
        QuizQuestion(
            id = "q9",
            chapterId = "lesson_6",
            questionBn = "scanf() ফাংশনে চলকের নামের পূর্বে কোন প্রতীক দেওয়া বাধ্যতামূলক?",
            optionsBn = listOf("* (স্টার)", "& (অ্যাম্পারস্যান্ড)", "# (হ্যাশ)", "% (শতকরা)"),
            correctOptionIndex = 1,
            explanationBn = "& প্রতীক হলো অ্যাড্রেস-অব অপারেটর। এটি চলকের মেমোরি ঠিকানা নির্দেশ করে যাতে scanf সেখানে ইনপুট রাখতে পারে।"
        ),
        QuizQuestion(
            id = "q10",
            chapterId = "lesson_7",
            questionBn = "switch-case স্টেটমেন্টে প্রতিটি case শেষে কোনটি না দিলে পরবর্তী case ও চালু হয়ে যায়?",
            optionsBn = listOf("continue", "break", "return", "exit"),
            correctOptionIndex = 1,
            explanationBn = "break স্টেটমেন্ট না দিলে switch থেকে বের না হয়ে সরাসরি পরবর্তী case এ প্রবেশ করে (যাকে Fall-through বলে)।"
        ),
        QuizQuestion(
            id = "q11",
            chapterId = "lesson_8",
            questionBn = "শর্ত মিথ্যা হলেও অন্তত একবার কার্যকর হয় কোন লুপটি?",
            optionsBn = listOf("for লুপ", "while লুপ", "do-while লুপ", "কোনোটিই নয়"),
            correctOptionIndex = 2,
            explanationBn = "do-while একটি এক্সিট-কন্ট্রোলড লুপ; এর শর্ত লুপ বডির শেষে যাচাই করা হয় বলে প্রথমবার শর্ত চেক ছাড়াই বডি চলে।"
        ),
        QuizQuestion(
            id = "q12",
            chapterId = "lesson_9",
            questionBn = "int marks[10]; এই অ্যারের সর্বশেষ উপাদানের ইনডেক্স কত?",
            optionsBn = listOf("10", "9", "0", "11"),
            correctOptionIndex = 1,
            explanationBn = "সি ভাষায় অ্যারে ইনডেক্স ০ থেকে শুরু হয়। ১০ সাইজের অ্যারের ইনডেক্স হবে ০ থেকে (১০ - ১) = ৯ পর্যন্ত।"
        ),
        QuizQuestion(
            id = "q13",
            chapterId = "lesson_10",
            questionBn = "যে ফাংশন কোনো মান ফেরত দেয় না, তার রিটার্ন টাইপ কী?",
            optionsBn = listOf("int", "float", "void", "null"),
            correctOptionIndex = 2,
            explanationBn = "মানহীন বা কোনো ফলাফল রিটার্ন না করা ফাংশনে void রিটার্ন টাইপ উল্লেখ করতে হয়।"
        ),
        QuizQuestion(
            id = "q14",
            chapterId = "lesson_11",
            questionBn = "পয়েন্টার যে ঠিকানায় নির্দেশ করছে তার মান পড়ার জন্য কোন প্রতীক ব্যবহৃত হয়?",
            optionsBn = listOf("&", "*", "->", "."),
            correctOptionIndex = 1,
            explanationBn = "* (অ্যাস্ট্যারিস্ক বা ইনডাইরেকশন অপারেটর) পয়েন্টারের নির্দেশিত মেমোরি অবস্থানের মান (Value at address) নির্দেশ করে।"
        ),
        QuizQuestion(
            id = "q15",
            chapterId = "lesson_12",
            questionBn = "ভিন্ন ভিন্ন ডেটা টাইপকে একক ইউনিটে একত্রিত করতে কোনটি ব্যবহৃত হয়?",
            optionsBn = listOf("অ্যারে (Array)", "স্ট্রাকচার (Structure)", "পয়েন্টার (Pointer)", "লুপ (Loop)"),
            correctOptionIndex = 1,
            explanationBn = "অ্যারে সমজাতীয় ডেটা সংরক্ষণ করে, আর স্ট্রাকচার (struct) বিভিন্ন ধরনের ডেটা টাইপের মিশ্রণ তৈরি করে।"
        )
    )
}
