package com.example.presentation.lesson

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Bookmark
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.ContentRepository
import com.example.presentation.AppViewModel
import com.example.presentation.components.CodeBlockView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonDetailScreen(
    lessonId: String,
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    onOpenInPlayground: (String) -> Unit,
    onNavigateToQuiz: (String) -> Unit,
    onNavigateToFlowchart: (String) -> Unit,
    onNavigateToNextLesson: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val lesson = remember(lessonId) { ContentRepository.getLessonById(lessonId) }
    val progressMap by viewModel.progressMap.collectAsState()
    val bookmarks by viewModel.bookmarks.collectAsState()
    val isCompleted = progressMap[lessonId] == true
    val isBookmarked = bookmarks.any { it.id == lessonId }

    if (lesson == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("পাঠটি খুঁজে পাওয়া যায়নি।")
        }
        return
    }

    val nextLesson = remember(lesson.chapterNumber) {
        ContentRepository.getAllLessons().find { it.chapterNumber == lesson.chapterNumber + 1 }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (lesson.isExtra) "অতিরিক্ত পাঠ: ${lesson.titleBn}" else "অধ্যায় ${lesson.chapterNumber}: ${lesson.titleBn}",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                },
                actions = {
                    // Bookmark toggle
                    IconButton(
                        onClick = {
                            viewModel.toggleBookmark(
                                id = lesson.id,
                                type = "LESSON",
                                title = "অধ্যায় ${lesson.chapterNumber}: ${lesson.titleBn}",
                                subtitle = lesson.subtitle,
                                targetId = lesson.id
                            )
                        },
                        modifier = Modifier.testTag("bookmark_lesson_btn")
                    ) {
                        Icon(
                            imageVector = if (isBookmarked) Icons.Default.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "বুকমার্ক",
                            tint = if (isBookmarked) Color(0xFFFFA000) else MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Mark as read button
                    FilledIconToggleButton(
                        checked = isCompleted,
                        onCheckedChange = { viewModel.toggleLessonCompleted(lesson.id) },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("mark_as_read_btn")
                    ) {
                        Icon(
                            imageVector = if (isCompleted) Icons.Default.CheckCircle else Icons.Default.Check,
                            contentDescription = "পড়া সম্পন্ন",
                            tint = if (isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 3.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { onNavigateToQuiz(lesson.id) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Quiz, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("কুইজ দিন", fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            viewModel.setLessonProgress(lesson.id, true)
                            if (nextLesson != null) {
                                onNavigateToNextLesson(nextLesson.id)
                            } else {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(if (isCompleted) "পরবর্তী পাঠ" else "পড়া সম্পন্ন ও পরবর্তী", fontSize = 13.sp)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header info
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Column {
                    if (lesson.isExtra) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.7f)
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("🚀", fontSize = 22.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "সিলেবাস বহির্ভূত সমৃদ্ধি পাঠ",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                    Text(
                                        text = "এই অধ্যায়টি আপনার প্রোগ্রামিং দক্ষতা ও জানার আগ্রহ বাড়াতে যুক্ত করা হয়েছে। এটি এইচএসসি বোর্ড পরীক্ষার মূল সিলেবাসের অন্তর্ভুক্ত নয়।",
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp,
                                        color = MaterialTheme.colorScheme.onTertiaryContainer
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (lesson.isExtra) MaterialTheme.colorScheme.tertiaryContainer else MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = if (lesson.isExtra) "★ অতিরিক্ত পাঠ (ঐচ্ছিক)" else "HSC ICT অধ্যায় ৫.${lesson.chapterNumber}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (lesson.isExtra) MaterialTheme.colorScheme.onTertiaryContainer else MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "পড়ার সময়: ${lesson.durationMinutes} মিনিট",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = lesson.titleBn,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = lesson.titleEn,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = lesson.subtitle,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Learning objectives
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.CheckCircleOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "এই পাঠ শেষে যা যা শিখবে:",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        lesson.objectives.forEach { obj ->
                            Row(
                                modifier = Modifier.padding(vertical = 3.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text("• ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                Text(
                                    text = obj,
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Sections
            items(lesson.sections) { section ->
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = section.title,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = section.content,
                        fontSize = 14.sp,
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Note box
                    if (!section.note.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1))
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    Icons.Default.Info,
                                    contentDescription = null,
                                    tint = Color(0xFFF57F17),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = section.note,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    color = Color(0xFF4E342E)
                                )
                            }
                        }
                    }

                    // Code example
                    if (section.codeExample != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        CodeBlockView(
                            title = section.codeExample.title,
                            code = section.codeExample.code,
                            expectedOutput = section.codeExample.expectedOutput,
                            explanation = section.codeExample.explanation,
                            onRunInPlayground = onOpenInPlayground
                        )
                    }
                }
            }

            // Flowchart action CTA (especially for relevant chapters like algorithm, loops, branching)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF3E8FF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.AccountTree,
                            contentDescription = null,
                            tint = Color(0xFF7E57C2),
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ফ্লোচার্ট ভিজ্যুয়ালাইজার",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF4A148C)
                            )
                            Text(
                                text = "অ্যানিমেটেড ধাপে ধাপে এক্সিকিউশন ও ভ্যারিয়েবল ট্রেসিং দেখুন",
                                fontSize = 11.sp,
                                color = Color(0xFF6A1B9A)
                            )
                        }
                        FilledTonalButton(
                            onClick = { onNavigateToFlowchart("fc_even_odd") },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("ভিজ্যুয়াল দেখুন", fontSize = 12.sp)
                        }
                    }
                }
            }

            // Common Mistakes
            if (lesson.commonMistakes.isNotEmpty()) {
                item {
                    Text(
                        text = "শিক্ষার্থীদের সাধারণ ভুলসমূহ ও সমাধান:",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFD32F2F)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    lesson.commonMistakes.forEach { mistake ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Cancel,
                                        contentDescription = null,
                                        tint = Color(0xFFC62828),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "ভুল পদ্ধতি: ${mistake.wrongCode}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFFC62828)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF2E7D32),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "সঠিক পদ্ধতি: ${mistake.correctCode}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF2E7D32)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "কারণ: ${mistake.explanation}",
                                    fontSize = 11.sp,
                                    lineHeight = 16.sp,
                                    color = Color(0xFF37474F)
                                )
                            }
                        }
                    }
                }
            }

            // Practice Questions
            if (lesson.practiceQuestions.isNotEmpty()) {
                item {
                    Text(
                        text = "অনুশীলনী প্রশ্ন ও সমাধান:",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                items(lesson.practiceQuestions) { pq ->
                    var isExpanded by remember { mutableStateOf(false) }
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = "প্রশ্ন: ${pq.question}",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ইঙ্গিত: ${pq.hint}",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = { isExpanded = !isExpanded },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(if (isExpanded) "সমাধান লুকান" else "সমাধান কোড দেখুন")
                            }
                            AnimatedVisibility(visible = isExpanded) {
                                CodeBlockView(
                                    title = "সমাধান কোড",
                                    code = pq.solutionCode,
                                    onRunInPlayground = onOpenInPlayground
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}
