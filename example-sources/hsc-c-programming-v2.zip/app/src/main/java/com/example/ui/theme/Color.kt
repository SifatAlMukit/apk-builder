package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val PrimaryBlue = Color(0xFF006699)
val PrimaryBlueVariant = Color(0xFF004D73)
val SecondaryTeal = Color(0xFF00838F)
val TertiaryAmber = Color(0xFFF57C00)
val BackgroundLight = Color(0xFFF8F9FC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEFF2F7)
val OnPrimaryLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF191C1E)

// Dark Theme Colors
val PrimaryBlueDark = Color(0xFF4FC3F7)
val SecondaryTealDark = Color(0xFF80DEEA)
val TertiaryAmberDark = Color(0xFFFFB74D)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OnPrimaryDark = Color(0xFF00344F)
val OnSurfaceDark = Color(0xFFF1F5F9)

// Code & Terminal Colors
val CodeBackgroundDark = Color(0xFF131722)
val CodeBackgroundLight = Color(0xFFF1F5F9)
val TerminalGreen = Color(0xFF4CAF50)
val TerminalError = Color(0xFFEF5350)
val AccentPurple = Color(0xFF7E57C2)
val SuccessGreen = Color(0xFF2E7D32)
val WarningOrange = Color(0xFFED6C02)
