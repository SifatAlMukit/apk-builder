package com.example.compiler

class CParseException(message: String, val line: Int) : Exception("লাইন $line: $message")

class CParser(private val tokens: List<Token>) {
    private var current = 0

    fun parse(): CProgram {
        val includes = mutableListOf<String>()
        val functions = mutableMapOf<String, FunctionDef>()
        val globalVars = mutableListOf<VarDeclStmt>()

        while (!isAtEnd()) {
            when {
                check(TokenType.INCLUDE) -> {
                    includes.add(advance().text)
                }
                check(TokenType.DEFINE) -> {
                    advance() // Skip defines
                }
                isType(peek().type) -> {
                    // Could be function or global variable
                    val type = advance().text
                    if (!check(TokenType.IDENTIFIER)) {
                        throw CParseException("ডেটা টাইপ '${type}'-এর পর চলক বা ফাংশনের নাম প্রত্যাশিত।", peek().line)
                    }
                    val name = advance().text
                    if (check(TokenType.LPAREN)) {
                        // Function declaration/definition
                        val func = parseFunction(type, name)
                        functions[name] = func
                    } else {
                        // Variable declaration
                        val vars = parseVarDeclList(type, name)
                        globalVars.addAll(vars)
                    }
                }
                else -> {
                    // Skip unexpected token to avoid crash
                    advance()
                }
            }
        }

        if (!functions.containsKey("main")) {
            throw CParseException("প্রোগ্রামে 'main()' ফাংশন খুঁজে পাওয়া যায়নি। সি প্রোগ্রামের শুরু অবশ্যই main() দিয়ে হতে হবে।", 1)
        }

        return CProgram(includes, functions, globalVars)
    }

    private fun parseFunction(returnType: String, name: String): FunctionDef {
        val line = previous().line
        consume(TokenType.LPAREN, "ফাংশনের প্যারামিটারের পূর্বে '(' প্রত্যাশিত।")
        val params = mutableListOf<Param>()
        if (!check(TokenType.RPAREN) && !check(TokenType.VOID)) {
            do {
                if (check(TokenType.VOID)) {
                    advance()
                    break
                }
                if (!isType(peek().type)) {
                    throw CParseException("প্যারামিটারের ডেটা টাইপ প্রত্যাশিত।", peek().line)
                }
                val pType = advance().text
                val pName = if (check(TokenType.IDENTIFIER)) advance().text else "param${params.size}"
                params.add(Param(pType, pName))
            } while (match(TokenType.COMMA))
        } else if (check(TokenType.VOID)) {
            advance()
        }
        consume(TokenType.RPAREN, "ফাংশনের প্যারামিটার তালিকার শেষে ')' প্রত্যাশিত।")

        // Parse body
        consume(TokenType.LBRACE, "ফাংশন বডি শুরুর জন্য '{' প্রত্যাশিত।")
        val body = parseBlock()
        return FunctionDef(returnType, name, params, body, line)
    }

    private fun parseBlock(): BlockStmt {
        val statements = mutableListOf<Stmt>()
        while (!check(TokenType.RBRACE) && !isAtEnd()) {
            statements.add(parseDeclarationOrStatement())
        }
        consume(TokenType.RBRACE, "ব্লক শেষ করার জন্য '}' প্রত্যাশিত।")
        return BlockStmt(statements)
    }

    private fun parseDeclarationOrStatement(): Stmt {
        return if (isType(peek().type)) {
            val type = advance().text
            if (!check(TokenType.IDENTIFIER)) {
                throw CParseException("চলকের নাম প্রত্যাশিত।", peek().line)
            }
            val name = advance().text
            val decls = parseVarDeclList(type, name)
            if (decls.size == 1) decls[0] else VarDeclListStmt(decls)
        } else {
            parseStatement()
        }
    }

    private fun parseVarDeclList(type: String, firstName: String): List<VarDeclStmt> {
        val decls = mutableListOf<VarDeclStmt>()
        var name = firstName
        while (true) {
            val line = previous().line
            var arraySize: Expr? = null
            if (match(TokenType.LBRACKET)) {
                arraySize = if (!check(TokenType.RBRACKET)) parseExpression() else null
                consume(TokenType.RBRACKET, "অ্যারে সাইজের শেষে ']' প্রত্যাশিত।")
            }
            var initExpr: Expr? = null
            if (match(TokenType.ASSIGN)) {
                initExpr = parseExpression()
            }
            decls.add(VarDeclStmt(type, name, arraySize, initExpr, line))

            if (match(TokenType.COMMA)) {
                if (check(TokenType.IDENTIFIER)) {
                    name = advance().text
                } else {
                    throw CParseException("কমা ',' এর পর পরবর্তী চলকের নাম দিন।", peek().line)
                }
            } else {
                break
            }
        }
        consume(TokenType.SEMICOLON, "স্টেটমেন্টের শেষে সেমিকোলন ';' বাদ পড়েছে।")
        return decls
    }

    private fun parseStatement(): Stmt {
        return when {
            match(TokenType.IF) -> parseIf()
            match(TokenType.SWITCH) -> parseSwitch()
            match(TokenType.FOR) -> parseFor()
            match(TokenType.WHILE) -> parseWhile()
            match(TokenType.DO) -> parseDoWhile()
            match(TokenType.BREAK) -> {
                val line = previous().line
                consume(TokenType.SEMICOLON, "'break'-এর পর সেমিকোলন ';' দিন।")
                BreakStmt(line)
            }
            match(TokenType.CONTINUE) -> {
                val line = previous().line
                consume(TokenType.SEMICOLON, "'continue'-এর পর সেমিকোলন ';' দিন।")
                ContinueStmt(line)
            }
            match(TokenType.RETURN) -> {
                val line = previous().line
                val value = if (!check(TokenType.SEMICOLON)) parseExpression() else null
                consume(TokenType.SEMICOLON, "'return'-এর পর সেমিকোলন ';' দিন।")
                ReturnStmt(value, line)
            }
            match(TokenType.LBRACE) -> parseBlock()
            else -> parseExpressionStatement()
        }
    }

    private fun parseIf(): IfStmt {
        val line = previous().line
        consume(TokenType.LPAREN, "'if'-এর শর্তের পূর্বে '(' দিন।")
        val condition = parseExpression()
        consume(TokenType.RPAREN, "'if'-এর শর্তের শেষে ')' দিন।")
        val thenBranch = parseStatementOrBlock()
        val elseBranch = if (match(TokenType.ELSE)) parseStatementOrBlock() else null
        return IfStmt(condition, thenBranch, elseBranch, line)
    }

    private fun parseSwitch(): SwitchStmt {
        val line = previous().line
        consume(TokenType.LPAREN, "'switch'-এর পর '(' দিন।")
        val condition = parseExpression()
        consume(TokenType.RPAREN, "'switch'-এর শর্তের শেষে ')' দিন।")
        consume(TokenType.LBRACE, "'switch'-এর পর '{' দিন।")
        val cases = mutableListOf<SwitchCase>()
        val defaultStatements = mutableListOf<Stmt>()

        while (!check(TokenType.RBRACE) && !isAtEnd()) {
            if (match(TokenType.CASE)) {
                val lit = parseExpression()
                consume(TokenType.COLON, "'case'-এর মানের পর কোলন ':' দিন।")
                val caseStmts = mutableListOf<Stmt>()
                while (!check(TokenType.CASE) && !check(TokenType.DEFAULT) && !check(TokenType.RBRACE) && !isAtEnd()) {
                    caseStmts.add(parseDeclarationOrStatement())
                }
                val caseVal = when (lit) {
                    is LiteralExpr -> (lit.value as? Number)?.toLong() ?: 0L
                    else -> 0L
                }
                cases.add(SwitchCase(caseVal, caseStmts))
            } else if (match(TokenType.DEFAULT)) {
                consume(TokenType.COLON, "'default'-এর পর কোলন ':' দিন।")
                while (!check(TokenType.CASE) && !check(TokenType.DEFAULT) && !check(TokenType.RBRACE) && !isAtEnd()) {
                    defaultStatements.add(parseDeclarationOrStatement())
                }
            } else {
                advance()
            }
        }
        consume(TokenType.RBRACE, "'switch'-এর শেষে '}' দিন।")
        return SwitchStmt(condition, cases, defaultStatements, line)
    }

    private fun parseFor(): ForStmt {
        val line = previous().line
        consume(TokenType.LPAREN, "'for'-এর পর '(' দিন।")
        val init = if (match(TokenType.SEMICOLON)) {
            null
        } else if (isType(peek().type)) {
            val type = advance().text
            val name = advance().text
            val decls = parseVarDeclList(type, name)
            if (decls.size == 1) decls[0] else VarDeclListStmt(decls)
        } else {
            val expr = parseExpression()
            consume(TokenType.SEMICOLON, "for লুপের প্রারম্ভিক মানের পর সেমিকোলন ';' দিন।")
            ExprStmt(expr)
        }

        val condition = if (!check(TokenType.SEMICOLON)) parseExpression() else null
        consume(TokenType.SEMICOLON, "for লুপের শর্তের পর সেমিকোলন ';' দিন।")

        val update = if (!check(TokenType.RPAREN)) parseExpression() else null
        consume(TokenType.RPAREN, "for লুপের শেষে ')' দিন।")

        val body = parseStatementOrBlock()
        return ForStmt(init, condition, update, body, line)
    }

    private fun parseWhile(): WhileStmt {
        val line = previous().line
        consume(TokenType.LPAREN, "'while'-এর পর '(' দিন।")
        val condition = parseExpression()
        consume(TokenType.RPAREN, "'while'-এর শর্তের শেষে ')' দিন।")
        val body = parseStatementOrBlock()
        return WhileStmt(condition, body, line)
    }

    private fun parseDoWhile(): DoWhileStmt {
        val line = previous().line
        val body = parseStatementOrBlock()
        consume(TokenType.WHILE, "'do' লুপের শেষে 'while' কী-ওয়ার্ড দিন।")
        consume(TokenType.LPAREN, "'while'-এর পর '(' দিন।")
        val condition = parseExpression()
        consume(TokenType.RPAREN, "'while'-এর শর্তের শেষে ')' দিন।")
        consume(TokenType.SEMICOLON, "'do-while' লুপের শেষে সেমিকোলন ';' দিন।")
        return DoWhileStmt(body, condition, line)
    }

    private fun parseStatementOrBlock(): Stmt {
        return if (check(TokenType.LBRACE)) {
            advance()
            parseBlock()
        } else {
            parseDeclarationOrStatement()
        }
    }

    private fun parseExpressionStatement(): Stmt {
        val expr = parseExpression()
        consume(TokenType.SEMICOLON, "স্টেটমেন্টের শেষে সেমিকোলন ';' বাদ পড়েছে।")
        return ExprStmt(expr)
    }

    // Expressions
    fun parseExpression(): Expr = parseAssignment()

    private fun parseAssignment(): Expr {
        val expr = parseTernary()
        if (match(TokenType.ASSIGN, TokenType.PLUS_ASSIGN, TokenType.MINUS_ASSIGN, TokenType.STAR_ASSIGN, TokenType.SLASH_ASSIGN, TokenType.PERCENT_ASSIGN)) {
            val op = previous().type
            val line = previous().line
            val value = parseAssignment()
            return AssignExpr(expr, op, value, line)
        }
        return expr
    }

    private fun parseTernary(): Expr {
        var expr = parseLogicalOr()
        if (match(TokenType.QUESTION)) {
            val line = previous().line
            val trueExpr = parseExpression()
            consume(TokenType.COLON, "টারনারি অপারেটরে '?' এর পর ':' প্রত্যাশিত।")
            val falseExpr = parseTernary()
            expr = TernaryExpr(expr, trueExpr, falseExpr, line)
        }
        return expr
    }

    private fun parseLogicalOr(): Expr {
        var expr = parseLogicalAnd()
        while (match(TokenType.PIPE_PIPE)) {
            val op = previous().type
            val line = previous().line
            val right = parseLogicalAnd()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseLogicalAnd(): Expr {
        var expr = parseBitwise()
        while (match(TokenType.AMP_AMP)) {
            val op = previous().type
            val line = previous().line
            val right = parseBitwise()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseBitwise(): Expr {
        var expr = parseEquality()
        while (match(TokenType.AMP, TokenType.PIPE, TokenType.CARET)) {
            val op = previous().type
            val line = previous().line
            val right = parseEquality()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseEquality(): Expr {
        var expr = parseRelational()
        while (match(TokenType.EQUAL_EQUAL, TokenType.NOT_EQUAL)) {
            val op = previous().type
            val line = previous().line
            val right = parseRelational()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseRelational(): Expr {
        var expr = parseAdditive()
        while (match(TokenType.LESS, TokenType.LESS_EQUAL, TokenType.GREATER, TokenType.GREATER_EQUAL)) {
            val op = previous().type
            val line = previous().line
            val right = parseAdditive()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseAdditive(): Expr {
        var expr = parseMultiplicative()
        while (match(TokenType.PLUS, TokenType.MINUS)) {
            val op = previous().type
            val line = previous().line
            val right = parseMultiplicative()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseMultiplicative(): Expr {
        var expr = parseUnary()
        while (match(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT)) {
            val op = previous().type
            val line = previous().line
            val right = parseUnary()
            expr = BinaryExpr(expr, op, right, line)
        }
        return expr
    }

    private fun parseUnary(): Expr {
        if (match(TokenType.BANG, TokenType.MINUS, TokenType.PLUS_PLUS, TokenType.MINUS_MINUS, TokenType.AMP, TokenType.STAR)) {
            val op = previous().type
            val line = previous().line
            val right = parseUnary()
            return UnaryExpr(op, right, isPrefix = true, line)
        }
        return parsePostfix()
    }

    private fun parsePostfix(): Expr {
        var expr = parsePrimary()
        while (true) {
            when {
                match(TokenType.PLUS_PLUS) -> {
                    expr = UnaryExpr(TokenType.PLUS_PLUS, expr, isPrefix = false, previous().line)
                }
                match(TokenType.MINUS_MINUS) -> {
                    expr = UnaryExpr(TokenType.MINUS_MINUS, expr, isPrefix = false, previous().line)
                }
                match(TokenType.LBRACKET) -> {
                    val index = parseExpression()
                    consume(TokenType.RBRACKET, "অ্যারে সূচকের শেষে ']' প্রত্যাশিত।")
                    if (expr is VariableExpr) {
                        expr = ArrayAccessExpr(expr.name, index, previous().line)
                    }
                }
                match(TokenType.LPAREN) -> {
                    // Function call
                    val args = mutableListOf<Expr>()
                    if (!check(TokenType.RPAREN)) {
                        do {
                            args.add(parseExpression())
                        } while (match(TokenType.COMMA))
                    }
                    consume(TokenType.RPAREN, "ফাংশন কলের প্যারামিটার তালিকার শেষে ')' প্রত্যাশিত।")
                    if (expr is VariableExpr) {
                        expr = CallExpr(expr.name, args, previous().line)
                    }
                }
                else -> break
            }
        }
        return expr
    }

    private fun parsePrimary(): Expr {
        val token = peek()
        return when (token.type) {
            TokenType.INT_LITERAL -> {
                advance()
                LiteralExpr(token.literal ?: 0L, token.line)
            }
            TokenType.FLOAT_LITERAL -> {
                advance()
                LiteralExpr(token.literal ?: 0.0, token.line)
            }
            TokenType.CHAR_LITERAL -> {
                advance()
                LiteralExpr(token.literal ?: ' ', token.line)
            }
            TokenType.STRING_LITERAL -> {
                advance()
                LiteralExpr(token.literal ?: "", token.line)
            }
            TokenType.IDENTIFIER -> {
                advance()
                VariableExpr(token.text, token.line)
            }
            TokenType.LPAREN -> {
                advance()
                val expr = parseExpression()
                consume(TokenType.RPAREN, "বন্ধনীর শেষে ')' প্রত্যাশিত।")
                expr
            }
            TokenType.LBRACE -> {
                advance()
                val elements = mutableListOf<Expr>()
                if (!check(TokenType.RBRACE)) {
                    do {
                        elements.add(parseExpression())
                    } while (match(TokenType.COMMA))
                }
                consume(TokenType.RBRACE, "অ্যারে ইনিশিয়ালাইজারের শেষে '}' প্রত্যাশিত।")
                ArrayLiteralExpr(elements, token.line)
            }
            else -> {
                throw CParseException("অনাকাঙ্ক্ষিত টোকেন '${token.text}'। বাক্যরীতি (Syntax) যাচাই করুন।", token.line)
            }
        }
    }

    private fun isType(type: TokenType): Boolean {
        return type in listOf(TokenType.INT, TokenType.FLOAT, TokenType.DOUBLE, TokenType.CHAR, TokenType.VOID)
    }

    private fun match(vararg types: TokenType): Boolean {
        for (t in types) {
            if (check(t)) {
                advance()
                return true
            }
        }
        return false
    }

    private fun check(type: TokenType): Boolean {
        if (isAtEnd()) return false
        return peek().type == type
    }

    private fun advance(): Token {
        if (!isAtEnd()) current++
        return previous()
    }

    private fun isAtEnd(): Boolean = peek().type == TokenType.EOF
    private fun peek(): Token = tokens[current]
    private fun previous(): Token = tokens[current - 1]

    private fun consume(type: TokenType, errorMessage: String): Token {
        if (check(type)) return advance()
        throw CParseException(errorMessage, peek().line)
    }
}
