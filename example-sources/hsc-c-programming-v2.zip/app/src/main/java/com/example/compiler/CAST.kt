package com.example.compiler

sealed class Stmt
sealed class Expr

data class Param(val type: String, val name: String)

data class SwitchCase(val value: Long, val body: List<Stmt>)

data class BlockStmt(val statements: List<Stmt>) : Stmt()

data class VarDeclStmt(
    val type: String,
    val name: String,
    val arraySize: Expr?,
    val initExpr: Expr?,
    val line: Int
) : Stmt()

data class VarDeclListStmt(val declarations: List<VarDeclStmt>) : Stmt()

data class ExprStmt(val expr: Expr) : Stmt()

data class IfStmt(
    val condition: Expr,
    val thenBranch: Stmt,
    val elseBranch: Stmt?,
    val line: Int
) : Stmt()

data class SwitchStmt(
    val condition: Expr,
    val cases: List<SwitchCase>,
    val defaultStatements: List<Stmt>,
    val line: Int
) : Stmt()

data class ForStmt(
    val init: Stmt?,
    val condition: Expr?,
    val update: Expr?,
    val body: Stmt,
    val line: Int
) : Stmt()

data class WhileStmt(
    val condition: Expr,
    val body: Stmt,
    val line: Int
) : Stmt()

data class DoWhileStmt(
    val body: Stmt,
    val condition: Expr,
    val line: Int
) : Stmt()

data class BreakStmt(val line: Int) : Stmt()
data class ContinueStmt(val line: Int) : Stmt()
data class ReturnStmt(val value: Expr?, val line: Int) : Stmt()

data class FunctionDef(
    val returnType: String,
    val name: String,
    val params: List<Param>,
    val body: BlockStmt,
    val line: Int
) : Stmt()

// Expressions
data class LiteralExpr(val value: Any?, val line: Int) : Expr()
data class ArrayLiteralExpr(val elements: List<Expr>, val line: Int) : Expr()
data class VariableExpr(val name: String, val line: Int) : Expr()
data class ArrayAccessExpr(val arrayName: String, val index: Expr, val line: Int) : Expr()
data class BinaryExpr(val left: Expr, val op: TokenType, val right: Expr, val line: Int) : Expr()
data class UnaryExpr(val op: TokenType, val right: Expr, val isPrefix: Boolean, val line: Int) : Expr()
data class AssignExpr(val target: Expr, val op: TokenType, val value: Expr, val line: Int) : Expr()
data class CallExpr(val callee: String, val arguments: List<Expr>, val line: Int) : Expr()
data class TernaryExpr(val condition: Expr, val trueExpr: Expr, val falseExpr: Expr, val line: Int) : Expr()

data class CProgram(
    val includes: List<String>,
    val functions: Map<String, FunctionDef>,
    val globalVars: List<VarDeclStmt>
)
