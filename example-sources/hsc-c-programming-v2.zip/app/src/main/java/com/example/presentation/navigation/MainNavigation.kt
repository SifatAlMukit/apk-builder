package com.example.presentation.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.example.presentation.AppViewModel
import com.example.presentation.cheatsheet.CheatSheetScreen
import com.example.presentation.flowchart.FlowchartScreen
import com.example.presentation.glossary.GlossaryScreen
import com.example.presentation.home.HomeScreen
import com.example.presentation.lesson.CourseBrowserScreen
import com.example.presentation.lesson.LessonDetailScreen
import com.example.presentation.playground.PlaygroundScreen
import com.example.presentation.projects.MiniProjectsScreen
import com.example.presentation.projects.ProjectDetailScreen
import com.example.presentation.quiz.QuizScreen
import com.example.presentation.search.SearchScreen
import com.example.presentation.settings.SettingsScreen

data class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)

val BOTTOM_NAV_ITEMS = listOf(
    BottomNavItem(Screen.Home.route, "হোম", Icons.Filled.Home, Icons.Outlined.Home),
    BottomNavItem(Screen.Course.route, "পাঠ্যসূচি", Icons.Filled.MenuBook, Icons.Outlined.MenuBook),
    BottomNavItem(Screen.Playground.route, "প্লেগ্রাউন্ড", Icons.Filled.Code, Icons.Outlined.Code),
    BottomNavItem(Screen.Quiz.createRoute("all"), "কুইজ", Icons.Filled.Quiz, Icons.Outlined.Quiz),
    BottomNavItem(Screen.Settings.route, "সেটিংস", Icons.Filled.Settings, Icons.Outlined.Settings)
)

@Composable
fun MainNavigation(
    viewModel: AppViewModel,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    // Check if bottom bar should be visible
    val showBottomBar = currentRoute in listOf(
        Screen.Home.route,
        Screen.Course.route,
        Screen.Playground.route,
        Screen.Quiz.route,
        Screen.Settings.route
    ) || currentRoute?.startsWith("quiz/") == true

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    BOTTOM_NAV_ITEMS.forEach { item ->
                        val isSelected = when (item.route) {
                            Screen.Quiz.createRoute("all") -> currentRoute?.startsWith("quiz") == true
                            else -> currentRoute == item.route
                        }

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                val isHomeDestination = item.route == Screen.Home.route
                                navController.navigate(item.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = !isHomeDestination
                                    }
                                    launchSingleTop = true
                                    restoreState = !isHomeDestination
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title
                                )
                            },
                            label = {
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.testTag("nav_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToLesson = { lessonId ->
                        navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                    },
                    onNavigateToCourse = {
                        navController.navigate(Screen.Course.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateToPlayground = {
                        navController.navigate(Screen.Playground.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateToFlowchart = {
                        navController.navigate(Screen.Flowchart.createRoute("fc_even_odd"))
                    },
                    onNavigateToQuiz = {
                        navController.navigate(Screen.Quiz.createRoute("all")) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateToCheatSheet = {
                        navController.navigate(Screen.CheatSheet.route)
                    },
                    onNavigateToGlossary = {
                        navController.navigate(Screen.Glossary.route)
                    },
                    onNavigateToProjects = {
                        navController.navigate(Screen.MiniProjects.route)
                    },
                    onNavigateToSearch = {
                        navController.navigate(Screen.Search.route)
                    }
                )
            }

            composable(Screen.Course.route) {
                CourseBrowserScreen(
                    viewModel = viewModel,
                    onNavigateToLesson = { lessonId ->
                        navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                    },
                    onNavigateBack = {
                        navController.popBackStack()
                    },
                    onNavigateToSearch = {
                        navController.navigate(Screen.Search.route)
                    }
                )
            }

            composable(
                route = Screen.LessonDetail.route,
                arguments = listOf(navArgument("lessonId") { type = NavType.StringType })
            ) { backStackEntry ->
                val lessonId = backStackEntry.arguments?.getString("lessonId") ?: "lesson_1"
                LessonDetailScreen(
                    lessonId = lessonId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onOpenInPlayground = { code ->
                        viewModel.setPlaygroundCode(code)
                        navController.navigate(Screen.Playground.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onNavigateToQuiz = { chId ->
                        navController.navigate(Screen.Quiz.createRoute(chId))
                    },
                    onNavigateToFlowchart = { fcId ->
                        navController.navigate(Screen.Flowchart.createRoute(fcId))
                    },
                    onNavigateToNextLesson = { nextId ->
                        navController.navigate(Screen.LessonDetail.createRoute(nextId)) {
                            popUpTo(Screen.LessonDetail.route) { inclusive = true }
                        }
                    }
                )
            }

            composable(Screen.Playground.route) {
                PlaygroundScreen(viewModel = viewModel)
            }

            composable(
                route = Screen.Flowchart.route,
                arguments = listOf(navArgument("flowchartId") { type = NavType.StringType })
            ) { backStackEntry ->
                val flowchartId = backStackEntry.arguments?.getString("flowchartId") ?: "fc_even_odd"
                FlowchartScreen(
                    initialFlowchartId = flowchartId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Screen.Quiz.route,
                arguments = listOf(navArgument("chapterId") { type = NavType.StringType })
            ) { backStackEntry ->
                val chapterId = backStackEntry.arguments?.getString("chapterId") ?: "all"
                QuizScreen(
                    chapterId = chapterId,
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.CheatSheet.route) {
                CheatSheetScreen(
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Glossary.route) {
                GlossaryScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.MiniProjects.route) {
                MiniProjectsScreen(
                    onNavigateToProject = { projectId ->
                        navController.navigate(Screen.ProjectDetail.createRoute(projectId))
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(
                route = Screen.ProjectDetail.route,
                arguments = listOf(navArgument("projectId") { type = NavType.StringType })
            ) { backStackEntry ->
                val projectId = backStackEntry.arguments?.getString("projectId") ?: "proj_student_result"
                ProjectDetailScreen(
                    projectId = projectId,
                    onNavigateBack = { navController.popBackStack() },
                    onOpenInPlayground = { code ->
                        viewModel.setPlaygroundCode(code)
                        navController.navigate(Screen.Playground.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }

            composable(Screen.Search.route) {
                SearchScreen(
                    viewModel = viewModel,
                    onNavigateToLesson = { lessonId ->
                        navController.navigate(Screen.LessonDetail.createRoute(lessonId))
                    },
                    onNavigateToProject = { projectId ->
                        navController.navigate(Screen.ProjectDetail.createRoute(projectId))
                    },
                    onNavigateToCheatSheet = {
                        navController.navigate(Screen.CheatSheet.route)
                    },
                    onNavigateToGlossary = {
                        navController.navigate(Screen.Glossary.route)
                    },
                    onNavigateBack = { navController.popBackStack() }
                )
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    viewModel = viewModel,
                    onNavigateBack = { navController.popBackStack() },
                    onLoadSnippet = { code ->
                        viewModel.setPlaygroundCode(code)
                        navController.navigate(Screen.Playground.route) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
        }
    }
}
