package com.example.data.repository

import com.example.core.model.*

data class GlobalSearchResult(
    val type: String, // "পাঠ (Lesson)", "শব্দকোষ (Glossary)", "চিট শিট (Cheat Sheet)", "প্রজেক্ট (Project)", "প্রশ্ন (Quiz)"
    val title: String,
    val subtitle: String,
    val targetId: String
)

object ContentRepository {

    fun getAllLessons(): List<Lesson> = LessonData.lessons

    fun getLessonById(id: String): Lesson? = LessonData.lessons.find { it.id == id }

    fun getAllFlowcharts(): List<FlowchartData> = FlowchartDataRepository.flowcharts

    fun getFlowchartById(id: String): FlowchartData? = FlowchartDataRepository.flowcharts.find { it.id == id }

    fun getAllCheatSheets(): List<CheatSheetItem> = CheatSheetData.cheatSheets

    fun getAllGlossaryItems(): List<GlossaryItem> = GlossaryData.items

    fun getAllQuizQuestions(): List<QuizQuestion> = QuizData.questions

    fun getQuizQuestionsForChapter(chapterId: String): List<QuizQuestion> {
        val filtered = QuizData.questions.filter { it.chapterId == chapterId }
        return if (filtered.isNotEmpty()) filtered else QuizData.questions.take(5)
    }

    fun getAllProjects(): List<MiniProject> = ProjectsData.projects

    fun getProjectById(id: String): MiniProject? = ProjectsData.projects.find { it.id == id }

    fun globalSearch(query: String): List<GlobalSearchResult> {
        if (query.isBlank()) return emptyList()
        val q = query.trim().lowercase()
        val results = mutableListOf<GlobalSearchResult>()

        // Search in lessons
        for (lesson in LessonData.lessons) {
            if (lesson.titleBn.lowercase().contains(q) ||
                lesson.titleEn.lowercase().contains(q) ||
                lesson.subtitle.lowercase().contains(q) ||
                lesson.sections.any { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) }
            ) {
                results.add(
                    GlobalSearchResult(
                        type = "পাঠ (Lesson)",
                        title = "${lesson.chapterNumber}. ${lesson.titleBn}",
                        subtitle = lesson.subtitle,
                        targetId = lesson.id
                    )
                )
            }
        }

        // Search in glossary
        for (g in GlossaryData.items) {
            if (g.termBn.lowercase().contains(q) ||
                g.termEn.lowercase().contains(q) ||
                g.definitionBn.lowercase().contains(q)
            ) {
                results.add(
                    GlobalSearchResult(
                        type = "শব্দকোষ (Glossary)",
                        title = "${g.termEn} (${g.termBn})",
                        subtitle = g.definitionBn.take(60) + "...",
                        targetId = g.id
                    )
                )
            }
        }

        // Search in cheat sheets
        for (cs in CheatSheetData.cheatSheets) {
            for (entry in cs.items) {
                if (entry.symbolOrKeyword.lowercase().contains(q) ||
                    entry.nameBn.lowercase().contains(q) ||
                    entry.descriptionBn.lowercase().contains(q)
                ) {
                    results.add(
                        GlobalSearchResult(
                            type = "চিট শিট (Cheat Sheet)",
                            title = "${entry.symbolOrKeyword} - ${entry.nameBn}",
                            subtitle = entry.descriptionBn,
                            targetId = entry.symbolOrKeyword
                        )
                    )
                }
            }
        }

        // Search in projects
        for (p in ProjectsData.projects) {
            if (p.titleBn.lowercase().contains(q) ||
                p.titleEn.lowercase().contains(q) ||
                p.overviewBn.lowercase().contains(q)
            ) {
                results.add(
                    GlobalSearchResult(
                        type = "প্রজেক্ট (Project)",
                        title = p.titleBn,
                        subtitle = p.overviewBn.take(60) + "...",
                        targetId = p.id
                    )
                )
            }
        }

        return results
    }
}
