package com.example.presentation.quiz

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.QuizQuestion
import com.example.data.repository.ContentRepository
import com.example.presentation.AppViewModel
import com.example.presentation.components.ConfettiView
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(
    chapterId: String = "all",
    viewModel: AppViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    val questions = remember(chapterId) {
        if (chapterId == "all" || chapterId.isEmpty()) {
            ContentRepository.getAllQuizQuestions().shuffled()
        } else {
            ContentRepository.getQuizQuestionsForChapter(chapterId)
        }
    }

    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOptionIndex by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var isQuizFinished by remember { mutableStateOf(false) }
    var userAnswers by remember { mutableStateOf(mapOf<Int, Int>()) } // questionIndex -> selectedOptionIndex

    // Timer per question (30 seconds)
    var timeLeft by remember { mutableIntStateOf(30) }
    var timerRunning by remember { mutableStateOf(true) }

    LaunchedEffect(currentIndex, timerRunning, isQuizFinished) {
        if (!isQuizFinished && timerRunning) {
            timeLeft = 30
            while (timeLeft > 0 && selectedOptionIndex == null) {
                delay(1000)
                timeLeft--
            }
            if (timeLeft == 0 && selectedOptionIndex == null) {
                // Auto mark as timed out
                selectedOptionIndex = -1
            }
        }
    }

    val currentQuestion = questions.getOrNull(currentIndex)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        if (isQuizFinished) "কুইজ ফলাফল ও মূল্যায়ন" else "এইচএসসি সি কুইজ পরীক্ষা",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "ফিরে যান")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isQuizFinished) {
                // Scorecard View
                val total = questions.size
                val percentage = if (total > 0) (score * 100) / total else 0

                // Confetti if score >= 70%
                if (percentage >= 70) {
                    ConfettiView()
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (percentage >= 80) {
                                    if (isDark) Color(0xFF1B382B) else Color(0xFFE8F5E9)
                                } else {
                                    if (isDark) Color(0xFF3E271E) else Color(0xFFFFF3E0)
                                }
                            )
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(80.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (percentage >= 80) Color(0xFF2E7D32) else Color(0xFFE65100)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "$score / $total",
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                                Spacer(modifier = Modifier.height(14.dp))
                                Text(
                                    text = if (percentage >= 80) "অসাধারণ ফলাফল! 🎉" else if (percentage >= 50) "সন্তোষজনক অগ্রগতি! 👍" else "আরও অনুশীলনের প্রয়োজন 📚",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (percentage >= 80) {
                                        if (isDark) Color(0xFF81C784) else Color(0xFF1B5E20)
                                    } else {
                                        if (isDark) Color(0xFFFFB74D) else Color(0xFFBF360C)
                                    }
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "সঠিকতার হার: $percentage%",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Action buttons
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    currentIndex = 0
                                    score = 0
                                    selectedOptionIndex = null
                                    userAnswers = emptyMap()
                                    isQuizFinished = false
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("পুনরায় পরীক্ষা দিন")
                            }

                            Button(
                                onClick = onNavigateBack,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("সমাপ্ত করুন")
                            }
                        }
                    }

                    // Answers review header
                    item {
                        Text(
                            text = "উত্তরপত্র পর্যালোচনা (Answer Review):",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Answers review list
                    itemsIndexed(questions) { idx, q ->
                        val userAns = userAnswers[idx]
                        val isUserCorrect = userAns == q.correctOptionIndex

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUserCorrect) Color(0xFFF1F8E9) else Color(0xFFFFEBEE)
                            )
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "${idx + 1}. ${q.questionBn}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "সঠিক উত্তর: ${q.optionsBn[q.correctOptionIndex]}",
                                    fontSize = 13.sp,
                                    color = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.SemiBold
                                )
                                if (!isUserCorrect && userAns != null && userAns >= 0) {
                                    Text(
                                        text = "তোমার উত্তর: ${q.optionsBn[userAns]}",
                                        fontSize = 13.sp,
                                        color = Color(0xFFC62828)
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "ব্যাখ্যা: ${q.explanationBn}",
                                    fontSize = 12.sp,
                                    lineHeight = 16.sp,
                                    color = Color(0xFF455A64)
                                )
                            }
                        }
                    }
                }
            } else if (currentQuestion != null) {
                // Active Quiz Question View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                ) {
                    // Progress & Timer Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "প্রশ্ন ${currentIndex + 1} / ${questions.size}",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Timer,
                                contentDescription = null,
                                tint = if (timeLeft <= 5) Color(0xFFE53935) else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${timeLeft}s",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (timeLeft <= 5) Color(0xFFE53935) else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { (currentIndex + 1).toFloat() / questions.size.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp))
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Question Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Text(
                            text = currentQuestion.questionBn,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 24.sp,
                            modifier = Modifier.padding(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // 4 Options
                    currentQuestion.optionsBn.forEachIndexed { optIndex, optionText ->
                        val isSelected = selectedOptionIndex == optIndex
                        val isCorrect = optIndex == currentQuestion.correctOptionIndex
                        val isAnswered = selectedOptionIndex != null

                        val cardBorderColor = when {
                            isAnswered && isCorrect -> if (isDark) Color(0xFF81C784) else Color(0xFF2E7D32)
                            isAnswered && isSelected && !isCorrect -> if (isDark) Color(0xFFEF5350) else Color(0xFFC62828)
                            else -> MaterialTheme.colorScheme.outlineVariant
                        }

                        val cardBgColor = when {
                            isAnswered && isCorrect -> if (isDark) Color(0xFF1B382B) else Color(0xFFE8F5E9)
                            isAnswered && isSelected && !isCorrect -> if (isDark) Color(0xFF3E1E1E) else Color(0xFFFFEBEE)
                            else -> MaterialTheme.colorScheme.surface
                        }

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp)
                                .clickable(enabled = !isAnswered) {
                                    selectedOptionIndex = optIndex
                                    userAnswers = userAnswers + (currentIndex to optIndex)
                                    if (optIndex == currentQuestion.correctOptionIndex) {
                                        score++
                                    }
                                }
                                .testTag("quiz_option_$optIndex"),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, cardBorderColor),
                            colors = CardDefaults.cardColors(containerColor = cardBgColor)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val optionLetter = listOf("ক", "খ", "গ", "ঘ").getOrElse(optIndex) { "${optIndex + 1}" }
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isAnswered && isCorrect -> Color(0xFF2E7D32)
                                                isAnswered && isSelected && !isCorrect -> Color(0xFFC62828)
                                                else -> MaterialTheme.colorScheme.surfaceVariant
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = optionLetter,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = if (isAnswered && (isCorrect || isSelected)) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Text(
                                    text = optionText,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )

                                if (isAnswered) {
                                    if (isCorrect) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = "সঠিক",
                                            tint = Color(0xFF2E7D32)
                                        )
                                    } else if (isSelected) {
                                        Icon(
                                            Icons.Default.Cancel,
                                            contentDescription = "ভুল",
                                            tint = Color(0xFFC62828)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Explanation Box (shows after answering)
                    AnimatedVisibility(visible = selectedOptionIndex != null) {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "💡 সমাধান ও ব্যাখ্যা:",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0F172A)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentQuestion.explanationBn,
                                    fontSize = 12.sp,
                                    lineHeight = 17.sp,
                                    color = Color(0xFF334155)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Next button
                    if (selectedOptionIndex != null) {
                        Button(
                            onClick = {
                                if (currentIndex < questions.size - 1) {
                                    currentIndex++
                                    selectedOptionIndex = null
                                } else {
                                    isQuizFinished = true
                                    viewModel.saveQuizResult(chapterId, score, questions.size)
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("next_quiz_question_btn")
                        ) {
                            Text(
                                if (currentIndex < questions.size - 1) "পরবর্তী প্রশ্ন" else "ফলাফল দেখুন",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
