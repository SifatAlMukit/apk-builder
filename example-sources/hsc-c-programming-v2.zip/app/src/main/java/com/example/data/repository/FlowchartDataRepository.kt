package com.example.data.repository

import com.example.core.model.*

object FlowchartDataRepository {

    val flowcharts: List<FlowchartData> = listOf(
        FlowchartData(
            id = "fc_even_odd",
            titleBn = "জোড় না বিজোড় সংখ্যা পরীক্ষা",
            descriptionBn = "একটি পূর্ণসংখ্যা ইনপুট নিয়ে তা ২ দ্বারা নিঃশেষে বিভাজ্য কিনা যাচাই করার ফ্লোচার্ট।",
            nodes = listOf(
                FlowchartNode("1", "শুরু (Start)", null, FlowchartNodeType.START_END, 0.5f, 0.08f),
                FlowchartNode("2", "ইনপুট সংখ্যা n", "scanf(\"%d\", &n)", FlowchartNodeType.INPUT_OUTPUT, 0.5f, 0.24f),
                FlowchartNode("3", "n % 2 == 0 ?", "২ দ্বারা বিভাজ্য?", FlowchartNodeType.DECISION, 0.5f, 0.42f),
                FlowchartNode("4", "ছাপাও \"জোড়\"", "printf(\"Even\")", FlowchartNodeType.INPUT_OUTPUT, 0.22f, 0.62f),
                FlowchartNode("5", "ছাপাও \"বিজোড়\"", "printf(\"Odd\")", FlowchartNodeType.INPUT_OUTPUT, 0.78f, 0.62f),
                FlowchartNode("6", "শেষ (Stop)", null, FlowchartNodeType.START_END, 0.5f, 0.88f)
            ),
            edges = listOf(
                FlowchartEdge("1", "2"),
                FlowchartEdge("2", "3"),
                FlowchartEdge("3", "4", "হ্যাঁ (Yes)"),
                FlowchartEdge("3", "5", "না (No)"),
                FlowchartEdge("4", "6"),
                FlowchartEdge("5", "6")
            ),
            executionTrace = listOf(
                ExecutionStep(1, "1", "প্রোগ্রাম শুরু", "শুরু প্রতীকের মাধ্যমে ফ্লোচার্ট এক্সিকিউশন আরম্ভ হলো।"),
                ExecutionStep(2, "2", "n = 14", "ইনপুট সামান্তরিক প্রতীকে সংখ্যা n = 14 গৃহীত হলো।"),
                ExecutionStep(3, "3", "14 % 2 == 0 (সত্য)", "হীরক প্রতীকে শর্ত যাচাই: 14 কে 2 দিয়ে ভাগ করলে ভাগশেষ 0। তাই শর্ত সত্য (Yes)।"),
                ExecutionStep(4, "4", "আউটপুট: Even", "বামপাশের প্রবাহ বরাবর যেয়ে 'জোড়' ফলাফল প্রদর্শন করলো।"),
                ExecutionStep(5, "6", "সমাপ্তি", "প্রোগ্রাম সফলভাবে শেষ হলো।")
            )
        ),
        FlowchartData(
            id = "fc_largest_of_three",
            titleBn = "৩টি সংখ্যার মধ্যে বৃহত্তম নির্ণয়",
            descriptionBn = "তিনটি সংখ্যা a, b, c এর মধ্যে যৌক্তিক তুলনা করে সবচেয়ে বড় সংখ্যাটি নির্ধারণ।",
            nodes = listOf(
                FlowchartNode("1", "শুরু (Start)", null, FlowchartNodeType.START_END, 0.5f, 0.08f),
                FlowchartNode("2", "ইনপুট a, b, c", "scanf(\"%d%d%d\", &a,&b,&c)", FlowchartNodeType.INPUT_OUTPUT, 0.5f, 0.22f),
                FlowchartNode("3", "a > b এবং a > c ?", "শর্ত ১", FlowchartNodeType.DECISION, 0.5f, 0.38f),
                FlowchartNode("4", "b > c ?", "শর্ত ২", FlowchartNodeType.DECISION, 0.76f, 0.54f),
                FlowchartNode("5", "ছাপাও a বৃহত্তম", "printf(\"%d\", a)", FlowchartNodeType.INPUT_OUTPUT, 0.24f, 0.54f),
                FlowchartNode("6", "ছাপাও b বৃহত্তম", "printf(\"%d\", b)", FlowchartNodeType.INPUT_OUTPUT, 0.62f, 0.72f),
                FlowchartNode("7", "ছাপাও c বৃহত্তম", "printf(\"%d\", c)", FlowchartNodeType.INPUT_OUTPUT, 0.90f, 0.72f),
                FlowchartNode("8", "শেষ (Stop)", null, FlowchartNodeType.START_END, 0.5f, 0.90f)
            ),
            edges = listOf(
                FlowchartEdge("1", "2"),
                FlowchartEdge("2", "3"),
                FlowchartEdge("3", "5", "হ্যাঁ (Yes)"),
                FlowchartEdge("3", "4", "না (No)"),
                FlowchartEdge("4", "6", "হ্যাঁ (Yes)"),
                FlowchartEdge("4", "7", "না (No)"),
                FlowchartEdge("5", "8"),
                FlowchartEdge("6", "8"),
                FlowchartEdge("7", "8")
            ),
            executionTrace = listOf(
                ExecutionStep(1, "1", "শুরু", "প্রোগ্রাম আরম্ভ হলো।"),
                ExecutionStep(2, "2", "a = 25, b = 40, c = 18", "তিনটি সংখ্যার মান ইনপুট হিসেবে নেওয়া হলো।"),
                ExecutionStep(3, "3", "25 > 40? (মিথ্যা)", "প্রথম হীরক প্রতীকে a > b সত্য নয়, তাই 'না' পথে চলে গেল।"),
                ExecutionStep(4, "4", "40 > 18? (সত্য)", "দ্বিতীয় হীরক প্রতীকে b > c সত্য হয়েছে, তাই 'হ্যাঁ' পথে যাবে।"),
                ExecutionStep(5, "6", "আউটপুট: 40", "b অর্থাৎ 40 সংখ্যাটিকে বৃহত্তম হিসেবে প্রদর্শন করলো।"),
                ExecutionStep(6, "8", "সমাপ্তি", "প্রোগ্রামের কাজ সমাপ্ত।")
            )
        ),
        FlowchartData(
            id = "fc_sum_series",
            titleBn = "১ থেকে N ধারার যোগফল",
            descriptionBn = "লুপ কাঠামোর মাধ্যমে ১ + ২ + ৩ + ... + N পদ পর্যন্ত সংখ্যার ক্রমিক সমষ্টি বের করা।",
            nodes = listOf(
                FlowchartNode("1", "শুরু (Start)", null, FlowchartNodeType.START_END, 0.5f, 0.08f),
                FlowchartNode("2", "ইনপুট N", "scanf(\"%d\", &N)", FlowchartNodeType.INPUT_OUTPUT, 0.5f, 0.22f),
                FlowchartNode("3", "sum = 0, i = 1", "ইনিশিয়ালাইজেশন", FlowchartNodeType.PROCESS, 0.5f, 0.36f),
                FlowchartNode("4", "i <= N ?", "লুপের শর্ত", FlowchartNodeType.DECISION, 0.5f, 0.52f),
                FlowchartNode("5", "sum = sum + i\ni = i + 1", "হিসাব ও মান বৃদ্ধি", FlowchartNodeType.PROCESS, 0.24f, 0.68f),
                FlowchartNode("6", "ছাপাও sum", "printf(\"%d\", sum)", FlowchartNodeType.INPUT_OUTPUT, 0.78f, 0.68f),
                FlowchartNode("7", "শেষ (Stop)", null, FlowchartNodeType.START_END, 0.5f, 0.90f)
            ),
            edges = listOf(
                FlowchartEdge("1", "2"),
                FlowchartEdge("2", "3"),
                FlowchartEdge("3", "4"),
                FlowchartEdge("4", "5", "হ্যাঁ (Yes)"),
                FlowchartEdge("5", "4", "লুপ পুনরাবৃত্তি"),
                FlowchartEdge("4", "6", "না (No)"),
                FlowchartEdge("6", "7")
            ),
            executionTrace = listOf(
                ExecutionStep(1, "1", "প্রোগ্রাম শুরু", "শুরু ধাপ।"),
                ExecutionStep(2, "2", "N = 3", "সীমা N = 3 ইনপুট নেওয়া হলো।"),
                ExecutionStep(3, "3", "sum = 0, i = 1", "কাউন্টার ও যোগফল ইনিশিয়ালাইজ করা হলো।"),
                ExecutionStep(4, "4", "i (1) <= 3 (সত্য)", "লুপ শর্ত সত্য, বডিতে প্রবেশ।"),
                ExecutionStep(5, "5", "sum = 1, i = 2", "sum = 0 + 1 = 1 এবং i এর মান ১ বৃদ্ধি।"),
                ExecutionStep(6, "4", "i (2) <= 3 (সত্য)", "দ্বিতীয়বার লুপ শর্ত সত্য।"),
                ExecutionStep(7, "5", "sum = 3, i = 3", "sum = 1 + 2 = 3 এবং i বৃদ্ধি পেয়ে 3।"),
                ExecutionStep(8, "4", "i (3) <= 3 (সত্য)", "তৃতীয়বার লুপ শর্ত সত্য।"),
                ExecutionStep(9, "5", "sum = 6, i = 4", "sum = 3 + 3 = 6 এবং i বৃদ্ধি পেয়ে 4।"),
                ExecutionStep(10, "4", "i (4) <= 3 (মিথ্যা)", "i এর মান ৪ হওয়ায় শর্ত মিথ্যা, লুপ সমাপ্ত।"),
                ExecutionStep(11, "6", "আউটপুট: 6", "ফলাফল sum = 6 প্রিন্ট করা হলো।"),
                ExecutionStep(12, "7", "শেষ", "প্রোগ্রাম সমাপ্ত।")
            )
        )
    )
}
