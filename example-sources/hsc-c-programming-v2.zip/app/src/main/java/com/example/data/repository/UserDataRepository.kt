package com.example.data.repository

import com.example.data.local.AppDao
import com.example.data.local.BookmarkEntity
import com.example.data.local.LessonProgressEntity
import com.example.data.local.QuizScoreEntity
import com.example.data.local.SnippetEntity
import kotlinx.coroutines.flow.Flow

class UserDataRepository(private val dao: AppDao) {

    val allProgress: Flow<List<LessonProgressEntity>> = dao.getAllProgress()
    val allBookmarks: Flow<List<BookmarkEntity>> = dao.getAllBookmarks()
    val allSnippets: Flow<List<SnippetEntity>> = dao.getAllSnippets()
    val allQuizScores: Flow<List<QuizScoreEntity>> = dao.getAllQuizScores()

    fun isBookmarked(id: String): Flow<Boolean> = dao.isBookmarked(id)

    suspend fun toggleLessonProgress(lessonId: String, currentStatus: Boolean) {
        dao.setProgress(LessonProgressEntity(lessonId = lessonId, isCompleted = !currentStatus))
    }

    suspend fun setLessonProgress(lessonId: String, isCompleted: Boolean) {
        dao.setProgress(LessonProgressEntity(lessonId = lessonId, isCompleted = isCompleted))
    }

    suspend fun toggleBookmark(id: String, type: String, title: String, subtitle: String, targetId: String, currentlyBookmarked: Boolean) {
        if (currentlyBookmarked) {
            dao.removeBookmark(id)
        } else {
            dao.addBookmark(BookmarkEntity(id = id, type = type, title = title, subtitle = subtitle, targetId = targetId))
        }
    }

    suspend fun saveSnippet(title: String, code: String): Long {
        return dao.saveSnippet(SnippetEntity(title = title, code = code))
    }

    suspend fun deleteSnippet(id: Long) {
        dao.deleteSnippet(id)
    }

    suspend fun saveQuizScore(chapterId: String, score: Int, total: Int) {
        dao.saveQuizScore(QuizScoreEntity(chapterId = chapterId, highestScore = score, totalQuestions = total))
    }

    suspend fun resetAllProgress() {
        dao.clearProgress()
    }
}
