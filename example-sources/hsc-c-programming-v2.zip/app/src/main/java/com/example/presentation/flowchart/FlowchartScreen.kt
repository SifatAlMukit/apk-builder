package com.example.presentation.flowchart

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.core.model.FlowchartData
import com.example.core.model.FlowchartNodeType
import com.example.data.repository.FlowchartDataRepository
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FlowchartScreen(
    initialFlowchartId: String = "fc_even_odd",
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = androidx.compose.foundation.isSystemInDarkTheme()
    val allFlowcharts = FlowchartDataRepository.flowcharts
    var selectedFlowchart by remember {
        mutableStateOf(allFlowcharts.find { it.id == initialFlowchartId } ?: allFlowcharts.first())
    }

    var currentStepIndex by remember(selectedFlowchart) { mutableIntStateOf(0) }
    var isAutoPlaying by remember { mutableStateOf(false) }

    val currentStep = selectedFlowchart.executionTrace.getOrNull(currentStepIndex)
    val activeNodeId = currentStep?.activeNodeId

    // Auto play loop
    LaunchedEffect(isAutoPlaying, currentStepIndex, selectedFlowchart) {
        if (isAutoPlaying) {
            delay(1500)
            if (currentStepIndex < selectedFlowchart.executionTrace.size - 1) {
                currentStepIndex++
            } else {
                isAutoPlaying = false
            }
        }
    }

    // Pulse animation for active node
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val textMeasurer = rememberTextMeasurer()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(selectedFlowchart.titleBn, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("অ্যানিমেটেড ফ্লোচার্ট ও ট্রেসিং", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "পেছনে যান")
                    }
                },
                actions = {
                    // Flowchart selector menu
                    var showMenu by remember { mutableStateOf(false) }
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "অন্যান্য ফ্লোচার্ট")
                    }
                    DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        allFlowcharts.forEach { fc ->
                            DropdownMenuItem(
                                text = { Text(fc.titleBn) },
                                onClick = {
                                    selectedFlowchart = fc
                                    currentStepIndex = 0
                                    isAutoPlaying = false
                                    showMenu = false
                                }
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            // Step controller & inspector
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Variable State & Explanation
                    if (currentStep != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ধাপ ${currentStep.stepNumber} / ${selectedFlowchart.executionTrace.size}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.primaryContainer
                            ) {
                                Text(
                                    text = currentStep.variableStateBn,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentStep.explanationBn,
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Playback Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                currentStepIndex = 0
                                isAutoPlaying = false
                            },
                            enabled = currentStepIndex > 0
                        ) {
                            Icon(Icons.Default.Replay, contentDescription = "রিসেট")
                        }

                        IconButton(
                            onClick = {
                                if (currentStepIndex > 0) currentStepIndex--
                            },
                            enabled = currentStepIndex > 0
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "পূর্ববর্তী ধাপ")
                        }

                        FilledIconButton(
                            onClick = { isAutoPlaying = !isAutoPlaying },
                            colors = IconButtonDefaults.filledIconButtonColors(
                                containerColor = if (isAutoPlaying) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                if (isAutoPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isAutoPlaying) "থামান" else "অটো প্লে"
                            )
                        }

                        IconButton(
                            onClick = {
                                if (currentStepIndex < selectedFlowchart.executionTrace.size - 1) {
                                    currentStepIndex++
                                }
                            },
                            enabled = currentStepIndex < selectedFlowchart.executionTrace.size - 1
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "পরবর্তী ধাপ")
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Flowchart Selection Tabs
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(allFlowcharts) { fc ->
                    FilterChip(
                        selected = fc.id == selectedFlowchart.id,
                        onClick = {
                            selectedFlowchart = fc
                            currentStepIndex = 0
                            isAutoPlaying = false
                        },
                        label = { Text(fc.titleBn, fontSize = 12.sp) }
                    )
                }
            }

            // Flowchart Canvas Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .background(if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9))
                    .padding(12.dp)
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("flowchart_canvas")
                ) {
                    val w = size.width
                    val h = size.height

                    val nodeMap = selectedFlowchart.nodes.associateBy { it.id }

                    // 1. Draw Edges (Arrows)
                    selectedFlowchart.edges.forEach { edge ->
                        val fromNode = nodeMap[edge.fromId]
                        val toNode = nodeMap[edge.toId]
                        if (fromNode != null && toNode != null) {
                            val startX = fromNode.x * w
                            val startY = fromNode.y * h + 24.dp.toPx()
                            val endX = toNode.x * w
                            val endY = toNode.y * h - 24.dp.toPx()

                            val isEdgeActive = activeNodeId == edge.fromId

                            // Draw connecting line
                            drawLine(
                                color = if (isEdgeActive) {
                                    if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)
                                } else {
                                    if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
                                },
                                start = Offset(startX, startY),
                                end = Offset(endX, endY),
                                strokeWidth = if (isEdgeActive) 3.5f else 2f,
                                cap = StrokeCap.Round
                            )

                            // Draw arrow tip
                            val angle = kotlin.math.atan2(endY - startY, endX - startX)
                            val arrowLen = 14f
                            val arrowAngle = Math.PI / 6
                            val arrowP1 = Offset(
                                (endX - arrowLen * kotlin.math.cos(angle - arrowAngle)).toFloat(),
                                (endY - arrowLen * kotlin.math.sin(angle - arrowAngle)).toFloat()
                            )
                            val arrowP2 = Offset(
                                (endX - arrowLen * kotlin.math.cos(angle + arrowAngle)).toFloat(),
                                (endY - arrowLen * kotlin.math.sin(angle + arrowAngle)).toFloat()
                            )
                            drawLine(
                                color = if (isEdgeActive) {
                                    if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)
                                } else {
                                    if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
                                },
                                start = Offset(endX, endY),
                                end = arrowP1,
                                strokeWidth = 2.5f
                            )
                            drawLine(
                                color = if (isEdgeActive) {
                                    if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7)
                                } else {
                                    if (isDark) Color(0xFF64748B) else Color(0xFF94A3B8)
                                },
                                start = Offset(endX, endY),
                                end = arrowP2,
                                strokeWidth = 2.5f
                            )

                            // Draw edge label (e.g. Yes / No)
                            if (edge.labelBn != null) {
                                val midX = (startX + endX) / 2 + 10f
                                val midY = (startY + endY) / 2
                                val labelLayout = textMeasurer.measure(
                                    AnnotatedString(edge.labelBn),
                                    style = TextStyle(
                                        color = if (isEdgeActive) {
                                            if (isDark) Color(0xFFFDE047) else Color(0xFFD97706)
                                        } else {
                                            if (isDark) Color(0xFF94A3B8) else Color(0xFF475569)
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                drawText(labelLayout, topLeft = Offset(midX, midY - 14f))
                            }
                        }
                    }

                    // 2. Draw Nodes (Shapes)
                    selectedFlowchart.nodes.forEach { node ->
                        val cx = node.x * w
                        val cy = node.y * h
                        val isActive = node.id == activeNodeId
                        val scale = if (isActive) pulseScale else 1f

                        val nodeWidth = 140.dp.toPx() * scale
                        val nodeHeight = 44.dp.toPx() * scale
                        val inactiveNodeFill = if (isDark) Color(0xFF1E293B) else Color(0xFFFFFFFF)

                        when (node.type) {
                            FlowchartNodeType.START_END -> {
                                // Oval / Capsule
                                val fillColor = if (isActive) Color(0xFF0284C7) else inactiveNodeFill
                                val strokeColor = if (isActive) Color(0xFF38BDF8) else Color(0xFF0284C7)
                                drawRoundRect(
                                    color = fillColor,
                                    topLeft = Offset(cx - nodeWidth / 2, cy - nodeHeight / 2),
                                    size = Size(nodeWidth, nodeHeight),
                                    cornerRadius = CornerRadius(nodeHeight / 2, nodeHeight / 2)
                                )
                                drawRoundRect(
                                    color = strokeColor,
                                    topLeft = Offset(cx - nodeWidth / 2, cy - nodeHeight / 2),
                                    size = Size(nodeWidth, nodeHeight),
                                    cornerRadius = CornerRadius(nodeHeight / 2, nodeHeight / 2),
                                    style = Stroke(width = if (isActive) 3f else 1.5f)
                                )
                            }
                            FlowchartNodeType.INPUT_OUTPUT -> {
                                // Parallelogram
                                val slant = 18f
                                val path = Path().apply {
                                    moveTo(cx - nodeWidth / 2 + slant, cy - nodeHeight / 2)
                                    lineTo(cx + nodeWidth / 2 + slant, cy - nodeHeight / 2)
                                    lineTo(cx + nodeWidth / 2 - slant, cy + nodeHeight / 2)
                                    lineTo(cx - nodeWidth / 2 - slant, cy + nodeHeight / 2)
                                    close()
                                }
                                val fillColor = if (isActive) Color(0xFF0D9488) else inactiveNodeFill
                                val strokeColor = if (isActive) Color(0xFF2DD4BF) else Color(0xFF0D9488)
                                drawPath(path, color = fillColor)
                                drawPath(path, color = strokeColor, style = Stroke(width = if (isActive) 3f else 1.5f))
                            }
                            FlowchartNodeType.PROCESS -> {
                                // Rectangle
                                val fillColor = if (isActive) Color(0xFF4F46E5) else inactiveNodeFill
                                val strokeColor = if (isActive) Color(0xFF818CF8) else Color(0xFF4F46E5)
                                drawRoundRect(
                                    color = fillColor,
                                    topLeft = Offset(cx - nodeWidth / 2, cy - nodeHeight / 2),
                                    size = Size(nodeWidth, nodeHeight),
                                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                                )
                                drawRoundRect(
                                    color = strokeColor,
                                    topLeft = Offset(cx - nodeWidth / 2, cy - nodeHeight / 2),
                                    size = Size(nodeWidth, nodeHeight),
                                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                                    style = Stroke(width = if (isActive) 3f else 1.5f)
                                )
                            }
                            FlowchartNodeType.DECISION -> {
                                // Diamond (Rombus)
                                val dWidth = nodeWidth * 1.1f
                                val dHeight = nodeHeight * 1.25f
                                val path = Path().apply {
                                    moveTo(cx, cy - dHeight / 2)
                                    lineTo(cx + dWidth / 2, cy)
                                    lineTo(cx, cy + dHeight / 2)
                                    lineTo(cx - dWidth / 2, cy)
                                    close()
                                }
                                val fillColor = if (isActive) Color(0xFFD97706) else inactiveNodeFill
                                val strokeColor = if (isActive) Color(0xFFFBBF24) else Color(0xFFD97706)
                                drawPath(path, color = fillColor)
                                drawPath(path, color = strokeColor, style = Stroke(width = if (isActive) 3f else 1.5f))
                            }
                        }

                        // Text inside node
                        val nodeTextColor = if (isActive || isDark) Color.White else Color(0xFF0F172A)
                        val textLayout = textMeasurer.measure(
                            AnnotatedString(node.labelBn),
                            style = TextStyle(
                                color = nodeTextColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        drawText(
                            textLayout,
                            topLeft = Offset(
                                cx - textLayout.size.width / 2,
                                cy - textLayout.size.height / 2
                            )
                        )
                    }
                }
            }
        }
    }
}
