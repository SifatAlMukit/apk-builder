package com.example.presentation.navigation

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Course : Screen("course")
    data object LessonDetail : Screen("lesson/{lessonId}") {
        fun createRoute(lessonId: String) = "lesson/$lessonId"
    }
    data object Playground : Screen("playground")
    data object Flowchart : Screen("flowchart/{flowchartId}") {
        fun createRoute(flowchartId: String) = "flowchart/$flowchartId"
    }
    data object Quiz : Screen("quiz/{chapterId}") {
        fun createRoute(chapterId: String) = "quiz/$chapterId"
    }
    data object CheatSheet : Screen("cheatsheet")
    data object Glossary : Screen("glossary")
    data object MiniProjects : Screen("projects")
    data object ProjectDetail : Screen("project/{projectId}") {
        fun createRoute(projectId: String) = "project/$projectId"
    }
    data object Search : Screen("search")
    data object Settings : Screen("settings")
}
