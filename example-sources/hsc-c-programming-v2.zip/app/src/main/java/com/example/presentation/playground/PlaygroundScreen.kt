package com.example.presentation.playground

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.automirrored.filled.WrapText
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.compiler.CSyntaxHighlighter
import com.example.presentation.AppViewModel
import com.example.ui.theme.CodeBackgroundDark
import com.example.ui.theme.TerminalGreen

val SAMPLE_TEMPLATES = listOf(
    "Hello World" to """#include <stdio.h>

int main() {
    // স্ক্রিনে শুভেচ্ছা বার্তা প্রদর্শন
    printf("স্বাগতম! সি প্রোগ্রামিং জগতে।\n");
    return 0;
}""",
    "ইনপুট (scanf ইন্টারেক্টিভ)" to """#include <stdio.h>

int main() {
    int roll;
    float gpa;
    // ব্যবহারকারীর কাছ থেকে রোল নম্বর গ্রহণ (&roll দিয়ে মেমোরি অ্যাড্রেস নির্দেশ)
    printf("আপনার রোল নম্বর দিন: ");
    scanf("%d", &roll);
    
    // জিপিএ ইনপুট গ্রহণ
    printf("রোল %d গৃহীত হয়েছে!\nআপনার জিপিএ দিন: ", roll);
    scanf("%f", &gpa);
    
    // ফলাফল ফরম্যাট করে প্রদর্শন
    printf("\n=========================\n");
    printf("      শিক্ষার্থীর বিবরণ     \n");
    printf("=========================\n");
    printf("রোল নম্বর: %d\n", roll);
    printf("প্রাপ্ত জিপিএ: %.2f\n", gpa);
    printf("=========================\n");
    return 0;
}""",
    "২ সংখ্যার যোগফল (scanf)" to """#include <stdio.h>

int main() {
    int a, b;
    // দুটি পূর্ণসংখ্যা ইনপুট নেওয়া
    printf("প্রথম সংখ্যা দিন: ");
    scanf("%d", &a);
    printf("দ্বিতীয় সংখ্যা দিন: ");
    scanf("%d", &b);
    
    // যোগফল নির্ণয়
    int sum = a + b;
    printf("\n%d + %d এর যোগফল = %d\n", a, b, sum);
    return 0;
}""",
    "বৃহত্তম সংখ্যা" to """#include <stdio.h>

int main() {
    int a = 45, b = 80, c = 32;
    // লজিক্যাল AND (&&) দিয়ে ৩টি সংখ্যার মধ্যে তুলনা
    if (a >= b && a >= c) {
        printf("বৃহত্তম সংখ্যা: %d\n", a);
    } else if (b >= a && b >= c) {
        printf("বৃহত্তম সংখ্যা: %d\n", b);
    } else {
        printf("বৃহত্তম সংখ্যা: %d\n", c);
    }
    return 0;
}""",
    "জোড় না বিজোড়" to """#include <stdio.h>

int main() {
    int num;
    // সংখ্যা ইনপুট
    printf("একটি সংখ্যা লিখুন: ");
    scanf("%d", &num);
    
    // ভাগশেষ (% 2) শূন্য হলে জোড়, অন্যথায় বিজোড়
    if (num % 2 == 0) {
        printf("%d হলো জোড় সংখ্যা (Even)\n", num);
    } else {
        printf("%d হলো বিজোড় সংখ্যা (Odd)\n", num);
    }
    return 0;
}""",
    "লিপ ইয়ার পরীক্ষা" to """#include <stdio.h>

int main() {
    int year;
    // সাল ইনপুট গ্রহণ
    printf("পরীক্ষা করার জন্য সাল লিখুন: ");
    scanf("%d", &year);
    
    // লিপ ইয়ারের শর্ত: ৪০০ দ্বারা বিভাজ্য অথবা ৪ দ্বারা বিভাজ্য কিন্তু ১০০ দ্বারা নয়
    if ((year % 400 == 0) || (year % 4 == 0 && year % 100 != 0)) {
        printf("%d একটি অধিবর্ষ (Leap Year)\n", year);
    } else {
        printf("%d অধিবর্ষ নয়\n", year);
    }
    return 0;
}""",
    "ধারা ১+২+...+N" to """#include <stdio.h>

int main() {
    int n, sum = 0;
    // শেষ পদ N ইনপুট
    printf("কত পর্যন্ত যোগ করতে চান (N): ");
    scanf("%d", &n);
    
    // ১ থেকে N পর্যন্ত লুপ চালিয়ে যোগফল বের করা
    for (int i = 1; i <= n; i++) {
        sum += i;
    }
    printf("১ থেকে %d পর্যন্ত সংখ্যার যোগফল = %d\n", n, sum);
    return 0;
}""",
    "ফ্যাক্টোরিয়াল (n!)" to """#include <stdio.h>

int main() {
    int n;
    long fact = 1;
    // ধনাত্মক সংখ্যা ইনপুট
    printf("কোন সংখ্যার ফ্যাক্টোরিয়াল চান? ");
    scanf("%d", &n);
    
    // ১ থেকে n পর্যন্ত ক্রমিক গুণ
    for (int i = 1; i <= n; i++) {
        fact *= i;
    }
    printf("%d এর ফ্যাক্টোরিয়াল (%d!) = %ld\n", n, n, fact);
    return 0;
}""",
    "মৌলিক সংখ্যা (Prime)" to """#include <stdio.h>

int main() {
    int n, isPrime = 1;
    // সংখ্যা ইনপুট
    printf("যাচাই করতে একটি সংখ্যা লিখুন: ");
    scanf("%d", &n);
    
    // ২ থেকে রুট(n) পর্যন্ত ভাগ যায় কিনা পরীক্ষা
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            isPrime = 0;
            break;
        }
    }
    if (isPrime && n > 1) {
        printf("%d একটি মৌলিক সংখ্যা (Prime Number)\n", n);
    } else {
        printf("%d মৌলিক সংখ্যা নয়\n", n);
    }
    return 0;
}""",
    "গুণের নামতা" to """#include <stdio.h>

int main() {
    int num;
    // ব্যবহারকারীর কাছ থেকে সংখ্যা গ্রহণ
    printf("কোন সংখ্যার নামতা দেখতে চান? ");
    scanf("%d", &num);

    printf("\n=== %d এর গুণের নামতা ===\n", num);
    // ১ থেকে ১০ পর্যন্ত লুপ চালিয়ে নামতা প্রদর্শন
    for (int i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", num, i, num * i);
    }
    return 0;
}""",
    "গ্রেড নির্ণয় (GPA)" to """#include <stdio.h>

int main() {
    int marks;
    // প্রাপ্ত নম্বর ইনপুট গ্রহণ
    printf("আপনার প্রাপ্ত নম্বর লিখুন (০-১০০): ");
    scanf("%d", &marks);

    printf("\nফলাফল: ");
    // শর্ত যাচাই করে লেটার গ্রেড নির্ধারণ
    if (marks >= 80) {
        printf("A+ (জিপিএ ৫.০০) - অসাধারণ!\n");
    } else if (marks >= 70) {
        printf("A (জিপিএ ৪.০০)\n");
    } else if (marks >= 60) {
        printf("A- (জিপিএ ৩.৫০)\n");
    } else if (marks >= 50) {
        printf("B (জিপিএ ৩.০০)\n");
    } else if (marks >= 33) {
        printf("D (জিপিএ ১.০০) - উত্তীর্ণ\n");
    } else {
        printf("F (ফেল) - পুনরায় চেষ্টা করুন\n");
    }
    return 0;
}""",
    "ত্রিভুজের ক্ষেত্রফল" to """#include <stdio.h>

int main() {
    float base, height, area;
    // ভূমি ও উচ্চতা ইনপুট গ্রহণ
    printf("ত্রিভুজের ভূমি (Base) লিখুন: ");
    scanf("%f", &base);
    printf("ত্রিভুজের উচ্চতা (Height) লিখুন: ");
    scanf("%f", &height);

    // ক্ষেত্রফল সূত্র: ০.৫ * ভূমি * উচ্চতা
    area = 0.5 * base * height;

    printf("\n-------------------------\n");
    printf("ভূমি = %.2f, উচ্চতা = %.2f\n", base, height);
    printf("ত্রিভুজের ক্ষেত্রফল = %.2f বর্গ একক\n", area);
    printf("-------------------------\n");
    return 0;
}""",
    "তাপমাত্রা রূপান্তর (°C to °F)" to """#include <stdio.h>

int main() {
    float celsius, fahrenheit;
    // সেলসিয়াস মান গ্রহণ
    printf("সেলসিয়াস তাপমাত্রা লিখুন (°C): ");
    scanf("%f", &celsius);

    // ফারেনহাইটে রূপান্তর সূত্র: (C * 9/5) + 32
    fahrenheit = (celsius * 9.0 / 5.0) + 32.0;

    printf("\n%.2f° সেলসিয়াস = %.2f° ফারেনহাইট\n", celsius, fahrenheit);
    return 0;
}""",
    "উল্টো সংখ্যা (Reverse Number)" to """#include <stdio.h>

int main() {
    int n, reversed = 0, temp;
    // একটি পূর্ণসংখ্যা ইনপুট
    printf("যেকোনো পূর্ণসংখ্যা লিখুন: ");
    scanf("%d", &n);
    temp = n;

    // লুপে শেষ অঙ্ক (% 10) নিয়ে সংখ্যা উল্টানো
    while (temp != 0) {
        int rem = temp % 10;
        reversed = reversed * 10 + rem;
        temp = temp / 10;
    }

    printf("\nমূল সংখ্যা: %d\n", n);
    printf("উল্টানো সংখ্যা: %d\n", reversed);
    return 0;
}""",
    "ফিবোনাচ্চি ধারা" to """#include <stdio.h>

int main() {
    int count;
    // ধারার পদের সংখ্যা গ্রহণ
    printf("কয়টি ফিবোনাচ্চি পদ দেখতে চান? ");
    scanf("%d", &count);

    int t1 = 0, t2 = 1, next;
    printf("\nফিবোনাচ্চি ধারা: ");

    // লুপ চালিয়ে ধারার পদগুলো পরপর বের করা
    for (int i = 1; i <= count; i++) {
        printf("%d ", t1);
        next = t1 + t2;
        t1 = t2;
        t2 = next;
    }
    printf("\n");
    return 0;
}""",
    "স্টার পিরামিড" to """#include <stdio.h>

int main() {
    int rows;
    // সারির সংখ্যা ইনপুট
    printf("কয়টি সারির স্টার প্যাটার্ন চান? ");
    scanf("%d", &rows);

    printf("\n=== স্টার প্যাটার্ন ===\n");
    // নেস্টেড লুপ: বাইরের লুপ সারি নিয়ন্ত্রণ করে
    for (int i = 1; i <= rows; i++) {
        // ভেতরের লুপ প্রতিটি সারিতে তারকা প্রিন্ট করে
        for (int j = 1; j <= i; j++) {
            printf("* ");
        }
        printf("\n");
    }
    return 0;
}""",
    "গড় নির্ণয় (Average)" to """#include <stdio.h>

int main() {
    int n;
    float sum = 0, val;
    // কতগুলো সংখ্যার গড় বের করতে হবে
    printf("কয়টি সংখ্যার গড় করতে চান? ");
    scanf("%d", &n);

    // লুপে প্রতিটি সংখ্যা ইনপুট নিয়ে যোগ
    for (int i = 1; i <= n; i++) {
        printf("%d নং সংখ্যা দিন: ", i);
        scanf("%f", &val);
        sum += val;
    }

    // গড় = মোট যোগফল / সংখ্যার পরিমাণ
    float avg = sum / n;
    printf("\nমোট যোগফল = %.2f\n", sum);
    printf("গড় মান (Average) = %.2f\n", avg);
    return 0;
}""",
    "মিনি এটিএম ব্যালেন্স চেক" to """#include <stdio.h>

int main() {
    int balance = 5000;
    int choice, amount;

    printf("=== ডিজিটাল এটিএম বুথ ===\n");
    printf("১. ব্যালেন্স অনুসন্ধান\n");
    printf("২. টাকা জমা (Deposit)\n");
    printf("৩. টাকা উত্তোলন (Withdraw)\n");
    printf("আপনার পছন্দ চাপুন (১-৩): ");
    scanf("%d", &choice);

    // মেনু সিলেকশন লজিক
    if (choice == 1) {
        printf("\nআপনার বর্তমান ব্যালেন্স: %d টাকা\n", balance);
    } else if (choice == 2) {
        printf("কত টাকা জমা দিতে চান? ");
        scanf("%d", &amount);
        balance += amount;
        printf("জমা সফল! নতুন ব্যালেন্স: %d টাকা\n", balance);
    } else if (choice == 3) {
        printf("কত টাকা তুলতে চান? ");
        scanf("%d", &amount);
        if (amount <= balance) {
            balance -= amount;
            printf("উত্তোলন সফল! অবশিষ্ট ব্যালেন্স: %d টাকা\n", balance);
        } else {
            printf("অপর্যাপ্ত ব্যালেন্স! উত্তোলন সম্ভব নয়।\n");
        }
    } else {
        printf("অবৈধ অপশন নির্বাচন করেছেন।\n");
    }
    return 0;
}""",
    "গ.সা.গু ও ল.সা.গু" to """#include <stdio.h>

int main() {
    int n1, n2, a, b, temp, gcd, lcm;
    // দুটি ধনাত্মক সংখ্যা গ্রহণ
    printf("প্রথম সংখ্যা দিন: ");
    scanf("%d", &n1);
    printf("দ্বিতীয় সংখ্যা দিন: ");
    scanf("%d", &n2);

    a = n1;
    b = n2;

    // ইউক্লিডীয় অ্যালগরিদম দিয়ে গ.সা.গু নির্ণয়
    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }
    gcd = a;
    // ল.সা.গু সূত্র = (n1 * n2) / গ.সা.গু
    lcm = (n1 * n2) / gcd;

    printf("\n%d ও %d এর গ.সা.গু (GCD) = %d\n", n1, n2, gcd);
    printf("%d ও %d এর ল.সা.গু (LCM) = %d\n", n1, n2, lcm);
    return 0;
}"""
)

val QUICK_INSERT_KEYS = listOf(
    "{}", "()", "[]", ";", "\"", "'", "==", "!=", "<", ">", "<=", ">=", "&&", "||", "++", "--", "printf()", "scanf()", "#include <stdio.h>"
)

private fun processAutoIndent(oldVal: TextFieldValue, newVal: TextFieldValue): TextFieldValue {
    val oldText = oldVal.text
    val newText = newVal.text

    // Check if the user pressed Enter (single newline character inserted)
    if (newText.length == oldText.length + 1 &&
        newVal.selection.start == oldVal.selection.start + 1
    ) {
        val insertedIndex = oldVal.selection.start
        if (insertedIndex in 0 until newText.length && newText[insertedIndex] == '\n') {
            val textBeforeNewline = newText.substring(0, insertedIndex)
            val lastNewlineBefore = textBeforeNewline.lastIndexOf('\n')
            val previousLine = if (lastNewlineBefore == -1) {
                textBeforeNewline
            } else {
                textBeforeNewline.substring(lastNewlineBefore + 1)
            }

            val indentSpaces = previousLine.takeWhile { it == ' ' || it == '\t' }
            val trimmedPrev = previousLine.trimEnd()
            val extraIndent = if (trimmedPrev.endsWith("{")) "    " else ""
            val totalIndent = indentSpaces + extraIndent

            if (totalIndent.isNotEmpty()) {
                val textAfterNewline = newText.substring(insertedIndex + 1)
                val indentedText = textBeforeNewline + "\n" + totalIndent + textAfterNewline
                val newCursor = insertedIndex + 1 + totalIndent.length
                return TextFieldValue(
                    text = indentedText,
                    selection = TextRange(newCursor)
                )
            }
        }
    }

    // Auto un-indent when typing '}' on a line that only has indentation
    if (newText.length == oldText.length + 1 &&
        newVal.selection.start == oldVal.selection.start + 1
    ) {
        val insertedIndex = oldVal.selection.start
        if (insertedIndex in 0 until newText.length && newText[insertedIndex] == '}') {
            val textBeforeBrace = newText.substring(0, insertedIndex)
            val lastNewlineBefore = textBeforeBrace.lastIndexOf('\n')
            val lineBeforeBrace = if (lastNewlineBefore == -1) {
                textBeforeBrace
            } else {
                textBeforeBrace.substring(lastNewlineBefore + 1)
            }

            if (lineBeforeBrace.all { it == ' ' } && lineBeforeBrace.length >= 4) {
                val textBeforeLine = if (lastNewlineBefore == -1) "" else newText.substring(0, lastNewlineBefore + 1)
                val unindentedLine = lineBeforeBrace.drop(4) + "}"
                val textAfterBrace = newText.substring(insertedIndex + 1)
                val modifiedText = textBeforeLine + unindentedLine + textAfterBrace
                val newCursor = textBeforeLine.length + unindentedLine.length
                return TextFieldValue(
                    text = modifiedText,
                    selection = TextRange(newCursor)
                )
            }
        }
    }

    return newVal
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaygroundScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isDarkTheme = androidx.compose.foundation.isSystemInDarkTheme()
    val initialCode by viewModel.playgroundCode.collectAsState()
    val executionResult by viewModel.executionResult.collectAsState()
    val isExecuting by viewModel.isExecuting.collectAsState()
    val liveTerminalOutput by viewModel.liveTerminalOutput.collectAsState()
    val isWaitingForInput by viewModel.isWaitingForInput.collectAsState()
    val isWordWrapEnabled by viewModel.isWordWrapEnabled.collectAsState()

    val syntaxVisualTransformation = remember(isDarkTheme) {
        VisualTransformation { text ->
            TransformedText(
                text = CSyntaxHighlighter.highlight(text.text, isDarkTheme = isDarkTheme),
                offsetMapping = OffsetMapping.Identity
            )
        }
    }

    var textFieldValue by remember { mutableStateOf(TextFieldValue(initialCode)) }
    var undoStack by remember { mutableStateOf(listOf<String>()) }
    var redoStack by remember { mutableStateOf(listOf<String>()) }
    var showSaveDialog by remember { mutableStateOf(false) }
    var snippetTitle by remember { mutableStateOf("") }
    var showTemplatesSheet by remember { mutableStateOf(false) }
    var liveInputText by remember { mutableStateOf("") }
    val inputFocusRequester = remember { FocusRequester() }

    val terminalScrollState = rememberScrollState()

    // Auto-scroll terminal as new output arrives or when input prompt appears
    LaunchedEffect(liveTerminalOutput, isWaitingForInput) {
        terminalScrollState.animateScrollTo(terminalScrollState.maxValue)
    }

    // Auto-focus the input field as soon as scanf requests input
    LaunchedEffect(isWaitingForInput) {
        if (isWaitingForInput) {
            try {
                inputFocusRequester.requestFocus()
            } catch (_: Exception) {}
        }
    }

    // Sync whenever ViewModel code changes from outside (e.g. from Lesson "Run in playground")
    LaunchedEffect(initialCode) {
        if (textFieldValue.text != initialCode) {
            textFieldValue = TextFieldValue(initialCode)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("সি কোড প্লেগ্রাউন্ড", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                        Text("আউটপুট কনসোল ও সি ইন্টারপ্রেটার", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                actions = {
                    // Templates button
                    IconButton(
                        onClick = { showTemplatesSheet = true },
                        modifier = Modifier.testTag("templates_btn")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "টেমপ্লেট")
                    }

                    // Save snippet button
                    IconButton(
                        onClick = { showSaveDialog = true },
                        modifier = Modifier.testTag("save_snippet_btn")
                    ) {
                        Icon(Icons.Outlined.BookmarkAdd, contentDescription = "সংরক্ষণ করুন")
                    }

                    // Share button
                    IconButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "C Source Code (HSC ICT)")
                                putExtra(Intent.EXTRA_TEXT, textFieldValue.text)
                            }
                            context.startActivity(Intent.createChooser(intent, "কোড শেয়ার করুন"))
                        }
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "শেয়ার করুন")
                    }

                    // Run or Stop button
                    if (isExecuting) {
                        FilledTonalButton(
                            onClick = { viewModel.stopExecution() },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFFD32F2F),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("stop_code_btn")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("থামান", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    } else {
                        FilledTonalButton(
                            onClick = {
                                viewModel.setPlaygroundCode(textFieldValue.text)
                                viewModel.runCode()
                            },
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF2E7D32),
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("run_code_btn")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("রান", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Editor Toolbar (Undo, Redo, Clear, Copy)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = {
                            if (undoStack.isNotEmpty()) {
                                redoStack = redoStack + textFieldValue.text
                                val prev = undoStack.last()
                                undoStack = undoStack.dropLast(1)
                                textFieldValue = TextFieldValue(prev)
                                viewModel.setPlaygroundCode(prev)
                            }
                        },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Undo, contentDescription = "আনডু", modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            if (redoStack.isNotEmpty()) {
                                undoStack = undoStack + textFieldValue.text
                                val next = redoStack.last()
                                redoStack = redoStack.dropLast(1)
                                textFieldValue = TextFieldValue(next)
                                viewModel.setPlaygroundCode(next)
                            }
                        },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Redo, contentDescription = "রিডু", modifier = Modifier.size(18.dp))
                    }

                    IconButton(
                        onClick = {
                            undoStack = undoStack + textFieldValue.text
                            textFieldValue = TextFieldValue("")
                            viewModel.setPlaygroundCode("")
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Clear, contentDescription = "মুছে ফেলুন", modifier = Modifier.size(18.dp))
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Word wrap toggle button with explicit readable badge
                    Surface(
                        onClick = {
                            viewModel.toggleWordWrap()
                            Toast.makeText(
                                context,
                                if (!isWordWrapEnabled) "Text Wrap চালু করা হয়েছে (স্ক্রিনের ভেতর লাইন ভাঙবে)" else "Text Wrap বন্ধ করা হয়েছে (অনুভূমিক স্ক্রোলিং চালু)",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isWordWrapEnabled) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(
                            1.dp,
                            if (isWordWrapEnabled) MaterialTheme.colorScheme.primary else Color(0xFF455A64)
                        ),
                        modifier = Modifier
                            .height(32.dp)
                            .testTag("toggle_word_wrap_btn")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                Icons.AutoMirrored.Filled.WrapText,
                                contentDescription = if (isWordWrapEnabled) "Text Wrap বন্ধ করুন" else "Text Wrap চালু করুন",
                                tint = if (isWordWrapEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isWordWrapEnabled) "Wrap: অন" else "Wrap: অফ",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isWordWrapEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("C Source", textFieldValue.text)
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "কোড কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "কপি", modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Editor and Terminal Split
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                // Code Editor Section (Editor + Quick Symbol Toolbar at its bottom)
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.05f)
                        .background(if (isDarkTheme) CodeBackgroundDark else Color(0xFFF8FAFC))
                ) {
                    val lines = remember(textFieldValue.text) { textFieldValue.text.lines() }
                    val editorVerticalScroll = rememberScrollState()
                    val editorHorizontalScroll = rememberScrollState()

                    // Code Editor Box (Line numbers + editable code)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(editorVerticalScroll)
                                .padding(8.dp)
                        ) {
                            // Line numbers
                            Column(
                                modifier = Modifier
                                    .widthIn(min = 28.dp)
                                    .padding(end = 8.dp)
                                    .drawBehind {
                                        drawLine(
                                            color = if (isDarkTheme) Color(0xFF263238) else Color(0xFFE2E8F0),
                                            start = Offset(size.width, 0f),
                                            end = Offset(size.width, size.height),
                                            strokeWidth = 2f
                                        )
                                    },
                                horizontalAlignment = Alignment.End
                            ) {
                                lines.indices.forEach { index ->
                                    Text(
                                        text = "${index + 1}",
                                        color = if (isDarkTheme) Color(0xFF546E7A) else Color(0xFF64748B),
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 20.sp
                                    )
                                }
                            }

                            // Editable code field (Wrapped or Horizontal Scrolled)
                            val codeModifier = if (isWordWrapEnabled) {
                                Modifier
                                    .fillMaxWidth()
                                    .padding(start = 8.dp)
                            } else {
                                Modifier
                                    .horizontalScroll(editorHorizontalScroll)
                                    .widthIn(min = 1600.dp)
                                    .padding(start = 8.dp)
                            }

                            BasicTextField(
                                value = textFieldValue,
                                onValueChange = { newVal ->
                                    val processedVal = processAutoIndent(textFieldValue, newVal)
                                    if (processedVal.text != textFieldValue.text) {
                                        undoStack = undoStack + textFieldValue.text
                                    }
                                    textFieldValue = processedVal
                                    viewModel.setPlaygroundCode(processedVal.text)
                                },
                                visualTransformation = syntaxVisualTransformation,
                                textStyle = TextStyle(
                                    color = if (isDarkTheme) Color(0xFFECEFF1) else Color(0xFF0F172A),
                                    fontSize = 13.sp,
                                    fontFamily = FontFamily.Monospace,
                                    lineHeight = 20.sp
                                ),
                                cursorBrush = SolidColor(if (isDarkTheme) Color(0xFF00B4D8) else Color(0xFF006699)),
                                modifier = codeModifier.testTag("code_editor_field")
                            )
                        }
                    }

                    // Quick symbol insert row - Standard placement at the bottom of the editor!
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (isDarkTheme) Color(0xFF141C28) else Color(0xFFF1F5F9))
                            .padding(horizontal = 6.dp, vertical = 5.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(QUICK_INSERT_KEYS) { key ->
                            Surface(
                                onClick = {
                                    undoStack = undoStack + textFieldValue.text
                                    val currentText = textFieldValue.text
                                    val selection = textFieldValue.selection
                                    val selMin = minOf(selection.min, currentText.length)
                                    val selMax = minOf(selection.max, currentText.length)

                                    val (insertText, cursorOffset) = when (key) {
                                        "{}" -> Pair("{\n    \n}", 6)
                                        "()" -> Pair("()", 1)
                                        "[]" -> Pair("[]", 1)
                                        "\"" -> Pair("\"\"", 1)
                                        "'" -> Pair("''", 1)
                                        "printf()" -> Pair("printf(\"\");", 8)
                                        "scanf()" -> Pair("scanf(\"%d\", &);", 13)
                                        "#include <stdio.h>" -> Pair("#include <stdio.h>\n", 19)
                                        else -> Pair(key, key.length)
                                    }

                                    val newText = currentText.replaceRange(selMin, selMax, insertText)
                                    val newCursorPos = selMin + cursorOffset
                                    textFieldValue = TextFieldValue(
                                        text = newText,
                                        selection = TextRange(newCursorPos)
                                    )
                                    viewModel.setPlaygroundCode(newText)
                                },
                                shape = RoundedCornerShape(6.dp),
                                color = if (isDarkTheme) Color(0xFF253042) else Color(0xFFFFFFFF),
                                border = if (isDarkTheme) null else BorderStroke(1.dp, Color(0xFFCBD5E1)),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Box(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = key,
                                        color = if (isDarkTheme) Color(0xFFECEFF1) else Color(0xFF1E293B),
                                        fontSize = 12.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }

                // Interactive Live Terminal Console
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.95f),
                    color = if (isDarkTheme) Color(0xFF090D16) else Color(0xFFF1F5F9),
                    border = if (isDarkTheme) null else BorderStroke(1.dp, Color(0xFFE2E8F0)),
                    tonalElevation = if (isDarkTheme) 8.dp else 1.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp)
                    ) {
                        // Terminal Header bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Status indicator dot
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when {
                                                isWaitingForInput -> Color(0xFFFFB74D) // Amber for waiting
                                                isExecuting -> Color(0xFF4CAF50)     // Green for running
                                                else -> if (isDarkTheme) Color(0xFF78909C) else Color(0xFF94A3B8)
                                            }
                                        )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = when {
                                        isWaitingForInput -> "ইনপুটের অপেক্ষায় (scanf Input)..."
                                        isExecuting -> "আউটপুট কনসোল (চলছে...)"
                                        else -> "আউটপুট কনসোল (Output Console)"
                                    },
                                    color = if (isWaitingForInput) {
                                        if (isDarkTheme) Color(0xFFFFB74D) else Color(0xFFD97706)
                                    } else {
                                        if (isDarkTheme) Color(0xFFCFD8DC) else Color(0xFF1E293B)
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (executionResult != null) {
                                    Text(
                                        text = "${executionResult?.executionTimeMs}ms • ~${executionResult?.simulatedMemoryBytes}B",
                                        fontSize = 11.sp,
                                        color = if (isDarkTheme) Color(0xFF90A4AE) else Color(0xFF64748B),
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                }

                                if (isExecuting) {
                                    IconButton(
                                        onClick = { viewModel.stopExecution() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Stop,
                                            contentDescription = "থামান",
                                            tint = Color(0xFFFF5252),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                } else if (liveTerminalOutput.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.clearExecution() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "ক্লিয়ার",
                                            tint = if (isDarkTheme) Color(0xFF78909C) else Color(0xFF475569),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }

                        HorizontalDivider(
                            color = if (isDarkTheme) Color(0xFF1E2638) else Color(0xFFCBD5E1),
                            modifier = Modifier.padding(vertical = 6.dp)
                        )

                        // Terminal Output View
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .verticalScroll(terminalScrollState)
                        ) {
                            when {
                                liveTerminalOutput.isNotEmpty() -> {
                                    Text(
                                        text = liveTerminalOutput,
                                        color = if (isDarkTheme) Color(0xFFA5D6A7) else Color(0xFF1B5E20),
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace,
                                        lineHeight = 18.sp
                                    )

                                    if (executionResult != null) {
                                        val res = executionResult!!
                                        if (res.isSuccess) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "--------------------------------\nProcess returned ${res.exitCode} (0x${res.exitCode.toString(16)})  execution time : ${res.executionTimeMs / 1000.0} s",
                                                color = if (isDarkTheme) Color(0xFF546E7A) else Color(0xFF64748B),
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        } else if (res.error != null) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = res.error,
                                                color = if (isDarkTheme) Color(0xFFFF8A80) else Color(0xFFC62828),
                                                fontSize = 12.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 18.sp
                                            )
                                        }
                                    }
                                }
                                isExecuting -> {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = TerminalGreen,
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "কনসোল চালু হচ্ছে...",
                                            color = if (isDarkTheme) Color(0xFF81C784) else Color(0xFF2E7D32),
                                            fontSize = 12.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                                else -> {
                                    Text(
                                        text = "আউটপুট কনসোল (Output Console):\n• কোড লিখে উপরে 'রান' বাটনে চাপুন।\n• কোডে scanf() থাকলে এক্সিকিউশন চলার সময় ঠিক যেমন রিয়েল কম্পিউটারে হয়, এখানে ইনপুট চাওয়া হবে।\n• আপনি তখন মান লিখে 'পাঠান' বা Enter চাপলেই কোড চলতে থাকবে।",
                                        color = if (isDarkTheme) Color(0xFF546E7A) else Color(0xFF64748B),
                                        fontSize = 12.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                            }
                        }

                        // Real-Time Interactive Input Line (Active when scanf is waiting)
                        AnimatedVisibility(visible = isWaitingForInput) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 8.dp)
                            ) {
                                // Terminal prompt & input field
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            if (isDarkTheme) Color(0xFF0F1A2C) else Color(0xFFFFFFFF),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .then(
                                            if (!isDarkTheme) Modifier.border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp)) else Modifier
                                        )
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "stdin > ",
                                        color = if (isDarkTheme) Color(0xFFFFB74D) else Color(0xFFD97706),
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 14.sp
                                    )
                                    BasicTextField(
                                        value = liveInputText,
                                        onValueChange = { liveInputText = it },
                                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                                        keyboardActions = KeyboardActions(
                                            onSend = {
                                                val toSend = if (liveInputText.isNotBlank()) liveInputText else "0"
                                                viewModel.sendTerminalInput(toSend)
                                                liveInputText = ""
                                            }
                                        ),
                                        textStyle = TextStyle(
                                            color = if (isDarkTheme) Color(0xFF80D8FF) else Color(0xFF0284C7),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.SemiBold
                                        ),
                                        cursorBrush = SolidColor(if (isDarkTheme) Color(0xFFFFB74D) else Color(0xFFD97706)),
                                        modifier = Modifier
                                            .weight(1f)
                                            .focusRequester(inputFocusRequester)
                                            .testTag("interactive_terminal_input")
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    FilledTonalButton(
                                        onClick = {
                                            val toSend = if (liveInputText.isNotBlank()) liveInputText else "0"
                                            viewModel.sendTerminalInput(toSend)
                                            liveInputText = ""
                                        },
                                        colors = ButtonDefaults.filledTonalButtonColors(
                                            containerColor = Color(0xFF0077B6),
                                            contentColor = Color.White
                                        ),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("পাঠান ↵", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                // Mobile Quick Numpad / Space Bar for rapid input without switching keyboards
                                LazyRow(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 6.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    val quickKeys = listOf("0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "-", "Space", "⌫")
                                    items(quickKeys) { key ->
                                        Surface(
                                            onClick = {
                                                when (key) {
                                                    "Space" -> liveInputText += " "
                                                    "⌫" -> if (liveInputText.isNotEmpty()) liveInputText = liveInputText.dropLast(1)
                                                    else -> liveInputText += key
                                                }
                                            },
                                            shape = RoundedCornerShape(4.dp),
                                            color = if (key == "Space" || key == "⌫") Color(0xFF263238) else Color(0xFF1E2838),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = key,
                                                    color = Color(0xFFECEFF1),
                                                    fontSize = 11.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                }

                                Text(
                                    text = "💡 টিপস: সংখ্যা লিখে কীবোর্ডের Enter বা 'পাঠান' চাপুন। একাধিক ইনপুটের জন্য স্পেস দিন (যেমন: 10 20)",
                                    color = Color(0xFF78909C),
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(top = 4.dp, start = 4.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Sheet for Templates
    if (showTemplatesSheet) {
        ModalBottomSheet(
            onDismissRequest = { showTemplatesSheet = false }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 24.dp)
            ) {
                Column {
                    Text(
                        text = "সি প্রোগ্রামিং এক্সাম্পল ও টেমপ্লেট",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "মোট ${SAMPLE_TEMPLATES.size} টি ইন্টার‍্যাক্টিভ ও বোর্ড স্ট্যান্ডার্ড প্রোগ্রাম (কমেন্ট সহ)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 520.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(SAMPLE_TEMPLATES) { (name, code) ->
                        val isInteractive = code.contains("scanf(")
                        Card(
                            onClick = {
                                undoStack = undoStack + textFieldValue.text
                                textFieldValue = TextFieldValue(code)
                                viewModel.setPlaygroundCode(code)
                                showTemplatesSheet = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("template_item_${name.replace(" ", "_")}"),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant
                            ),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isInteractive) MaterialTheme.colorScheme.primaryContainer
                                                else MaterialTheme.colorScheme.surface
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isInteractive) Icons.Default.Keyboard else Icons.Default.Code,
                                            contentDescription = null,
                                            tint = if (isInteractive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = name,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Text(
                                            text = if (isInteractive) "ইন্টারেক্টিভ ইনপুট (scanf)" else "স্ট্যান্ডার্ড আউটপুট (printf)",
                                            fontSize = 11.sp,
                                            color = if (isInteractive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Save Snippet Dialog
    if (showSaveDialog) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("স্নিপেট হিসেবে সংরক্ষণ") },
            text = {
                Column {
                    Text("এই কোড স্নিপেটটির একটি নাম দিন:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = snippetTitle,
                        onValueChange = { snippetTitle = it },
                        placeholder = { Text("যেমন: আমার তৈরি প্রাইম চেকার") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (snippetTitle.isNotBlank()) {
                            viewModel.saveCurrentSnippet(snippetTitle)
                            Toast.makeText(context, "স্নিপেট সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
                            showSaveDialog = false
                            snippetTitle = ""
                        }
                    }
                ) {
                    Text("সংরক্ষণ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
