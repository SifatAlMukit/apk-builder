package com.example.compiler

import java.util.Scanner
import kotlin.math.*

data class ExecutionResult(
    val output: String,
    val exitCode: Int = 0,
    val executionTimeMs: Long = 0,
    val simulatedMemoryBytes: Int = 0,
    val error: String? = null,
    val isSuccess: Boolean = true
)

class CRuntimeException(message: String, val line: Int) : Exception("রানটাইম ত্রুটি (লাইন $line): $message")
class ReturnSignal(val value: Any?) : Exception()
class BreakSignal : Exception()
class ContinueSignal : Exception()

class Environment(val parent: Environment? = null) {
    private val values = mutableMapOf<String, Any?>()

    fun define(name: String, value: Any?) {
        values[name] = value
    }

    fun contains(name: String): Boolean {
        if (values.containsKey(name)) return true
        return parent?.contains(name) ?: false
    }

    fun get(name: String): Any? {
        if (values.containsKey(name)) return values[name]
        return parent?.get(name)
    }

    fun set(name: String, value: Any?) {
        if (values.containsKey(name)) {
            values[name] = value
            return
        }
        if (parent != null && parent.contains(name)) {
            parent.set(name, value)
            return
        }
        values[name] = value
    }
}

class CInterpreter(
    private val program: CProgram,
    private val stdin: String = "",
    private val onOutput: (suspend (String) -> Unit)? = null,
    private val onInputRequest: (suspend () -> String)? = null
) {
    private val outputBuffer = StringBuilder()
    private val stdinScanner = Scanner(stdin)
    private val pendingInputTokens = ArrayDeque<String>()
    private var stepCount = 0
    private val maxSteps = 100000
    private var simulatedMemory = 64 // Base process memory

    // Global environment
    private val globalEnv = Environment()

    suspend fun run(): ExecutionResult {
        val startTime = System.currentTimeMillis()
        try {
            // Initialize global variables
            for (varDecl in program.globalVars) {
                executeVarDecl(varDecl, globalEnv)
            }

            // Call main()
            val mainFunc = program.functions["main"] ?: throw CRuntimeException("প্রোগ্রামে main() ফাংশন পাওয়া যায়নি।", 1)
            val exitVal = executeFunction(mainFunc, emptyList())

            val exitCode = when (exitVal) {
                is Number -> exitVal.toInt()
                else -> 0
            }

            val duration = System.currentTimeMillis() - startTime
            return ExecutionResult(
                output = outputBuffer.toString(),
                exitCode = exitCode,
                executionTimeMs = maxOf(duration, 1L),
                simulatedMemoryBytes = simulatedMemory,
                isSuccess = true
            )
        } catch (e: CParseException) {
            return ExecutionResult(
                output = outputBuffer.toString(),
                exitCode = -1,
                error = e.message,
                isSuccess = false
            )
        } catch (e: CRuntimeException) {
            return ExecutionResult(
                output = outputBuffer.toString(),
                exitCode = -1,
                error = e.message,
                isSuccess = false
            )
        } catch (e: Exception) {
            return ExecutionResult(
                output = outputBuffer.toString(),
                exitCode = -1,
                error = "অপ্রত্যাশিত ত্রুটি: ${e.localizedMessage ?: "Unknown"}",
                isSuccess = false
            )
        }
    }

    private suspend fun executeFunction(func: FunctionDef, args: List<Any?>): Any? {
        val funcEnv = Environment(globalEnv)
        // Bind parameters
        for (i in func.params.indices) {
            if (i < args.size) {
                funcEnv.define(func.params[i].name, args[i])
                simulatedMemory += 4
            }
        }

        try {
            executeBlock(func.body, funcEnv)
        } catch (r: ReturnSignal) {
            return r.value
        }
        return 0L
    }

    private suspend fun executeBlock(block: BlockStmt, env: Environment) {
        val blockEnv = Environment(env)
        for (stmt in block.statements) {
            checkStepLimit(1)
            executeStatement(stmt, blockEnv)
        }
    }

    private suspend fun executeStatement(stmt: Stmt, env: Environment) {
        checkStepLimit(1)
        when (stmt) {
            is VarDeclStmt -> executeVarDecl(stmt, env)
            is VarDeclListStmt -> {
                for (d in stmt.declarations) {
                    executeVarDecl(d, env)
                }
            }
            is ExprStmt -> evaluateExpression(stmt.expr, env)
            is IfStmt -> {
                val cond = evaluateExpression(stmt.condition, env)
                if (isTruthy(cond)) {
                    executeStatement(stmt.thenBranch, env)
                } else if (stmt.elseBranch != null) {
                    executeStatement(stmt.elseBranch, env)
                }
            }
            is SwitchStmt -> {
                val condVal = (evaluateExpression(stmt.condition, env) as? Number)?.toLong() ?: 0L
                var matched = false
                try {
                    for (case in stmt.cases) {
                        if (matched || case.value == condVal) {
                            matched = true
                            for (s in case.body) {
                                executeStatement(s, env)
                            }
                        }
                    }
                    if (!matched) {
                        for (s in stmt.defaultStatements) {
                            executeStatement(s, env)
                        }
                    }
                } catch (b: BreakSignal) {
                    // Switch break
                }
            }
            is ForStmt -> {
                val forEnv = Environment(env)
                if (stmt.init != null) {
                    executeStatement(stmt.init, forEnv)
                }
                while (true) {
                    checkStepLimit(stmt.line)
                    if (stmt.condition != null) {
                        val cond = evaluateExpression(stmt.condition, forEnv)
                        if (!isTruthy(cond)) break
                    }
                    try {
                        executeStatement(stmt.body, forEnv)
                    } catch (b: BreakSignal) {
                        break
                    } catch (c: ContinueSignal) {
                        // proceed to update
                    }
                    if (stmt.update != null) {
                        evaluateExpression(stmt.update, forEnv)
                    }
                }
            }
            is WhileStmt -> {
                while (true) {
                    checkStepLimit(stmt.line)
                    val cond = evaluateExpression(stmt.condition, env)
                    if (!isTruthy(cond)) break
                    try {
                        executeStatement(stmt.body, env)
                    } catch (b: BreakSignal) {
                        break
                    } catch (c: ContinueSignal) {
                        continue
                    }
                }
            }
            is DoWhileStmt -> {
                do {
                    checkStepLimit(stmt.line)
                    try {
                        executeStatement(stmt.body, env)
                    } catch (b: BreakSignal) {
                        break
                    } catch (c: ContinueSignal) {
                        // proceed to condition
                    }
                    val cond = evaluateExpression(stmt.condition, env)
                    if (!isTruthy(cond)) break
                } while (true)
            }
            is BreakStmt -> throw BreakSignal()
            is ContinueStmt -> throw ContinueSignal()
            is ReturnStmt -> {
                val retVal = if (stmt.value != null) evaluateExpression(stmt.value, env) else null
                throw ReturnSignal(retVal)
            }
            is BlockStmt -> executeBlock(stmt, env)
            is FunctionDef -> {
                // Nested or declaration
            }
        }
    }

    private suspend fun executeVarDecl(stmt: VarDeclStmt, env: Environment) {
        val type = stmt.type
        val name = stmt.name
        simulatedMemory += when (type) {
            "int", "float" -> 4
            "double" -> 8
            "char" -> 1
            else -> 4
        }

        if (stmt.arraySize != null || stmt.initExpr is ArrayLiteralExpr) {
            val initArray = if (stmt.initExpr != null) {
                @Suppress("UNCHECKED_CAST")
                evaluateExpression(stmt.initExpr, env) as? Array<Any?>
            } else null
            val declaredSize = stmt.arraySize?.let { (evaluateExpression(it, env) as? Number)?.toInt() }
            val size = declaredSize ?: initArray?.size ?: 10
            simulatedMemory += size * 4
            val arr = Array<Any?>(size) { idx ->
                if (initArray != null && idx < initArray.size) initArray[idx] else 0L
            }
            env.define(name, arr)
        } else if (stmt.initExpr != null) {
            val initVal = evaluateExpression(stmt.initExpr, env)
            env.define(name, castToType(initVal, type))
        } else {
            val defaultVal = when (type) {
                "int" -> 0L
                "float", "double" -> 0.0
                "char" -> '\u0000'
                else -> 0L
            }
            env.define(name, defaultVal)
        }
    }

    private suspend fun evaluateExpression(expr: Expr, env: Environment): Any? {
        return when (expr) {
            is LiteralExpr -> expr.value
            is ArrayLiteralExpr -> {
                val list = expr.elements.map { evaluateExpression(it, env) }
                list.toTypedArray()
            }
            is VariableExpr -> {
                val varName = expr.name
                if (env.contains(varName)) {
                    env.get(varName)
                } else {
                    throw CRuntimeException("চলক (Variable) '$varName' ডিক্লেয়ার করা হয়নি।", expr.line)
                }
            }
            is ArrayAccessExpr -> {
                val arr = env.get(expr.arrayName) as? Array<Any?>
                    ?: throw CRuntimeException("অ্যারে '${expr.arrayName}' খুঁজে পাওয়া যায়নি।", expr.line)
                val idx = (evaluateExpression(expr.index, env) as? Number)?.toInt()
                    ?: throw CRuntimeException("অ্যারে ইনডেক্স সঠিক নয়।", expr.line)
                if (idx < 0 || idx >= arr.size) {
                    throw CRuntimeException("অ্যারে সূচক সীমার বাইরে (Index $idx, Size ${arr.size})।", expr.line)
                }
                arr[idx]
            }
            is BinaryExpr -> evaluateBinary(expr, env)
            is UnaryExpr -> evaluateUnary(expr, env)
            is AssignExpr -> evaluateAssign(expr, env)
            is CallExpr -> evaluateCall(expr, env)
            is TernaryExpr -> {
                val cond = evaluateExpression(expr.condition, env)
                if (isTruthy(cond)) evaluateExpression(expr.trueExpr, env)
                else evaluateExpression(expr.falseExpr, env)
            }
        }
    }

    private suspend fun evaluateBinary(expr: BinaryExpr, env: Environment): Any? {
        val left = evaluateExpression(expr.left, env)
        val right = evaluateExpression(expr.right, env)

        val isFloatOp = (left is Double || left is Float || right is Double || right is Float)

        return when (expr.op) {
            TokenType.PLUS -> {
                if (left is String || right is String) {
                    "$left$right"
                } else if (isFloatOp) {
                    asDouble(left) + asDouble(right)
                } else {
                    asLong(left) + asLong(right)
                }
            }
            TokenType.MINUS -> {
                if (isFloatOp) asDouble(left) - asDouble(right)
                else asLong(left) - asLong(right)
            }
            TokenType.STAR -> {
                if (isFloatOp) asDouble(left) * asDouble(right)
                else asLong(left) * asLong(right)
            }
            TokenType.SLASH -> {
                val rDouble = asDouble(right)
                if (rDouble == 0.0) {
                    throw CRuntimeException("শূন্য (০) দিয়ে ভাগ করা সম্ভব নয় (Division by zero)।", expr.line)
                }
                if (isFloatOp) asDouble(left) / rDouble
                else asLong(left) / asLong(right)
            }
            TokenType.PERCENT -> {
                val rLong = asLong(right)
                if (rLong == 0L) {
                    throw CRuntimeException("শূন্য (০) দিয়ে মডুলাস বা ভাগশেষ নির্ণয় করা সম্ভব নয়।", expr.line)
                }
                asLong(left) % rLong
            }
            TokenType.EQUAL_EQUAL -> if (isFloatOp) if (asDouble(left) == asDouble(right)) 1L else 0L else if (asLong(left) == asLong(right)) 1L else 0L
            TokenType.NOT_EQUAL -> if (isFloatOp) if (asDouble(left) != asDouble(right)) 1L else 0L else if (asLong(left) != asLong(right)) 1L else 0L
            TokenType.LESS -> if (isFloatOp) if (asDouble(left) < asDouble(right)) 1L else 0L else if (asLong(left) < asLong(right)) 1L else 0L
            TokenType.LESS_EQUAL -> if (isFloatOp) if (asDouble(left) <= asDouble(right)) 1L else 0L else if (asLong(left) <= asLong(right)) 1L else 0L
            TokenType.GREATER -> if (isFloatOp) if (asDouble(left) > asDouble(right)) 1L else 0L else if (asLong(left) > asLong(right)) 1L else 0L
            TokenType.GREATER_EQUAL -> if (isFloatOp) if (asDouble(left) >= asDouble(right)) 1L else 0L else if (asLong(left) >= asLong(right)) 1L else 0L
            TokenType.AMP_AMP -> if (isTruthy(left) && isTruthy(right)) 1L else 0L
            TokenType.PIPE_PIPE -> if (isTruthy(left) || isTruthy(right)) 1L else 0L
            TokenType.AMP -> asLong(left) and asLong(right)
            TokenType.PIPE -> asLong(left) or asLong(right)
            TokenType.CARET -> asLong(left) xor asLong(right)
            else -> 0L
        }
    }

    private suspend fun evaluateUnary(expr: UnaryExpr, env: Environment): Any? {
        when (expr.op) {
            TokenType.BANG -> {
                val v = evaluateExpression(expr.right, env)
                return if (isTruthy(v)) 0L else 1L
            }
            TokenType.MINUS -> {
                val v = evaluateExpression(expr.right, env)
                return if (v is Double || v is Float) -asDouble(v) else -asLong(v)
            }
            TokenType.PLUS_PLUS -> {
                return handleIncDec(expr.right, env, delta = 1, isPrefix = expr.isPrefix, line = expr.line)
            }
            TokenType.MINUS_MINUS -> {
                return handleIncDec(expr.right, env, delta = -1, isPrefix = expr.isPrefix, line = expr.line)
            }
            TokenType.AMP -> {
                return 1000L + (expr.right.hashCode() and 0xFFF)
            }
            TokenType.STAR -> {
                return evaluateExpression(expr.right, env)
            }
            else -> return evaluateExpression(expr.right, env)
        }
    }

    private suspend fun handleIncDec(target: Expr, env: Environment, delta: Long, isPrefix: Boolean, line: Int): Any? {
        when (target) {
            is VariableExpr -> {
                val name = target.name
                val curVal = env.get(name) ?: 0L
                val newVal = asLong(curVal) + delta
                env.set(name, newVal)
                return if (isPrefix) newVal else curVal
            }
            is ArrayAccessExpr -> {
                val arr = env.get(target.arrayName) as? Array<Any?>
                    ?: throw CRuntimeException("অ্যারে খুঁজে পাওয়া যায়নি।", line)
                val idx = (evaluateExpression(target.index, env) as? Number)?.toInt() ?: 0
                val curVal = arr[idx] ?: 0L
                val newVal = asLong(curVal) + delta
                arr[idx] = newVal
                return if (isPrefix) newVal else curVal
            }
            else -> throw CRuntimeException("ইনক্রিমেন্ট/ডিক্রিমেন্ট অপারেটর শুধুমাত্র চলকের উপর প্রয়োগ করা যায়।", line)
        }
    }

    private suspend fun evaluateAssign(expr: AssignExpr, env: Environment): Any? {
        val rhs = evaluateExpression(expr.value, env)
        when (val target = expr.target) {
            is VariableExpr -> {
                val name = target.name
                val curVal = env.get(name) ?: 0L
                val finalVal = when (expr.op) {
                    TokenType.ASSIGN -> rhs
                    TokenType.PLUS_ASSIGN -> if (curVal is Double || rhs is Double) asDouble(curVal) + asDouble(rhs) else asLong(curVal) + asLong(rhs)
                    TokenType.MINUS_ASSIGN -> if (curVal is Double || rhs is Double) asDouble(curVal) - asDouble(rhs) else asLong(curVal) - asLong(rhs)
                    TokenType.STAR_ASSIGN -> if (curVal is Double || rhs is Double) asDouble(curVal) * asDouble(rhs) else asLong(curVal) * asLong(rhs)
                    TokenType.SLASH_ASSIGN -> {
                        val dRhs = asDouble(rhs)
                        if (dRhs == 0.0) throw CRuntimeException("শূন্য দিয়ে ভাগ করা অবৈধ।", expr.line)
                        if (curVal is Double || rhs is Double) asDouble(curVal) / dRhs else asLong(curVal) / asLong(rhs)
                    }
                    TokenType.PERCENT_ASSIGN -> asLong(curVal) % asLong(rhs)
                    else -> rhs
                }
                env.set(name, finalVal)
                return finalVal
            }
            is ArrayAccessExpr -> {
                val arr = env.get(target.arrayName) as? Array<Any?>
                    ?: throw CRuntimeException("অ্যারে '${target.arrayName}' খুঁজে পাওয়া যায়নি।", expr.line)
                val idx = (evaluateExpression(target.index, env) as? Number)?.toInt() ?: 0
                arr[idx] = rhs
                return rhs
            }
            else -> throw CRuntimeException("অ্যাসাইনমেন্টের বামপাশে সঠিক চলক প্রত্যাশিত।", expr.line)
        }
    }

    private suspend fun evaluateCall(expr: CallExpr, env: Environment): Any? {
        val funcName = expr.callee
        val args = mutableListOf<Any?>()
        for (arg in expr.arguments) {
            args.add(evaluateExpression(arg, env))
        }

        // Standard I/O & Math functions
        when (funcName) {
            "printf" -> {
                handlePrintf(args)
                return 0L
            }
            "scanf" -> {
                handleScanf(expr.arguments, env)
                return 1L
            }
            "sqrt" -> return sqrt(asDouble(args.getOrNull(0) ?: 0.0))
            "pow" -> return asDouble(args.getOrNull(0) ?: 0.0).pow(asDouble(args.getOrNull(1) ?: 1.0))
            "abs" -> return abs(asLong(args.getOrNull(0) ?: 0L))
            "fabs" -> return abs(asDouble(args.getOrNull(0) ?: 0.0))
            "floor" -> return floor(asDouble(args.getOrNull(0) ?: 0.0))
            "ceil" -> return ceil(asDouble(args.getOrNull(0) ?: 0.0))
            "sin" -> return sin(asDouble(args.getOrNull(0) ?: 0.0))
            "cos" -> return cos(asDouble(args.getOrNull(0) ?: 0.0))
            "strlen" -> return (args.getOrNull(0)?.toString() ?: "").length.toLong()
            "rand" -> return (0..32767).random().toLong()
            "exit" -> throw ReturnSignal(0L)
        }

        // User-defined functions
        val func = program.functions[funcName]
            ?: throw CRuntimeException("ফাংশন '$funcName()' ডিক্লেয়ার করা হয়নি।", expr.line)

        return executeFunction(func, args)
    }

    private suspend fun handlePrintf(args: List<Any?>) {
        if (args.isEmpty()) return
        val formatStr = args[0]?.toString() ?: ""
        val chunk = StringBuilder()
        var argIdx = 1
        var i = 0

        while (i < formatStr.length) {
            if (formatStr[i] == '%' && i + 1 < formatStr.length) {
                i++
                var precision = -1
                if (formatStr[i] == '.') {
                    i++
                    var precStr = ""
                    while (i < formatStr.length && formatStr[i].isDigit()) {
                        precStr += formatStr[i]
                        i++
                    }
                    precision = precStr.toIntOrNull() ?: 2
                }

                when (val spec = formatStr[i]) {
                    'd', 'i' -> {
                        val v = if (argIdx < args.size) asLong(args[argIdx++]) else 0L
                        chunk.append(v)
                    }
                    'f', 'g' -> {
                        val v = if (argIdx < args.size) asDouble(args[argIdx++]) else 0.0
                        if (precision >= 0) {
                            chunk.append(String.format("%.${precision}f", v))
                        } else {
                            chunk.append(String.format("%.6f", v))
                        }
                    }
                    'c' -> {
                        val v = if (argIdx < args.size) args[argIdx++] else ' '
                        if (v is Number) chunk.append(v.toLong().toInt().toChar())
                        else chunk.append(v.toString().firstOrNull() ?: ' ')
                    }
                    's' -> {
                        val v = if (argIdx < args.size) args[argIdx++] else ""
                        chunk.append(v.toString())
                    }
                    '%' -> chunk.append('%')
                    else -> chunk.append("%$spec")
                }
            } else {
                chunk.append(formatStr[i])
            }
            i++
        }

        val text = chunk.toString()
        outputBuffer.append(text)
        onOutput?.invoke(text)
    }

    private suspend fun nextInputToken(): String {
        while (pendingInputTokens.isEmpty()) {
            if (onInputRequest != null) {
                val line = onInputRequest.invoke()
                val tokens = line.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                pendingInputTokens.addAll(tokens)
            } else if (stdinScanner.hasNext()) {
                pendingInputTokens.add(stdinScanner.next())
            } else {
                return "0"
            }
        }
        return pendingInputTokens.removeFirst()
    }

    private suspend fun handleScanf(argExprs: List<Expr>, env: Environment) {
        if (argExprs.isEmpty()) return
        val format = (evaluateExpression(argExprs[0], env) as? String) ?: ""
        val targets = argExprs.drop(1)

        val specifiers = mutableListOf<String>()
        val regex = Regex("%([0-9]*\\.?[0-9]*)?([dfcis])")
        for (match in regex.findAll(format)) {
            specifiers.add(match.groupValues[2])
        }

        for (idx in targets.indices) {
            val targetExpr = targets[idx]
            val spec = specifiers.getOrNull(idx) ?: "d"

            val actualTarget = when (targetExpr) {
                is UnaryExpr -> if (targetExpr.op == TokenType.AMP) targetExpr.right else targetExpr
                else -> targetExpr
            }

            val rawToken = nextInputToken()
            val inputVal: Any? = when (spec) {
                "d", "i" -> rawToken.toLongOrNull() ?: 0L
                "f" -> rawToken.toDoubleOrNull() ?: 0.0
                "c" -> rawToken.firstOrNull() ?: ' '
                "s" -> rawToken
                else -> rawToken.toLongOrNull() ?: 0L
            }

            when (actualTarget) {
                is VariableExpr -> {
                    env.set(actualTarget.name, inputVal)
                }
                is ArrayAccessExpr -> {
                    val arr = env.get(actualTarget.arrayName) as? Array<Any?>
                    val i = (evaluateExpression(actualTarget.index, env) as? Number)?.toInt() ?: 0
                    if (arr != null && i >= 0 && i < arr.size) {
                        arr[i] = inputVal
                    }
                }
                else -> {}
            }
        }
    }

    private fun checkStepLimit(line: Int) {
        stepCount++
        if (stepCount > maxSteps) {
            throw CRuntimeException("সীমাহীন লুপ (Infinite loop) শনাক্ত হয়েছে! লুপের শর্ত ও পরিবর্তন যাচাই করুন।", line)
        }
    }

    private fun isTruthy(v: Any?): Boolean {
        return when (v) {
            null -> false
            is Boolean -> v
            is Number -> v.toDouble() != 0.0
            is Char -> v != '\u0000'
            is String -> v.isNotEmpty()
            else -> true
        }
    }

    private fun asLong(v: Any?): Long {
        return when (v) {
            is Number -> v.toLong()
            is Char -> v.code.toLong()
            is Boolean -> if (v) 1L else 0L
            is String -> v.toLongOrNull() ?: 0L
            else -> 0L
        }
    }

    private fun asDouble(v: Any?): Double {
        return when (v) {
            is Number -> v.toDouble()
            is Char -> v.code.toDouble()
            is Boolean -> if (v) 1.0 else 0.0
            is String -> v.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }

    private fun castToType(value: Any?, type: String): Any? {
        return when (type) {
            "int" -> asLong(value)
            "float", "double" -> asDouble(value)
            "char" -> when (value) {
                is Char -> value
                is Number -> value.toLong().toInt().toChar()
                else -> ' '
            }
            else -> value
        }
    }
}
