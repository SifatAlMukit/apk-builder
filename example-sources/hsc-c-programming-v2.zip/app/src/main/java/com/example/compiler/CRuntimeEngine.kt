package com.example.compiler

import kotlinx.coroutines.runBlocking

object CRuntimeEngine {

    fun hasScanf(code: String): Boolean {
        return code.contains(Regex("""\bscanf\s*\("""))
    }

    fun compileAndExecute(sourceCode: String, stdinInput: String = ""): ExecutionResult {
        return runBlocking {
            compileAndExecuteInteractive(sourceCode, stdinInput = stdinInput)
        }
    }

    suspend fun compileAndExecuteInteractive(
        sourceCode: String,
        stdinInput: String = "",
        onOutput: (suspend (String) -> Unit)? = null,
        onInputRequest: (suspend () -> String)? = null
    ): ExecutionResult {
        return try {
            val lexer = CLexer(sourceCode)
            val tokens = lexer.scanTokens()
            val parser = CParser(tokens)
            val program = parser.parse()
            val interpreter = CInterpreter(
                program = program,
                stdin = stdinInput,
                onOutput = onOutput,
                onInputRequest = onInputRequest
            )
            interpreter.run()
        } catch (e: CParseException) {
            val errorMsg = "কম্পাইল ত্রুটি:\n${e.message}"
            onOutput?.invoke("\n$errorMsg\n")
            ExecutionResult(
                output = "",
                exitCode = 1,
                error = errorMsg,
                isSuccess = false
            )
        } catch (e: Exception) {
            val errorMsg = "ত্রুটি: ${e.localizedMessage ?: "কোড এক্সিকিউশনে সমস্যা হয়েছে।"}"
            onOutput?.invoke("\n$errorMsg\n")
            ExecutionResult(
                output = "",
                exitCode = 1,
                error = errorMsg,
                isSuccess = false
            )
        }
    }
}
