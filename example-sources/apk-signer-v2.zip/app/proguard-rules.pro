# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# General preservation for annotations and signatures
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod
-keepattributes SourceFile,LineNumberTable

# 1. Bouncy Castle Cryptography Library
-dontwarn org.bouncycastle.**
-dontnote org.bouncycastle.**
-keep class org.bouncycastle.** { *; }

# 2. Custom JKS Provider and KeyStore SPI
-keep class com.example.crypto.jks.** { *; }
-keepclassmembers class com.example.crypto.jks.JksKeyStoreSpi {
    public <init>();
    *;
}
-keepclassmembers class * extends java.security.Provider {
    public <init>(...);
}
-keepclassmembers class * extends java.security.KeyStoreSpi {
    public <init>();
    *;
}

# 3. Android APK Signer & Verifier (apksig)
-dontwarn com.android.apksig.**
-keep class com.android.apksig.** { *; }

# 4. App Data Models, Converters, and Crypto Engines
-keep class com.example.data.model.** { *; }
-keep class com.example.data.db.** { *; }
-keepclassmembers class com.example.data.db.** { *; }
-keep class com.example.crypto.** { *; }

# 5. Moshi & Networking
-dontwarn com.squareup.moshi.**
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**

