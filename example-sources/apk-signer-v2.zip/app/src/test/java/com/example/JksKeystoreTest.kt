package com.example

import com.example.crypto.KeystoreManager
import com.example.crypto.converter.*
import com.example.crypto.jks.JksKeyStoreSpi
import com.example.crypto.jks.JksProvider
import com.example.data.model.KeystoreConfig
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File
import java.security.KeyStore
import java.security.PrivateKey

@RunWith(RobolectricTestRunner::class)
class JksKeystoreTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private val testPassword = "jksSecretPassword123!"
    private val testAlias = "myreleasekey"

    @Before
    fun setUp() {
        JksProvider.register()
    }

    @Test
    fun testJksProviderRegistered() {
        val ks = KeyStore.getInstance("JKS")
        assertNotNull(ks)
    }

    @Test
    fun testGenerateAndLoadJksKeystore() {
        val jksFile = tempFolder.newFile("test_release.jks")
        val config = KeystoreConfig(
            name = "My Release Key",
            fileName = "test_release.jks",
            alias = testAlias,
            storePassword = testPassword,
            keyPassword = testPassword,
            storeType = "JKS",
            keyAlgorithm = "RSA",
            keySize = 2048,
            validityYears = 25,
            commonName = "Release Unit",
            organization = "AI Studio Android"
        )

        // Generate JKS keystore
        val certInfo = KeystoreManager.generateKeystore(config, jksFile)
        assertNotNull(certInfo)
        assertEquals(testAlias, certInfo.alias)
        assertTrue(jksFile.exists())
        assertTrue(jksFile.length() > 0)

        // Inspect format with FormatDetector
        val inspection = FormatDetector.detectAndInspect(jksFile, testPassword)
        assertEquals(KeystoreFormat.JKS, inspection.detectedFormat)
        assertTrue(inspection.isPasswordVerified)
        assertEquals(1, inspection.aliases.size)
        assertEquals(testAlias, inspection.aliases.first().alias)
        assertTrue(inspection.hasPrivateKey)

        // Load JKS keystore via KeystoreManager
        val (loadedKs, loadedType) = KeystoreManager.loadKeyStore(jksFile, testPassword)
        assertEquals("JKS", loadedType)
        val aliases = KeystoreManager.getAliases(loadedKs)
        assertTrue(aliases.contains(testAlias))

        val key = loadedKs.getKey(testAlias, testPassword.toCharArray())
        assertNotNull("Private key must be recoverable from JKS", key)
        assertTrue(key is PrivateKey)

        val cert = loadedKs.getCertificate(testAlias)
        assertNotNull("Certificate must exist for alias", cert)
    }

    @Test
    fun testConvertPkcs12ToJksAndBack() {
        val p12File = tempFolder.newFile("source.p12")
        val p12Config = KeystoreConfig(
            name = "Source P12",
            fileName = "source.p12",
            alias = "p12key",
            storePassword = testPassword,
            keyPassword = testPassword,
            storeType = "PKCS12",
            keyAlgorithm = "RSA",
            keySize = 2048,
            validityYears = 25
        )
        KeystoreManager.generateKeystore(p12Config, p12File)

        // Convert PKCS12 -> JKS
        val inspectionP12 = FormatDetector.detectAndInspect(p12File, testPassword)
        val jksOutDir = tempFolder.newFolder("jks_out")
        val convertToJksResult = KeystoreConverterEngine.convert(
            sourceFile = p12File,
            sourceInspection = inspectionP12,
            sourcePassword = testPassword,
            options = ConversionOptions(
                targetFormat = KeystoreFormat.JKS,
                targetStorePassword = "convertedJksPass456!",
                useSamePassword = true
            ),
            outputDirectory = jksOutDir
        )

        assertTrue(convertToJksResult.errorMessage ?: "", convertToJksResult.success)
        assertTrue(convertToJksResult.verificationPassed)
        val jksFile = convertToJksResult.outputFile
        assertTrue(jksFile.exists())
        assertTrue(jksFile.length() > 0)

        // Convert JKS -> PKCS12
        val inspectionJks = FormatDetector.detectAndInspect(jksFile, "convertedJksPass456!")
        val p12OutDir = tempFolder.newFolder("p12_out")
        val convertBackResult = KeystoreConverterEngine.convert(
            sourceFile = jksFile,
            sourceInspection = inspectionJks,
            sourcePassword = "convertedJksPass456!",
            options = ConversionOptions(
                targetFormat = KeystoreFormat.PKCS12,
                targetStorePassword = "finalP12Pass789!",
                useSamePassword = true
            ),
            outputDirectory = p12OutDir
        )

        assertTrue(convertBackResult.errorMessage ?: "", convertBackResult.success)
        assertTrue(convertBackResult.verificationPassed)
        assertTrue(convertBackResult.outputFile.exists())
    }

    @Test
    fun testLoadStandardOracleJks() {
        val oracleJks = File("/tmp/real_oracle.jks")
        if (oracleJks.exists()) {
            val (ks, type) = KeystoreManager.loadKeyStore(oracleJks, "password123")
            assertEquals("JKS", type)
            val aliases = KeystoreManager.getAliases(ks)
            assertTrue(aliases.contains("testkey"))
            val key = ks.getKey("testkey", "password123".toCharArray())
            assertNotNull(key)
        }
    }
}

