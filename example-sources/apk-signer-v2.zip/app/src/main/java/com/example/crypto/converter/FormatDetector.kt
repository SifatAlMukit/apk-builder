package com.example.crypto.converter

import com.example.crypto.KeystoreManager
import com.example.crypto.jks.JksProvider
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.openssl.PEMEncryptedKeyPair
import org.bouncycastle.openssl.PEMKeyPair
import org.bouncycastle.openssl.PEMParser
import org.bouncycastle.openssl.bc.BcPEMDecryptorProvider
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter
import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo
import org.bouncycastle.pkcs.jcajce.JcePKCSPBEInputDecryptorProviderBuilder
import java.io.*
import java.security.KeyStore
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAKey

object FormatDetector {

    /**
     * Inspects a file and detects its cryptographic format.
     * If [password] is provided, attempts to unlock and parse aliases/keys.
     */
    fun detectAndInspect(file: File, password: String? = null): SourceInspection {
        JksProvider.register()
        if (!file.exists() || file.length() == 0L) {
            return SourceInspection(
                detectedFormat = null,
                formatConfidence = SourceInspection.Confidence.UNKNOWN,
                detectionNote = "File is empty or does not exist",
                requiresPassword = false,
                isPasswordVerified = false,
                fileSize = file.length(),
                fileName = file.name
            )
        }

        val headerBytes = ByteArray(minOf(file.length().toInt(), 4096))
        try {
            FileInputStream(file).use { it.read(headerBytes) }
        } catch (e: Exception) {
            return SourceInspection(
                detectedFormat = null,
                formatConfidence = SourceInspection.Confidence.UNKNOWN,
                detectionNote = "Cannot read file: ${e.message}",
                requiresPassword = false,
                isPasswordVerified = false,
                fileSize = file.length(),
                fileName = file.name
            )
        }

        // Check for ASCII / PEM armor
        val isPemText = isLikelyPem(headerBytes)
        if (isPemText) {
            return inspectPemFile(file, password)
        }

        // Check for Binary formats
        // 1. JKS Magic: 0xFEEDFEED
        val isJksMagic = headerBytes.size >= 4 &&
                (headerBytes[0].toInt() and 0xFF == 0xFE) &&
                (headerBytes[1].toInt() and 0xFF == 0xED) &&
                (headerBytes[2].toInt() and 0xFF == 0xFE) &&
                (headerBytes[3].toInt() and 0xFF == 0xED)

        // 2. Try DER Certificate parsing
        val derCert = tryParseDerCertificate(file)
        if (derCert != null) {
            val certInfo = KeystoreManager.extractCertificateInfo(derCert, "certificate")
            val aliasInspection = AliasInspection(
                alias = "certificate",
                isKeyEntry = false,
                isCertEntry = true,
                keyAlgorithm = certInfo.keyAlgorithm,
                keySize = certInfo.keySize,
                certificateChainLength = 1,
                subjectDn = certInfo.subjectDn,
                issuerDn = certInfo.issuerDn,
                sha256Fingerprint = certInfo.sha256Fingerprint,
                sha1Fingerprint = certInfo.sha1Fingerprint,
                validFrom = certInfo.validFrom,
                validUntil = certInfo.validUntil,
                isExpired = certInfo.isExpired
            )

            return SourceInspection(
                detectedFormat = KeystoreFormat.DER_CERT,
                formatConfidence = SourceInspection.Confidence.HIGH,
                detectionNote = "Identified binary X.509 DER Certificate (${certInfo.keyAlgorithm} ${certInfo.keySize}-bit)",
                requiresPassword = false,
                isPasswordVerified = true,
                fileSize = file.length(),
                fileName = file.name,
                aliases = listOf(aliasInspection),
                defaultAlias = "certificate",
                hasPrivateKey = false,
                hasCertificates = true
            )
        }

        // 3. Binary KeyStore probing (PKCS12, JKS, BKS)
        val candidateOrder = when {
            isJksMagic -> listOf("JKS", "PKCS12", "BKS")
            file.name.endsWith(".jks", ignoreCase = true) -> listOf("JKS", "PKCS12", "BKS")
            file.name.endsWith(".bks", ignoreCase = true) -> listOf("BKS", "PKCS12", "JKS")
            else -> listOf("PKCS12", "JKS", "BKS")
        }

        // If password is provided, attempt to load
        if (!password.isNullOrEmpty()) {
            for (type in candidateOrder) {
                try {
                    val ks = KeystoreManager.getKeyStoreInstance(type)
                    file.inputStream().use { fis ->
                        ks.load(fis, password.toCharArray())
                    }
                    // Loaded successfully!
                    val detectedFormat = when (type.uppercase()) {
                        "PKCS12" -> KeystoreFormat.PKCS12
                        "JKS" -> KeystoreFormat.JKS
                        "BKS" -> KeystoreFormat.BKS
                        else -> KeystoreFormat.PKCS12
                    }
                    val aliases = extractAliasesInspection(ks, password)
                    val hasKey = aliases.any { it.isKeyEntry }
                    val hasCert = aliases.any { it.isCertEntry || it.certificateChainLength > 0 }

                    return SourceInspection(
                        detectedFormat = detectedFormat,
                        formatConfidence = SourceInspection.Confidence.HIGH,
                        detectionNote = "Successfully unlocked $type KeyStore with ${aliases.size} alias(es)",
                        requiresPassword = true,
                        isPasswordVerified = true,
                        fileSize = file.length(),
                        fileName = file.name,
                        aliases = aliases,
                        defaultAlias = aliases.firstOrNull()?.alias ?: "",
                        hasPrivateKey = hasKey,
                        hasCertificates = hasCert
                    )
                } catch (_: Exception) {
                    // Try next candidate
                }
            }
        }

        // Probing failed or no password provided yet
        val presumptiveFormat = when {
            isJksMagic -> KeystoreFormat.JKS
            file.name.endsWith(".jks", ignoreCase = true) -> KeystoreFormat.JKS
            file.name.endsWith(".bks", ignoreCase = true) -> KeystoreFormat.BKS
            file.name.endsWith(".p12", ignoreCase = true) || file.name.endsWith(".pfx", ignoreCase = true) -> KeystoreFormat.PKCS12
            else -> KeystoreFormat.PKCS12
        }

        val note = if (password.isNullOrEmpty()) {
            "Detected ${presumptiveFormat.displayName} container. Password required to read aliases."
        } else {
            "Incorrect password for ${presumptiveFormat.displayName} file. Please verify and try again."
        }

        return SourceInspection(
            detectedFormat = presumptiveFormat,
            formatConfidence = if (isJksMagic) SourceInspection.Confidence.HIGH else SourceInspection.Confidence.MEDIUM,
            detectionNote = note,
            requiresPassword = true,
            isPasswordVerified = false,
            fileSize = file.length(),
            fileName = file.name
        )
    }

    private fun isLikelyPem(bytes: ByteArray): Boolean {
        val str = try {
            String(bytes.take(256).toByteArray(), Charsets.US_ASCII)
        } catch (_: Exception) {
            return false
        }
        return str.contains("-----BEGIN ")
    }

    private fun tryParseDerCertificate(file: File): X509Certificate? {
        return try {
            val certFactory = CertificateFactory.getInstance("X.509")
            file.inputStream().use { fis ->
                certFactory.generateCertificate(fis) as? X509Certificate
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun inspectPemFile(file: File, password: String?): SourceInspection {
        val content = try {
            file.readText(Charsets.UTF_8)
        } catch (_: Exception) {
            file.readText(Charsets.ISO_8859_1)
        }

        var hasCert = false
        var hasKey = false
        var isKeyEncrypted = false
        var certCount = 0

        val reader = StringReader(content)
        val pemParser = PEMParser(reader)
        var obj: Any?

        val certificates = mutableListOf<X509Certificate>()
        var parsedKey: Any? = null

        try {
            while (pemParser.readObject().also { obj = it } != null) {
                when (val item = obj) {
                    is X509CertificateHolder -> {
                        hasCert = true
                        certCount++
                        try {
                            val cert = JcaX509CertificateConverter().getCertificate(item)
                            certificates.add(cert)
                        } catch (_: Exception) {}
                    }
                    is PKCS8EncryptedPrivateKeyInfo -> {
                        hasKey = true
                        isKeyEncrypted = true
                        if (!password.isNullOrEmpty()) {
                            try {
                                val decryptor = JcePKCSPBEInputDecryptorProviderBuilder().build(password.toCharArray())
                                val pki = item.decryptPrivateKeyInfo(decryptor)
                                parsedKey = JcaPEMKeyConverter().getPrivateKey(pki)
                            } catch (_: Exception) {}
                        }
                    }
                    is PEMEncryptedKeyPair -> {
                        hasKey = true
                        isKeyEncrypted = true
                        if (!password.isNullOrEmpty()) {
                            try {
                                val decryptor = BcPEMDecryptorProvider(password.toCharArray())
                                val keyPair = item.decryptKeyPair(decryptor)
                                parsedKey = JcaPEMKeyConverter().getKeyPair(keyPair).private
                            } catch (_: Exception) {}
                        }
                    }
                    is PEMKeyPair -> {
                        hasKey = true
                        try {
                            parsedKey = JcaPEMKeyConverter().getKeyPair(item).private
                        } catch (_: Exception) {}
                    }
                    is PrivateKeyInfo -> {
                        hasKey = true
                        try {
                            parsedKey = JcaPEMKeyConverter().getPrivateKey(item)
                        } catch (_: Exception) {}
                    }
                }
            }
        } catch (_: Exception) {}

        val detectedFormat = when {
            hasKey && hasCert -> KeystoreFormat.PEM_FULL
            hasKey -> KeystoreFormat.PEM_KEY
            hasCert -> KeystoreFormat.PEM_CERT
            else -> KeystoreFormat.PEM_FULL
        }

        val requiresPass = isKeyEncrypted
        val isVerified = if (requiresPass) parsedKey != null else true

        val aliases = mutableListOf<AliasInspection>()
        if (certificates.isNotEmpty()) {
            val leaf = certificates.first()
            val certInfo = KeystoreManager.extractCertificateInfo(leaf, "cert")
            aliases.add(
                AliasInspection(
                    alias = if (hasKey) "key" else "certificate",
                    isKeyEntry = hasKey && isVerified,
                    isCertEntry = true,
                    keyAlgorithm = certInfo.keyAlgorithm,
                    keySize = certInfo.keySize,
                    certificateChainLength = certificates.size,
                    subjectDn = certInfo.subjectDn,
                    issuerDn = certInfo.issuerDn,
                    sha256Fingerprint = certInfo.sha256Fingerprint,
                    sha1Fingerprint = certInfo.sha1Fingerprint,
                    validFrom = certInfo.validFrom,
                    validUntil = certInfo.validUntil,
                    isExpired = certInfo.isExpired
                )
            )
        } else if (hasKey) {
            aliases.add(
                AliasInspection(
                    alias = "key",
                    isKeyEntry = true,
                    isCertEntry = false,
                    keyAlgorithm = if (parsedKey != null) (parsedKey as? java.security.Key)?.algorithm ?: "RSA" else "Unknown",
                    keySize = 2048,
                    certificateChainLength = 0,
                    subjectDn = "N/A (Key Only)",
                    issuerDn = "N/A",
                    sha256Fingerprint = "N/A",
                    sha1Fingerprint = "N/A",
                    validFrom = 0L,
                    validUntil = 0L,
                    isExpired = false
                )
            )
        }

        val note = when {
            requiresPass && !isVerified -> "Encrypted Private Key detected in PEM file. Password required to decrypt."
            hasKey && hasCert -> "Identified PEM Bundle with Private Key and $certCount Certificate(s)"
            hasCert -> "Identified PEM Public Certificate ($certCount chain certificate(s))"
            hasKey -> "Identified PEM Private Key"
            else -> "PEM armor detected"
        }

        return SourceInspection(
            detectedFormat = detectedFormat,
            formatConfidence = SourceInspection.Confidence.HIGH,
            detectionNote = note,
            requiresPassword = requiresPass,
            isPasswordVerified = isVerified,
            fileSize = file.length(),
            fileName = file.name,
            aliases = aliases,
            defaultAlias = aliases.firstOrNull()?.alias ?: "",
            hasPrivateKey = hasKey,
            hasCertificates = hasCert
        )
    }

    private fun extractAliasesInspection(ks: KeyStore, password: String): List<AliasInspection> {
        val list = mutableListOf<AliasInspection>()
        val aliasesEnum = ks.aliases()
        while (aliasesEnum.hasMoreElements()) {
            val alias = aliasesEnum.nextElement()
            val isKey = ks.isKeyEntry(alias)
            val isCert = ks.isCertificateEntry(alias)
            val chain = ks.getCertificateChain(alias)
            val cert = (ks.getCertificate(alias) as? X509Certificate)
                ?: (chain?.firstOrNull() as? X509Certificate)

            if (cert != null) {
                val certInfo = KeystoreManager.extractCertificateInfo(cert, alias)
                list.add(
                    AliasInspection(
                        alias = alias,
                        isKeyEntry = isKey,
                        isCertEntry = isCert,
                        keyAlgorithm = certInfo.keyAlgorithm,
                        keySize = certInfo.keySize,
                        certificateChainLength = chain?.size ?: 1,
                        subjectDn = certInfo.subjectDn,
                        issuerDn = certInfo.issuerDn,
                        sha256Fingerprint = certInfo.sha256Fingerprint,
                        sha1Fingerprint = certInfo.sha1Fingerprint,
                        validFrom = certInfo.validFrom,
                        validUntil = certInfo.validUntil,
                        isExpired = certInfo.isExpired
                    )
                )
            } else if (isKey) {
                list.add(
                    AliasInspection(
                        alias = alias,
                        isKeyEntry = true,
                        isCertEntry = false,
                        keyAlgorithm = "Unknown",
                        keySize = 0,
                        certificateChainLength = 0,
                        subjectDn = "N/A",
                        issuerDn = "N/A",
                        sha256Fingerprint = "N/A",
                        sha1Fingerprint = "N/A",
                        validFrom = 0L,
                        validUntil = 0L,
                        isExpired = false
                    )
                )
            }
        }
        return list
    }
}
