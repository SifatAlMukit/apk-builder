package com.example.crypto

import com.android.apksig.ApkSigner
import com.example.data.model.CertificateInfo
import com.example.data.model.SigningConfig
import com.example.data.model.SigningResult
import java.io.File
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate

object ApkSignerManager {

    /**
     * Signs an input APK using the provided KeyStore and alias configuration.
     * Reports step-by-step progress via [onProgress] callback.
     */
    fun signApk(
        inputApk: File,
        outputApk: File,
        keyStore: KeyStore,
        alias: String,
        keyPassword: String,
        config: SigningConfig,
        onProgress: (step: String, fraction: Float) -> Unit = { _, _ -> }
    ): SigningResult {
        onProgress("Validating input files and keystore...", 0.10f)

        if (!inputApk.exists() || inputApk.length() == 0L) {
            return SigningResult(
                success = false,
                errorMessage = "Input APK file does not exist or is empty."
            )
        }

        // 1. Extract Key and Certificate Chain
        onProgress("Retrieving signing key and certificate chain...", 0.25f)
        val privateKey = try {
            keyStore.getKey(alias, keyPassword.toCharArray()) as? PrivateKey
        } catch (e: Exception) {
            return SigningResult(
                success = false,
                errorMessage = "Invalid key password for alias '$alias': ${e.localizedMessage}"
            )
        }

        if (privateKey == null) {
            return SigningResult(
                success = false,
                errorMessage = "Alias '$alias' does not correspond to a valid private signing key."
            )
        }

        val certChain = try {
            keyStore.getCertificateChain(alias)?.mapNotNull { it as? X509Certificate }
                ?: listOf(
                    keyStore.getCertificate(alias) as? X509Certificate
                        ?: return SigningResult(
                            success = false,
                            errorMessage = "No certificate found for alias '$alias'."
                        )
                )
        } catch (e: Exception) {
            return SigningResult(
                success = false,
                errorMessage = "Failed to load certificate chain: ${e.localizedMessage}"
            )
        }

        if (certChain.isEmpty()) {
            return SigningResult(
                success = false,
                errorMessage = "Certificate chain is empty for alias '$alias'."
            )
        }

        // 2. Prepare output file and pre-align archive
        onProgress("Optimizing archive layout with 4-byte / 16KB ZipAlign...", 0.40f)
        outputApk.parentFile?.mkdirs()
        if (outputApk.exists()) {
            outputApk.delete()
        }

        val alignedTemp = File(outputApk.parentFile, "aligned_${System.currentTimeMillis()}_${inputApk.name}")
        val wasAligned = try {
            ZipAligner.align(inputApk, alignedTemp)
        } catch (_: Exception) {
            false
        }
        val actualInputApk = if (wasAligned && alignedTemp.exists() && alignedTemp.length() > 0) {
            alignedTemp
        } else {
            inputApk
        }

        // 3. Configure ApkSigner
        onProgress("Configuring cryptographic signer (v1/v2/v3/v4)...", 0.55f)
        try {
            val signerConfig = ApkSigner.SignerConfig.Builder(
                alias,
                privateKey,
                certChain
            ).build()

            val signerBuilder = ApkSigner.Builder(listOf(signerConfig))
                .setInputApk(actualInputApk)
                .setOutputApk(outputApk)
                .setV1SigningEnabled(config.v1SigningEnabled)
                .setV2SigningEnabled(config.v2SigningEnabled)
                .setV3SigningEnabled(config.v3SigningEnabled)
                .setV4SigningEnabled(config.v4SigningEnabled)
                .setOtherSignersSignaturesPreserved(false)

            onProgress("Computing digests and signing APK blocks...", 0.70f)
            val signer = signerBuilder.build()
            signer.sign()

            // 4. Verify the newly generated signed APK
            onProgress("Verifying generated signatures...", 0.88f)
            val verification = ApkVerifierManager.verifyApk(outputApk)

            val signerInfos = certChain.map {
                KeystoreManager.extractCertificateInfo(it, alias)
            }

            if (!verification.isVerified && verification.errors.isNotEmpty()) {
                val errSummary = verification.errors.joinToString("\n")
                return SigningResult(
                    success = false,
                    outputApkPath = outputApk.absolutePath,
                    outputApkName = outputApk.name,
                    outputApkSize = outputApk.length(),
                    errorMessage = "Signing produced an unverified APK:\n$errSummary",
                    v1Signed = verification.v1Verified,
                    v2Signed = verification.v2Verified,
                    v3Signed = verification.v3Verified,
                    v4Signed = verification.v4Verified,
                    signerCertificates = signerInfos
                )
            }

            onProgress("Signing completed successfully!", 1.0f)
            return SigningResult(
                success = true,
                outputApkPath = outputApk.absolutePath,
                outputApkName = outputApk.name,
                outputApkSize = outputApk.length(),
                v1Signed = verification.v1Verified,
                v2Signed = verification.v2Verified,
                v3Signed = verification.v3Verified,
                v4Signed = verification.v4Verified,
                signerCertificates = signerInfos
            )

        } catch (e: Exception) {
            if (outputApk.exists()) {
                outputApk.delete()
            }
            return SigningResult(
                success = false,
                errorMessage = "APK Signing failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
            )
        } finally {
            if (alignedTemp.exists()) {
                alignedTemp.delete()
            }
        }
    }
}
