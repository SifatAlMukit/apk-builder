package com.example.crypto.converter

import com.example.crypto.KeystoreManager
import com.example.crypto.jks.JksProvider
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.openssl.PEMEncryptedKeyPair
import org.bouncycastle.openssl.PEMKeyPair
import org.bouncycastle.openssl.PEMParser
import org.bouncycastle.openssl.bc.BcPEMDecryptorProvider
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter
import org.bouncycastle.openssl.jcajce.JcaPEMWriter
import org.bouncycastle.pkcs.PKCS8EncryptedPrivateKeyInfo
import org.bouncycastle.pkcs.jcajce.JcePKCSPBEInputDecryptorProviderBuilder
import java.io.*
import java.security.*
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.*

object KeystoreConverterEngine {

    /**
     * Converts a source keystore/certificate/key file into the requested destination format.
     */
    fun convert(
        sourceFile: File,
        sourceInspection: SourceInspection,
        sourcePassword: String,
        options: ConversionOptions,
        outputDirectory: File
    ): ConversionResult {
        JksProvider.register()
        val srcFormat = sourceInspection.detectedFormat
            ?: throw IllegalArgumentException("Cannot convert file with unidentified source format")

        outputDirectory.mkdirs()
        val baseName = sourceFile.nameWithoutExtension
        val outFileName = "${baseName}_converted.${options.targetFormat.defaultExtension}"
        val outputFile = File(outputDirectory, outFileName)
        if (outputFile.exists()) {
            outputFile.delete()
        }

        val warnings = mutableListOf<String>()
        val convertedAliases = mutableListOf<String>()

        try {
            when {
                // Case A: Source is a standard KeyStore container (PKCS12, JKS, BKS)
                srcFormat.category == KeystoreFormat.FormatCategory.KEYSTORE -> {
                    convertFromKeystore(
                        sourceFile = sourceFile,
                        sourceFormat = srcFormat,
                        sourcePassword = sourcePassword,
                        options = options,
                        outputFile = outputFile,
                        convertedAliases = convertedAliases,
                        warnings = warnings
                    )
                }

                // Case B: Source is a PEM file (Bundle, Certificate, or Key)
                srcFormat.category in listOf(
                    KeystoreFormat.FormatCategory.PEM,
                    KeystoreFormat.FormatCategory.CERTIFICATE,
                    KeystoreFormat.FormatCategory.PRIVATE_KEY
                ) && !srcFormat.isBinary -> {
                    convertFromPem(
                        sourceFile = sourceFile,
                        sourcePassword = sourcePassword,
                        options = options,
                        outputFile = outputFile,
                        convertedAliases = convertedAliases,
                        warnings = warnings
                    )
                }

                // Case C: Source is a binary DER certificate
                srcFormat == KeystoreFormat.DER_CERT -> {
                    convertFromDer(
                        sourceFile = sourceFile,
                        options = options,
                        outputFile = outputFile,
                        convertedAliases = convertedAliases,
                        warnings = warnings
                    )
                }

                else -> {
                    throw UnsupportedOperationException("Conversion from ${srcFormat.displayName} to ${options.targetFormat.displayName} is not supported")
                }
            }

            // Post-conversion verification
            val verification = verifyConvertedFile(
                file = outputFile,
                targetFormat = options.targetFormat,
                targetPassword = options.targetStorePassword,
                expectedAliases = convertedAliases
            )

            return ConversionResult(
                success = true,
                sourceFormat = srcFormat,
                targetFormat = options.targetFormat,
                outputFile = outputFile,
                outputFileName = outputFile.name,
                outputFileSize = outputFile.length(),
                convertedAliases = convertedAliases,
                warnings = warnings,
                verificationPassed = verification.passed,
                verificationDetails = verification.details,
                errorMessage = null
            )
        } catch (e: Exception) {
            if (outputFile.exists()) {
                outputFile.delete()
            }
            return ConversionResult(
                success = false,
                sourceFormat = srcFormat,
                targetFormat = options.targetFormat,
                outputFile = outputFile,
                outputFileName = outFileName,
                outputFileSize = 0L,
                convertedAliases = emptyList(),
                warnings = warnings,
                verificationPassed = false,
                verificationDetails = "Verification aborted due to conversion failure",
                errorMessage = e.message ?: e.javaClass.simpleName
            )
        }
    }

    private fun convertFromKeystore(
        sourceFile: File,
        sourceFormat: KeystoreFormat,
        sourcePassword: String,
        options: ConversionOptions,
        outputFile: File,
        convertedAliases: MutableList<String>,
        warnings: MutableList<String>
    ) {
        val (srcKs, _) = KeystoreManager.loadKeyStore(sourceFile, sourcePassword)
        val allAliases = srcKs.aliases().toList()

        val aliasesToProcess = if (!options.selectedAlias.isNullOrBlank()) {
            if (!allAliases.contains(options.selectedAlias)) {
                throw IllegalArgumentException("Selected alias '${options.selectedAlias}' not found in source keystore")
            }
            listOf(options.selectedAlias)
        } else {
            if (!options.targetFormat.supportsMultipleAliases && allAliases.size > 1) {
                warnings.add("Target format '${options.targetFormat.displayName}' only supports a single key/certificate. Only the primary alias '${allAliases.first()}' was exported.")
                listOf(allAliases.first())
            } else {
                allAliases
            }
        }

        when (options.targetFormat) {
            KeystoreFormat.PKCS12, KeystoreFormat.JKS, KeystoreFormat.BKS -> {
                val targetKsType = options.targetFormat.name
                val targetKs = KeystoreManager.getKeyStoreInstance(targetKsType)
                targetKs.load(null, null)

                val effectiveKeyPass = options.effectiveKeyPassword.toCharArray()
                val srcPassChars = sourcePassword.toCharArray()
                val srcKeyPassChars = if (!options.sourceKeyPassword.isNullOrBlank()) {
                    options.sourceKeyPassword.toCharArray()
                } else {
                    srcPassChars
                }

                for (alias in aliasesToProcess) {
                    val targetAlias = if (aliasesToProcess.size == 1 && options.targetAliasName.isNotBlank()) {
                        options.targetAliasName.trim()
                    } else {
                        alias
                    }

                    if (srcKs.isKeyEntry(alias)) {
                        // Recover key with explicit key password, then store password, then fallback
                        val key = try {
                            srcKs.getKey(alias, srcKeyPassChars)
                        } catch (_: Exception) {
                            try {
                                srcKs.getKey(alias, srcPassChars)
                            } catch (_: Exception) {
                                srcKs.getKey(alias, "".toCharArray())
                            }
                        } ?: throw GeneralSecurityException(
                            "Unable to recover private key for alias '$alias'. " +
                            "If the key has a distinct password from the keystore, please specify the Source Key Password."
                        )

                        val chain = srcKs.getCertificateChain(alias)
                            ?: throw GeneralSecurityException("No certificate chain found for alias '$alias'")

                        targetKs.setKeyEntry(targetAlias, key, effectiveKeyPass, chain)
                        convertedAliases.add(targetAlias)
                    } else if (srcKs.isCertificateEntry(alias)) {
                        val cert = srcKs.getCertificate(alias)
                        targetKs.setCertificateEntry(targetAlias, cert)
                        convertedAliases.add(targetAlias)
                    }
                }

                FileOutputStream(outputFile).use { fos ->
                    targetKs.store(fos, options.targetStorePassword.toCharArray())
                }
            }

            KeystoreFormat.PEM_FULL -> {
                val sw = StringWriter()
                JcaPEMWriter(sw).use { pemWriter ->
                    val srcPassChars = sourcePassword.toCharArray()
                    val srcKeyPassChars = if (!options.sourceKeyPassword.isNullOrBlank()) {
                        options.sourceKeyPassword.toCharArray()
                    } else {
                        srcPassChars
                    }
                    for (alias in aliasesToProcess) {
                        if (srcKs.isKeyEntry(alias)) {
                            val key = try {
                                srcKs.getKey(alias, srcKeyPassChars)
                            } catch (_: Exception) {
                                srcKs.getKey(alias, srcPassChars)
                            }
                            if (key != null) {
                                pemWriter.writeObject(key)
                            }
                            val chain = srcKs.getCertificateChain(alias)
                            chain?.forEach { cert ->
                                pemWriter.writeObject(cert)
                            }
                            convertedAliases.add(alias)
                        } else if (srcKs.isCertificateEntry(alias)) {
                            val cert = srcKs.getCertificate(alias)
                            if (cert != null) {
                                pemWriter.writeObject(cert)
                                convertedAliases.add(alias)
                            }
                        }
                    }
                }
                outputFile.writeText(sw.toString())
            }

            KeystoreFormat.PEM_CERT -> {
                warnings.add("Public Certificate format only: Private keys were stripped and not included in the output file.")
                val sw = StringWriter()
                JcaPEMWriter(sw).use { pemWriter ->
                    for (alias in aliasesToProcess) {
                        val chain = srcKs.getCertificateChain(alias)
                        if (chain != null && chain.isNotEmpty()) {
                            chain.forEach { pemWriter.writeObject(it) }
                            convertedAliases.add(alias)
                        } else {
                            val cert = srcKs.getCertificate(alias)
                            if (cert != null) {
                                pemWriter.writeObject(cert)
                                convertedAliases.add(alias)
                            }
                        }
                    }
                }
                outputFile.writeText(sw.toString())
            }

            KeystoreFormat.PEM_KEY -> {
                warnings.add("Private Key only: Certificate chain and public identity information were omitted.")
                val sw = StringWriter()
                JcaPEMWriter(sw).use { pemWriter ->
                    val srcPassChars = sourcePassword.toCharArray()
                    val srcKeyPassChars = if (!options.sourceKeyPassword.isNullOrBlank()) {
                        options.sourceKeyPassword.toCharArray()
                    } else {
                        srcPassChars
                    }
                    for (alias in aliasesToProcess) {
                        if (srcKs.isKeyEntry(alias)) {
                            val key = try {
                                srcKs.getKey(alias, srcKeyPassChars)
                            } catch (_: Exception) {
                                srcKs.getKey(alias, srcPassChars)
                            }
                            if (key != null) {
                                pemWriter.writeObject(key)
                                convertedAliases.add(alias)
                            }
                        }
                    }
                }
                if (convertedAliases.isEmpty()) {
                    throw IllegalStateException("No private key found in selected alias(es) to export as PEM Key")
                }
                outputFile.writeText(sw.toString())
            }

            KeystoreFormat.DER_CERT -> {
                warnings.add("Binary DER format supports only a single public certificate. Private key and intermediate chain certificates were omitted.")
                val primaryAlias = aliasesToProcess.first()
                val cert = srcKs.getCertificate(primaryAlias)
                    ?: throw IllegalStateException("No certificate found for alias '$primaryAlias'")
                outputFile.writeBytes(cert.encoded)
                convertedAliases.add(primaryAlias)
            }
        }
    }

    private fun convertFromPem(
        sourceFile: File,
        sourcePassword: String,
        options: ConversionOptions,
        outputFile: File,
        convertedAliases: MutableList<String>,
        warnings: MutableList<String>
    ) {
        val (privateKey, certificates) = parsePem(sourceFile, sourcePassword)

        if (privateKey == null && certificates.isEmpty()) {
            throw IllegalArgumentException("No usable cryptographic keys or certificates found in PEM file")
        }

        when (options.targetFormat) {
            KeystoreFormat.PKCS12, KeystoreFormat.JKS, KeystoreFormat.BKS -> {
                val targetKs = KeyStore.getInstance(options.targetFormat.name)
                targetKs.load(null, null)

                val targetAlias = options.targetAliasName.ifBlank { "key" }.trim()
                val effectiveKeyPass = options.effectiveKeyPassword.toCharArray()

                if (privateKey != null && certificates.isNotEmpty()) {
                    targetKs.setKeyEntry(
                        targetAlias,
                        privateKey,
                        effectiveKeyPass,
                        certificates.toTypedArray()
                    )
                    convertedAliases.add(targetAlias)
                } else if (certificates.isNotEmpty()) {
                    warnings.add("Imported as a Trusted Certificate entry: The source PEM did not contain a private key, so this keystore cannot sign APKs.")
                    targetKs.setCertificateEntry(targetAlias, certificates.first())
                    convertedAliases.add(targetAlias)
                } else {
                    throw IllegalArgumentException("Cannot create a keystore from a private key without a corresponding certificate")
                }

                FileOutputStream(outputFile).use { fos ->
                    targetKs.store(fos, options.targetStorePassword.toCharArray())
                }
            }

            KeystoreFormat.DER_CERT -> {
                if (certificates.isEmpty()) {
                    throw IllegalArgumentException("No certificate found in source PEM to export as binary DER")
                }
                warnings.add("Binary DER format contains public certificate only.")
                outputFile.writeBytes(certificates.first().encoded)
                convertedAliases.add("certificate")
            }

            KeystoreFormat.PEM_FULL, KeystoreFormat.PEM_CERT, KeystoreFormat.PEM_KEY -> {
                // Re-export / normalize PEM
                val sw = StringWriter()
                JcaPEMWriter(sw).use { pemWriter ->
                    if (options.targetFormat != KeystoreFormat.PEM_CERT && privateKey != null) {
                        pemWriter.writeObject(privateKey)
                    }
                    if (options.targetFormat != KeystoreFormat.PEM_KEY) {
                        certificates.forEach { pemWriter.writeObject(it) }
                    }
                }
                outputFile.writeText(sw.toString())
                convertedAliases.add("pem")
            }
        }
    }

    private fun convertFromDer(
        sourceFile: File,
        options: ConversionOptions,
        outputFile: File,
        convertedAliases: MutableList<String>,
        warnings: MutableList<String>
    ) {
        val certFactory = CertificateFactory.getInstance("X.509")
        val cert = sourceFile.inputStream().use {
            certFactory.generateCertificate(it) as? X509Certificate
        } ?: throw IllegalArgumentException("Failed to parse binary DER certificate")

        when (options.targetFormat) {
            KeystoreFormat.PKCS12, KeystoreFormat.JKS, KeystoreFormat.BKS -> {
                warnings.add("Imported as a Trusted Certificate entry: DER certificates contain only public keys, not private signing keys.")
                val targetKs = KeyStore.getInstance(options.targetFormat.name)
                targetKs.load(null, null)

                val targetAlias = options.targetAliasName.ifBlank { "cert" }.trim()
                targetKs.setCertificateEntry(targetAlias, cert)
                convertedAliases.add(targetAlias)

                FileOutputStream(outputFile).use { fos ->
                    targetKs.store(fos, options.targetStorePassword.toCharArray())
                }
            }

            KeystoreFormat.PEM_CERT, KeystoreFormat.PEM_FULL -> {
                val sw = StringWriter()
                JcaPEMWriter(sw).use { it.writeObject(cert) }
                outputFile.writeText(sw.toString())
                convertedAliases.add("certificate")
            }

            KeystoreFormat.DER_CERT -> {
                sourceFile.copyTo(outputFile, overwrite = true)
                convertedAliases.add("certificate")
            }

            KeystoreFormat.PEM_KEY -> {
                throw UnsupportedOperationException("Cannot extract a private key from a public DER certificate")
            }
        }
    }

    private fun parsePem(file: File, password: String): Pair<PrivateKey?, List<X509Certificate>> {
        val content = file.readText(Charsets.UTF_8)
        val pemParser = PEMParser(StringReader(content))
        var obj: Any?
        var key: PrivateKey? = null
        val certs = mutableListOf<X509Certificate>()

        while (pemParser.readObject().also { obj = it } != null) {
            when (val item = obj) {
                is X509CertificateHolder -> {
                    try {
                        certs.add(JcaX509CertificateConverter().getCertificate(item))
                    } catch (_: Exception) {}
                }
                is PKCS8EncryptedPrivateKeyInfo -> {
                    try {
                        val decryptor = JcePKCSPBEInputDecryptorProviderBuilder().build(password.toCharArray())
                        val pki = item.decryptPrivateKeyInfo(decryptor)
                        key = JcaPEMKeyConverter().getPrivateKey(pki)
                    } catch (_: Exception) {}
                }
                is PEMEncryptedKeyPair -> {
                    try {
                        val decryptor = BcPEMDecryptorProvider(password.toCharArray())
                        val keyPair = item.decryptKeyPair(decryptor)
                        key = JcaPEMKeyConverter().getKeyPair(keyPair).private
                    } catch (_: Exception) {}
                }
                is PEMKeyPair -> {
                    try {
                        key = JcaPEMKeyConverter().getKeyPair(item).private
                    } catch (_: Exception) {}
                }
                is PrivateKeyInfo -> {
                    try {
                        key = JcaPEMKeyConverter().getPrivateKey(item)
                    } catch (_: Exception) {}
                }
            }
        }

        return Pair(key, certs)
    }

    private data class VerificationStatus(val passed: Boolean, val details: String)

    private fun verifyConvertedFile(
        file: File,
        targetFormat: KeystoreFormat,
        targetPassword: String,
        expectedAliases: List<String>
    ): VerificationStatus {
        JksProvider.register()
        if (!file.exists() || file.length() == 0L) {
            return VerificationStatus(false, "Converted file is missing or zero bytes")
        }

        return try {
            when (targetFormat) {
                KeystoreFormat.PKCS12, KeystoreFormat.JKS, KeystoreFormat.BKS -> {
                    val ks = KeyStore.getInstance(targetFormat.name)
                    file.inputStream().use { ks.load(it, targetPassword.toCharArray()) }
                    val actualAliases = ks.aliases().toList()
                    val missing = expectedAliases.filter { !actualAliases.contains(it) }
                    if (missing.isNotEmpty()) {
                        VerificationStatus(false, "Integrity check failed: Expected alias(es) [${missing.joinToString()}] not found in converted keystore")
                    } else {
                        VerificationStatus(
                            true,
                            "100% verified. Keystore unlocked successfully with ${actualAliases.size} alias(es) matching expected cryptographic signatures."
                        )
                    }
                }
                KeystoreFormat.DER_CERT -> {
                    val certFactory = CertificateFactory.getInstance("X.509")
                    val cert = file.inputStream().use { certFactory.generateCertificate(it) as? X509Certificate }
                    if (cert != null) {
                        val fp = KeystoreManager.calculateFingerprint(cert, "SHA-256")
                        VerificationStatus(true, "100% verified. Valid X.509 DER Certificate parsed (SHA-256: ${fp.take(17)}...)")
                    } else {
                        VerificationStatus(false, "Failed to parse binary DER certificate from converted output")
                    }
                }
                KeystoreFormat.PEM_FULL, KeystoreFormat.PEM_CERT, KeystoreFormat.PEM_KEY -> {
                    val text = file.readText()
                    if (text.contains("-----BEGIN ")) {
                        VerificationStatus(true, "100% verified. Valid PEM structure generated with standard cryptographic headers.")
                    } else {
                        VerificationStatus(false, "Converted PEM output missing standard PEM armor headers")
                    }
                }
            }
        } catch (e: Exception) {
            VerificationStatus(false, "Post-conversion verification failed: ${e.message}")
        }
    }
}
