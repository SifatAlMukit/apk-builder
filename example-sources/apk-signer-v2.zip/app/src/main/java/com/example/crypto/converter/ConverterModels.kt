package com.example.crypto.converter

import java.io.File

/**
 * Inspection details of the source file.
 */
data class SourceInspection(
    val detectedFormat: KeystoreFormat?,
    val formatConfidence: Confidence,
    val detectionNote: String,
    val requiresPassword: Boolean,
    val isPasswordVerified: Boolean,
    val fileSize: Long,
    val fileName: String,
    val aliases: List<AliasInspection> = emptyList(),
    val defaultAlias: String = "",
    val hasPrivateKey: Boolean = false,
    val hasCertificates: Boolean = false,
    val warnings: List<String> = emptyList()
) {
    enum class Confidence { HIGH, MEDIUM, LOW, UNKNOWN }
}

/**
 * Inspection metadata for a single alias within the source file.
 */
data class AliasInspection(
    val alias: String,
    val isKeyEntry: Boolean,
    val isCertEntry: Boolean,
    val keyAlgorithm: String,
    val keySize: Int,
    val certificateChainLength: Int,
    val subjectDn: String,
    val issuerDn: String,
    val sha256Fingerprint: String,
    val sha1Fingerprint: String,
    val validFrom: Long,
    val validUntil: Long,
    val isExpired: Boolean
)

/**
 * Configuration options selected by the user for converting the keystore.
 */
data class ConversionOptions(
    val targetFormat: KeystoreFormat,
    val selectedAlias: String? = null, // null means "All Aliases" (if target supports multiple)
    val targetStorePassword: String = "",
    val targetKeyPassword: String = "",
    val useSamePassword: Boolean = true,
    val targetAliasName: String = "", // Optional rename if single alias
    val encryptPrivateKey: Boolean = false,
    val exportAllAliasesAsPem: Boolean = true,
    val sourceKeyPassword: String? = null
) {
    val effectiveKeyPassword: String
        get() = if (useSamePassword) targetStorePassword else targetKeyPassword.ifBlank { targetStorePassword }
}

/**
 * Outcome of a format conversion operation.
 */
data class ConversionResult(
    val success: Boolean,
    val sourceFormat: KeystoreFormat,
    val targetFormat: KeystoreFormat,
    val outputFile: File,
    val outputFileName: String,
    val outputFileSize: Long,
    val convertedAliases: List<String>,
    val warnings: List<String> = emptyList(),
    val verificationPassed: Boolean = false,
    val verificationDetails: String = "",
    val errorMessage: String? = null
)
