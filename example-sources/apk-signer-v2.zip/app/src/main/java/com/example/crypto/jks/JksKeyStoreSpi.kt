package com.example.crypto.jks

import org.bouncycastle.asn1.ASN1ObjectIdentifier
import org.bouncycastle.asn1.pkcs.EncryptedPrivateKeyInfo
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo
import org.bouncycastle.asn1.x509.AlgorithmIdentifier
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter
import java.io.*
import java.security.*
import java.security.cert.Certificate
import java.security.cert.CertificateFactory
import java.security.spec.PKCS8EncodedKeySpec
import java.util.*

/**
 * Pure Kotlin/Java implementation of Java KeyStore (JKS) Service Provider Interface.
 *
 * Android runtime does not include the proprietary Sun/Oracle JKS KeyStore provider,
 * causing `KeyStore.getInstance("JKS")` to throw `KeyStoreException: JKS not found`.
 * This SPI implements the full JKS binary file format (magic 0xfeedfeed, version 2,
 * SHA-1 checksum integrity with "Mighty Aphrodite", and password-based XOR-SHA1 key encryption),
 * enabling complete read/write support for standard .jks / .keystore files.
 */
class JksKeyStoreSpi : KeyStoreSpi() {

    companion object {
        const val MAGIC: Int = 0xFEEDFEED.toInt() // -17957139
        const val LEGACY_TYPO_MAGIC: Int = -17958195 // 0xFEEDFACD (backwards compatibility for internally created files)
        const val VERSION_1: Int = 1
        const val VERSION_2: Int = 2

        const val TAG_KEY: Int = 1
        const val TAG_CERT: Int = 2

        const val SUN_KEY_PROTECTION_OID = "1.3.6.1.4.1.42.2.17.1.1"

        private val DIGEST_SEPARATOR = "Mighty Aphrodite".toByteArray(Charsets.UTF_8)

        fun charsToBytes(chars: CharArray): ByteArray {
            val bytes = ByteArray(chars.size * 2)
            var j = 0
            for (c in chars) {
                bytes[j++] = (c.code ushr 8).toByte()
                bytes[j++] = (c.code and 0xFF).toByte()
            }
            return bytes
        }

        fun encryptPrivateKey(key: Key, password: CharArray): ByteArray {
            val plainKey = key.encoded ?: throw KeyStoreException("Private key does not provide PKCS#8 encoded bytes")
            val sha = MessageDigest.getInstance("SHA-1")
            val passwdBytes = charsToBytes(password)

            // 1. Generate 20-byte random salt
            val salt = ByteArray(20)
            SecureRandom().nextBytes(salt)

            // 2. Keystream XOR encryption
            val keystream = ByteArray(20)
            System.arraycopy(salt, 0, keystream, 0, 20)

            val keyLen = plainKey.size
            val xorData = ByteArray(keyLen)
            var count = 0
            while (count < keyLen) {
                sha.reset()
                sha.update(passwdBytes)
                sha.update(keystream)
                sha.digest(keystream, 0, keystream.size)
                for (i in 0 until keystream.size) {
                    if (count >= keyLen) break
                    xorData[count] = (plainKey[count].toInt() xor keystream[i].toInt()).toByte()
                    count++
                }
            }

            // 3. Compute check digest = SHA-1(passwdBytes + plainKey)
            sha.reset()
            sha.update(passwdBytes)
            sha.update(plainKey)
            val check = sha.digest() // 20 bytes

            // 4. Combine into encrypted stream: salt (20) + xorData (keyLen) + check (20)
            val encrypted = ByteArray(20 + keyLen + 20)
            System.arraycopy(salt, 0, encrypted, 0, 20)
            System.arraycopy(xorData, 0, encrypted, 20, keyLen)
            System.arraycopy(check, 0, encrypted, 20 + keyLen, 20)

            // 5. Wrap into PKCS#8 EncryptedPrivateKeyInfo with Sun OID
            return try {
                val algId = AlgorithmIdentifier(ASN1ObjectIdentifier(SUN_KEY_PROTECTION_OID))
                val epki = EncryptedPrivateKeyInfo(algId, encrypted)
                epki.encoded
            } catch (_: Exception) {
                try {
                    javax.crypto.EncryptedPrivateKeyInfo(SUN_KEY_PROTECTION_OID, encrypted).encoded
                } catch (_: Exception) {
                    encrypted
                }
            }
        }

        fun decryptPrivateKey(keyBlob: ByteArray, password: CharArray): PrivateKey {
            // 1. Unwrap from PKCS#8 EncryptedPrivateKeyInfo
            val encrypted = try {
                val epki = EncryptedPrivateKeyInfo.getInstance(keyBlob)
                epki.encryptedData
            } catch (_: Exception) {
                try {
                    val jEpki = javax.crypto.EncryptedPrivateKeyInfo(keyBlob)
                    jEpki.encryptedData
                } catch (_: Exception) {
                    keyBlob
                }
            }

            if (encrypted.size < 40) {
                throw UnrecoverableKeyException("Corrupted encrypted key data (length ${encrypted.size} < 40)")
            }

            val salt = ByteArray(20)
            System.arraycopy(encrypted, 0, salt, 0, 20)

            val keyLen = encrypted.size - 40
            val xorData = ByteArray(keyLen)
            System.arraycopy(encrypted, 20, xorData, 0, keyLen)

            val check = ByteArray(20)
            System.arraycopy(encrypted, encrypted.size - 20, check, 0, 20)

            // 2. Keystream XOR decryption
            val sha = MessageDigest.getInstance("SHA-1")
            val passwdBytes = charsToBytes(password)
            val keystream = ByteArray(20)
            System.arraycopy(salt, 0, keystream, 0, 20)

            val plainKey = ByteArray(keyLen)
            var count = 0
            while (count < keyLen) {
                sha.reset()
                sha.update(passwdBytes)
                sha.update(keystream)
                sha.digest(keystream, 0, keystream.size)
                for (i in 0 until keystream.size) {
                    if (count >= keyLen) break
                    plainKey[count] = (xorData[count].toInt() xor keystream[i].toInt()).toByte()
                    count++
                }
            }

            // 3. Verify check digest
            sha.reset()
            sha.update(passwdBytes)
            sha.update(plainKey)
            val computedCheck = sha.digest()
            if (!MessageDigest.isEqual(check, computedCheck)) {
                throw UnrecoverableKeyException("Cannot recover key: password incorrect or corrupted key")
            }

            // 4. Construct PrivateKey
            return try {
                val pki = PrivateKeyInfo.getInstance(plainKey)
                JcaPEMKeyConverter().getPrivateKey(pki)
            } catch (_: Exception) {
                val keySpec = PKCS8EncodedKeySpec(plainKey)
                try {
                    KeyFactory.getInstance("RSA").generatePrivate(keySpec)
                } catch (_: Exception) {
                    try {
                        KeyFactory.getInstance("EC").generatePrivate(keySpec)
                    } catch (_: Exception) {
                        KeyFactory.getInstance("DSA").generatePrivate(keySpec)
                    }
                }
            }
        }
    }

    private sealed class Entry(open val alias: String, open val date: Date) {
        data class KeyEntry(
            override val alias: String,
            override val date: Date,
            val chain: List<Certificate>,
            var privateKey: Key? = null,
            var encryptedKeyBlob: ByteArray? = null,
            var keyPassword: CharArray? = null
        ) : Entry(alias, date)

        data class CertEntry(
            override val alias: String,
            override val date: Date,
            val cert: Certificate
        ) : Entry(alias, date)
    }

    private val entries = LinkedHashMap<String, Entry>()

    override fun engineGetKey(alias: String, password: CharArray?): Key? {
        val entry = entries[alias.lowercase(Locale.ROOT)] as? Entry.KeyEntry ?: return null

        if (entry.privateKey != null) {
            if (entry.keyPassword == null || password == null || entry.keyPassword.contentEquals(password)) {
                return entry.privateKey
            }
        }

        val blob = entry.encryptedKeyBlob ?: return entry.privateKey
        val pwd = password ?: entry.keyPassword ?: throw UnrecoverableKeyException("Password required to recover key '$alias'")
        val recovered = decryptPrivateKey(blob, pwd)
        entry.privateKey = recovered
        entry.keyPassword = pwd.clone()
        return recovered
    }

    override fun engineGetCertificateChain(alias: String): Array<Certificate>? {
        val entry = entries[alias.lowercase(Locale.ROOT)] as? Entry.KeyEntry ?: return null
        return if (entry.chain.isEmpty()) null else entry.chain.toTypedArray()
    }

    override fun engineGetCertificate(alias: String): Certificate? {
        return when (val entry = entries[alias.lowercase(Locale.ROOT)]) {
            is Entry.KeyEntry -> entry.chain.firstOrNull()
            is Entry.CertEntry -> entry.cert
            null -> null
        }
    }

    override fun engineGetCreationDate(alias: String): Date? {
        return entries[alias.lowercase(Locale.ROOT)]?.date
    }

    override fun engineSetKeyEntry(alias: String, key: Key, password: CharArray?, chain: Array<out Certificate>?) {
        val certList = chain?.toList() ?: emptyList()
        val entry = Entry.KeyEntry(
            alias = alias,
            date = Date(),
            chain = certList,
            privateKey = key,
            keyPassword = password?.clone()
        )
        entries[alias.lowercase(Locale.ROOT)] = entry
    }

    override fun engineSetKeyEntry(alias: String, key: ByteArray, chain: Array<out Certificate>?) {
        val certList = chain?.toList() ?: emptyList()
        val entry = Entry.KeyEntry(
            alias = alias,
            date = Date(),
            chain = certList,
            encryptedKeyBlob = key
        )
        entries[alias.lowercase(Locale.ROOT)] = entry
    }

    override fun engineSetCertificateEntry(alias: String, cert: Certificate) {
        val entry = Entry.CertEntry(
            alias = alias,
            date = Date(),
            cert = cert
        )
        entries[alias.lowercase(Locale.ROOT)] = entry
    }

    override fun engineDeleteEntry(alias: String) {
        entries.remove(alias.lowercase(Locale.ROOT))
    }

    override fun engineAliases(): Enumeration<String> {
        return Collections.enumeration(entries.values.map { it.alias })
    }

    override fun engineContainsAlias(alias: String): Boolean {
        return entries.containsKey(alias.lowercase(Locale.ROOT))
    }

    override fun engineSize(): Int {
        return entries.size
    }

    override fun engineIsKeyEntry(alias: String): Boolean {
        return entries[alias.lowercase(Locale.ROOT)] is Entry.KeyEntry
    }

    override fun engineIsCertificateEntry(alias: String): Boolean {
        return entries[alias.lowercase(Locale.ROOT)] is Entry.CertEntry
    }

    override fun engineGetCertificateAlias(cert: Certificate): String? {
        for (entry in entries.values) {
            when (entry) {
                is Entry.CertEntry -> {
                    if (entry.cert == cert) return entry.alias
                }
                is Entry.KeyEntry -> {
                    if (entry.chain.firstOrNull() == cert) return entry.alias
                }
            }
        }
        return null
    }

    override fun engineStore(stream: OutputStream, password: CharArray?) {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)

        // 1. Magic
        dos.writeInt(MAGIC)
        // 2. Version
        dos.writeInt(VERSION_2)
        // 3. Count
        dos.writeInt(entries.size)

        for (entry in entries.values) {
            when (entry) {
                is Entry.KeyEntry -> {
                    dos.writeInt(TAG_KEY)
                    dos.writeUTF(entry.alias)
                    dos.writeLong(entry.date.time)

                    val keyBlob = if (entry.encryptedKeyBlob != null) {
                        entry.encryptedKeyBlob!!
                    } else if (entry.privateKey != null) {
                        val keyPass = entry.keyPassword ?: password
                            ?: throw KeyStoreException("Password needed to encrypt private key for alias '${entry.alias}'")
                        encryptPrivateKey(entry.privateKey!!, keyPass)
                    } else {
                        throw KeyStoreException("Key entry '${entry.alias}' has no key data")
                    }

                    dos.writeInt(keyBlob.size)
                    dos.write(keyBlob)

                    dos.writeInt(entry.chain.size)
                    for (cert in entry.chain) {
                        dos.writeUTF(cert.type)
                        val encoded = cert.encoded
                        dos.writeInt(encoded.size)
                        dos.write(encoded)
                    }
                }
                is Entry.CertEntry -> {
                    dos.writeInt(TAG_CERT)
                    dos.writeUTF(entry.alias)
                    dos.writeLong(entry.date.time)

                    dos.writeUTF(entry.cert.type)
                    val encoded = entry.cert.encoded
                    dos.writeInt(encoded.size)
                    dos.write(encoded)
                }
            }
        }

        dos.flush()
        val bodyBytes = baos.toByteArray()

        // 4. Calculate SHA-1 Checksum
        val md = MessageDigest.getInstance("SHA-1")
        val pwdBytes = charsToBytes(password ?: CharArray(0))
        md.update(pwdBytes)
        md.update(DIGEST_SEPARATOR)
        md.update(bodyBytes)
        val checksum = md.digest()

        stream.write(bodyBytes)
        stream.write(checksum)
        stream.flush()
    }

    override fun engineLoad(stream: InputStream?, password: CharArray?) {
        entries.clear()
        if (stream == null) {
            return
        }

        val allBytes = stream.readBytes()
        if (allBytes.isEmpty()) {
            return
        }

        if (allBytes.size < 4 + 4 + 4 + 20) {
            throw IOException("Invalid JKS file: stream is too short (${allBytes.size} bytes)")
        }

        val bodyBytes = allBytes.copyOfRange(0, allBytes.size - 20)
        val fileChecksum = allBytes.copyOfRange(allBytes.size - 20, allBytes.size)

        if (password != null) {
            val md = MessageDigest.getInstance("SHA-1")
            val pwdBytes = charsToBytes(password)
            md.update(pwdBytes)
            md.update(DIGEST_SEPARATOR)
            md.update(bodyBytes)
            val computedChecksum = md.digest()
            if (!MessageDigest.isEqual(fileChecksum, computedChecksum)) {
                throw UnrecoverableKeyException("Password incorrect or keystore tampered with")
            }
        }

        val bais = ByteArrayInputStream(bodyBytes)
        val dis = DataInputStream(bais)

        val magic = dis.readInt()
        if (magic != MAGIC && magic != LEGACY_TYPO_MAGIC) {
            throw IOException("Invalid JKS magic number: expected 0xfeedfeed, got 0x%08x".format(magic))
        }

        val version = dis.readInt()
        if (version != VERSION_1 && version != VERSION_2) {
            throw IOException("Unsupported JKS version: $version")
        }

        val count = dis.readInt()
        val certFactory = CertificateFactory.getInstance("X.509")

        for (i in 0 until count) {
            val tag = dis.readInt()
            val alias = dis.readUTF()
            val date = Date(dis.readLong())

            when (tag) {
                TAG_KEY -> {
                    val keyBlobLen = dis.readInt()
                    val keyBlob = ByteArray(keyBlobLen)
                    dis.readFully(keyBlob)

                    val certCount = dis.readInt()
                    val chain = ArrayList<Certificate>(certCount)
                    for (c in 0 until certCount) {
                        val certType = dis.readUTF()
                        val certLen = dis.readInt()
                        val certBytes = ByteArray(certLen)
                        dis.readFully(certBytes)
                        val cf = if (certType.equals("X.509", ignoreCase = true)) certFactory else CertificateFactory.getInstance(certType)
                        val cert = cf.generateCertificate(ByteArrayInputStream(certBytes))
                        chain.add(cert)
                    }

                    val keyEntry = Entry.KeyEntry(
                        alias = alias,
                        date = date,
                        chain = chain,
                        encryptedKeyBlob = keyBlob
                    )

                    if (password != null) {
                        try {
                            keyEntry.privateKey = decryptPrivateKey(keyBlob, password)
                            keyEntry.keyPassword = password.clone()
                        } catch (_: Exception) {
                            // Key may have a distinct password
                        }
                    }

                    entries[alias.lowercase(Locale.ROOT)] = keyEntry
                }
                TAG_CERT -> {
                    val certType = dis.readUTF()
                    val certLen = dis.readInt()
                    val certBytes = ByteArray(certLen)
                    dis.readFully(certBytes)
                    val cf = if (certType.equals("X.509", ignoreCase = true)) certFactory else CertificateFactory.getInstance(certType)
                    val cert = cf.generateCertificate(ByteArrayInputStream(certBytes))

                    val certEntry = Entry.CertEntry(
                        alias = alias,
                        date = date,
                        cert = cert
                    )
                    entries[alias.lowercase(Locale.ROOT)] = certEntry
                }
                else -> {
                    throw IOException("Unrecognized JKS entry tag: $tag")
                }
            }
        }
    }
}
