package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.KeystoreManager
import com.example.crypto.converter.*
import com.example.data.db.AppDatabase
import com.example.data.db.KeystoreEntity
import com.example.data.repository.KeystoreRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

enum class ConverterStep {
    SELECT_SOURCE,
    INSPECT_SOURCE,
    CONFIGURE_TARGET,
    CONVERSION_RESULT
}

class ConverterViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KeystoreRepository by lazy {
        val db = AppDatabase.getDatabase(application)
        KeystoreRepository(db.keystoreDao())
    }

    val savedKeystores: StateFlow<List<KeystoreEntity>> = repository.allKeystores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _step = MutableStateFlow(ConverterStep.SELECT_SOURCE)
    val step: StateFlow<ConverterStep> = _step.asStateFlow()

    private val _sourceFile = MutableStateFlow<File?>(null)
    val sourceFile: StateFlow<File?> = _sourceFile.asStateFlow()

    private val _sourceFileName = MutableStateFlow("")
    val sourceFileName: StateFlow<String> = _sourceFileName.asStateFlow()

    private val _sourceFileSize = MutableStateFlow(0L)
    val sourceFileSize: StateFlow<Long> = _sourceFileSize.asStateFlow()

    private val _sourcePassword = MutableStateFlow("")
    val sourcePassword: StateFlow<String> = _sourcePassword.asStateFlow()

    private val _sourceKeyPassword = MutableStateFlow("")
    val sourceKeyPassword: StateFlow<String> = _sourceKeyPassword.asStateFlow()

    var useSameSourcePassword = MutableStateFlow(true)

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _sourceInspection = MutableStateFlow<SourceInspection?>(null)
    val sourceInspection: StateFlow<SourceInspection?> = _sourceInspection.asStateFlow()

    private val _conversionOptions = MutableStateFlow(
        ConversionOptions(targetFormat = KeystoreFormat.PKCS12)
    )
    val conversionOptions: StateFlow<ConversionOptions> = _conversionOptions.asStateFlow()

    private val _isConverting = MutableStateFlow(false)
    val isConverting: StateFlow<Boolean> = _isConverting.asStateFlow()

    private val _conversionResult = MutableStateFlow<ConversionResult?>(null)
    val conversionResult: StateFlow<ConversionResult?> = _conversionResult.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _savedToLibrarySuccess = MutableStateFlow(false)
    val savedToLibrarySuccess: StateFlow<Boolean> = _savedToLibrarySuccess.asStateFlow()

    fun reset() {
        _step.value = ConverterStep.SELECT_SOURCE
        _sourceFile.value = null
        _sourceFileName.value = ""
        _sourceFileSize.value = 0L
        _sourcePassword.value = ""
        _sourceKeyPassword.value = ""
        useSameSourcePassword.value = true
        _sourceInspection.value = null
        _conversionOptions.value = ConversionOptions(targetFormat = KeystoreFormat.PKCS12)
        _conversionResult.value = null
        _errorMessage.value = null
        _savedToLibrarySuccess.value = false
    }

    /**
     * Loads a source file from a Uri (picked via SAF) into secure cache and inspects it.
     */
    fun loadSourceFromUri(uri: Uri, name: String, size: Long) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _sourceFileName.value = name
            _sourceFileSize.value = size
            _step.value = ConverterStep.INSPECT_SOURCE

            try {
                val context = getApplication<Application>()
                val cacheDir = File(context.cacheDir, "converter_staging").apply { mkdirs() }
                val tempFile = File(cacheDir, "src_${System.currentTimeMillis()}_$name")

                withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempFile).use { output ->
                            input.copyTo(output)
                        }
                    }
                }

                _sourceFile.value = tempFile
                inspectFile(tempFile, null)
            } catch (e: Exception) {
                _errorMessage.value = "Failed to stage file: ${e.message}"
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    /**
     * Preloads an already-saved Keystore from the app's local repository.
     */
    fun loadFromSavedKeystore(entity: KeystoreEntity) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _sourceFileName.value = entity.fileName
            _sourceFileSize.value = File(entity.filePath).length()
            _step.value = ConverterStep.INSPECT_SOURCE

            val file = File(entity.filePath)
            _sourceFile.value = file
            inspectFile(file, null)
            _isAnalyzing.value = false
        }
    }

    /**
     * Unlocks source file with a user-entered password.
     */
    fun unlockWithPassword(password: String, keyPassword: String? = null) {
        _sourcePassword.value = password
        _sourceKeyPassword.value = keyPassword ?: ""
        useSameSourcePassword.value = keyPassword.isNullOrBlank()
        val file = _sourceFile.value ?: return
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            inspectFile(file, password)
            _isAnalyzing.value = false
        }
    }

    fun setSourceKeyPassword(keyPassword: String, useSame: Boolean) {
        _sourceKeyPassword.value = keyPassword
        useSameSourcePassword.value = useSame
    }

    private suspend fun inspectFile(file: File, password: String?) {
        withContext(Dispatchers.IO) {
            val inspection = FormatDetector.detectAndInspect(file, password)
            _sourceInspection.value = inspection

            if (inspection.isPasswordVerified) {
                // Determine sensible default destination format
                val defaultTarget = when (inspection.detectedFormat) {
                    KeystoreFormat.PKCS12 -> KeystoreFormat.JKS
                    KeystoreFormat.JKS -> KeystoreFormat.PKCS12
                    KeystoreFormat.BKS -> KeystoreFormat.PKCS12
                    KeystoreFormat.PEM_FULL -> KeystoreFormat.PKCS12
                    KeystoreFormat.PEM_CERT -> KeystoreFormat.DER_CERT
                    KeystoreFormat.DER_CERT -> KeystoreFormat.PEM_CERT
                    else -> KeystoreFormat.PKCS12
                }

                _conversionOptions.value = ConversionOptions(
                    targetFormat = defaultTarget,
                    selectedAlias = if (inspection.aliases.size == 1) inspection.aliases.first().alias else null,
                    targetStorePassword = password ?: "",
                    useSamePassword = true
                )
            }
        }
    }

    fun proceedToConfigure() {
        if (_sourceInspection.value?.isPasswordVerified == true) {
            _step.value = ConverterStep.CONFIGURE_TARGET
        }
    }

    fun updateConversionOptions(updater: (ConversionOptions) -> ConversionOptions) {
        _conversionOptions.value = updater(_conversionOptions.value)
    }

    /**
     * Executes the conversion on IO dispatcher.
     */
    fun executeConversion() {
        val file = _sourceFile.value ?: return
        val inspection = _sourceInspection.value ?: return
        val options = _conversionOptions.value

        viewModelScope.launch {
            _isConverting.value = true
            _errorMessage.value = null
            _step.value = ConverterStep.CONVERSION_RESULT

            try {
                val context = getApplication<Application>()
                val outDir = File(context.cacheDir, "converter_output").apply { mkdirs() }

                val result = withContext(Dispatchers.IO) {
                    val finalOptions = if (!useSameSourcePassword.value && _sourceKeyPassword.value.isNotBlank()) {
                        options.copy(sourceKeyPassword = _sourceKeyPassword.value)
                    } else {
                        options
                    }
                    KeystoreConverterEngine.convert(
                        sourceFile = file,
                        sourceInspection = inspection,
                        sourcePassword = _sourcePassword.value,
                        options = finalOptions,
                        outputDirectory = outDir
                    )
                }

                _conversionResult.value = result
                if (!result.success) {
                    _errorMessage.value = result.errorMessage
                }
            } catch (e: Exception) {
                _errorMessage.value = "Conversion failed: ${e.message}"
            } finally {
                _isConverting.value = false
            }
        }
    }

    /**
     * Saves the converted keystore to user-specified Uri via SAF.
     */
    fun saveOutputToUri(context: Context, destUri: Uri) {
        val result = _conversionResult.value ?: return
        if (!result.outputFile.exists()) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                context.contentResolver.openOutputStream(destUri)?.use { output ->
                    result.outputFile.inputStream().use { input ->
                        input.copyTo(output)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _errorMessage.value = "Failed to export file: ${e.message}"
                }
            }
        }
    }

    /**
     * Creates an Intent to share the converted file.
     */
    fun getShareIntent(): Intent? {
        val result = _conversionResult.value ?: return null
        val file = result.outputFile
        if (!file.exists()) return null

        val context = getApplication<Application>()
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return Intent(Intent.ACTION_SEND).apply {
            type = result.targetFormat.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Converted ${result.targetFormat.displayName}: ${file.name}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /**
     * Adds the converted Keystore directly into the App's local Room database library.
     */
    fun saveToAppKeystoreLibrary(customName: String) {
        val result = _conversionResult.value ?: return
        if (!result.success || !result.outputFile.exists()) return
        if (result.targetFormat.category != KeystoreFormat.FormatCategory.KEYSTORE) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val context = getApplication<Application>()
                val keystoresDir = File(context.filesDir, "keystores").apply { mkdirs() }
                val targetFile = File(keystoresDir, "converted_${System.currentTimeMillis()}_${result.outputFileName}")
                result.outputFile.copyTo(targetFile, overwrite = true)

                // Inspect certificate of converted keystore
                val (ks, _) = KeystoreManager.loadKeyStore(targetFile, _conversionOptions.value.targetStorePassword)
                val primaryAlias = result.convertedAliases.firstOrNull() ?: ks.aliases().toList().firstOrNull() ?: "key"
                val certInfo = KeystoreManager.getCertificateInfo(ks, primaryAlias)

                val entity = KeystoreEntity(
                    name = customName.ifBlank { "Converted (${result.targetFormat.name})" },
                    fileName = targetFile.name,
                    filePath = targetFile.absolutePath,
                    storeType = result.targetFormat.name,
                    aliases = result.convertedAliases.joinToString(","),
                    defaultAlias = primaryAlias,
                    certificateDn = certInfo?.subjectDn ?: "N/A",
                    sha256Fingerprint = certInfo?.sha256Fingerprint ?: "N/A",
                    validUntil = certInfo?.validUntil ?: (System.currentTimeMillis() + 315360000000L),
                    keyAlgorithm = certInfo?.keyAlgorithm ?: "RSA",
                    keySize = certInfo?.keySize ?: 2048
                )

                repository.insertKeystore(entity)
                withContext(Dispatchers.Main) {
                    _savedToLibrarySuccess.value = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    _errorMessage.value = "Failed to save to keystore library: ${e.message}"
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        // Clean up temporary files in converter_staging
        try {
            val context = getApplication<Application>()
            File(context.cacheDir, "converter_staging").deleteRecursively()
        } catch (_: Exception) {}
    }
}
