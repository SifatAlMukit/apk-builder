package com.example.crypto

import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Pure Kotlin implementation of Android's ZipAlign utility.
 *
 * Aligns all uncompressed (STORED) entries within a ZIP/APK file to 4-byte boundaries,
 * and shared libraries (.so) to 16,384-byte (16KB page) boundaries for modern Android OS memory mapping.
 *
 * This operation MUST be performed before applying Android APK Signature Schemes v2/v3,
 * as modifying entry offsets after signature generation invalidates cryptographic block digests.
 */
object ZipAligner {

    private const val LFH_SIGNATURE = 0x04034b50
    private const val CDH_SIGNATURE = 0x02014b50

    const val DEFAULT_ALIGNMENT = 4
    const val SO_PAGE_ALIGNMENT = 16384 // 16KB page alignment (Android 15+ standard)

    /**
     * Aligns the input APK file into the output APK file.
     * Returns true if alignment succeeded, or false if already aligned or corrupted.
     */
    fun align(inputFile: File, outputFile: File, pageAlignment: Int = SO_PAGE_ALIGNMENT): Boolean {
        if (!inputFile.exists() || inputFile.length() < 22) {
            return false
        }

        try {
            RandomAccessFile(inputFile, "r").use { rafIn ->
                val fileLen = rafIn.length()

                // 1. Locate End of Central Directory (EOCD)
                val eocdOffset = findEocd(rafIn, fileLen)
                if (eocdOffset == -1L) return false

                rafIn.seek(eocdOffset)
                val eocdBuf = ByteArray(22)
                rafIn.readFully(eocdBuf)
                val eocd = ByteBuffer.wrap(eocdBuf).order(ByteOrder.LITTLE_ENDIAN)
                eocd.position(10)
                val totalEntries = eocd.short.toInt() and 0xFFFF
                val cdSize = eocd.int.toLong() and 0xFFFFFFFFL
                val cdOffset = eocd.int.toLong() and 0xFFFFFFFFL
                val commentLen = eocd.short.toInt() and 0xFFFF

                val commentBytes = if (commentLen > 0) {
                    val b = ByteArray(commentLen)
                    rafIn.readFully(b)
                    b
                } else ByteArray(0)

                // 2. Read Central Directory records
                rafIn.seek(cdOffset)
                val cdBytes = ByteArray(cdSize.toInt())
                rafIn.readFully(cdBytes)
                val cdBuf = ByteBuffer.wrap(cdBytes).order(ByteOrder.LITTLE_ENDIAN)

                class CdEntry(
                    val fixedHeader: ByteArray, // 46 bytes
                    val compressionMethod: Int,
                    val fileName: String,
                    val fileNameBytes: ByteArray,
                    val extraBytes: ByteArray,
                    val commentBytes: ByteArray,
                    var localHeaderOffset: Long
                )

                val cdEntries = ArrayList<CdEntry>(totalEntries)
                var pos = 0
                for (i in 0 until totalEntries) {
                    if (pos + 46 > cdBytes.size) break
                    val sig = cdBuf.getInt(pos)
                    if (sig != CDH_SIGNATURE) break

                    val fixed = cdBytes.copyOfRange(pos, pos + 46)
                    val method = cdBuf.getShort(pos + 10).toInt() and 0xFFFF
                    val fnLen = cdBuf.getShort(pos + 28).toInt() and 0xFFFF
                    val extraLen = cdBuf.getShort(pos + 30).toInt() and 0xFFFF
                    val commLen = cdBuf.getShort(pos + 32).toInt() and 0xFFFF
                    val localOffset = cdBuf.getInt(pos + 42).toLong() and 0xFFFFFFFFL

                    pos += 46
                    val fnBytes = cdBytes.copyOfRange(pos, pos + fnLen)
                    pos += fnLen
                    val exBytes = cdBytes.copyOfRange(pos, pos + extraLen)
                    pos += extraLen
                    val cmBytes = cdBytes.copyOfRange(pos, pos + commLen)
                    pos += commLen

                    val fileName = String(fnBytes, Charsets.UTF_8)
                    cdEntries.add(CdEntry(fixed, method, fileName, fnBytes, exBytes, cmBytes, localOffset))
                }

                // 3. Process entries and write to output file
                if (outputFile.exists()) outputFile.delete()
                outputFile.parentFile?.mkdirs()

                FileOutputStream(outputFile).use { fos ->
                    val dos = BufferedOutputStream(fos, 65536)
                    var outPos = 0L

                    for (entry in cdEntries) {
                        rafIn.seek(entry.localHeaderOffset)
                        val lfhBuf = ByteArray(30)
                        rafIn.readFully(lfhBuf)
                        val lfh = ByteBuffer.wrap(lfhBuf).order(ByteOrder.LITTLE_ENDIAN)
                        val lfhSig = lfh.getInt(0)
                        if (lfhSig != LFH_SIGNATURE) {
                            return false
                        }

                        val fnLen = lfh.getShort(26).toInt() and 0xFFFF
                        val origExtraLen = lfh.getShort(28).toInt() and 0xFFFF
                        val fn = ByteArray(fnLen)
                        rafIn.readFully(fn)
                        val origExtra = ByteArray(origExtraLen)
                        rafIn.readFully(origExtra)

                        val compSize = lfh.getInt(18).toLong() and 0xFFFFFFFFL

                        // Determine alignment requirement
                        val alignment = if (entry.compressionMethod == 0) { // STORED (uncompressed)
                            if (entry.fileName.endsWith(".so", ignoreCase = true)) pageAlignment else DEFAULT_ALIGNMENT
                        } else {
                            1
                        }

                        // Calculate current data offset and required padding
                        val currentDataOffset = outPos + 30 + fnLen + origExtraLen
                        val remainder = (currentDataOffset % alignment).toInt()
                        val padding = if (remainder != 0) alignment - remainder else 0

                        val newExtraLen = origExtraLen + padding
                        // Update Local File Header extra length in-place
                        val newLfh = lfhBuf.clone()
                        ByteBuffer.wrap(newLfh).order(ByteOrder.LITTLE_ENDIAN).putShort(28, newExtraLen.toShort())

                        // Update local header offset for Central Directory
                        entry.localHeaderOffset = outPos

                        // Write Local Header + Filename + Original Extra + Alignment Padding
                        dos.write(newLfh)
                        dos.write(fn)
                        dos.write(origExtra)
                        if (padding > 0) {
                            dos.write(ByteArray(padding))
                        }
                        outPos += 30 + fnLen + newExtraLen

                        // Stream payload
                        val buffer = ByteArray(minOf(compSize.toInt(), 65536))
                        var remaining = compSize
                        while (remaining > 0) {
                            val toRead = minOf(remaining.toInt(), buffer.size)
                            val read = rafIn.read(buffer, 0, toRead)
                            if (read <= 0) break
                            dos.write(buffer, 0, read)
                            remaining -= read
                        }
                        outPos += compSize
                    }

                    // 4. Write Central Directory records with updated local header offsets
                    val cdStartOffset = outPos
                    var totalCdSize = 0L

                    for (entry in cdEntries) {
                        val fixed = entry.fixedHeader.clone()
                        ByteBuffer.wrap(fixed).order(ByteOrder.LITTLE_ENDIAN).putInt(42, entry.localHeaderOffset.toInt())

                        dos.write(fixed)
                        dos.write(entry.fileNameBytes)
                        dos.write(entry.extraBytes)
                        dos.write(entry.commentBytes)

                        val entryCdSize = 46 + entry.fileNameBytes.size + entry.extraBytes.size + entry.commentBytes.size
                        outPos += entryCdSize
                        totalCdSize += entryCdSize
                    }

                    // 5. Write updated EOCD record
                    val newEocd = eocdBuf.clone()
                    val eocdWriter = ByteBuffer.wrap(newEocd).order(ByteOrder.LITTLE_ENDIAN)
                    eocdWriter.putInt(12, totalCdSize.toInt())
                    eocdWriter.putInt(16, cdStartOffset.toInt())

                    dos.write(newEocd)
                    if (commentBytes.isNotEmpty()) {
                        dos.write(commentBytes)
                    }
                    dos.flush()
                }
            }
            return true
        } catch (_: Exception) {
            return false
        }
    }

    private fun findEocd(raf: RandomAccessFile, fileLen: Long): Long {
        val maxSearch = minOf(fileLen, 65536 + 22).toInt()
        val buf = ByteArray(maxSearch)
        val searchStart = fileLen - maxSearch
        raf.seek(searchStart)
        raf.readFully(buf)

        for (i in maxSearch - 22 downTo 0) {
            if (buf[i] == 0x50.toByte() &&
                buf[i + 1] == 0x4b.toByte() &&
                buf[i + 2] == 0x05.toByte() &&
                buf[i + 3] == 0x06.toByte()
            ) {
                return searchStart + i
            }
        }
        return -1L
    }
}
