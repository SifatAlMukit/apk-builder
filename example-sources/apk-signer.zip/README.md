# APK Signer 🛡️✍️

[![Platform](https://img.shields.io/badge/Platform-Android-green.svg)](https://developer.android.com)
[![Language](https://img.shields.io/badge/Language-Kotlin-purple.svg)](https://kotlinlang.org)
[![UI](https://img.shields.io/badge/UI-Jetpack%20Compose%20M3-blue.svg)](https://developer.android.com/jetpack/compose)
[![Min SDK](https://img.shields.io/badge/Min%20SDK-24-orange.svg)](https://developer.android.com)
[![Target SDK](https://img.shields.io/badge/Target%20SDK-36-brightgreen.svg)](https://developer.android.com)
[![Crypto](https://img.shields.io/badge/Crypto-BouncyCastle%20%2B%20apksig-red.svg)](https://source.android.com/security/apksigning)

An open-source, fully on-device Android utility application designed to generate cryptographic keystores, convert between certificate formats, and digitally sign and verify Android APK packages with modern APK signature schemes (v1, v2, v3, and v4).

---

## ✨ Features

### 1. ✍️ APK Signing
- **Multi-Scheme Support**: Sign APK packages with:
  - **v1 (JAR Signature)**: Backward compatibility with older Android versions.
  - **v2 (APK Signature Scheme v2)**: Whole-file integrity check for Android 7.0+.
  - **v3 (APK Signature Scheme v3)**: Key rotation support for Android 9.0+.
  - **v4 (Streaming Signature)**: Incremental installations for Android 11+.
- **ZipAlign Integration**: Automatically aligns zip entries on 4-byte boundaries before/during signing.
- **Workflow Actions**:
  - Save signed APK directly to device storage.
  - Share signed APK via Android share sheet.
  - Install signed APK immediately via Android Package Installer.

### 2. 🔍 APK Verification & Inspection
- Inspect any Android APK file to examine digital signatures.
- Detailed validation results for each signature scheme (**v1, v2, v3, v4**).
- Certificate fingerprint extraction:
  - **SHA-256**
  - **SHA-1**
  - **MD5**
- Certificate metadata viewing: Subject DN, Issuer DN, Serial Number, Validity Dates, and Public Key algorithm/size.
- Quick action to re-sign the inspected APK with a different keystore.

### 3. 🔑 Keystore Generation
- Generate secure cryptographic key pairs and X.509 self-signed certificates entirely on-device.
- **Supported Formats**:
  - **PKCS#12** (`.p12` / `.pfx` - Modern standard)
  - **JKS** (`.jks` / `.keystore` - Java KeyStore)
  - **BKS** (`.bks` - Bouncy Castle KeyStore)
- **Algorithms**:
  - RSA (2048-bit, 3072-bit, 4096-bit)
  - EC (Elliptic Curve with secp256r1, secp384r1)
- **Customizable Certificate Details**:
  - Common Name (CN), Organization (O), Organizational Unit (OU)
  - City / Locality (L), State / Province (ST), Country Code (C)
  - Configurable validity period (up to 100 years).

### 4. 📂 Keystore Management
- Secure local storage managed via **Android Jetpack Room (SQLite)**.
- Import existing keystore files (`.jks`, `.keystore`, `.p12`, `.bks`).
- Export keystores and public certificates (`.crt` / `.pem`) to device storage.
- Search, filter, and inspect stored keys with certificate fingerprints.

### 5. 🔄 Keystore Converter
- Seamlessly convert keys and certificates between different formats:
  - **JKS ↔ PKCS12 ↔ BKS**
  - Extract or import private keys and certificates in PEM format.
- Automatic keystore format detection using magic bytes and header inspection.
- Password migration and alias management during conversion.

---

## 🔒 Security & Privacy

- **100% On-Device**: All cryptographic operations, key generation, signing, and verification occur locally on your device.
- **No Network Transmission**: No keystore files, private keys, passwords, or APKs are uploaded to any external server.
- **Sandboxed Storage**: Keystores saved within the app database are protected by Android's internal app sandbox.

---

## 📱 Architecture & Tech Stack

- **User Interface**: [Jetpack Compose](https://developer.android.com/jetpack/compose) with Material Design 3 (M3).
- **Adaptive Layout**: Responsive design adapting to compact devices (phones) via `NavigationBar` and large/tablet screens via `NavigationRail`.
- **Architecture Pattern**: MVVM (Model-View-ViewModel) with unidirectional data flow (StateFlow & Coroutines).
- **Cryptography Engine**:
  - [Bouncy Castle](https://www.bouncycastle.org/) (`bcprov`, `bcpkix`) for X.509 generation and JKS/BKS providers.
  - [Android apksig](https://source.android.com/docs/security/features/apksigning) for APK signature generation and verification.
- **Local Persistence**: [Room Database](https://developer.android.com/training/data-storage/room) with KSP code generation.
- **Language**: 100% Kotlin with Kotlin Coroutines and Flow.

---

## 📂 Project Structure

```text
app/src/main/java/com/example/
├── MainActivity.kt                  # App entry point
├── crypto/                          # Cryptographic core
│   ├── ApkSignerManager.kt          # APK signing (v1, v2, v3, v4)
│   ├── ApkVerifierManager.kt        # APK signature verification
│   ├── KeystoreManager.kt           # Keystore generation & loading
│   ├── converter/                   # Keystore format converter engine
│   └── jks/                         # Custom JKS format provider
├── data/                            # Data access layer
│   ├── db/                          # Room Database, Entities, & DAOs
│   ├── model/                       # Data models & Certificate info
│   └── repository/                  # Keystore repository
├── ui/                              # Presentation layer
│   ├── MainScreen.kt                # Adaptive navigation shell
│   ├── components/                  # Reusable Compose UI components
│   ├── screens/                     # Feature screens:
│   │   ├── SignApkScreen.kt         # Sign APK screen
│   │   ├── VerifyApkScreen.kt       # Verify APK screen
│   │   ├── GenerateKeystoreScreen.kt# Keystore generator screen
│   │   ├── KeystoresScreen.kt       # Keystores manager screen
│   │   └── ConverterScreen.kt       # Keystore converter screen
│   ├── theme/                       # M3 Colors, Typography, Shapes
│   └── viewmodel/                   # Screen ViewModels
```

---

## 🛠️ Building & Running

### Prerequisites
- Android Studio Ladybug (or newer)
- Android SDK 36 (minSdk 24)
- JDK 17 or higher
- Gradle 8.x

### Build Commands

```bash
# Clone the repository
git clone <repo-url>
cd <project-folder>

# Build debug APK
gradle assembleDebug

# Run unit and Robolectric tests
gradle :app:testDebugUnitTest

# Install on connected device/emulator
gradle installDebug
```

---

## 📄 License

This project is licensed under the Apache License, Version 2.0. See [LICENSE](LICENSE) for details.
