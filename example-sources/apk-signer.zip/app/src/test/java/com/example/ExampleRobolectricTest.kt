package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.crypto.KeystoreManager
import com.example.data.model.KeystoreConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("APK Signer", appName)
  }

  @Test
  fun `generate and inspect keystore`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val testKeystoreFile = File(context.cacheDir, "unit_test_keystore.p12")
    if (testKeystoreFile.exists()) testKeystoreFile.delete()

    val config = KeystoreConfig(
      name = "Test Key",
      fileName = "unit_test_keystore.p12",
      alias = "test_alias",
      storePassword = "password123",
      keyPassword = "password123",
      useSamePassword = true,
      storeType = "PKCS12",
      keyAlgorithm = "RSA",
      keySize = 2048,
      validityYears = 10,
      commonName = "Test Developer",
      organization = "AI Studio",
      countryCode = "US"
    )

    val certInfo = KeystoreManager.generateKeystore(config, testKeystoreFile)
    assertTrue(testKeystoreFile.exists())
    assertTrue(testKeystoreFile.length() > 0)
    assertEquals("test_alias", certInfo.alias)
    assertTrue(certInfo.sha256Fingerprint.isNotEmpty())
    assertTrue(certInfo.subjectDn.contains("Test Developer"))

    val (loadedKs, storeType) = KeystoreManager.loadKeyStore(testKeystoreFile, "password123")
    assertNotNull(loadedKs)
    val aliases = KeystoreManager.getAliases(loadedKs)
    assertTrue(aliases.contains("test_alias"))

    testKeystoreFile.delete()
  }
}

