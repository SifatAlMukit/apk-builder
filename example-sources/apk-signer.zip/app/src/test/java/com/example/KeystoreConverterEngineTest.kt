package com.example

import com.example.crypto.KeystoreManager
import com.example.crypto.converter.*
import com.example.data.model.KeystoreConfig
import org.junit.Assert.*
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import java.io.File

@RunWith(RobolectricTestRunner::class)
class KeystoreConverterEngineTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var sourceP12File: File
    private val testPassword = "testPassword123!"
    private val testAlias = "testkey"

    @Before
    fun setup() {
        sourceP12File = tempFolder.newFile("source_test.p12")
        val config = KeystoreConfig(
            name = "Test Keystore",
            fileName = "source_test.p12",
            alias = testAlias,
            storePassword = testPassword,
            keyPassword = testPassword,
            storeType = "PKCS12",
            keyAlgorithm = "RSA",
            keySize = 2048,
            validityYears = 25,
            commonName = "Test Unit",
            organization = "Android PKI Test"
        )
        KeystoreManager.generateKeystore(config, sourceP12File)
        assertTrue(sourceP12File.exists())
        assertTrue(sourceP12File.length() > 0)
    }

    @Test
    fun testFormatDetectionAndInspection() {
        // Without password -> detected as PKCS12, requires password
        val inspectionNoPass = FormatDetector.detectAndInspect(sourceP12File, null)
        assertEquals(KeystoreFormat.PKCS12, inspectionNoPass.detectedFormat)
        assertTrue(inspectionNoPass.requiresPassword)
        assertFalse(inspectionNoPass.isPasswordVerified)

        // With password -> verified, aliases found
        val inspectionWithPass = FormatDetector.detectAndInspect(sourceP12File, testPassword)
        assertEquals(KeystoreFormat.PKCS12, inspectionWithPass.detectedFormat)
        assertTrue(inspectionWithPass.isPasswordVerified)
        assertEquals(1, inspectionWithPass.aliases.size)
        assertEquals(testAlias, inspectionWithPass.aliases.first().alias)
        assertEquals("RSA", inspectionWithPass.aliases.first().keyAlgorithm)
    }

    @Test
    fun testConvertPkcs12ToJks() {
        val inspection = FormatDetector.detectAndInspect(sourceP12File, testPassword)
        val outDir = tempFolder.newFolder("out_jks")
        val options = ConversionOptions(
            targetFormat = KeystoreFormat.JKS,
            targetStorePassword = "newJksPassword456!",
            useSamePassword = true
        )

        val result = KeystoreConverterEngine.convert(
            sourceFile = sourceP12File,
            sourceInspection = inspection,
            sourcePassword = testPassword,
            options = options,
            outputDirectory = outDir
        )

        assertTrue(result.errorMessage ?: "", result.success)
        assertTrue(result.verificationPassed)
        assertEquals(KeystoreFormat.JKS, result.targetFormat)
        assertTrue(result.outputFile.exists())
        assertTrue(result.outputFile.length() > 0)

        // Verify that the converted JKS can be inspected and loaded
        val jksInspection = FormatDetector.detectAndInspect(result.outputFile, "newJksPassword456!")
        assertEquals(KeystoreFormat.JKS, jksInspection.detectedFormat)
        assertTrue(jksInspection.isPasswordVerified)
        assertEquals(1, jksInspection.aliases.size)
        assertEquals(testAlias, jksInspection.aliases.first().alias)
    }

    @Test
    fun testConvertPkcs12ToPemFullBundle() {
        val inspection = FormatDetector.detectAndInspect(sourceP12File, testPassword)
        val outDir = tempFolder.newFolder("out_pem")
        val options = ConversionOptions(
            targetFormat = KeystoreFormat.PEM_FULL
        )

        val result = KeystoreConverterEngine.convert(
            sourceFile = sourceP12File,
            sourceInspection = inspection,
            sourcePassword = testPassword,
            options = options,
            outputDirectory = outDir
        )

        assertTrue(result.errorMessage ?: "", result.success)
        assertTrue(result.verificationPassed)
        val pemContent = result.outputFile.readText()
        assertTrue(pemContent.contains("-----BEGIN PRIVATE KEY-----") || pemContent.contains("-----BEGIN RSA PRIVATE KEY-----"))
        assertTrue(pemContent.contains("-----BEGIN CERTIFICATE-----"))
    }

    @Test
    fun testConvertPkcs12ToPublicCertPemAndDer() {
        val inspection = FormatDetector.detectAndInspect(sourceP12File, testPassword)
        val outDir = tempFolder.newFolder("out_certs")

        // 1. PEM_CERT
        val pemCertResult = KeystoreConverterEngine.convert(
            sourceFile = sourceP12File,
            sourceInspection = inspection,
            sourcePassword = testPassword,
            options = ConversionOptions(targetFormat = KeystoreFormat.PEM_CERT),
            outputDirectory = outDir
        )
        assertTrue(pemCertResult.success)
        assertTrue(pemCertResult.warnings.isNotEmpty()) // Warns about private key omission
        val pemText = pemCertResult.outputFile.readText()
        assertTrue(pemText.contains("-----BEGIN CERTIFICATE-----"))
        assertFalse(pemText.contains("PRIVATE KEY"))

        // 2. DER_CERT
        val derCertResult = KeystoreConverterEngine.convert(
            sourceFile = sourceP12File,
            sourceInspection = inspection,
            sourcePassword = testPassword,
            options = ConversionOptions(targetFormat = KeystoreFormat.DER_CERT),
            outputDirectory = outDir
        )
        assertTrue(derCertResult.success)
        assertTrue(derCertResult.verificationPassed)
        val derInspection = FormatDetector.detectAndInspect(derCertResult.outputFile, null)
        assertEquals(KeystoreFormat.DER_CERT, derInspection.detectedFormat)
    }
}
