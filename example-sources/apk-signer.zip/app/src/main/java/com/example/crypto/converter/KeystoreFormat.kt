package com.example.crypto.converter

/**
 * Supported formats for keystores, certificate containers, and key bundles.
 */
enum class KeystoreFormat(
    val displayName: String,
    val description: String,
    val defaultExtension: String,
    val mimeType: String,
    val supportsPrivateKey: Boolean,
    val supportsCertificate: Boolean,
    val supportsMultipleAliases: Boolean,
    val supportsCertChain: Boolean,
    val isBinary: Boolean,
    val category: FormatCategory
) {
    PKCS12(
        displayName = "PKCS#12 (.p12 / .pfx)",
        description = "Modern cross-platform industry standard for key pairs and certificates. Supported by Android, Java, iOS, and OpenSSL.",
        defaultExtension = "p12",
        mimeType = "application/x-pkcs12",
        supportsPrivateKey = true,
        supportsCertificate = true,
        supportsMultipleAliases = true,
        supportsCertChain = true,
        isBinary = true,
        category = FormatCategory.KEYSTORE
    ),
    JKS(
        displayName = "Java KeyStore (.jks / .keystore)",
        description = "Legacy Java KeyStore format traditionally used by Android Gradle builds and JDK toolchains.",
        defaultExtension = "jks",
        mimeType = "application/x-java-keystore",
        supportsPrivateKey = true,
        supportsCertificate = true,
        supportsMultipleAliases = true,
        supportsCertChain = true,
        isBinary = true,
        category = FormatCategory.KEYSTORE
    ),
    BKS(
        displayName = "Bouncy Castle KeyStore (.bks)",
        description = "Bouncy Castle proprietary format historically utilized on earlier Android systems and embedded Java environments.",
        defaultExtension = "bks",
        mimeType = "application/octet-stream",
        supportsPrivateKey = true,
        supportsCertificate = true,
        supportsMultipleAliases = true,
        supportsCertChain = true,
        isBinary = true,
        category = FormatCategory.KEYSTORE
    ),
    PEM_FULL(
        displayName = "PEM Key & Cert Bundle (.pem)",
        description = "Human-readable ASCII text containing both PKCS#8 private key and full X.509 certificate chain. Standard for Web servers and DevOps.",
        defaultExtension = "pem",
        mimeType = "application/x-pem-file",
        supportsPrivateKey = true,
        supportsCertificate = true,
        supportsMultipleAliases = false,
        supportsCertChain = true,
        isBinary = false,
        category = FormatCategory.PEM
    ),
    PEM_CERT(
        displayName = "X.509 Certificate PEM (.crt / .pem)",
        description = "Public certificate chain only in PEM armor. Does NOT contain private keys. Used for public verification and SSL truststores.",
        defaultExtension = "crt",
        mimeType = "application/x-x509-ca-cert",
        supportsPrivateKey = false,
        supportsCertificate = true,
        supportsMultipleAliases = false,
        supportsCertChain = true,
        isBinary = false,
        category = FormatCategory.CERTIFICATE
    ),
    PEM_KEY(
        displayName = "Private Key PEM (.key / .pem)",
        description = "Raw PKCS#8 private key in PEM format without certificates. Suitable for cryptographic engines and signing scripts.",
        defaultExtension = "key",
        mimeType = "application/pkcs8",
        supportsPrivateKey = true,
        supportsCertificate = false,
        supportsMultipleAliases = false,
        supportsCertChain = false,
        isBinary = false,
        category = FormatCategory.PRIVATE_KEY
    ),
    DER_CERT(
        displayName = "Binary DER Certificate (.der / .cer)",
        description = "Raw binary encoded X.509 certificate. Commonly used in hardware security modules, smart cards, and Windows systems.",
        defaultExtension = "der",
        mimeType = "application/x-x509-ca-cert",
        supportsPrivateKey = false,
        supportsCertificate = true,
        supportsMultipleAliases = false,
        supportsCertChain = false,
        isBinary = true,
        category = FormatCategory.CERTIFICATE
    );

    enum class FormatCategory(val label: String) {
        KEYSTORE("KeyStore Container"),
        PEM("PEM Bundle"),
        CERTIFICATE("Public Certificate"),
        PRIVATE_KEY("Private Key")
    }

    companion object {
        fun fromExtension(extension: String): KeystoreFormat? {
            val ext = extension.lowercase().removePrefix(".")
            return when (ext) {
                "p12", "pfx" -> PKCS12
                "jks", "keystore" -> JKS
                "bks" -> BKS
                "crt", "cer" -> PEM_CERT
                "key" -> PEM_KEY
                "der" -> DER_CERT
                "pem" -> PEM_FULL
                else -> null
            }
        }
    }
}
