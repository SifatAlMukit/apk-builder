package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.KeystoreManager
import com.example.data.db.AppDatabase
import com.example.data.db.KeystoreEntity
import com.example.data.model.CertificateInfo
import com.example.data.model.KeystoreConfig
import com.example.data.repository.KeystoreRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

sealed interface GenerateKeystoreUiState {
    data object Idle : GenerateKeystoreUiState
    data class Generating(val progressMessage: String) : GenerateKeystoreUiState
    data class Success(
        val entity: KeystoreEntity,
        val certificateInfo: CertificateInfo
    ) : GenerateKeystoreUiState
    data class Error(val message: String) : GenerateKeystoreUiState
}

class GenerateKeystoreViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KeystoreRepository = KeystoreRepository(
        AppDatabase.getDatabase(application).keystoreDao()
    )

    private val _uiState = MutableStateFlow<GenerateKeystoreUiState>(GenerateKeystoreUiState.Idle)
    val uiState: StateFlow<GenerateKeystoreUiState> = _uiState.asStateFlow()

    // Form State
    var name = MutableStateFlow("My Release Key")
    var alias = MutableStateFlow("release")
    var storePassword = MutableStateFlow("")
    var keyPassword = MutableStateFlow("")
    var useSamePassword = MutableStateFlow(true)
    var storeType = MutableStateFlow("PKCS12") // "PKCS12" or "JKS"
    var keyAlgorithm = MutableStateFlow("RSA") // "RSA" or "EC"
    var keySize = MutableStateFlow(2048)
    var validityYears = MutableStateFlow(25)

    // X.500 DN
    var commonName = MutableStateFlow("Android Developer")
    var organizationUnit = MutableStateFlow("Engineering")
    var organization = MutableStateFlow("App Studio")
    var city = MutableStateFlow("")
    var state = MutableStateFlow("")
    var countryCode = MutableStateFlow("US")

    fun applyPreset(presetName: String) {
        when (presetName) {
            "google_play" -> {
                storeType.value = "PKCS12"
                keyAlgorithm.value = "RSA"
                keySize.value = 2048
                validityYears.value = 25
            }
            "high_security" -> {
                storeType.value = "PKCS12"
                keyAlgorithm.value = "RSA"
                keySize.value = 4096
                validityYears.value = 30
            }
            "elliptic_curve" -> {
                storeType.value = "PKCS12"
                keyAlgorithm.value = "EC"
                keySize.value = 256
                validityYears.value = 25
            }
            "legacy_jks" -> {
                storeType.value = "JKS"
                keyAlgorithm.value = "RSA"
                keySize.value = 2048
                validityYears.value = 25
            }
        }
    }

    fun resetForm() {
        _uiState.value = GenerateKeystoreUiState.Idle
        storePassword.value = ""
        keyPassword.value = ""
    }

    fun generateKeystore() {
        val currentName = name.value.trim()
        val currentAlias = alias.value.trim()
        val currentStorePass = storePassword.value
        val currentKeyPass = if (useSamePassword.value) currentStorePass else keyPassword.value

        // Comprehensive validation
        if (currentName.isBlank()) {
            _uiState.value = GenerateKeystoreUiState.Error("Please enter a keystore name.")
            return
        }
        if (currentAlias.isBlank()) {
            _uiState.value = GenerateKeystoreUiState.Error("Please enter a key alias.")
            return
        }
        if (currentStorePass.length < 6) {
            _uiState.value = GenerateKeystoreUiState.Error("Keystore password must be at least 6 characters.")
            return
        }
        if (!useSamePassword.value && currentKeyPass.length < 6) {
            _uiState.value = GenerateKeystoreUiState.Error("Key alias password must be at least 6 characters.")
            return
        }
        if (countryCode.value.isNotBlank() && countryCode.value.trim().length != 2) {
            _uiState.value = GenerateKeystoreUiState.Error("Country Code must be exactly 2 letters (e.g. US, DE, CA).")
            return
        }

        viewModelScope.launch {
            _uiState.value = GenerateKeystoreUiState.Generating("Generating cryptographic keypair & X.509 certificate...")
            try {
                val (entity, certInfo) = withContext(Dispatchers.IO) {
                    val context = getApplication<Application>()
                    val ext = if (storeType.value.equals("JKS", ignoreCase = true)) "jks" else "p12"
                    val sanitizedName = currentName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
                    val fileName = "${sanitizedName}_${System.currentTimeMillis()}.$ext"

                    val dir = File(context.filesDir, "keystores").apply { mkdirs() }
                    val targetFile = File(dir, fileName)

                    val config = KeystoreConfig(
                        name = currentName,
                        fileName = fileName,
                        alias = currentAlias,
                        storePassword = currentStorePass,
                        keyPassword = currentKeyPass,
                        useSamePassword = useSamePassword.value,
                        storeType = storeType.value,
                        keyAlgorithm = keyAlgorithm.value,
                        keySize = keySize.value,
                        validityYears = validityYears.value,
                        commonName = commonName.value.trim(),
                        organizationUnit = organizationUnit.value.trim(),
                        organization = organization.value.trim(),
                        city = city.value.trim(),
                        state = state.value.trim(),
                        countryCode = countryCode.value.trim().uppercase()
                    )

                    val cert = KeystoreManager.generateKeystore(config, targetFile)

                    val newEntity = KeystoreEntity(
                        name = currentName,
                        fileName = fileName,
                        filePath = targetFile.absolutePath,
                        storeType = storeType.value,
                        aliases = currentAlias,
                        defaultAlias = currentAlias,
                        certificateDn = cert.subjectDn,
                        sha256Fingerprint = cert.sha256Fingerprint,
                        validUntil = cert.validUntil,
                        keyAlgorithm = cert.keyAlgorithm,
                        keySize = cert.keySize
                    )

                    val id = repository.insertKeystore(newEntity)
                    Pair(newEntity.copy(id = id), cert)
                }

                _uiState.value = GenerateKeystoreUiState.Success(entity, certInfo)
            } catch (e: Exception) {
                _uiState.value = GenerateKeystoreUiState.Error(
                    "Keystore generation failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
                )
            }
        }
    }

    fun exportGeneratedKeystore(destinationUri: Uri, entity: KeystoreEntity) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val sourceFile = File(entity.filePath)
                    val context = getApplication<Application>()
                    context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }
}
