package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "keystores")
data class KeystoreEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val fileName: String,
    val filePath: String,
    val storeType: String, // "PKCS12" or "JKS"
    val aliases: String, // comma-separated list of aliases
    val defaultAlias: String,
    val certificateDn: String, // Subject DN
    val sha256Fingerprint: String,
    val validUntil: Long,
    val keyAlgorithm: String = "RSA",
    val keySize: Int = 2048,
    val createdAt: Long = System.currentTimeMillis()
)
