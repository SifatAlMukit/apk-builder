package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.crypto.converter.*
import com.example.data.db.KeystoreEntity
import com.example.ui.components.FingerprintItem
import com.example.ui.components.PasswordInputField
import com.example.ui.components.StatusPill
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.ConverterStep
import com.example.ui.viewmodel.ConverterViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConverterScreen(
    viewModel: ConverterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val step by viewModel.step.collectAsStateWithLifecycle()
    val sourceFile by viewModel.sourceFile.collectAsStateWithLifecycle()
    val sourceFileName by viewModel.sourceFileName.collectAsStateWithLifecycle()
    val sourceFileSize by viewModel.sourceFileSize.collectAsStateWithLifecycle()
    val isAnalyzing by viewModel.isAnalyzing.collectAsStateWithLifecycle()
    val inspection by viewModel.sourceInspection.collectAsStateWithLifecycle()
    val options by viewModel.conversionOptions.collectAsStateWithLifecycle()
    val isConverting by viewModel.isConverting.collectAsStateWithLifecycle()
    val result by viewModel.conversionResult.collectAsStateWithLifecycle()
    val errorMessage by viewModel.errorMessage.collectAsStateWithLifecycle()
    val savedKeystores by viewModel.savedKeystores.collectAsStateWithLifecycle()
    val savedToLibrarySuccess by viewModel.savedToLibrarySuccess.collectAsStateWithLifecycle()

    var sourcePasswordInput by remember { mutableStateOf("") }
    var showAddToLibraryDialog by remember { mutableStateOf(false) }
    var libraryKeystoreName by remember { mutableStateOf("") }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val (name, size) = queryUriDetails(context, uri)
            viewModel.loadSourceFromUri(uri, name, size)
        }
    }

    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument(options.targetFormat.mimeType)
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.saveOutputToUri(context, uri)
            Toast.makeText(context, "File exported successfully", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Keystore Converter", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    if (step != ConverterStep.SELECT_SOURCE) {
                        IconButton(
                            onClick = {
                                viewModel.reset()
                                sourcePasswordInput = ""
                            },
                            modifier = Modifier.testTag("converter_reset_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset Converter")
                        }
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // Step Progress Indicator
            item {
                StepIndicatorRow(currentStep = step)
            }

            // Error Banner
            if (errorMessage != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                errorMessage ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            // STEP 1: SELECT SOURCE FILE
            if (step == ConverterStep.SELECT_SOURCE) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("converter_pick_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primaryContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.FileOpen,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                "Select Keystore or Certificate",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "Supports PKCS#12 (.p12, .pfx), JKS (.jks), BKS (.bks), PEM (.pem, .crt, .key), and binary DER (.der, .cer)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    filePickerLauncher.launch(arrayOf("*/*"))
                                },
                                modifier = Modifier.fillMaxWidth().testTag("converter_browse_button")
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Browse Storage")
                            }
                        }
                    }
                }

                // Or pick from saved keystores
                if (savedKeystores.isNotEmpty()) {
                    item {
                        Text(
                            "Or Select From Saved Keystores",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    items(savedKeystores) { ks ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.loadFromSavedKeystore(ks) },
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.VpnKey,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(ks.name, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        "${ks.storeType} • Alias: ${ks.defaultAlias}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Icon(
                                    Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // STEP 2: INSPECT SOURCE & UNLOCK
            if (step == ConverterStep.INSPECT_SOURCE) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.FindInPage,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        sourceFileName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        formatFileSize(sourceFileSize),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            if (isAnalyzing) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text("Analyzing format and probing cryptographic structure...", style = MaterialTheme.typography.bodySmall)
                                }
                            } else if (inspection != null) {
                                val insp = inspection!!

                                // Format badge
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                "Detected: ${insp.detectedFormat?.displayName ?: "Unknown Format"}",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                insp.detectionNote,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }

                                // Password needed?
                                if (insp.requiresPassword && !insp.isPasswordVerified) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        "Keystore Password Required",
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        "Enter the password to decrypt the container and extract aliases and keys.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))

                                    PasswordInputField(
                                        value = sourcePasswordInput,
                                        onValueChange = { sourcePasswordInput = it },
                                        label = "Source Keystore Password",
                                        modifier = Modifier.testTag("converter_source_password")
                                    )

                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = { viewModel.unlockWithPassword(sourcePasswordInput) },
                                        modifier = Modifier.fillMaxWidth().testTag("converter_unlock_button"),
                                        enabled = sourcePasswordInput.isNotBlank()
                                    ) {
                                        Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Unlock & Inspect Content")
                                    }
                                }

                                // If verified, display aliases & proceed button
                                if (insp.isPasswordVerified) {
                                    Spacer(modifier = Modifier.height(16.dp))
                                    Text(
                                        "Available Aliases (${insp.aliases.size})",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    insp.aliases.forEach { alias ->
                                        Surface(
                                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                        ) {
                                            Column(modifier = Modifier.padding(12.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        imageVector = if (alias.isKeyEntry) Icons.Default.VpnKey else Icons.Default.Verified,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(alias.alias, fontWeight = FontWeight.Bold)
                                                    Spacer(modifier = Modifier.weight(1f))
                                                    StatusPill(
                                                        text = if (alias.isKeyEntry) "Key Pair" else "Certificate",
                                                        isActive = true,
                                                        activeColor = if (alias.isKeyEntry) SuccessGreen else MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    "${alias.keyAlgorithm} ${alias.keySize}-bit • Chain: ${alias.certificateChainLength} cert(s)",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                if (alias.subjectDn.isNotBlank()) {
                                                    Text(
                                                        "Subject: ${alias.subjectDn}",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                if (alias.sha256Fingerprint.isNotBlank() && alias.sha256Fingerprint != "N/A") {
                                                    Spacer(modifier = Modifier.height(6.dp))
                                                    FingerprintItem("SHA-256", alias.sha256Fingerprint)
                                                }
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(16.dp))
                                    Button(
                                        onClick = { viewModel.proceedToConfigure() },
                                        modifier = Modifier.fillMaxWidth().testTag("converter_proceed_configure_button")
                                    ) {
                                        Text("Choose Destination Format")
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // STEP 3: CONFIGURE TARGET FORMAT & OPTIONS
            if (step == ConverterStep.CONFIGURE_TARGET) {
                val insp = inspection
                val srcFormat = insp?.detectedFormat

                // Destination format picker
                item {
                    Text(
                        "1. Choose Target Format",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        KeystoreFormat.entries.forEach { format ->
                            val isSelected = options.targetFormat == format
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.updateConversionOptions { it.copy(targetFormat = format) }
                                    },
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                                ),
                                border = if (isSelected) CardDefaults.outlinedCardBorder().copy(width = 2.dp) else null
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = isSelected,
                                        onClick = {
                                            viewModel.updateConversionOptions { it.copy(targetFormat = format) }
                                        }
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(format.displayName, fontWeight = FontWeight.Bold)
                                        Text(
                                            format.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Format Difference Warning Card
                item {
                    val targetFormat = options.targetFormat
                    if (srcFormat != null && srcFormat.supportsPrivateKey && !targetFormat.supportsPrivateKey) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.15f)),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(WarningAmber))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Lossy Conversion Notice", fontWeight = FontWeight.Bold, color = WarningAmber)
                                    Text(
                                        "The destination format (${targetFormat.displayName}) contains only public certificates. The private signing key will NOT be included in the output file.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    } else if (targetFormat == KeystoreFormat.PEM_KEY) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = WarningAmber.copy(alpha = 0.15f)),
                            border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(WarningAmber))
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = WarningAmber)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Private Key Only", fontWeight = FontWeight.Bold, color = WarningAmber)
                                    Text(
                                        "The exported PEM file will contain raw private keys without certificate chain identity info.",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }
                    }
                }

                // Alias selection (if multiple aliases available)
                if (insp != null && insp.aliases.size > 1) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("2. Alias Selection", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(8.dp))

                                if (options.targetFormat.supportsMultipleAliases) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.updateConversionOptions { it.copy(selectedAlias = null) } }
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = options.selectedAlias == null,
                                            onClick = { viewModel.updateConversionOptions { it.copy(selectedAlias = null) } }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Convert All Aliases (${insp.aliases.size} entries)")
                                    }
                                }

                                insp.aliases.forEach { aliasItem ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.updateConversionOptions { it.copy(selectedAlias = aliasItem.alias) } }
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        RadioButton(
                                            selected = options.selectedAlias == aliasItem.alias,
                                            onClick = { viewModel.updateConversionOptions { it.copy(selectedAlias = aliasItem.alias) } }
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("${aliasItem.alias} (${aliasItem.keyAlgorithm} ${aliasItem.keySize}-bit)")
                                    }
                                }
                            }
                        }
                    }
                }

                // Passwords & Options for Keystore target
                if (options.targetFormat.category == KeystoreFormat.FormatCategory.KEYSTORE) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("3. Target Keystore Security", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Spacer(modifier = Modifier.height(10.dp))

                                PasswordInputField(
                                    value = options.targetStorePassword,
                                    onValueChange = { pass ->
                                        viewModel.updateConversionOptions { it.copy(targetStorePassword = pass) }
                                    },
                                    label = "Destination Keystore Password",
                                    modifier = Modifier.testTag("converter_target_password")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.clickable {
                                        viewModel.updateConversionOptions { it.copy(useSamePassword = !it.useSamePassword) }
                                    }
                                ) {
                                    Checkbox(
                                        checked = options.useSamePassword,
                                        onCheckedChange = { same ->
                                            viewModel.updateConversionOptions { it.copy(useSamePassword = same) }
                                        }
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Use same password for key entries (Recommended)")
                                }

                                if (!options.useSamePassword) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    PasswordInputField(
                                        value = options.targetKeyPassword,
                                        onValueChange = { pass ->
                                            viewModel.updateConversionOptions { it.copy(targetKeyPassword = pass) }
                                        },
                                        label = "Destination Key Password",
                                        modifier = Modifier.testTag("converter_target_key_password")
                                    )
                                }
                            }
                        }
                    }
                }

                // Execute Conversion button
                item {
                    Button(
                        onClick = { viewModel.executeConversion() },
                        modifier = Modifier.fillMaxWidth().testTag("converter_execute_button"),
                        enabled = !isConverting && (
                                options.targetFormat.category != KeystoreFormat.FormatCategory.KEYSTORE || options.targetStorePassword.isNotBlank()
                                )
                    ) {
                        if (isConverting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Converting & Verifying...")
                        } else {
                            Icon(Icons.Default.Transform, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Convert to ${options.targetFormat.displayName}")
                        }
                    }
                }
            }

            // STEP 4: RESULT & POST-CONVERSION VERIFICATION
            if (step == ConverterStep.CONVERSION_RESULT && result != null) {
                val res = result!!
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("converter_result_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            // Header: Success Icon & Status
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .background(if (res.success && res.verificationPassed) SuccessGreen else ErrorRed),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (res.success && res.verificationPassed) Icons.Default.CheckCircle else Icons.Default.Error,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.surface
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        if (res.success && res.verificationPassed) "Conversion Succeeded" else "Conversion Failed",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (res.success && res.verificationPassed) SuccessGreen else ErrorRed
                                    )
                                    Text(
                                        "${res.sourceFormat.displayName} → ${res.targetFormat.displayName}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Verification check
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (res.verificationPassed) SuccessGreen.copy(alpha = 0.12f) else ErrorRed.copy(alpha = 0.12f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (res.verificationPassed) Icons.Default.Verified else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (res.verificationPassed) SuccessGreen else ErrorRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            if (res.verificationPassed) "Integrity Verified" else "Verification Warning",
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (res.verificationPassed) SuccessGreen else ErrorRed
                                        )
                                        Text(
                                            res.verificationDetails,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // Output File Info
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text("Output File Details", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text("File: ${res.outputFileName}", style = MaterialTheme.typography.bodySmall)
                                    Text("Size: ${formatFileSize(res.outputFileSize)}", style = MaterialTheme.typography.bodySmall)
                                    if (res.convertedAliases.isNotEmpty()) {
                                        Text("Aliases: ${res.convertedAliases.joinToString()}", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }

                            // Warnings
                            if (res.warnings.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(12.dp))
                                res.warnings.forEach { warning ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        verticalAlignment = Alignment.Top
                                    ) {
                                        Icon(Icons.Default.Info, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(warning, style = MaterialTheme.typography.bodySmall, color = WarningAmber)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { exportFileLauncher.launch(res.outputFileName) },
                                    modifier = Modifier.weight(1f).testTag("converter_save_file_button")
                                ) {
                                    Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Save File")
                                }

                                OutlinedButton(
                                    onClick = {
                                        val shareIntent = viewModel.getShareIntent()
                                        if (shareIntent != null) {
                                            context.startActivity(android.content.Intent.createChooser(shareIntent, "Share Converted File"))
                                        }
                                    },
                                    modifier = Modifier.weight(1f).testTag("converter_share_button")
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Share")
                                }
                            }

                            // Add to Keystore Library Button (if target is a KeyStore)
                            if (res.targetFormat.category == KeystoreFormat.FormatCategory.KEYSTORE) {
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        libraryKeystoreName = "Converted ${res.targetFormat.name}"
                                        showAddToLibraryDialog = true
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("converter_add_library_button"),
                                    enabled = !savedToLibrarySuccess
                                ) {
                                    Icon(
                                        if (savedToLibrarySuccess) Icons.Default.Check else Icons.Default.BookmarkAdd,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (savedToLibrarySuccess) "Added to Keystores Library!" else "Add to App Keystores Library")
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = {
                                    viewModel.reset()
                                    sourcePasswordInput = ""
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Convert Another File")
                            }
                        }
                    }
                }
            }
        }
    }

    // Add to library dialog
    if (showAddToLibraryDialog) {
        AlertDialog(
            onDismissRequest = { showAddToLibraryDialog = false },
            title = { Text("Save to Keystore Library") },
            text = {
                Column {
                    Text(
                        "Give this converted keystore a friendly name so you can select it when signing APKs.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = libraryKeystoreName,
                        onValueChange = { libraryKeystoreName = it },
                        label = { Text("Keystore Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("converter_library_name_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.saveToAppKeystoreLibrary(libraryKeystoreName)
                        showAddToLibraryDialog = false
                    },
                    modifier = Modifier.testTag("converter_confirm_add_library")
                ) {
                    Text("Save to Library")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddToLibraryDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun StepIndicatorRow(currentStep: ConverterStep) {
    val steps = listOf(
        ConverterStep.SELECT_SOURCE to "1. Select",
        ConverterStep.INSPECT_SOURCE to "2. Inspect",
        ConverterStep.CONFIGURE_TARGET to "3. Configure",
        ConverterStep.CONVERSION_RESULT to "4. Converted"
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEach { (step, label) ->
            val isActive = currentStep == step
            val isDone = currentStep.ordinal > step.ordinal

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = when {
                    isActive -> MaterialTheme.colorScheme.primaryContainer
                    isDone -> SuccessGreen.copy(alpha = 0.2f)
                    else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                }
            ) {
                Text(
                    text = label,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                    color = when {
                        isActive -> MaterialTheme.colorScheme.onPrimaryContainer
                        isDone -> SuccessGreen
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    }
                )
            }
        }
    }
}
