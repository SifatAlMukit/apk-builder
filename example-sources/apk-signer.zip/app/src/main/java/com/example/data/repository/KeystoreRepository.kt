package com.example.data.repository

import com.example.data.db.KeystoreDao
import com.example.data.db.KeystoreEntity
import kotlinx.coroutines.flow.Flow
import java.io.File

class KeystoreRepository(private val keystoreDao: KeystoreDao) {
    val allKeystores: Flow<List<KeystoreEntity>> = keystoreDao.getAllKeystores()

    suspend fun getKeystoreById(id: Long): KeystoreEntity? = keystoreDao.getKeystoreById(id)

    suspend fun insertKeystore(keystore: KeystoreEntity): Long = keystoreDao.insertKeystore(keystore)

    suspend fun updateKeystore(keystore: KeystoreEntity) = keystoreDao.updateKeystore(keystore)

    suspend fun deleteKeystore(keystore: KeystoreEntity) {
        // Also delete the physical file if it exists in private storage
        try {
            val file = File(keystore.filePath)
            if (file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {}
        keystoreDao.deleteKeystore(keystore)
    }

    suspend fun deleteKeystoreById(id: Long) {
        val keystore = keystoreDao.getKeystoreById(id)
        if (keystore != null) {
            deleteKeystore(keystore)
        }
    }
}
