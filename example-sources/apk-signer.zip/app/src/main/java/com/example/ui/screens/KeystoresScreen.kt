package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.crypto.KeystoreManager
import com.example.data.db.KeystoreEntity
import com.example.data.model.CertificateInfo
import com.example.ui.components.*
import com.example.ui.theme.KeyGold
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.KeystoreOperationState
import com.example.ui.viewmodel.KeystoresViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KeystoresScreen(
    viewModel: KeystoresViewModel,
    onNavigateToGenerate: () -> Unit,
    onConvertToFormat: ((KeystoreEntity) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keystores by viewModel.filteredKeystores.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val opState by viewModel.opState.collectAsStateWithLifecycle()
    val selectedCertDetails by viewModel.selectedKeystoreDetails.collectAsStateWithLifecycle()

    var showImportDialog by remember { mutableStateOf(false) }
    var importedUri by remember { mutableStateOf<Uri?>(null) }
    var importFriendlyName by remember { mutableStateOf("") }
    var importPassword by remember { mutableStateOf("") }

    var keystoreToExport by remember { mutableStateOf<KeystoreEntity?>(null) }
    var keystoreToDelete by remember { mutableStateOf<KeystoreEntity?>(null) }
    var keystoreToInspect by remember { mutableStateOf<KeystoreEntity?>(null) }
    var inspectPassword by remember { mutableStateOf("") }
    var showInspectPasswordPrompt by remember { mutableStateOf(false) }

    // File pickers
    val importFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            importedUri = uri
            val (name, _) = queryUriDetails(context, uri)
            importFriendlyName = name.substringBeforeLast(".")
            showImportDialog = true
        }
    }

    val exportFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null && keystoreToExport != null) {
            viewModel.exportKeystoreToUri(keystoreToExport!!, uri)
            keystoreToExport = null
        }
    }

    // Delete Confirmation
    ConfirmationDialog(
        show = keystoreToDelete != null,
        title = "Delete Keystore?",
        message = "Are you sure you want to delete '${keystoreToDelete?.name}'? The private key will be removed permanently.",
        confirmButtonText = "Delete",
        isDestructive = true,
        onConfirm = {
            keystoreToDelete?.let { viewModel.deleteKeystore(it) }
            keystoreToDelete = null
        },
        onDismiss = { keystoreToDelete = null }
    )

    // Password Prompt to inspect details
    if (showInspectPasswordPrompt && keystoreToInspect != null) {
        AlertDialog(
            onDismissRequest = {
                showInspectPasswordPrompt = false
                inspectPassword = ""
            },
            title = { Text("Unlock Keystore") },
            text = {
                Column {
                    Text(
                        "Enter the password for '${keystoreToInspect?.name}' to inspect all certificate attributes and fingerprints:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    PasswordInputField(
                        value = inspectPassword,
                        onValueChange = { inspectPassword = it },
                        label = "Keystore Password",
                        testTag = "inspect_password_input"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val ks = keystoreToInspect!!
                        showInspectPasswordPrompt = false
                        viewModel.loadCertificateDetails(ks, inspectPassword)
                        inspectPassword = ""
                    },
                    enabled = inspectPassword.isNotBlank(),
                    modifier = Modifier.testTag("unlock_keystore_button")
                ) {
                    Text("Unlock & View")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showInspectPasswordPrompt = false
                    inspectPassword = ""
                }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Detailed Certificate View Dialog
    if (selectedCertDetails != null) {
        CertificateDetailsDialog(
            certInfo = selectedCertDetails!!,
            onDismiss = { viewModel.dismissCertificateDetails() }
        )
    }

    // Import Keystore Dialog
    if (showImportDialog && importedUri != null) {
        AlertDialog(
            onDismissRequest = {
                showImportDialog = false
                importedUri = null
                importPassword = ""
            },
            title = { Text("Import Keystore") },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "Configure and unlock the keystore file:",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = importFriendlyName,
                        onValueChange = { importFriendlyName = it },
                        label = { Text("Friendly Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("import_name_input"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    PasswordInputField(
                        value = importPassword,
                        onValueChange = { importPassword = it },
                        label = "Keystore Password",
                        placeholder = "Password required to verify key",
                        testTag = "import_password_input"
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val uri = importedUri!!
                        viewModel.importKeystore(uri, importFriendlyName, importPassword)
                        showImportDialog = false
                        importedUri = null
                        importPassword = ""
                    },
                    enabled = importPassword.isNotBlank(),
                    modifier = Modifier.testTag("submit_import_button")
                ) {
                    Text("Import & Verify")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showImportDialog = false
                    importedUri = null
                    importPassword = ""
                }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.VpnKey,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Keystores", fontWeight = FontWeight.Bold)
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            importFileLauncher.launch(arrayOf("*/*"))
                        },
                        modifier = Modifier.testTag("import_keystore_action_button")
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = "Import Keystore")
                    }
                    IconButton(
                        onClick = onNavigateToGenerate,
                        modifier = Modifier.testTag("create_keystore_action_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "New Keystore")
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.onSearchQueryChanged(it) },
                placeholder = { Text("Search by name, alias, or DN...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear search")
                        }
                    }
                } else null,
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("search_keystores_input"),
                shape = RoundedCornerShape(12.dp)
            )

            // Operation State Banner
            when (opState) {
                is KeystoreOperationState.Loading -> {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp))
                }
                is KeystoreOperationState.Error -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                (opState as KeystoreOperationState.Error).message,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { viewModel.clearOpState() }) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }
                is KeystoreOperationState.Success -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SuccessGreen.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                (opState as KeystoreOperationState.Success).message,
                                color = SuccessGreen,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { viewModel.clearOpState() }) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }
                else -> {}
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Keystores List
            if (keystores.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.VpnKey,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (searchQuery.isBlank()) "No Keystores Available" else "No matching keystores",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Generate a new cryptographic keystore or import your existing .jks / .p12 file.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = onNavigateToGenerate,
                                modifier = Modifier.testTag("empty_generate_keystore_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Generate Keystore")
                            }
                            OutlinedButton(
                                onClick = { importFileLauncher.launch(arrayOf("*/*")) },
                                modifier = Modifier.testTag("empty_import_keystore_button")
                            ) {
                                Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Import")
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(keystores.size) { index ->
                        val item = keystores[index]
                        KeystoreListItemCard(
                            entity = item,
                            onInspect = {
                                keystoreToInspect = item
                                showInspectPasswordPrompt = true
                            },
                            onExport = {
                                keystoreToExport = item
                                exportFileLauncher.launch(item.fileName)
                            },
                            onConvert = if (onConvertToFormat != null) { { onConvertToFormat(item) } } else null,
                            onDelete = {
                                keystoreToDelete = item
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun KeystoreListItemCard(
    entity: KeystoreEntity,
    onInspect: () -> Unit,
    onExport: () -> Unit,
    onConvert: (() -> Unit)? = null,
    onDelete: () -> Unit
) {
    val isExpired = System.currentTimeMillis() > entity.validUntil
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val validUntilStr = remember(entity.validUntil) {
        if (entity.validUntil > 0) dateFormat.format(Date(entity.validUntil)) else "Unknown"
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("keystore_card_${entity.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            entity.name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        StatusPill(
                            text = if (isExpired) "Expired" else "Active",
                            isActive = !isExpired,
                            inactiveColor = MaterialTheme.colorScheme.error
                        )
                    }
                    Text(
                        "Alias: ${entity.defaultAlias} • ${entity.keyAlgorithm} ${entity.keySize}-bit",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                StatusPill(entity.storeType, isActive = true)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // SHA-256 Fingerprint preview
            if (entity.sha256Fingerprint.isNotBlank()) {
                FingerprintItem(
                    label = "SHA-256 Fingerprint",
                    value = entity.sha256Fingerprint
                )
                Spacer(modifier = Modifier.height(10.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Valid until: $validUntilStr",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = onInspect, modifier = Modifier.testTag("view_keystore_details_button_${entity.id}")) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Details")
                    }
                    if (onConvert != null) {
                        IconButton(onClick = onConvert, modifier = Modifier.testTag("convert_keystore_button_${entity.id}")) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Convert Format", modifier = Modifier.size(18.dp))
                        }
                    }
                    IconButton(onClick = onExport, modifier = Modifier.testTag("export_keystore_button_${entity.id}")) {
                        Icon(Icons.Default.Download, contentDescription = "Export Keystore", modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_keystore_button_${entity.id}")) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete Keystore", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun CertificateDetailsDialog(
    certInfo: CertificateInfo,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = SuccessGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Certificate Details", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 450.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Text("Distinguished Name (Subject)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Text(certInfo.subjectDn, style = MaterialTheme.typography.bodySmall)
                }

                item {
                    Text("Issuer", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    Text(certInfo.issuerDn, style = MaterialTheme.typography.bodySmall)
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Key Spec", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text("${certInfo.keyAlgorithm} (${certInfo.keySize}-bit)", style = MaterialTheme.typography.bodySmall)
                        }
                        Column {
                            Text("Signature Alg", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(certInfo.signatureAlgorithm, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("Valid From", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(dateFormat.format(Date(certInfo.validFrom)), style = MaterialTheme.typography.bodySmall)
                        }
                        Column {
                            Text("Valid Until", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                            Text(dateFormat.format(Date(certInfo.validUntil)), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                item {
                    Divider(modifier = Modifier.padding(vertical = 4.dp))
                    Text("Fingerprints", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                }

                item {
                    FingerprintItem("SHA-256", certInfo.sha256Fingerprint)
                }

                item {
                    FingerprintItem("SHA-1", certInfo.sha1Fingerprint)
                }

                item {
                    FingerprintItem("MD5", certInfo.md5Fingerprint)
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
