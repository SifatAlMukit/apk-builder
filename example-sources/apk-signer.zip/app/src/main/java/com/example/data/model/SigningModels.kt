package com.example.data.model

data class SigningConfig(
    val v1SigningEnabled: Boolean = true,
    val v2SigningEnabled: Boolean = true,
    val v3SigningEnabled: Boolean = true,
    val v4SigningEnabled: Boolean = false,
    val overwriteOriginal: Boolean = false
)

data class SigningResult(
    val success: Boolean,
    val outputApkPath: String = "",
    val outputApkName: String = "",
    val outputApkSize: Long = 0L,
    val errorMessage: String? = null,
    val v1Signed: Boolean = false,
    val v2Signed: Boolean = false,
    val v3Signed: Boolean = false,
    val v4Signed: Boolean = false,
    val signerCertificates: List<CertificateInfo> = emptyList()
)

data class ApkVerificationInfo(
    val apkFileName: String,
    val apkFileSize: Long,
    val isVerified: Boolean,
    val v1Verified: Boolean,
    val v2Verified: Boolean,
    val v3Verified: Boolean,
    val v4Verified: Boolean,
    val signers: List<CertificateInfo>,
    val warnings: List<String> = emptyList(),
    val errors: List<String> = emptyList()
)
