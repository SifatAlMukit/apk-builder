package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.db.KeystoreEntity
import com.example.ui.components.*
import com.example.ui.theme.KeyGold
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.SignApkViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignApkScreen(
    viewModel: SignApkViewModel,
    onNavigateToKeystores: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val savedKeystores by viewModel.savedKeystores.collectAsStateWithLifecycle()
    val selectedApkUri by viewModel.selectedApkUri.collectAsStateWithLifecycle()
    val selectedApkName by viewModel.selectedApkName.collectAsStateWithLifecycle()
    val selectedApkSize by viewModel.selectedApkSize.collectAsStateWithLifecycle()
    val inputVerification by viewModel.inputApkVerification.collectAsStateWithLifecycle()

    val selectedKeystore by viewModel.selectedKeystore.collectAsStateWithLifecycle()
    val availableAliases by viewModel.availableAliases.collectAsStateWithLifecycle()
    val selectedAlias by viewModel.selectedAlias.collectAsStateWithLifecycle()

    val keystorePassword by viewModel.keystorePassword.collectAsStateWithLifecycle()
    val keyPassword by viewModel.keyPassword.collectAsStateWithLifecycle()
    val useSamePassword by viewModel.useSamePassword.collectAsStateWithLifecycle()

    val v1Enabled by viewModel.v1Enabled.collectAsStateWithLifecycle()
    val v2Enabled by viewModel.v2Enabled.collectAsStateWithLifecycle()
    val v3Enabled by viewModel.v3Enabled.collectAsStateWithLifecycle()
    val v4Enabled by viewModel.v4Enabled.collectAsStateWithLifecycle()
    val overwriteOriginal by viewModel.overwriteOriginal.collectAsStateWithLifecycle()

    val isSigning by viewModel.isSigning.collectAsStateWithLifecycle()
    val progressStep by viewModel.progressStep.collectAsStateWithLifecycle()
    val progressFraction by viewModel.progressFraction.collectAsStateWithLifecycle()
    val signingResult by viewModel.signingResult.collectAsStateWithLifecycle()
    val generalError by viewModel.generalError.collectAsStateWithLifecycle()
    val showOverwriteConfirmation by viewModel.showOverwriteConfirmation.collectAsStateWithLifecycle()

    var showKeystorePicker by remember { mutableStateOf(false) }
    var showAdvancedOptions by remember { mutableStateOf(false) }

    // File pickers
    val apkPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val (name, size) = queryUriDetails(context, uri)
            viewModel.selectApk(uri, name, size)
        }
    }

    val saveApkLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/vnd.android.package-archive")
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.saveSignedApkToUri(uri)
            Toast.makeText(context, "Saved signed APK to device storage!", Toast.LENGTH_LONG).show()
        }
    }

    ConfirmationDialog(
        show = showOverwriteConfirmation,
        title = "Overwrite Original APK?",
        message = "Are you sure you want to overwrite '${selectedApkName}'? This action cannot be undone.",
        confirmButtonText = "Overwrite & Sign",
        isDestructive = true,
        onConfirm = { viewModel.confirmOverwriteAndSign() },
        onDismiss = { viewModel.dismissOverwriteConfirmation() }
    )

    // Keystore Selector Dialog
    if (showKeystorePicker) {
        AlertDialog(
            onDismissRequest = { showKeystorePicker = false },
            title = { Text("Select Keystore") },
            text = {
                if (savedKeystores.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            "No saved keystores found.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                showKeystorePicker = false
                                onNavigateToKeystores()
                            }
                        ) {
                            Text("Manage / Import Keystore")
                        }
                    }
                } else {
                    LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 350.dp)) {
                        items(savedKeystores.size) { index ->
                            val ks = savedKeystores[index]
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        viewModel.selectKeystore(ks)
                                        showKeystorePicker = false
                                    },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (selectedKeystore?.id == ks.id)
                                        MaterialTheme.colorScheme.primaryContainer
                                    else
                                        MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            ks.name,
                                            fontWeight = FontWeight.Bold,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        StatusPill(ks.storeType, isActive = true)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "Alias: ${ks.defaultAlias}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showKeystorePicker = false }) {
                    Text("Close")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Sign APK", fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // General Error Banner
            if (generalError != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    generalError ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                            IconButton(onClick = { viewModel.clearGeneralError() }) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss")
                            }
                        }
                    }
                }
            }

            // Step 1: Select APK Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("select_apk_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "1. Select APK File",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Button(
                                onClick = {
                                    apkPickerLauncher.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
                                },
                                modifier = Modifier.testTag("choose_apk_button")
                            ) {
                                Icon(Icons.Default.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (selectedApkUri == null) "Browse APK" else "Change")
                            }
                        }

                        if (selectedApkUri != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(
                                            Icons.Default.Android,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                selectedApkName,
                                                fontWeight = FontWeight.SemiBold,
                                                style = MaterialTheme.typography.bodyMedium
                                            )
                                            Text(
                                                formatFileSize(selectedApkSize),
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }

                                    // Inspection preview of input APK
                                    if (inputVerification != null) {
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("Current State:", style = MaterialTheme.typography.labelSmall)
                                            if (inputVerification?.isVerified == true) {
                                                StatusPill("Signed", isActive = true)
                                            } else {
                                                StatusPill("Unsigned / Unaligned", isActive = false, inactiveColor = WarningAmber)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Step 2: Select Keystore & Credentials
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("select_keystore_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "2. Signing Keystore",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            OutlinedButton(
                                onClick = { showKeystorePicker = true },
                                modifier = Modifier.testTag("choose_keystore_button")
                            ) {
                                Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (selectedKeystore == null) "Select Keystore" else "Change")
                            }
                        }

                        if (selectedKeystore != null) {
                            val ks = selectedKeystore!!
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(ks.name, fontWeight = FontWeight.Bold)
                                            Text(
                                                "Format: ${ks.storeType} • ${ks.keyAlgorithm} ${ks.keySize}-bit",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        StatusPill(ks.storeType, isActive = true)
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Password Input
                            PasswordInputField(
                                value = keystorePassword,
                                onValueChange = {
                                    viewModel.keystorePassword.value = it
                                    viewModel.unlockKeystoreAliases()
                                },
                                label = "Keystore Password",
                                placeholder = "Enter password to unlock keys",
                                testTag = "keystore_password_input"
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Alias Selection
                            if (availableAliases.isNotEmpty()) {
                                Text(
                                    "Key Alias",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    availableAliases.forEach { aliasName ->
                                        FilterChip(
                                            selected = selectedAlias == aliasName,
                                            onClick = { viewModel.selectedAlias.value = aliasName },
                                            label = { Text(aliasName) },
                                            leadingIcon = if (selectedAlias == aliasName) {
                                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                            } else null
                                        )
                                    }
                                }
                            } else {
                                OutlinedTextField(
                                    value = selectedAlias,
                                    onValueChange = { viewModel.selectedAlias.value = it },
                                    label = { Text("Key Alias") },
                                    placeholder = { Text("e.g. upload, release") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth().testTag("alias_text_field"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Use same password toggle
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    viewModel.useSamePassword.value = !useSamePassword
                                }
                            ) {
                                Checkbox(
                                    checked = useSamePassword,
                                    onCheckedChange = { viewModel.useSamePassword.value = it }
                                )
                                Text(
                                    "Key password is same as keystore password",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            if (!useSamePassword) {
                                Spacer(modifier = Modifier.height(4.dp))
                                PasswordInputField(
                                    value = keyPassword,
                                    onValueChange = { viewModel.keyPassword.value = it },
                                    label = "Key Alias Password",
                                    placeholder = "Enter alias password",
                                    testTag = "key_password_input"
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "No keystore selected. Choose an existing keystore or generate a new one.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Step 3: Signature Scheme Options
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                showAdvancedOptions = !showAdvancedOptions
                            },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "3. Signature Schemes",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "v1 (JAR) + v2 (Full APK) + v3 (Rotation)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { showAdvancedOptions = !showAdvancedOptions }) {
                                Icon(
                                    imageVector = if (showAdvancedOptions) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                    contentDescription = "Toggle signature options"
                                )
                            }
                        }

                        AnimatedVisibility(visible = showAdvancedOptions) {
                            Column(modifier = Modifier.padding(top = 12.dp)) {
                                Divider()
                                Spacer(modifier = Modifier.height(12.dp))

                                SchemeToggleRow(
                                    title = "v1 Scheme (JAR Signing)",
                                    description = "Required for backwards compatibility with Android < 7.0",
                                    checked = v1Enabled,
                                    onCheckedChange = { viewModel.v1Enabled.value = it }
                                )

                                SchemeToggleRow(
                                    title = "v2 Scheme (APK Signing Block)",
                                    description = "Fast verification, tamper proof, standard for Android 7.0+",
                                    checked = v2Enabled,
                                    onCheckedChange = { viewModel.v2Enabled.value = it }
                                )

                                SchemeToggleRow(
                                    title = "v3 Scheme (Key Rotation)",
                                    description = "Enables key rotation capabilities for Android 9.0+",
                                    checked = v3Enabled,
                                    onCheckedChange = { viewModel.v3Enabled.value = it }
                                )

                                SchemeToggleRow(
                                    title = "v4 Scheme (Streaming)",
                                    description = "Produces .idsig companion file for Android 11+ ADB streaming",
                                    checked = v4Enabled,
                                    onCheckedChange = { viewModel.v4Enabled.value = it }
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Divider()
                                Spacer(modifier = Modifier.height(8.dp))

                                // Overwrite toggle
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            "Overwrite original APK",
                                            fontWeight = FontWeight.SemiBold,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Text(
                                            "Default preserves original file and creates a new signed copy",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = overwriteOriginal,
                                        onCheckedChange = { viewModel.overwriteOriginal.value = it }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Progress Bar while signing
            if (isSigning) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 3.dp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text("Signing in progress...", fontWeight = FontWeight.Bold)
                                    Text(
                                        progressStep,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            LinearProgressIndicator(
                                progress = { progressFraction },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                        }
                    }
                }
            }

            // Sign Button
            item {
                Button(
                    onClick = { viewModel.requestSign() },
                    enabled = !isSigning && selectedApkUri != null && selectedKeystore != null && keystorePassword.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("sign_apk_primary_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Draw, contentDescription = null)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text("Sign APK Now", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Signing Result Card
            if (signingResult != null) {
                item {
                    val result = signingResult!!
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("signing_result_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (result.success)
                                MaterialTheme.colorScheme.surface
                            else
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(CircleShape)
                                        .background(if (result.success) SuccessGreen else MaterialTheme.colorScheme.error),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (result.success) Icons.Default.Check else Icons.Default.Close,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.surface
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        if (result.success) "Signing Succeeded!" else "Signing Failed",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = if (result.success) SuccessGreen else MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        if (result.success) "Output APK is signed and verified" else (result.errorMessage ?: "Unknown error"),
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }

                            if (result.success) {
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    SchemeBadge("v1 (JAR)", isEnabled = result.v1Signed)
                                    SchemeBadge("v2 (APK Block)", isEnabled = result.v2Signed)
                                    SchemeBadge("v3 (Rotation)", isEnabled = result.v3Signed)
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    "Output Size: ${formatFileSize(result.outputApkSize)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (result.signerCertificates.isNotEmpty()) {
                                    val cert = result.signerCertificates.first()
                                    Spacer(modifier = Modifier.height(10.dp))
                                    FingerprintItem("SHA-256 Fingerprint", cert.sha256Fingerprint)
                                }

                                Spacer(modifier = Modifier.height(16.dp))

                                // Action Buttons: Save, Share, Install
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            saveApkLauncher.launch(result.outputApkName.ifBlank { "signed_${selectedApkName}" })
                                        },
                                        modifier = Modifier.weight(1f).testTag("save_signed_apk_button")
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Save APK")
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val shareIntent = viewModel.getShareIntent()
                                            if (shareIntent != null) {
                                                context.startActivity(Intent.createChooser(shareIntent, "Share Signed APK"))
                                            }
                                        },
                                        modifier = Modifier.weight(1f).testTag("share_signed_apk_button")
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Share")
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = {
                                        val installIntent = viewModel.getInstallIntent()
                                        if (installIntent != null) {
                                            try {
                                                context.startActivity(installIntent)
                                            } catch (e: Exception) {
                                                Toast.makeText(context, "Install failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("install_signed_apk_button")
                                ) {
                                    Icon(Icons.Default.InstallMobile, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Install APK on Device")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SchemeToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text(description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

fun queryUriDetails(context: Context, uri: Uri): Pair<String, Long> {
    var name = "app.apk"
    var size = 0L
    try {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex != -1) name = cursor.getString(nameIndex) ?: "app.apk"
                if (sizeIndex != -1) size = cursor.getLong(sizeIndex)
            }
        }
    } catch (_: Exception) {}
    return Pair(name, size)
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    val value = bytes / Math.pow(1024.0, digitGroups.toDouble())
    return "%.1f %s".format(value, units[digitGroups])
}
