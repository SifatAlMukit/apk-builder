package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.KeystoreManager
import com.example.data.db.AppDatabase
import com.example.data.db.KeystoreEntity
import com.example.data.model.CertificateInfo
import com.example.data.repository.KeystoreRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

sealed interface KeystoreOperationState {
    data object Idle : KeystoreOperationState
    data class Loading(val message: String) : KeystoreOperationState
    data class Success(val message: String) : KeystoreOperationState
    data class Error(val message: String) : KeystoreOperationState
}

class KeystoresViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KeystoreRepository = KeystoreRepository(
        AppDatabase.getDatabase(application).keystoreDao()
    )

    val keystores: StateFlow<List<KeystoreEntity>> = repository.allKeystores
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _opState = MutableStateFlow<KeystoreOperationState>(KeystoreOperationState.Idle)
    val opState: StateFlow<KeystoreOperationState> = _opState.asStateFlow()

    private val _selectedKeystoreDetails = MutableStateFlow<CertificateInfo?>(null)
    val selectedKeystoreDetails: StateFlow<CertificateInfo?> = _selectedKeystoreDetails.asStateFlow()

    val filteredKeystores: StateFlow<List<KeystoreEntity>> = combine(keystores, _searchQuery) { list, query ->
        if (query.isBlank()) {
            list
        } else {
            list.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.defaultAlias.contains(query, ignoreCase = true) ||
                it.certificateDn.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun clearOpState() {
        _opState.value = KeystoreOperationState.Idle
    }

    /**
     * Imports an existing keystore (.jks, .p12, .keystore) from a user selected Uri.
     */
    fun importKeystore(uri: Uri, friendlyName: String, password: String) {
        viewModelScope.launch {
            _opState.value = KeystoreOperationState.Loading("Reading and validating keystore...")
            try {
                withContext(Dispatchers.IO) {
                    val context = getApplication<Application>()
                    val contentResolver = context.contentResolver

                    // Generate a safe unique filename in private app storage
                    val keystoreDir = File(context.filesDir, "keystores").apply { mkdirs() }
                    val cleanName = friendlyName.trim().replace(Regex("[^a-zA-Z0-9._-]"), "_")
                    val targetFile = File(keystoreDir, "${cleanName}_${System.currentTimeMillis()}.keystore")

                    // Copy bytes from SAF stream to private file
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(targetFile).use { output ->
                            input.copyTo(output)
                        }
                    } ?: throw IllegalStateException("Could not read from selected file.")

                    // Validate password and inspect contents
                    val (keyStore, storeType) = KeystoreManager.loadKeyStore(targetFile, password)
                    val aliases = KeystoreManager.getAliases(keyStore)

                    if (aliases.isEmpty()) {
                        targetFile.delete()
                        throw IllegalStateException("The keystore does not contain any key aliases.")
                    }

                    val defaultAlias = aliases.first()
                    val certInfo = KeystoreManager.getCertificateInfo(keyStore, defaultAlias)
                        ?: throw IllegalStateException("Failed to parse certificate for alias '$defaultAlias'")

                    val entity = KeystoreEntity(
                        name = if (friendlyName.isNotBlank()) friendlyName else targetFile.nameWithoutExtension,
                        fileName = targetFile.name,
                        filePath = targetFile.absolutePath,
                        storeType = storeType,
                        aliases = aliases.joinToString(","),
                        defaultAlias = defaultAlias,
                        certificateDn = certInfo.subjectDn,
                        sha256Fingerprint = certInfo.sha256Fingerprint,
                        validUntil = certInfo.validUntil,
                        keyAlgorithm = certInfo.keyAlgorithm,
                        keySize = certInfo.keySize
                    )

                    repository.insertKeystore(entity)
                }
                _opState.value = KeystoreOperationState.Success("Keystore imported and verified successfully!")
            } catch (e: Exception) {
                _opState.value = KeystoreOperationState.Error(
                    e.localizedMessage ?: "Failed to import keystore. Check password and format."
                )
            }
        }
    }

    /**
     * Inspects a saved keystore by loading its certificates.
     */
    fun loadCertificateDetails(entity: KeystoreEntity, password: String) {
        viewModelScope.launch {
            _opState.value = KeystoreOperationState.Loading("Loading certificate details...")
            try {
                val certInfo = withContext(Dispatchers.IO) {
                    val file = File(entity.filePath)
                    if (!file.exists()) {
                        throw IllegalStateException("Keystore file not found at: ${entity.filePath}")
                    }
                    val (keyStore, _) = KeystoreManager.loadKeyStore(file, password)
                    KeystoreManager.getCertificateInfo(keyStore, entity.defaultAlias)
                        ?: throw IllegalStateException("Unable to retrieve certificate for alias ${entity.defaultAlias}")
                }
                _selectedKeystoreDetails.value = certInfo
                _opState.value = KeystoreOperationState.Idle
            } catch (e: Exception) {
                _opState.value = KeystoreOperationState.Error(
                    "Failed to unlock keystore: ${e.localizedMessage ?: "Invalid password"}"
                )
            }
        }
    }

    fun dismissCertificateDetails() {
        _selectedKeystoreDetails.value = null
    }

    /**
     * Exports a keystore file to user-selected destination Uri.
     */
    fun exportKeystoreToUri(entity: KeystoreEntity, destinationUri: Uri) {
        viewModelScope.launch {
            _opState.value = KeystoreOperationState.Loading("Exporting keystore...")
            try {
                withContext(Dispatchers.IO) {
                    val sourceFile = File(entity.filePath)
                    if (!sourceFile.exists()) {
                        throw IllegalStateException("Source keystore file no longer exists.")
                    }
                    val context = getApplication<Application>()
                    context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                        sourceFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    } ?: throw IllegalStateException("Could not open destination for writing.")
                }
                _opState.value = KeystoreOperationState.Success("Keystore exported successfully!")
            } catch (e: Exception) {
                _opState.value = KeystoreOperationState.Error("Export failed: ${e.localizedMessage}")
            }
        }
    }

    fun deleteKeystore(entity: KeystoreEntity) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    repository.deleteKeystore(entity)
                }
                _opState.value = KeystoreOperationState.Success("Keystore deleted.")
            } catch (e: Exception) {
                _opState.value = KeystoreOperationState.Error("Delete failed: ${e.localizedMessage}")
            }
        }
    }
}
