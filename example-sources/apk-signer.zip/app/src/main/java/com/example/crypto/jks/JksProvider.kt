package com.example.crypto.jks

import java.security.Provider
import java.security.Security

/**
 * Custom JCA Provider that registers the JKS KeyStore format on Android.
 */
class JksProvider : Provider("JKS", 1.0, "Pure Kotlin Java KeyStore (JKS) Provider") {
    init {
        put("KeyStore.JKS", JksKeyStoreSpi::class.java.name)
        put("KeyStore.jks", JksKeyStoreSpi::class.java.name)
        put("Alg.Alias.KeyStore.jks", "JKS")
    }

    companion object {
        const val PROVIDER_NAME = "JKS"

        @Volatile
        private var isRegistered = false

        /**
         * Ensures that the JKS Provider is registered with highest precedence in JCA.
         */
        fun register() {
            if (!isRegistered) {
                synchronized(this) {
                    if (!isRegistered) {
                        try {
                            val provider = JksProvider()
                            // Insert at position 1 so KeyStore.getInstance("JKS") resolves immediately
                            Security.removeProvider(PROVIDER_NAME)
                            val pos = Security.insertProviderAt(provider, 1)
                            if (pos == -1) {
                                Security.addProvider(provider)
                            }
                        } catch (_: Exception) {
                            try {
                                Security.addProvider(JksProvider())
                            } catch (_: Exception) {}
                        }
                        isRegistered = true
                    }
                }
            }
        }
    }
}
