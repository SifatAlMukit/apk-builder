package com.example.crypto

import com.example.crypto.jks.JksProvider
import com.example.data.model.CertificateInfo
import com.example.data.model.KeystoreConfig
import org.bouncycastle.asn1.x500.X500NameBuilder
import org.bouncycastle.asn1.x500.style.BCStyle
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.*
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAKey
import java.security.spec.ECGenParameterSpec
import java.util.*

object KeystoreManager {

    private val bcProvider: Provider by lazy {
        val provider = BouncyCastleProvider()
        try {
            Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME)
            Security.insertProviderAt(provider, 1)
        } catch (_: Exception) {
            try {
                Security.addProvider(provider)
            } catch (_: Exception) {}
        }
        provider
    }

    init {
        setupBouncyCastle()
    }

    private fun setupBouncyCastle() {
        try {
            // Register custom JKS provider on Android
            JksProvider.register()
            // Trigger lazy registration
            bcProvider.name
        } catch (_: Exception) {}
    }

    /**
     * Generates a new KeyStore (PKCS12 or JKS) with a self-signed certificate and saves it to the target file.
     */
    fun generateKeystore(config: KeystoreConfig, targetFile: File): CertificateInfo {
        setupBouncyCastle()

        // 1. Generate KeyPair
        val keyPair = when (config.keyAlgorithm.uppercase()) {
            "EC" -> {
                val keyGen = try {
                    KeyPairGenerator.getInstance("EC", bcProvider)
                } catch (_: Exception) {
                    KeyPairGenerator.getInstance("EC")
                }
                val curveName = when (config.keySize) {
                    384 -> "secp384r1"
                    521 -> "secp521r1"
                    else -> "secp256r1"
                }
                keyGen.initialize(ECGenParameterSpec(curveName), SecureRandom())
                keyGen.generateKeyPair()
            }
            else -> {
                val keyGen = try {
                    KeyPairGenerator.getInstance("RSA", bcProvider)
                } catch (_: Exception) {
                    KeyPairGenerator.getInstance("RSA")
                }
                keyGen.initialize(config.keySize, SecureRandom())
                keyGen.generateKeyPair()
            }
        }

        // 2. Build Distinguished Name (DN)
        val nameBuilder = X500NameBuilder(BCStyle.INSTANCE)
        if (config.commonName.isNotBlank()) {
            nameBuilder.addRDN(BCStyle.CN, config.commonName.trim())
        } else {
            nameBuilder.addRDN(BCStyle.CN, "Android Developer")
        }
        if (config.organizationUnit.isNotBlank()) {
            nameBuilder.addRDN(BCStyle.OU, config.organizationUnit.trim())
        }
        if (config.organization.isNotBlank()) {
            nameBuilder.addRDN(BCStyle.O, config.organization.trim())
        }
        if (config.city.isNotBlank()) {
            nameBuilder.addRDN(BCStyle.L, config.city.trim())
        }
        if (config.state.isNotBlank()) {
            nameBuilder.addRDN(BCStyle.ST, config.state.trim())
        }
        if (config.countryCode.isNotBlank()) {
            nameBuilder.addRDN(BCStyle.C, config.countryCode.trim().uppercase())
        }

        val subject = nameBuilder.build()
        val serialNumber = BigInteger(64, SecureRandom())
        val notBefore = Date(System.currentTimeMillis() - 60_000L) // 1 min buffer
        val validityMillis = config.validityYears.toLong() * 365L * 24L * 60L * 60L * 1000L
        val notAfter = Date(System.currentTimeMillis() + validityMillis)

        val sigAlg = when {
            config.keyAlgorithm.equals("EC", ignoreCase = true) -> "SHA256withECDSA"
            config.keySize >= 4096 -> "SHA512withRSA"
            config.keySize >= 3072 -> "SHA384withRSA"
            else -> "SHA256withRSA"
        }

        // 3. Build X.509 Certificate
        val certBuilder = JcaX509v3CertificateBuilder(
            subject,
            serialNumber,
            notBefore,
            notAfter,
            subject,
            keyPair.public
        )

        val signer = JcaContentSignerBuilder(sigAlg).build(keyPair.private)
        val certHolder = certBuilder.build(signer)

        // Convert to X509Certificate using Android native CertificateFactory to avoid "X.509 not found" provider conflict
        val cert: X509Certificate = try {
            val certFactory = CertificateFactory.getInstance("X.509")
            certFactory.generateCertificate(ByteArrayInputStream(certHolder.encoded)) as X509Certificate
        } catch (_: Exception) {
            JcaX509CertificateConverter().getCertificate(certHolder)
        }

        // 4. Save to KeyStore
        val isJks = config.storeType.equals("JKS", ignoreCase = true)
        val storeType = if (isJks) "JKS" else "PKCS12"
        val keyStore = if (isJks) {
            KeyStore.getInstance("JKS")
        } else {
            try {
                KeyStore.getInstance(storeType, bcProvider)
            } catch (_: Exception) {
                KeyStore.getInstance(storeType)
            }
        }
        keyStore.load(null, null)

        val effectiveKeyPass = config.effectiveKeyPassword.toCharArray()
        keyStore.setKeyEntry(
            config.alias.trim(),
            keyPair.private,
            effectiveKeyPass,
            arrayOf(cert)
        )

        targetFile.parentFile?.mkdirs()
        FileOutputStream(targetFile).use { fos ->
            keyStore.store(fos, config.storePassword.toCharArray())
        }

        return extractCertificateInfo(cert, config.alias.trim())
    }

    /**
     * Loads a KeyStore from a file, attempting PKCS12, JKS, and BKS formats.
     */
    fun loadKeyStore(file: File, password: String): Pair<KeyStore, String> {
        setupBouncyCastle()
        val candidateTypes = listOf("PKCS12", "JKS", "BKS")
        var lastError: Exception? = null

        for (type in candidateTypes) {
            try {
                val ks = if (type == "JKS") {
                    KeyStore.getInstance("JKS")
                } else {
                    try {
                        KeyStore.getInstance(type, bcProvider)
                    } catch (_: Exception) {
                        KeyStore.getInstance(type)
                    }
                }

                file.inputStream().use { fis ->
                    ks.load(fis, password.toCharArray())
                }
                return Pair(ks, type)
            } catch (e: Exception) {
                lastError = e
            }
        }

        throw lastError ?: GeneralSecurityException("Unable to load keystore: invalid password or unsupported format")
    }

    /**
     * Retrieves all alias names from a loaded KeyStore.
     */
    fun getAliases(keyStore: KeyStore): List<String> {
        return keyStore.aliases().toList()
    }

    /**
     * Extracts certificate information for a specific alias.
     */
    fun getCertificateInfo(keyStore: KeyStore, alias: String): CertificateInfo? {
        val cert = keyStore.getCertificate(alias) as? X509Certificate ?: return null
        return extractCertificateInfo(cert, alias)
    }

    /**
     * Extracts detailed information, public key size, and fingerprints from an X509Certificate.
     */
    fun extractCertificateInfo(cert: X509Certificate, alias: String = ""): CertificateInfo {
        val subjectDn = cert.subjectX500Principal?.name ?: ""
        val issuerDn = cert.issuerX500Principal?.name ?: ""
        val serialNumber = cert.serialNumber?.toString(16)?.uppercase() ?: ""
        val validFrom = cert.notBefore?.time ?: 0L
        val validUntil = cert.notAfter?.time ?: 0L
        val isExpired = System.currentTimeMillis() > validUntil

        val keyAlgorithm = cert.publicKey?.algorithm ?: "Unknown"
        val keySize = when (val pubKey = cert.publicKey) {
            is RSAKey -> pubKey.modulus?.bitLength() ?: 0
            else -> 256
        }
        val sigAlg = cert.sigAlgName ?: "Unknown"

        val md5 = calculateFingerprint(cert, "MD5")
        val sha1 = calculateFingerprint(cert, "SHA-1")
        val sha256 = calculateFingerprint(cert, "SHA-256")

        return CertificateInfo(
            alias = alias,
            subjectDn = subjectDn,
            issuerDn = issuerDn,
            serialNumber = serialNumber,
            validFrom = validFrom,
            validUntil = validUntil,
            keyAlgorithm = keyAlgorithm,
            keySize = keySize,
            signatureAlgorithm = sigAlg,
            md5Fingerprint = md5,
            sha1Fingerprint = sha1,
            sha256Fingerprint = sha256,
            isExpired = isExpired
        )
    }

    /**
     * Calculates a cryptographic fingerprint (MD5, SHA-1, SHA-256) of a certificate.
     */
    fun calculateFingerprint(certificate: X509Certificate, algorithm: String): String {
        return try {
            val md = MessageDigest.getInstance(algorithm)
            val digest = md.digest(certificate.encoded)
            digest.joinToString(":") { "%02X".format(it) }
        } catch (_: Exception) {
            "Unavailable"
        }
    }

    /**
     * Formats an X509Certificate into a PEM string representation.
     */
    fun exportCertificateToPem(certificate: X509Certificate): String {
        val base64 = android.util.Base64.encodeToString(certificate.encoded, android.util.Base64.NO_WRAP)
        val formatted = base64.chunked(64).joinToString("\n")
        return "-----BEGIN CERTIFICATE-----\n$formatted\n-----END CERTIFICATE-----"
    }
}
