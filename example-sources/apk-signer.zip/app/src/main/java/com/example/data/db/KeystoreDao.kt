package com.example.data.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface KeystoreDao {
    @Query("SELECT * FROM keystores ORDER BY createdAt DESC")
    fun getAllKeystores(): Flow<List<KeystoreEntity>>

    @Query("SELECT * FROM keystores WHERE id = :id LIMIT 1")
    suspend fun getKeystoreById(id: Long): KeystoreEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKeystore(keystore: KeystoreEntity): Long

    @Update
    suspend fun updateKeystore(keystore: KeystoreEntity)

    @Delete
    suspend fun deleteKeystore(keystore: KeystoreEntity)

    @Query("DELETE FROM keystores WHERE id = :id")
    suspend fun deleteKeystoreById(id: Long)
}
