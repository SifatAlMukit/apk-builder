package com.example.crypto

import com.example.data.model.ApkVerificationInfo
import com.example.data.model.CertificateInfo
import com.android.apksig.ApkVerifier
import java.io.File
import java.security.cert.X509Certificate

object ApkVerifierManager {

    /**
     * Verifies an APK file's digital signatures (v1, v2, v3, v4) using the official Android ApkVerifier.
     */
    fun verifyApk(apkFile: File): ApkVerificationInfo {
        if (!apkFile.exists() || apkFile.length() == 0L) {
            return ApkVerificationInfo(
                apkFileName = apkFile.name,
                apkFileSize = 0L,
                isVerified = false,
                v1Verified = false,
                v2Verified = false,
                v3Verified = false,
                v4Verified = false,
                signers = emptyList(),
                warnings = emptyList(),
                errors = listOf("File does not exist or is empty.")
            )
        }

        try {
            val verifier = ApkVerifier.Builder(apkFile).build()
            val result = verifier.verify()

            val signersList = mutableListOf<CertificateInfo>()
            try {
                val certs: List<X509Certificate> = result.signerCertificates ?: emptyList()
                for (cert in certs) {
                    signersList.add(KeystoreManager.extractCertificateInfo(cert, alias = "Signer"))
                }
            } catch (_: Exception) {}

            val errorMessages = result.errors?.map { it.toString() } ?: emptyList()
            val warningMessages = result.warnings?.map { it.toString() } ?: emptyList()

            return ApkVerificationInfo(
                apkFileName = apkFile.name,
                apkFileSize = apkFile.length(),
                isVerified = result.isVerified,
                v1Verified = result.isVerifiedUsingV1Scheme,
                v2Verified = result.isVerifiedUsingV2Scheme,
                v3Verified = result.isVerifiedUsingV3Scheme,
                v4Verified = result.isVerifiedUsingV4Scheme,
                signers = signersList,
                warnings = warningMessages,
                errors = errorMessages
            )
        } catch (e: Exception) {
            return ApkVerificationInfo(
                apkFileName = apkFile.name,
                apkFileSize = apkFile.length(),
                isVerified = false,
                v1Verified = false,
                v2Verified = false,
                v3Verified = false,
                v4Verified = false,
                signers = emptyList(),
                warnings = emptyList(),
                errors = listOf("Verification failed: ${e.localizedMessage ?: e.javaClass.simpleName}")
            )
        }
    }
}
