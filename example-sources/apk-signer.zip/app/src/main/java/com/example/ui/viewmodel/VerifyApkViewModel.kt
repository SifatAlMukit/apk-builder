package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.ApkVerifierManager
import com.example.data.model.ApkVerificationInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class VerifyApkViewModel(application: Application) : AndroidViewModel(application) {

    private val _selectedApkName = MutableStateFlow("")
    val selectedApkName: StateFlow<String> = _selectedApkName.asStateFlow()

    private val _selectedApkSize = MutableStateFlow(0L)
    val selectedApkSize: StateFlow<Long> = _selectedApkSize.asStateFlow()

    private val _isVerifying = MutableStateFlow(false)
    val isVerifying: StateFlow<Boolean> = _isVerifying.asStateFlow()

    private val _verificationInfo = MutableStateFlow<ApkVerificationInfo?>(null)
    val verificationInfo: StateFlow<ApkVerificationInfo?> = _verificationInfo.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun verifyApk(uri: Uri, fileName: String, fileSize: Long) {
        _selectedApkName.value = fileName
        _selectedApkSize.value = fileSize
        _isVerifying.value = true
        _errorMessage.value = null
        _verificationInfo.value = null

        viewModelScope.launch {
            try {
                val info = withContext(Dispatchers.IO) {
                    val context = getApplication<Application>()
                    val stagingFile = File(context.cacheDir, "verify_staging_${System.currentTimeMillis()}.apk")

                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(stagingFile).use { output ->
                            input.copyTo(output)
                        }
                    } ?: throw IllegalStateException("Could not read APK file.")

                    val result = ApkVerifierManager.verifyApk(stagingFile)
                    stagingFile.delete()
                    result.copy(apkFileName = fileName, apkFileSize = fileSize)
                }

                _isVerifying.value = false
                _verificationInfo.value = info
            } catch (e: Exception) {
                _isVerifying.value = false
                _errorMessage.value = "Failed to verify APK: ${e.localizedMessage ?: e.javaClass.simpleName}"
            }
        }
    }

    fun clear() {
        _verificationInfo.value = null
        _selectedApkName.value = ""
        _selectedApkSize.value = 0L
        _errorMessage.value = null
    }
}
