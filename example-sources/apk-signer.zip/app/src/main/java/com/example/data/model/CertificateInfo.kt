package com.example.data.model

data class CertificateInfo(
    val alias: String = "",
    val subjectDn: String = "",
    val issuerDn: String = "",
    val serialNumber: String = "",
    val validFrom: Long = 0L,
    val validUntil: Long = 0L,
    val keyAlgorithm: String = "",
    val keySize: Int = 0,
    val signatureAlgorithm: String = "",
    val md5Fingerprint: String = "",
    val sha1Fingerprint: String = "",
    val sha256Fingerprint: String = "",
    val isExpired: Boolean = false
) {
    val commonName: String
        get() {
            val parts = subjectDn.split(",")
            for (part in parts) {
                val trimmed = part.trim()
                if (trimmed.startsWith("CN=", ignoreCase = true)) {
                    return trimmed.substring(3).trim()
                }
            }
            return subjectDn
        }

    val organization: String
        get() {
            val parts = subjectDn.split(",")
            for (part in parts) {
                val trimmed = part.trim()
                if (trimmed.startsWith("O=", ignoreCase = true)) {
                    return trimmed.substring(2).trim()
                }
            }
            return ""
        }
}
