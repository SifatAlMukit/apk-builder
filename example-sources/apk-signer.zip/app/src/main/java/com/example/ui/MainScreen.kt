package com.example.ui

import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.viewmodel.*

enum class NavDestination(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    SIGN("Sign APK", Icons.Filled.Draw, Icons.Outlined.Draw, "nav_tab_sign"),
    KEYSTORES("Keystores", Icons.Filled.VpnKey, Icons.Outlined.VpnKey, "nav_tab_keystores"),
    GENERATE("Generate", Icons.Filled.AddCircle, Icons.Outlined.AddCircleOutline, "nav_tab_generate"),
    CONVERT("Convert", Icons.Filled.SwapHoriz, Icons.Outlined.SwapHoriz, "nav_tab_convert"),
    VERIFY("Verify", Icons.Filled.VerifiedUser, Icons.Outlined.VerifiedUser, "nav_tab_verify")
}

@Composable
fun MainScreen(
    signApkViewModel: SignApkViewModel = viewModel(),
    keystoresViewModel: KeystoresViewModel = viewModel(),
    generateKeystoreViewModel: GenerateKeystoreViewModel = viewModel(),
    converterViewModel: ConverterViewModel = viewModel(),
    verifyApkViewModel: VerifyApkViewModel = viewModel()
) {
    var currentDestination by remember { mutableStateOf(NavDestination.SIGN) }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWideScreen = maxWidth >= 600.dp

        if (isWideScreen) {
            Row(modifier = Modifier.fillMaxSize()) {
                NavigationRail(
                    modifier = Modifier.testTag("main_nav_rail"),
                    header = {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = "APK Signer Logo",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(32.dp).padding(bottom = 16.dp)
                        )
                    }
                ) {
                    NavDestination.entries.forEach { destination ->
                        NavigationRailItem(
                            selected = currentDestination == destination,
                            onClick = { currentDestination = destination },
                            icon = {
                                Icon(
                                    imageVector = if (currentDestination == destination) destination.selectedIcon else destination.unselectedIcon,
                                    contentDescription = destination.title
                                )
                            },
                            label = { Text(destination.title) },
                            modifier = Modifier.testTag(destination.testTag)
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) {
                    ScreenContent(
                        destination = currentDestination,
                        signApkViewModel = signApkViewModel,
                        keystoresViewModel = keystoresViewModel,
                        generateKeystoreViewModel = generateKeystoreViewModel,
                        converterViewModel = converterViewModel,
                        verifyApkViewModel = verifyApkViewModel,
                        onNavigate = { currentDestination = it }
                    )
                }
            }
        } else {
            Scaffold(
                bottomBar = {
                    NavigationBar(modifier = Modifier.testTag("main_bottom_nav")) {
                        NavDestination.entries.forEach { destination ->
                            NavigationBarItem(
                                selected = currentDestination == destination,
                                onClick = { currentDestination = destination },
                                icon = {
                                    Icon(
                                        imageVector = if (currentDestination == destination) destination.selectedIcon else destination.unselectedIcon,
                                        contentDescription = destination.title
                                    )
                                },
                                label = { Text(destination.title) },
                                modifier = Modifier.testTag(destination.testTag)
                            )
                        }
                    }
                }
            ) { innerPadding ->
                Box(modifier = Modifier.padding(innerPadding)) {
                    ScreenContent(
                        destination = currentDestination,
                        signApkViewModel = signApkViewModel,
                        keystoresViewModel = keystoresViewModel,
                        generateKeystoreViewModel = generateKeystoreViewModel,
                        converterViewModel = converterViewModel,
                        verifyApkViewModel = verifyApkViewModel,
                        onNavigate = { currentDestination = it }
                    )
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(
    destination: NavDestination,
    signApkViewModel: SignApkViewModel,
    keystoresViewModel: KeystoresViewModel,
    generateKeystoreViewModel: GenerateKeystoreViewModel,
    converterViewModel: ConverterViewModel,
    verifyApkViewModel: VerifyApkViewModel,
    onNavigate: (NavDestination) -> Unit
) {
    Crossfade(targetState = destination, label = "screen_transition") { dest ->
        when (dest) {
            NavDestination.SIGN -> {
                SignApkScreen(
                    viewModel = signApkViewModel,
                    onNavigateToKeystores = { onNavigate(NavDestination.KEYSTORES) }
                )
            }
            NavDestination.KEYSTORES -> {
                KeystoresScreen(
                    viewModel = keystoresViewModel,
                    onNavigateToGenerate = { onNavigate(NavDestination.GENERATE) },
                    onConvertToFormat = { entity ->
                        converterViewModel.loadFromSavedKeystore(entity)
                        onNavigate(NavDestination.CONVERT)
                    }
                )
            }
            NavDestination.GENERATE -> {
                GenerateKeystoreScreen(
                    viewModel = generateKeystoreViewModel,
                    onKeystoreReadyForSigning = {
                        val success = generateKeystoreViewModel.uiState.value
                        if (success is GenerateKeystoreUiState.Success) {
                            signApkViewModel.selectKeystore(success.entity)
                        }
                        onNavigate(NavDestination.SIGN)
                    }
                )
            }
            NavDestination.CONVERT -> {
                ConverterScreen(
                    viewModel = converterViewModel
                )
            }
            NavDestination.VERIFY -> {
                VerifyApkScreen(
                    viewModel = verifyApkViewModel,
                    onSignThisApk = { uri: Uri, name: String, size: Long ->
                        signApkViewModel.selectApk(uri, name, size)
                        onNavigate(NavDestination.SIGN)
                    }
                )
            }
        }
    }
}
