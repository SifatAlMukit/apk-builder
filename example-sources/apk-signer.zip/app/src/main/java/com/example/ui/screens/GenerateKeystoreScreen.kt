package com.example.ui.screens

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.FingerprintItem
import com.example.ui.components.PasswordInputField
import com.example.ui.components.StatusPill
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.GenerateKeystoreUiState
import com.example.ui.viewmodel.GenerateKeystoreViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GenerateKeystoreScreen(
    viewModel: GenerateKeystoreViewModel,
    onKeystoreReadyForSigning: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()

    val name by viewModel.name.collectAsStateWithLifecycle()
    val alias by viewModel.alias.collectAsStateWithLifecycle()
    val storePassword by viewModel.storePassword.collectAsStateWithLifecycle()
    val keyPassword by viewModel.keyPassword.collectAsStateWithLifecycle()
    val useSamePassword by viewModel.useSamePassword.collectAsStateWithLifecycle()

    val storeType by viewModel.storeType.collectAsStateWithLifecycle()
    val keyAlgorithm by viewModel.keyAlgorithm.collectAsStateWithLifecycle()
    val keySize by viewModel.keySize.collectAsStateWithLifecycle()
    val validityYears by viewModel.validityYears.collectAsStateWithLifecycle()

    val commonName by viewModel.commonName.collectAsStateWithLifecycle()
    val orgUnit by viewModel.organizationUnit.collectAsStateWithLifecycle()
    val org by viewModel.organization.collectAsStateWithLifecycle()
    val city by viewModel.city.collectAsStateWithLifecycle()
    val state by viewModel.state.collectAsStateWithLifecycle()
    val countryCode by viewModel.countryCode.collectAsStateWithLifecycle()

    var selectedPreset by remember { mutableStateOf("google_play") }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/octet-stream")
    ) { uri: Uri? ->
        if (uri != null && uiState is GenerateKeystoreUiState.Success) {
            val success = uiState as GenerateKeystoreUiState.Success
            viewModel.exportGeneratedKeystore(uri, success.entity)
            Toast.makeText(context, "Keystore file exported successfully!", Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("Generate Keystore", fontWeight = FontWeight.Bold)
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            // Error banner if any
            if (uiState is GenerateKeystoreUiState.Error) {
                item {
                    val error = (uiState as GenerateKeystoreUiState.Error).message
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                error,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            // Success View
            if (uiState is GenerateKeystoreUiState.Success) {
                val success = uiState as GenerateKeystoreUiState.Success
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth().testTag("generate_success_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(SuccessGreen),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.surface)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        "Keystore Created Successfully!",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SuccessGreen
                                    )
                                    Text(
                                        "Saved securely in app storage",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Text("Keystore: ${success.entity.name}", fontWeight = FontWeight.SemiBold)
                            Text("Alias: ${success.entity.defaultAlias} (${success.entity.storeType})")
                            Text("Subject: ${success.certificateInfo.subjectDn}", style = MaterialTheme.typography.bodySmall)

                            Spacer(modifier = Modifier.height(12.dp))
                            FingerprintItem("SHA-256 Fingerprint", success.certificateInfo.sha256Fingerprint)
                            Spacer(modifier = Modifier.height(8.dp))
                            FingerprintItem("SHA-1 Fingerprint", success.certificateInfo.sha1Fingerprint)

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = onKeystoreReadyForSigning,
                                    modifier = Modifier.weight(1f).testTag("use_in_signer_button")
                                ) {
                                    Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sign APK Now")
                                }

                                OutlinedButton(
                                    onClick = {
                                        exportLauncher.launch(success.entity.fileName)
                                    },
                                    modifier = Modifier.weight(1f).testTag("export_generated_keystore_button")
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Export File")
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            TextButton(
                                onClick = { viewModel.resetForm() },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Generate Another Keystore")
                            }
                        }
                    }
                }
            } else {
                // Form View
                // 1. Presets Chips
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "Cryptographic Presets",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected = selectedPreset == "google_play",
                                    onClick = {
                                        selectedPreset = "google_play"
                                        viewModel.applyPreset("google_play")
                                    },
                                    label = { Text("Google Play") },
                                    modifier = Modifier.testTag("preset_google_play_chip")
                                )
                                FilterChip(
                                    selected = selectedPreset == "high_security",
                                    onClick = {
                                        selectedPreset = "high_security"
                                        viewModel.applyPreset("high_security")
                                    },
                                    label = { Text("RSA 4096") },
                                    modifier = Modifier.testTag("preset_high_security_chip")
                                )
                                FilterChip(
                                    selected = selectedPreset == "elliptic_curve",
                                    onClick = {
                                        selectedPreset = "elliptic_curve"
                                        viewModel.applyPreset("elliptic_curve")
                                    },
                                    label = { Text("EC P-256") },
                                    modifier = Modifier.testTag("preset_elliptic_curve_chip")
                                )
                            }
                        }
                    }
                }

                // 2. Keystore Identity
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "1. Keystore Basics",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = name,
                                onValueChange = { viewModel.name.value = it },
                                label = { Text("Keystore Friendly Name") },
                                placeholder = { Text("e.g. My Release Key") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("keystore_name_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = alias,
                                onValueChange = { viewModel.alias.value = it },
                                label = { Text("Key Alias") },
                                placeholder = { Text("e.g. release, upload") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("keystore_alias_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Text("Format", style = MaterialTheme.typography.labelMedium)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = storeType == "PKCS12",
                                    onClick = { viewModel.storeType.value = "PKCS12" },
                                    label = { Text("PKCS12 (Industry Standard)") }
                                )
                                FilterChip(
                                    selected = storeType == "JKS",
                                    onClick = { viewModel.storeType.value = "JKS" },
                                    label = { Text("JKS (Legacy)") }
                                )
                            }
                        }
                    }
                }

                // 3. Passwords
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "2. Passwords",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            PasswordInputField(
                                value = storePassword,
                                onValueChange = { viewModel.storePassword.value = it },
                                label = "Keystore Password",
                                placeholder = "Minimum 6 characters",
                                supportingText = "Used to encrypt the keystore container",
                                testTag = "gen_store_password_input"
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    viewModel.useSamePassword.value = !useSamePassword
                                }
                            ) {
                                Checkbox(
                                    checked = useSamePassword,
                                    onCheckedChange = { viewModel.useSamePassword.value = it }
                                )
                                Text(
                                    "Use same password for key alias",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            if (!useSamePassword) {
                                Spacer(modifier = Modifier.height(4.dp))
                                PasswordInputField(
                                    value = keyPassword,
                                    onValueChange = { viewModel.keyPassword.value = it },
                                    label = "Key Alias Password",
                                    placeholder = "Minimum 6 characters",
                                    testTag = "gen_key_password_input"
                                )
                            }
                        }
                    }
                }

                // 4. Certificate X.500 DN
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "3. Certificate Information (X.500)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            OutlinedTextField(
                                value = commonName,
                                onValueChange = { viewModel.commonName.value = it },
                                label = { Text("Common Name (CN)") },
                                placeholder = { Text("Developer or Company Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("dn_cn_input"),
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = org,
                                    onValueChange = { viewModel.organization.value = it },
                                    label = { Text("Organization (O)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("dn_o_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = orgUnit,
                                    onValueChange = { viewModel.organizationUnit.value = it },
                                    label = { Text("Org Unit (OU)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("dn_ou_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = city,
                                    onValueChange = { viewModel.city.value = it },
                                    label = { Text("City (L)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("dn_city_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = state,
                                    onValueChange = { viewModel.state.value = it },
                                    label = { Text("State (ST)") },
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("dn_state_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                OutlinedTextField(
                                    value = countryCode,
                                    onValueChange = { viewModel.countryCode.value = it.take(2).uppercase() },
                                    label = { Text("Country (C)") },
                                    placeholder = { Text("US") },
                                    singleLine = true,
                                    modifier = Modifier.weight(0.7f).testTag("dn_country_input"),
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }
                }

                // 5. Crypto Parameters & Validity
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                "4. Cryptographic Settings",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Key Algorithm: $keyAlgorithm", fontWeight = FontWeight.SemiBold)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(
                                        selected = keyAlgorithm == "RSA",
                                        onClick = {
                                            viewModel.keyAlgorithm.value = "RSA"
                                            viewModel.keySize.value = 2048
                                        },
                                        label = { Text("RSA") }
                                    )
                                    FilterChip(
                                        selected = keyAlgorithm == "EC",
                                        onClick = {
                                            viewModel.keyAlgorithm.value = "EC"
                                            viewModel.keySize.value = 256
                                        },
                                        label = { Text("EC") }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Key Size: $keySize-bit", fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (keyAlgorithm == "RSA") {
                                    FilterChip(
                                        selected = keySize == 2048,
                                        onClick = { viewModel.keySize.value = 2048 },
                                        label = { Text("2048 bit") }
                                    )
                                    FilterChip(
                                        selected = keySize == 3072,
                                        onClick = { viewModel.keySize.value = 3072 },
                                        label = { Text("3072 bit") }
                                    )
                                    FilterChip(
                                        selected = keySize == 4096,
                                        onClick = { viewModel.keySize.value = 4096 },
                                        label = { Text("4096 bit") }
                                    )
                                } else {
                                    FilterChip(
                                        selected = keySize == 256,
                                        onClick = { viewModel.keySize.value = 256 },
                                        label = { Text("256 bit (P-256)") }
                                    )
                                    FilterChip(
                                        selected = keySize == 384,
                                        onClick = { viewModel.keySize.value = 384 },
                                        label = { Text("384 bit (P-384)") }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Validity Duration", fontWeight = FontWeight.SemiBold)
                                Text("$validityYears Years", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                            Slider(
                                value = validityYears.toFloat(),
                                onValueChange = { viewModel.validityYears.value = it.toInt() },
                                valueRange = 1f..50f,
                                steps = 49,
                                modifier = Modifier.fillMaxWidth().testTag("validity_slider")
                            )
                        }
                    }
                }

                // Generate Button
                item {
                    val isGenerating = uiState is GenerateKeystoreUiState.Generating
                    Button(
                        onClick = { viewModel.generateKeystore() },
                        enabled = !isGenerating && name.isNotBlank() && alias.isNotBlank() && storePassword.length >= 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("generate_keystore_submit_button"),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        if (isGenerating) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.5.dp)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Generating Keys...")
                        } else {
                            Icon(Icons.Default.Security, contentDescription = null)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("Generate & Save Keystore", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
