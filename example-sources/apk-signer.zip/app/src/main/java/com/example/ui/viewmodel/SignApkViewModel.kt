package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.ApkSignerManager
import com.example.crypto.ApkVerifierManager
import com.example.crypto.KeystoreManager
import com.example.data.db.AppDatabase
import com.example.data.db.KeystoreEntity
import com.example.data.model.ApkVerificationInfo
import com.example.data.model.SigningConfig
import com.example.data.model.SigningResult
import com.example.data.repository.KeystoreRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class SignApkViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: KeystoreRepository = KeystoreRepository(
        AppDatabase.getDatabase(application).keystoreDao()
    )

    val savedKeystores: StateFlow<List<KeystoreEntity>> = repository.allKeystores
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Selection State
    private val _selectedApkUri = MutableStateFlow<Uri?>(null)
    val selectedApkUri: StateFlow<Uri?> = _selectedApkUri.asStateFlow()

    private val _selectedApkName = MutableStateFlow("")
    val selectedApkName: StateFlow<String> = _selectedApkName.asStateFlow()

    private val _selectedApkSize = MutableStateFlow(0L)
    val selectedApkSize: StateFlow<Long> = _selectedApkSize.asStateFlow()

    private val _inputApkVerification = MutableStateFlow<ApkVerificationInfo?>(null)
    val inputApkVerification: StateFlow<ApkVerificationInfo?> = _inputApkVerification.asStateFlow()

    // Keystore State
    private val _selectedKeystore = MutableStateFlow<KeystoreEntity?>(null)
    val selectedKeystore: StateFlow<KeystoreEntity?> = _selectedKeystore.asStateFlow()

    private val _availableAliases = MutableStateFlow<List<String>>(emptyList())
    val availableAliases: StateFlow<List<String>> = _availableAliases.asStateFlow()

    var selectedAlias = MutableStateFlow("")
    var keystorePassword = MutableStateFlow("")
    var keyPassword = MutableStateFlow("")
    var useSamePassword = MutableStateFlow(true)

    // Signing Options
    var v1Enabled = MutableStateFlow(true)
    var v2Enabled = MutableStateFlow(true)
    var v3Enabled = MutableStateFlow(true)
    var v4Enabled = MutableStateFlow(false)
    var overwriteOriginal = MutableStateFlow(false)

    // Execution & Progress State
    private val _isSigning = MutableStateFlow(false)
    val isSigning: StateFlow<Boolean> = _isSigning.asStateFlow()

    private val _progressStep = MutableStateFlow("")
    val progressStep: StateFlow<String> = _progressStep.asStateFlow()

    private val _progressFraction = MutableStateFlow(0f)
    val progressFraction: StateFlow<Float> = _progressFraction.asStateFlow()

    private val _signingResult = MutableStateFlow<SigningResult?>(null)
    val signingResult: StateFlow<SigningResult?> = _signingResult.asStateFlow()

    private val _generalError = MutableStateFlow<String?>(null)
    val generalError: StateFlow<String?> = _generalError.asStateFlow()

    private val _showOverwriteConfirmation = MutableStateFlow(false)
    val showOverwriteConfirmation: StateFlow<Boolean> = _showOverwriteConfirmation.asStateFlow()

    fun selectApk(uri: Uri, name: String, size: Long) {
        _selectedApkUri.value = uri
        _selectedApkName.value = name
        _selectedApkSize.value = size
        _signingResult.value = null
        _generalError.value = null

        // Inspect input APK in background
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val context = getApplication<Application>()
                    val tempInspect = File(context.cacheDir, "staging_inspect_${System.currentTimeMillis()}.apk")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(tempInspect).use { output ->
                            input.copyTo(output)
                        }
                    }
                    val info = ApkVerifierManager.verifyApk(tempInspect)
                    tempInspect.delete()
                    _inputApkVerification.value = info
                } catch (_: Exception) {
                    _inputApkVerification.value = null
                }
            }
        }
    }

    fun selectKeystore(entity: KeystoreEntity) {
        _selectedKeystore.value = entity
        val aliasesList = entity.aliases.split(",").map { it.trim() }.filter { it.isNotBlank() }
        _availableAliases.value = aliasesList
        selectedAlias.value = entity.defaultAlias.ifBlank { aliasesList.firstOrNull() ?: "" }
        _generalError.value = null
    }

    fun unlockKeystoreAliases() {
        val ks = _selectedKeystore.value ?: return
        val pass = keystorePassword.value
        if (pass.isBlank()) return

        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val file = File(ks.filePath)
                    val (keyStore, _) = KeystoreManager.loadKeyStore(file, pass)
                    val aliases = KeystoreManager.getAliases(keyStore)
                    _availableAliases.value = aliases
                    if (aliases.isNotEmpty() && !aliases.contains(selectedAlias.value)) {
                        selectedAlias.value = aliases.first()
                    }
                }
                _generalError.value = null
            } catch (e: Exception) {
                _generalError.value = "Failed to unlock keystore: ${e.localizedMessage ?: "Invalid password"}"
            }
        }
    }

    fun requestSign() {
        if (overwriteOriginal.value) {
            _showOverwriteConfirmation.value = true
        } else {
            executeSign()
        }
    }

    fun confirmOverwriteAndSign() {
        _showOverwriteConfirmation.value = false
        executeSign()
    }

    fun dismissOverwriteConfirmation() {
        _showOverwriteConfirmation.value = false
    }

    fun clearGeneralError() {
        _generalError.value = null
    }

    private fun executeSign() {
        val apkUri = _selectedApkUri.value
        if (apkUri == null) {
            _generalError.value = "Please select an APK file to sign."
            return
        }

        val keystoreEntity = _selectedKeystore.value
        if (keystoreEntity == null) {
            _generalError.value = "Please select a keystore."
            return
        }

        val alias = selectedAlias.value.trim()
        if (alias.isBlank()) {
            _generalError.value = "Please select or enter a key alias."
            return
        }

        val storePass = keystorePassword.value
        if (storePass.isBlank()) {
            _generalError.value = "Please enter the keystore password."
            return
        }

        val keyPass = if (useSamePassword.value) storePass else keyPassword.value
        if (keyPass.isBlank()) {
            _generalError.value = "Please enter the key password."
            return
        }

        if (!v1Enabled.value && !v2Enabled.value && !v3Enabled.value) {
            _generalError.value = "At least one signature scheme (v1, v2, or v3) must be enabled."
            return
        }

        _isSigning.value = true
        _progressStep.value = "Preparing staging files..."
        _progressFraction.value = 0.05f
        _signingResult.value = null

        viewModelScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val context = getApplication<Application>()
                    val cacheDir = context.cacheDir

                    val inputStaging = File(cacheDir, "input_signing_${System.currentTimeMillis()}.apk")
                    val outputStaging = File(cacheDir, "signed_${System.currentTimeMillis()}_${_selectedApkName.value.ifBlank { "output.apk" }}")

                    // 1. Copy SAF content stream to input staging file
                    _progressStep.value = "Copying input APK to secure staging area..."
                    _progressFraction.value = 0.15f
                    context.contentResolver.openInputStream(apkUri)?.use { inStream ->
                        FileOutputStream(inputStaging).use { outStream ->
                            inStream.copyTo(outStream)
                        }
                    } ?: throw IllegalStateException("Failed to read selected APK file from storage.")

                    // 2. Load KeyStore
                    _progressStep.value = "Unlocking keystore..."
                    _progressFraction.value = 0.25f
                    val keystoreFile = File(keystoreEntity.filePath)
                    val (loadedKeyStore, _) = KeystoreManager.loadKeyStore(keystoreFile, storePass)

                    // 3. Perform Signing
                    val config = SigningConfig(
                        v1SigningEnabled = v1Enabled.value,
                        v2SigningEnabled = v2Enabled.value,
                        v3SigningEnabled = v3Enabled.value,
                        v4SigningEnabled = v4Enabled.value,
                        overwriteOriginal = overwriteOriginal.value
                    )

                    val signResult = ApkSignerManager.signApk(
                        inputApk = inputStaging,
                        outputApk = outputStaging,
                        keyStore = loadedKeyStore,
                        alias = alias,
                        keyPassword = keyPass,
                        config = config,
                        onProgress = { step, fraction ->
                            _progressStep.value = step
                            _progressFraction.value = fraction
                        }
                    )

                    // Cleanup input staging
                    try { inputStaging.delete() } catch (_: Exception) {}

                    // If user explicitly requested overwriting original APK
                    if (signResult.success && overwriteOriginal.value) {
                        context.contentResolver.openOutputStream(apkUri, "wt")?.use { targetOut ->
                            outputStaging.inputStream().use { signedIn ->
                                signedIn.copyTo(targetOut)
                            }
                        }
                    }

                    signResult
                }

                _isSigning.value = false
                _signingResult.value = result
            } catch (e: Exception) {
                _isSigning.value = false
                _signingResult.value = SigningResult(
                    success = false,
                    errorMessage = "Signing error: ${e.localizedMessage ?: e.javaClass.simpleName}"
                )
            }
        }
    }

    fun saveSignedApkToUri(destinationUri: Uri) {
        val result = _signingResult.value ?: return
        if (!result.success || result.outputApkPath.isBlank()) return

        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val signedFile = File(result.outputApkPath)
                    val context = getApplication<Application>()
                    context.contentResolver.openOutputStream(destinationUri)?.use { out ->
                        signedFile.inputStream().use { input ->
                            input.copyTo(out)
                        }
                    } ?: throw IllegalStateException("Could not write to selected destination.")
                }
                _generalError.value = "Signed APK saved successfully to selected destination!"
            } catch (e: Exception) {
                _generalError.value = "Failed to save APK: ${e.localizedMessage}"
            }
        }
    }

    fun getShareIntent(): Intent? {
        val result = _signingResult.value ?: return null
        if (!result.success || result.outputApkPath.isBlank()) return null

        val context = getApplication<Application>()
        val file = File(result.outputApkPath)
        if (!file.exists()) return null

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.android.package-archive"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Signed APK: ${file.name}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun getInstallIntent(): Intent? {
        val result = _signingResult.value ?: return null
        if (!result.success || result.outputApkPath.isBlank()) return null

        val context = getApplication<Application>()
        val file = File(result.outputApkPath)
        if (!file.exists()) return null

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )

        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
    }
}
