package com.example.data.model

data class KeystoreConfig(
    val name: String,
    val fileName: String,
    val alias: String,
    val storePassword: String,
    val keyPassword: String,
    val useSamePassword: Boolean = true,
    val storeType: String = "PKCS12", // "PKCS12" or "JKS"
    val keyAlgorithm: String = "RSA", // "RSA" or "EC"
    val keySize: Int = 2048, // 2048, 3072, 4096 for RSA; 256, 384, 521 for EC
    val validityYears: Int = 25,
    val commonName: String = "",
    val organizationUnit: String = "",
    val organization: String = "",
    val city: String = "",
    val state: String = "",
    val countryCode: String = ""
) {
    val effectiveKeyPassword: String
        get() = if (useSamePassword) storePassword else keyPassword
}
