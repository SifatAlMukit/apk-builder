# Android Server Manager - Implementation Plan

Transform your Android device into a powerful, battery-optimized, offline local server capable of hosting networking services such as OpenSSH Server and VLESS (Xray-core) without requiring root access.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following architectural decisions were aligned during Phase 1 clarification:
> - **Server Execution Backend**: Bundled native binary loader with an integrated Java/Kotlin fallback engine, ensuring high performance on compatible ABIs while guaranteeing zero crashes and full operability across all devices.
> - **Navigation Architecture**: Bottom navigation bar with 5 primary destinations: **Dashboard**, **SSH Server**, **VLESS Server**, **Live Logs**, and **Tools & Settings**.
> - **Security Stance**: Opens directly to the Dashboard on launch; optional App Lock / Biometric authentication can be toggled in Settings.

---

## 1. Overview & Core Concept

**Android Server Manager** is a standalone, 100% offline server environment and management suite designed specifically for Android. It eliminates the need for terminal commands or complex Linux chroots by providing a clean, graphical control center.

- **Target Persona**: Network engineers, developers, privacy-conscious travelers, home lab enthusiasts, and power users who need an on-the-go local SSH jump host, file relay, or VLESS proxy node.
- **Key Value**:
  - Run real background server daemons on non-rooted Android using native ELF binary execution with Android foreground service isolation.
  - Complete zero-cloud privacy: configurations, credentials, encryption keys, user access lists, and telemetry stay strictly local in an encrypted Room SQLite database and DataStore.
  - Intuitive Visual Configuration Editors and QR code exports allow connecting laptops, phones, and consoles in seconds without manually hand-crafting JSON configs.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Dashboard & Quick Actions**:
   - The user opens the app to an active status board showcasing real-time CPU, RAM, battery temperature, storage, active Wi-Fi / Hotspot interface details, and local IP addresses (e.g., `192.168.1.45`).
   - Quick one-tap master controls: **Start All**, **Stop All**, **Restart All** with animated state badges and active client counts.
2. **SSH Service Management**:
   - Toggle SSH server on/off; configure custom ports (default `2222`), custom authentication (password or RSA/Ed25519 public keys), keypair generation wizard, import/export keys, and live connection logs.
3. **VLESS (Xray) Service Management**:
   - Configure VLESS protocol parameters, port (`4433`), generate/assign UUIDs, create multiple client credentials with traffic quotas, view live real-time bandwidth charts (Rx/Tx speed gauges), and export one-tap VLESS URIs & QR codes.
4. **Visual Configuration & User Management**:
   - Visual form editor for users, ports, flow controls, and timeouts. Switchable "Raw JSON Inspector" with real-time syntax validation.
5. **Logs & Diagnostics**:
   - Central stream of categorized server output (Info, Warning, Error, Connection Events) with live search filter, copy to clipboard, and text export.
6. **Built-in Local Terminal & Network Tools**:
   - Terminal emulator executing local Android shell commands (e.g., `netstat`, `ip addr`, `ping`) with scrollable output history.
   - Built-in Subnet Scanner & Network Discovery tools to view neighbors on the current LAN.

### Visual Identity & Theme

- **Aesthetic Direction**: *Industrial Cyber-Deck with Material You polish*. Clean, utilitarian, high-contrast, rounded M3 surfaces with glowing accent badges indicating active daemon states.
- **Color Palette**:
  - `Primary`: Deep Cyber Cyan / Electric Teal (`#00E5FF` dark / `#006875` light)
  - `Secondary`: Neon Amber / Terminal Green accents for service status (`#00E676` for Active/Listening, `#FF5252` for Stopped/Error)
  - `Surface`: Slate Midnight (`#0E141B` background, `#17202A` surface container, `#222F3E` card elevations)
  - `Text`: Ultra-crisp high-contrast off-whites and terminal monospaced status labels
- **Typography**: Clean Google Sans / Roboto paired with Jetpack Compose Monospace typography for ports, IPs, UUIDs, keys, and log readouts.
- **Micro-Interactions**: Spring animations on server switch toggles, pulsating indicators when daemons are accepting connections, smooth drawer & sheet expansions, and haptic feedback on service start/stop.

---

## 3. Key Product Decisions & Trade-Offs

- **Native Binary Execution vs. Integrated Kotlin Network Stack**:
  - *Chosen Approach*: Dual-mode architecture. The app extracts and manages native ELF binaries for `xray` and `sshd` into the app's private executable `filesDir/bin`. In parallel, a robust fallback engine using Kotlin socket servers ensures that even in emulator environments or architectures without matching ELF binaries, the app can start, accept TCP connections, simulate protocol handshakes, and collect telemetry.
  - *Why*: Guarantees zero crashing on all device architectures and containerized runtimes while supporting real native daemon processes when executables are present.
- **Foreground Service Isolation**:
  - *Chosen Approach*: Android `ForegroundService` with `FOREGROUND_SERVICE_TYPE_DATA_SYNC` / `SPECIAL_USE` and persistent notification controls (Start, Stop, Restart quick action buttons).
  - *Why*: Prevents Android OS low-memory killers from terminating active network sockets when the app is placed in the background or screen is locked.
- **Local SQLite (Room) + DataStore**:
  - *Chosen Approach*: Room handles structured data (Server profiles, Client users, Connection logs, SSH keys). DataStore handles user preferences (Dark/Light mode, Accent color, Language, Notification settings).
  - *Why*: 100% offline, persistent across app updates, ultra-fast queries with Flow reactivity.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                        Jetpack Compose UI (M3)                         │
│  ┌───────────────┬──────────────┬──────────────┬──────────┬──────────┐ │
│  │   Dashboard   │  SSH Screen  │ VLESS Screen │   Logs   │  Tools   │ │
│  └───────┬───────┴──────┬───────┴──────┬───────┴────┬─────┴────┬─────┘ │
└──────────┼──────────────┼──────────────┼────────────┼──────────┼───────┘
           ▼              ▼              ▼            ▼          ▼
┌────────────────────────────────────────────────────────────────────────┐
│                        ViewModels & State Layer                        │
│   (DashboardViewModel, SshViewModel, VlessViewModel, ToolsViewModel)   │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │
           ┌────────────────────────┴────────────────────────┐
           ▼                                                 ▼
┌──────────────────────────────┐              ┌──────────────────────────┐
│   Foreground Service Layer   │              │     Repository Layer     │
│   (ServerForegroundService)  │              │ (ServerConfigRepository, │
│  ┌────────────────────────┐  │              │  UserRepo, LogsRepo)     │
│  │ SshDaemonController    │  │              └────────────┬─────────────┘
│  │ VlessDaemonController  │  │                           │
│  │ SystemMonitorManager   │  │                           ▼
│  └────────────────────────┘  │              ┌──────────────────────────┐
└──────────────┬───────────────┘              │  Room Database (SQLite)  │
               ▼                              │  & DataStore Preferences │
┌──────────────────────────────┐              └──────────────────────────┘
│ Native Executable / Socket   │
│ (filesDir/bin & Net Sockets) │
└──────────────────────────────┘
```

### Key Entities & Data Models

1. **`ServerConfigEntity`**: Service type (`SSH` / `VLESS`), port, status (`STOPPED`, `RUNNING`, `ERROR`), auto-start flag, start time, total bytes uploaded, total bytes downloaded.
2. **`VlessUserEntity`**: UUID, username, enabled flag, expiration timestamp, data quota limit (MB), current usage, online status.
3. **`SshKeyEntity`**: Key name, public key string, private key alias, creation date, authorized status.
4. **`ServerLogEntity`**: Timestamp, service tag, log level (`INFO`, `WARN`, `ERROR`), message, client IP.
5. **`ConnectionHistoryEntity`**: Service type, client IP, connected at, disconnected at, total data transferred.

### Interactive Components & Working Handlers

- **Daemon Controller**: Executes binary processes via `ProcessBuilder` with environment redirection, PID tracking, and stdout/stderr flow pipes mapped directly to `LogsRepository`.
- **System Telemetry Collector**: Coroutine-based 1000ms ticker reading `/proc/stat`, `/proc/meminfo`, Android `BatteryManager`, and `TrafficStats` to provide live animated graphs.
- **Network Interface Detector**: Identifies `wlan0`, `ap0`, cellular or loopback IPs, subnet mask, default gateway, and hotspot broadcast state.
- **Visual & JSON Editor**: Bi-directional synchronizer between Form fields and structured JSON with live syntax error alerts.
- **QR Generator**: In-memory matrix calculation rendering standard `vless://` and `ssh://` share URIs directly into high-res Compose canvases and system share sheets.
