package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerType
import com.example.data.model.VlessUserEntity
import com.example.server.ConfigGenerator
import com.example.server.NetworkUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Android Server Manager", appName)
    }

    @Test
    fun `generate valid xray config json`() {
        val config = ServerConfigEntity(
            serverType = ServerType.VLESS,
            port = 4433,
            vlessProtocol = "tcp"
        )
        val user = VlessUserEntity(
            uuid = "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            username = "test_user",
            isEnabled = true
        )
        val json = ConfigGenerator.generateXrayConfigJson(config, listOf(user))
        val (isValid, error) = ConfigGenerator.validateJson(json)
        assertTrue(error ?: "JSON should be valid", isValid)
    }

    @Test
    fun `generate correct vless and ssh URIs`() {
        val user = VlessUserEntity(
            uuid = "12345678-1234-1234-1234-123456789abc",
            username = "alice"
        )
        val vlessUri = ConfigGenerator.generateVlessUri(user, "192.168.1.100", 4433, "MyServer")
        assertTrue(vlessUri.startsWith("vless://12345678-1234-1234-1234-123456789abc@192.168.1.100:4433"))

        val sshUri = ConfigGenerator.generateSshUri("admin", "192.168.1.100", 2222)
        assertEquals("ssh://admin@192.168.1.100:2222", sshUri)
    }
}
