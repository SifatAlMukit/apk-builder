package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ConnectionHistoryEntity
import com.example.data.model.LogLevel
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerLogEntity
import com.example.data.model.ServerType
import com.example.data.model.SshKeyEntity
import com.example.data.model.VlessUserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ServerConfigDao {
    @Query("SELECT * FROM server_configs")
    fun getAllConfigs(): Flow<List<ServerConfigEntity>>

    @Query("SELECT * FROM server_configs WHERE serverType = :type LIMIT 1")
    fun getConfigByType(type: ServerType): Flow<ServerConfigEntity?>

    @Query("SELECT * FROM server_configs WHERE serverType = :type LIMIT 1")
    suspend fun getConfigDirect(type: ServerType): ServerConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(config: ServerConfigEntity)

    @Update
    suspend fun update(config: ServerConfigEntity)
}

@Dao
interface VlessUserDao {
    @Query("SELECT * FROM vless_users ORDER BY createdAt DESC")
    fun getAllUsers(): Flow<List<VlessUserEntity>>

    @Query("SELECT * FROM vless_users ORDER BY createdAt DESC")
    suspend fun getAllUsersDirect(): List<VlessUserEntity>

    @Query("SELECT * FROM vless_users WHERE uuid = :uuid LIMIT 1")
    suspend fun getUserByUuid(uuid: String): VlessUserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: VlessUserEntity)

    @Update
    suspend fun updateUser(user: VlessUserEntity)

    @Delete
    suspend fun deleteUser(user: VlessUserEntity)

    @Query("DELETE FROM vless_users WHERE uuid = :uuid")
    suspend fun deleteByUuid(uuid: String)

    @Query("UPDATE vless_users SET isOnline = :isOnline WHERE uuid = :uuid")
    suspend fun updateOnlineStatus(uuid: String, isOnline: Boolean)

    @Query("UPDATE vless_users SET usedBytes = usedBytes + :bytes WHERE uuid = :uuid")
    suspend fun addTrafficUsage(uuid: String, bytes: Long)
}

@Dao
interface SshKeyDao {
    @Query("SELECT * FROM ssh_keys ORDER BY createdAt DESC")
    fun getAllKeys(): Flow<List<SshKeyEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKey(key: SshKeyEntity): Long

    @Delete
    suspend fun deleteKey(key: SshKeyEntity)

    @Query("DELETE FROM ssh_keys WHERE id = :id")
    suspend fun deleteKeyById(id: Long)

    @Query("UPDATE ssh_keys SET isAuthorized = :isAuthorized WHERE id = :id")
    suspend fun updateAuthorized(id: Long, isAuthorized: Boolean)
}

@Dao
interface ServerLogDao {
    @Query("SELECT * FROM server_logs ORDER BY timestamp DESC LIMIT 500")
    fun getRecentLogs(): Flow<List<ServerLogEntity>>

    @Query("SELECT * FROM server_logs WHERE serverType = :type ORDER BY timestamp DESC LIMIT 500")
    fun getLogsByType(type: ServerType): Flow<List<ServerLogEntity>>

    @Query("SELECT * FROM server_logs WHERE level = :level ORDER BY timestamp DESC LIMIT 500")
    fun getLogsByLevel(level: LogLevel): Flow<List<ServerLogEntity>>

    @Insert
    suspend fun insertLog(log: ServerLogEntity)

    @Query("DELETE FROM server_logs")
    suspend fun clearAllLogs()

    @Query("DELETE FROM server_logs WHERE serverType = :type")
    suspend fun clearLogsByType(type: ServerType)
}

@Dao
interface ConnectionHistoryDao {
    @Query("SELECT * FROM connection_history ORDER BY connectedAt DESC LIMIT 100")
    fun getRecentConnections(): Flow<List<ConnectionHistoryEntity>>

    @Query("SELECT * FROM connection_history WHERE serverType = :type ORDER BY connectedAt DESC LIMIT 100")
    fun getConnectionsByType(type: ServerType): Flow<List<ConnectionHistoryEntity>>

    @Insert
    suspend fun insertConnection(conn: ConnectionHistoryEntity): Long

    @Query("UPDATE connection_history SET disconnectedAt = :disconnectedAt, totalBytesTransferred = :bytes WHERE id = :id")
    suspend fun markDisconnected(id: Long, disconnectedAt: Long, bytes: Long)

    @Query("DELETE FROM connection_history")
    suspend fun clearHistory()
}
