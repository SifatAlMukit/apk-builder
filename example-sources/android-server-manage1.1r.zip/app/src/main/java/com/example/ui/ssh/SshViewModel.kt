package com.example.ui.ssh

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ServerApplication
import com.example.data.model.ConnectedClient
import com.example.data.model.ConnectionHistoryEntity
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerLogEntity
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.data.model.SshKeyEntity
import com.example.server.NetworkUtils
import com.example.service.ServerForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SshUiState(
    val config: ServerConfigEntity = ServerConfigEntity(serverType = ServerType.SSH, port = 2222),
    val status: ServerStatus = ServerStatus.STOPPED,
    val connectedClients: List<ConnectedClient> = emptyList(),
    val connectionHistory: List<ConnectionHistoryEntity> = emptyList(),
    val keys: List<SshKeyEntity> = emptyList(),
    val logs: List<ServerLogEntity> = emptyList(),
    val localIp: String = "127.0.0.1"
)

class SshViewModel(private val app: ServerApplication) : ViewModel() {

    private val repository = app.serverRepository
    private val sshEngine = app.sshServerEngine

    private val serverStatusFlow = combine(
        repository.getConfig(ServerType.SSH),
        repository.sshServerStatus,
        repository.connectedClients
    ) { cfg, status, clients ->
        Triple(cfg ?: ServerConfigEntity(serverType = ServerType.SSH, port = 2222), status, clients.filter { it.serverType == ServerType.SSH })
    }

    val uiState: StateFlow<SshUiState> = combine(
        serverStatusFlow,
        repository.connectionHistory,
        repository.allSshKeys,
        repository.getLogsByType(ServerType.SSH)
    ) { (cfg, status, clients), history, keys, logs ->
        SshUiState(
            config = cfg,
            status = status,
            connectedClients = clients,
            connectionHistory = history.filter { it.serverType == ServerType.SSH },
            keys = keys,
            logs = logs,
            localIp = NetworkUtils.getLocalIpAddress()
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        SshUiState()
    )

    fun toggleServer(context: Context) {
        if (uiState.value.status == ServerStatus.RUNNING) {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_STOP_SSH)
        } else {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_START_SSH)
        }
    }

    fun restartServer(context: Context) {
        viewModelScope.launch {
            sshEngine.restartServer(uiState.value.config)
        }
    }

    fun updatePort(port: Int) {
        viewModelScope.launch {
            val updated = uiState.value.config.copy(port = port)
            repository.saveConfig(updated)
        }
    }

    fun updateCredentials(username: String, pass: String) {
        viewModelScope.launch {
            val updated = uiState.value.config.copy(sshUsername = username, sshPassword = pass)
            repository.saveConfig(updated)
        }
    }

    fun updatePublicKeyAuthOnly(enabled: Boolean) {
        viewModelScope.launch {
            val updated = uiState.value.config.copy(sshPublicKeyAuthOnly = enabled)
            repository.saveConfig(updated)
        }
    }

    fun updateAutoStart(enabled: Boolean) {
        viewModelScope.launch {
            val updated = uiState.value.config.copy(autoStartOnBoot = enabled)
            repository.saveConfig(updated)
        }
    }

    fun generateNewKey(name: String) {
        viewModelScope.launch {
            val (pubKey, privAlias) = sshEngine.generateKeyPair(name)
            repository.insertSshKey(
                SshKeyEntity(
                    name = name,
                    publicKey = pubKey,
                    privateKeyAlias = privAlias,
                    isAuthorized = true
                )
            )
        }
    }

    fun importKey(name: String, publicKey: String) {
        viewModelScope.launch {
            repository.insertSshKey(
                SshKeyEntity(
                    name = name,
                    publicKey = publicKey.trim(),
                    isAuthorized = true
                )
            )
        }
    }

    fun deleteKey(id: Long) {
        viewModelScope.launch {
            repository.deleteSshKeyById(id)
        }
    }

    fun toggleKeyAuthorized(id: Long, authorized: Boolean) {
        viewModelScope.launch {
            repository.setSshKeyAuthorized(id, authorized)
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    class Factory(private val app: ServerApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return SshViewModel(app) as T
        }
    }
}
