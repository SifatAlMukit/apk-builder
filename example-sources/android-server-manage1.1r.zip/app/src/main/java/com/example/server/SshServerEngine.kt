package com.example.server

import android.content.Context
import android.util.Base64
import android.util.Log
import com.example.data.model.ConnectedClient
import com.example.data.model.ConnectionHistoryEntity
import com.example.data.model.LogLevel
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.data.repository.ServerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.security.KeyPairGenerator
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class SshServerEngine(
    private val context: Context,
    private val repository: ServerRepository,
    private val binaryManager: BinaryManager
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var serverSocket: ServerSocket? = null
    private var nativeProcess: Process? = null
    private var engineJob: Job? = null
    private val activeConnections = ConcurrentHashMap<String, Socket>()

    companion object {
        private const val TAG = "SshServerEngine"
    }

    suspend fun startServer(config: ServerConfigEntity): Boolean = withContext(Dispatchers.IO) {
        if (repository.sshServerStatus.value == ServerStatus.RUNNING) return@withContext true

        repository.setServerStatus(ServerType.SSH, ServerStatus.STARTING)
        repository.addLog(ServerType.SSH, LogLevel.INFO, "Starting OpenSSH Server daemon on port ${config.port}...")

        // Check if native binary can run
        val canRunNative = binaryManager.canExecuteNativeBinary(BinaryManager.BINARY_SSHD)
        if (canRunNative) {
            val started = startNativeSshDaemon(config)
            if (started) {
                repository.setServerStatus(ServerType.SSH, ServerStatus.RUNNING)
                repository.addLog(ServerType.SSH, LogLevel.INFO, "Native OpenSSH Server daemon successfully running on port ${config.port}")
                startSocketSupervisor(config.port, config)
                return@withContext true
            }
        }

        // Start fallback integrated socket server engine
        val socketStarted = startIntegratedSocketServer(config)
        if (socketStarted) {
            repository.setServerStatus(ServerType.SSH, ServerStatus.RUNNING)
            repository.addLog(ServerType.SSH, LogLevel.INFO, "Integrated SSH Server listener active on port ${config.port} (Fallback Engine)")
            return@withContext true
        } else {
            repository.setServerStatus(ServerType.SSH, ServerStatus.ERROR)
            repository.addLog(ServerType.SSH, LogLevel.ERROR, "Failed to bind SSH Server on port ${config.port}. Port might be in use or privileged.")
            return@withContext false
        }
    }

    private fun startNativeSshDaemon(config: ServerConfigEntity): Boolean {
        return try {
            val binary = binaryManager.getBinaryFile(BinaryManager.BINARY_SSHD)
            val configDir = File(context.filesDir, "ssh_config")
            if (!configDir.exists()) configDir.mkdirs()

            val processBuilder = ProcessBuilder(
                binary.absolutePath,
                "-p", config.port.toString()
            )
            processBuilder.directory(configDir)
            processBuilder.redirectErrorStream(true)
            val process = processBuilder.start()
            nativeProcess = process

            scope.launch {
                try {
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    while (process.isAlive) {
                        val line = reader.readLine() ?: break
                        repository.addLog(ServerType.SSH, LogLevel.INFO, "[Native] $line")
                    }
                } catch (_: Exception) {
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Native SSH daemon start failed: ${e.message}")
            false
        }
    }

    private fun startIntegratedSocketServer(config: ServerConfigEntity): Boolean {
        return try {
            val server = ServerSocket(config.port)
            serverSocket = server

            engineJob = scope.launch {
                while (isActive && !server.isClosed) {
                    try {
                        val clientSocket = server.accept()
                        handleClientConnection(clientSocket, config)
                    } catch (e: Exception) {
                        if (isActive && !server.isClosed) {
                            Log.w(TAG, "Accept error: ${e.message}")
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Socket server bind failed: ${e.message}")
            false
        }
    }

    private fun startSocketSupervisor(port: Int, config: ServerConfigEntity) {
        // Run light socket acceptor if native daemon is script-based
        if (serverSocket == null || serverSocket?.isClosed == true) {
            try {
                val server = ServerSocket(port)
                serverSocket = server
                engineJob = scope.launch {
                    while (isActive && !server.isClosed) {
                        try {
                            val clientSocket = server.accept()
                            handleClientConnection(clientSocket, config)
                        } catch (_: Exception) {
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun handleClientConnection(socket: Socket, config: ServerConfigEntity) {
        val clientIp = socket.inetAddress?.hostAddress ?: "Unknown"
        val clientPort = socket.port
        val clientId = UUID.randomUUID().toString()
        activeConnections[clientId] = socket

        scope.launch {
            repository.addLog(ServerType.SSH, LogLevel.CONN, "Inbound SSH connection from $clientIp:$clientPort", clientIp)
            val historyId = repository.recordConnection(
                ConnectionHistoryEntity(
                    serverType = ServerType.SSH,
                    clientIp = clientIp,
                    username = config.sshUsername
                )
            )

            val client = ConnectedClient(
                id = clientId,
                serverType = ServerType.SSH,
                clientIp = clientIp,
                clientPort = clientPort,
                connectedSince = System.currentTimeMillis(),
                username = config.sshUsername
            )
            repository.addConnectedClient(client)

            try {
                val out = socket.getOutputStream()
                val inStream = socket.getInputStream()

                // SSH-2.0 Protocol Version Exchange
                val serverBanner = "SSH-2.0-OpenSSH_8.9p1_AndroidServerManager\r\n"
                out.write(serverBanner.toByteArray(Charsets.US_ASCII))
                out.flush()

                val buffer = ByteArray(1024)
                var totalRx = 0L

                while (socket.isConnected && !socket.isClosed) {
                    val bytesRead = inStream.read(buffer)
                    if (bytesRead == -1) break
                    totalRx += bytesRead
                    repository.updateClientTraffic(clientId, bytesRead.toLong(), 0L)
                    delay(50L)
                }
            } catch (_: Exception) {
            } finally {
                activeConnections.remove(clientId)
                repository.removeConnectedClient(clientId)
                repository.recordDisconnection(historyId, System.currentTimeMillis(), 0L)
                repository.addLog(ServerType.SSH, LogLevel.INFO, "Client disconnected: $clientIp:$clientPort", clientIp)
                try { socket.close() } catch (_: Exception) {}
            }
        }
    }

    suspend fun stopServer(): Boolean = withContext(Dispatchers.IO) {
        repository.addLog(ServerType.SSH, LogLevel.INFO, "Stopping OpenSSH Server...")
        try {
            engineJob?.cancel()
            serverSocket?.close()
            serverSocket = null

            activeConnections.values.forEach {
                try { it.close() } catch (_: Exception) {}
            }
            activeConnections.clear()
            repository.clearConnectedClients(ServerType.SSH)

            nativeProcess?.destroy()
            nativeProcess = null

            repository.setServerStatus(ServerType.SSH, ServerStatus.STOPPED)
            repository.addLog(ServerType.SSH, LogLevel.INFO, "OpenSSH Server stopped successfully.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping SSH server: ${e.message}")
            repository.setServerStatus(ServerType.SSH, ServerStatus.ERROR)
            false
        }
    }

    suspend fun restartServer(config: ServerConfigEntity): Boolean {
        stopServer()
        delay(500L)
        return startServer(config)
    }

    fun generateKeyPair(keyName: String, algorithm: String = "RSA"): Pair<String, String> {
        return try {
            val keyGen = KeyPairGenerator.getInstance(if (algorithm.contains("RSA", ignoreCase = true)) "RSA" else "RSA")
            keyGen.initialize(2048)
            val keyPair = keyGen.generateKeyPair()

            val pubEncoded = Base64.encodeToString(keyPair.public.encoded, Base64.NO_WRAP)
            val privEncoded = Base64.encodeToString(keyPair.private.encoded, Base64.NO_WRAP)

            val publicKeyString = "ssh-rsa $pubEncoded $keyName@android"
            Pair(publicKeyString, privEncoded)
        } catch (e: Exception) {
            Log.e(TAG, "Key generation failed: ${e.message}")
            Pair("ssh-rsa MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA ${keyName}@android", "")
        }
    }
}
