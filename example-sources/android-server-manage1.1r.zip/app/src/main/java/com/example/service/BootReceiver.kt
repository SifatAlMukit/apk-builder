package com.example.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.ServerApplication
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val app = context.applicationContext as ServerApplication
            CoroutineScope(Dispatchers.IO).launch {
                val prefs = app.preferencesRepository.userPreferencesFlow.firstOrNull()
                if (prefs?.autoStartOnBoot == true) {
                    ServerForegroundService.startService(context, ServerForegroundService.ACTION_START_ALL)
                }
            }
        }
    }
}
