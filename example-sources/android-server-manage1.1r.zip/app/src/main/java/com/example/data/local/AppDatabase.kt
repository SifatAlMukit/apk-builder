package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ConnectionHistoryEntity
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerLogEntity
import com.example.data.model.ServerType
import com.example.data.model.SshKeyEntity
import com.example.data.model.VlessUserEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.UUID

@Database(
    entities = [
        ServerConfigEntity::class,
        VlessUserEntity::class,
        SshKeyEntity::class,
        ServerLogEntity::class,
        ConnectionHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun serverConfigDao(): ServerConfigDao
    abstract fun vlessUserDao(): VlessUserDao
    abstract fun sshKeyDao(): SshKeyDao
    abstract fun serverLogDao(): ServerLogDao
    abstract fun connectionHistoryDao(): ConnectionHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "android_server_manager.db"
                )
                    .fallbackToDestructiveMigration()
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate default server configurations
                            CoroutineScope(Dispatchers.IO).launch {
                                val dbInstance = getInstance(context)
                                dbInstance.serverConfigDao().insertOrUpdate(
                                    ServerConfigEntity(
                                        serverType = ServerType.SSH,
                                        isEnabled = false,
                                        port = 2222,
                                        sshUsername = "admin",
                                        sshPassword = "password123"
                                    )
                                )
                                dbInstance.serverConfigDao().insertOrUpdate(
                                    ServerConfigEntity(
                                        serverType = ServerType.VLESS,
                                        isEnabled = false,
                                        port = 4433,
                                        vlessProtocol = "tcp",
                                        vlessSecurity = "none"
                                    )
                                )
                                // Seed initial default VLESS user
                                dbInstance.vlessUserDao().insertUser(
                                    VlessUserEntity(
                                        uuid = UUID.randomUUID().toString(),
                                        username = "default_user",
                                        isEnabled = true,
                                        trafficLimitMb = 0L
                                    )
                                )
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
