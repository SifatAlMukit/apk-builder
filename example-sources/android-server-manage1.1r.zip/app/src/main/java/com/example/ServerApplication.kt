package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.repository.PreferencesRepository
import com.example.data.repository.ServerRepository
import com.example.server.BinaryManager
import com.example.server.SshServerEngine
import com.example.server.SystemMonitor
import com.example.server.VlessServerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class ServerApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var serverRepository: ServerRepository
        private set

    lateinit var preferencesRepository: PreferencesRepository
        private set

    lateinit var binaryManager: BinaryManager
        private set

    lateinit var sshServerEngine: SshServerEngine
        private set

    lateinit var vlessServerEngine: VlessServerEngine
        private set

    lateinit var systemMonitor: SystemMonitor
        private set

    override fun onCreate() {
        super.onCreate()

        database = AppDatabase.getInstance(this)
        serverRepository = ServerRepository(database)
        preferencesRepository = PreferencesRepository(this)
        binaryManager = BinaryManager(this)

        sshServerEngine = SshServerEngine(this, serverRepository, binaryManager)
        vlessServerEngine = VlessServerEngine(this, serverRepository, binaryManager)
        systemMonitor = SystemMonitor(this)

        // Asynchronously extract and prepare binaries on startup
        CoroutineScope(Dispatchers.IO).launch {
            binaryManager.extractAndPrepareBinaries()
        }
    }
}
