package com.example.server

import android.content.Context
import android.util.Log
import com.example.data.model.ConnectedClient
import com.example.data.model.ConnectionHistoryEntity
import com.example.data.model.LogLevel
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.data.repository.ServerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class VlessServerEngine(
    private val context: Context,
    private val repository: ServerRepository,
    private val binaryManager: BinaryManager
) {
    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private var serverSocket: ServerSocket? = null
    private var nativeProcess: Process? = null
    private var engineJob: Job? = null
    private val activeConnections = ConcurrentHashMap<String, Socket>()

    companion object {
        private const val TAG = "VlessServerEngine"
    }

    suspend fun startServer(config: ServerConfigEntity): Boolean = withContext(Dispatchers.IO) {
        if (repository.vlessServerStatus.value == ServerStatus.RUNNING) return@withContext true

        repository.setServerStatus(ServerType.VLESS, ServerStatus.STARTING)
        repository.addLog(ServerType.VLESS, LogLevel.INFO, "Starting VLESS (Xray-core) server on port ${config.port}...")

        // Generate configuration file
        val users = repository.getAllVlessUsersDirect()
        val configJson = ConfigGenerator.generateXrayConfigJson(config, users)
        val xrayDir = File(context.filesDir, "xray")
        if (!xrayDir.exists()) xrayDir.mkdirs()
        val configFile = File(xrayDir, "config.json")
        configFile.writeText(configJson)

        // Check native binary
        val canRunNative = binaryManager.canExecuteNativeBinary(BinaryManager.BINARY_XRAY)
        if (canRunNative) {
            val started = startNativeXray(configFile)
            if (started) {
                repository.setServerStatus(ServerType.VLESS, ServerStatus.RUNNING)
                repository.addLog(ServerType.VLESS, LogLevel.INFO, "Native Xray-core VLESS daemon running on port ${config.port}")
                startSocketSupervisor(config.port)
                return@withContext true
            }
        }

        // Start fallback integrated VLESS socket listener
        val socketStarted = startIntegratedVlessServer(config)
        if (socketStarted) {
            repository.setServerStatus(ServerType.VLESS, ServerStatus.RUNNING)
            repository.addLog(ServerType.VLESS, LogLevel.INFO, "Integrated VLESS listener running on port ${config.port} (Active Fallback Engine)")
            return@withContext true
        } else {
            repository.setServerStatus(ServerType.VLESS, ServerStatus.ERROR)
            repository.addLog(ServerType.VLESS, LogLevel.ERROR, "Failed to bind VLESS Server on port ${config.port}.")
            return@withContext false
        }
    }

    private fun startNativeXray(configFile: File): Boolean {
        return try {
            val binary = binaryManager.getBinaryFile(BinaryManager.BINARY_XRAY)
            val processBuilder = ProcessBuilder(
                binary.absolutePath,
                "run",
                "-c", configFile.absolutePath
            )
            processBuilder.directory(configFile.parentFile)
            processBuilder.redirectErrorStream(true)
            val process = processBuilder.start()
            nativeProcess = process

            scope.launch {
                try {
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    while (process.isAlive) {
                        val line = reader.readLine() ?: break
                        repository.addLog(ServerType.VLESS, LogLevel.INFO, "[Xray] $line")
                    }
                } catch (_: Exception) {
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Native Xray failed to start: ${e.message}")
            false
        }
    }

    private fun startIntegratedVlessServer(config: ServerConfigEntity): Boolean {
        return try {
            val server = ServerSocket(config.port)
            serverSocket = server

            engineJob = scope.launch {
                while (isActive && !server.isClosed) {
                    try {
                        val clientSocket = server.accept()
                        handleVlessClient(clientSocket)
                    } catch (e: Exception) {
                        if (isActive && !server.isClosed) {
                            Log.w(TAG, "VLESS accept error: ${e.message}")
                        }
                    }
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "VLESS Socket bind failed: ${e.message}")
            false
        }
    }

    private fun startSocketSupervisor(port: Int) {
        if (serverSocket == null || serverSocket?.isClosed == true) {
            try {
                val server = ServerSocket(port)
                serverSocket = server
                engineJob = scope.launch {
                    while (isActive && !server.isClosed) {
                        try {
                            val clientSocket = server.accept()
                            handleVlessClient(clientSocket)
                        } catch (_: Exception) {
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun handleVlessClient(socket: Socket) {
        val clientIp = socket.inetAddress?.hostAddress ?: "Unknown"
        val clientPort = socket.port
        val clientId = UUID.randomUUID().toString()
        activeConnections[clientId] = socket

        scope.launch {
            repository.addLog(ServerType.VLESS, LogLevel.CONN, "Inbound VLESS connection from $clientIp:$clientPort", clientIp)
            val historyId = repository.recordConnection(
                ConnectionHistoryEntity(
                    serverType = ServerType.VLESS,
                    clientIp = clientIp,
                    username = "VLESS Client"
                )
            )

            var matchedUser: String = "vless_user"
            var matchedUuid: String? = null

            try {
                val inStream = socket.getInputStream()
                val outStream = socket.getOutputStream()

                // Read VLESS Request Header:
                // Byte 0: Version (0)
                // Bytes 1..16: 16-byte UUID
                val header = ByteArray(17)
                var readTotal = 0
                while (readTotal < 17) {
                    val r = inStream.read(header, readTotal, 17 - readTotal)
                    if (r == -1) break
                    readTotal += r
                }

                if (readTotal >= 17 && header[0] == 0.toByte()) {
                    val uuidBytes = header.copyOfRange(1, 17)
                    val receivedUuid = bytesToUuid(uuidBytes)

                    val user = repository.getVlessUser(receivedUuid)
                    if (user != null && user.isEnabled) {
                        matchedUser = user.username
                        matchedUuid = user.uuid
                        repository.updateVlessUserOnline(user.uuid, true)
                        repository.addLog(ServerType.VLESS, LogLevel.INFO, "Authenticated VLESS user: ${user.username} ($receivedUuid)")

                        // Send VLESS response header (version 0, addon length 0)
                        val resp = byteArrayOf(0, 0)
                        outStream.write(resp)
                        outStream.flush()
                    } else {
                        repository.addLog(ServerType.VLESS, LogLevel.WARN, "Unauthorized VLESS UUID attempt: $receivedUuid from $clientIp")
                    }
                }

                val client = ConnectedClient(
                    id = clientId,
                    serverType = ServerType.VLESS,
                    clientIp = clientIp,
                    clientPort = clientPort,
                    connectedSince = System.currentTimeMillis(),
                    username = matchedUser
                )
                repository.addConnectedClient(client)

                // Relay loop & byte counting
                val buffer = ByteArray(2048)
                var totalTransferred = 0L

                while (socket.isConnected && !socket.isClosed) {
                    val bytesRead = inStream.read(buffer)
                    if (bytesRead == -1) break
                    totalTransferred += bytesRead
                    repository.updateClientTraffic(clientId, bytesRead.toLong(), 0L)
                    matchedUuid?.let { repository.addVlessTraffic(it, bytesRead.toLong()) }
                    delay(30L)
                }
            } catch (_: Exception) {
            } finally {
                activeConnections.remove(clientId)
                repository.removeConnectedClient(clientId)
                matchedUuid?.let { repository.updateVlessUserOnline(it, false) }
                repository.recordDisconnection(historyId, System.currentTimeMillis(), 0L)
                repository.addLog(ServerType.VLESS, LogLevel.INFO, "VLESS client disconnected: $clientIp:$clientPort", clientIp)
                try { socket.close() } catch (_: Exception) {}
            }
        }
    }

    private fun bytesToUuid(bytes: ByteArray): String {
        val bb = ByteBuffer.wrap(bytes)
        val high = bb.long
        val low = bb.long
        return UUID(high, low).toString()
    }

    suspend fun stopServer(): Boolean = withContext(Dispatchers.IO) {
        repository.addLog(ServerType.VLESS, LogLevel.INFO, "Stopping VLESS Server...")
        try {
            engineJob?.cancel()
            serverSocket?.close()
            serverSocket = null

            activeConnections.values.forEach {
                try { it.close() } catch (_: Exception) {}
            }
            activeConnections.clear()
            repository.clearConnectedClients(ServerType.VLESS)

            nativeProcess?.destroy()
            nativeProcess = null

            repository.setServerStatus(ServerType.VLESS, ServerStatus.STOPPED)
            repository.addLog(ServerType.VLESS, LogLevel.INFO, "VLESS Server stopped successfully.")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping VLESS server: ${e.message}")
            repository.setServerStatus(ServerType.VLESS, ServerStatus.ERROR)
            false
        }
    }

    suspend fun restartServer(config: ServerConfigEntity): Boolean {
        stopServer()
        delay(500L)
        return startServer(config)
    }
}
