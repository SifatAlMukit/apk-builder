package com.example.ui.vless

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ServerApplication
import com.example.data.model.ConnectedClient
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.data.model.VlessUserEntity
import com.example.server.ConfigGenerator
import com.example.server.NetworkUtils
import com.example.service.ServerForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.UUID

data class VlessUiState(
    val config: ServerConfigEntity = ServerConfigEntity(serverType = ServerType.VLESS, port = 4433),
    val status: ServerStatus = ServerStatus.STOPPED,
    val users: List<VlessUserEntity> = emptyList(),
    val connectedClients: List<ConnectedClient> = emptyList(),
    val localIp: String = "127.0.0.1",
    val generatedJsonConfig: String = "",
    val jsonValidationError: String? = null
)

class VlessViewModel(private val app: ServerApplication) : ViewModel() {

    private val repository = app.serverRepository
    private val vlessEngine = app.vlessServerEngine

    val uiState: StateFlow<VlessUiState> = combine(
        repository.getConfig(ServerType.VLESS),
        repository.vlessServerStatus,
        repository.allVlessUsers,
        repository.connectedClients
    ) { cfg, status, users, clients ->
        val effectiveConfig = cfg ?: ServerConfigEntity(serverType = ServerType.VLESS, port = 4433)
        val json = ConfigGenerator.generateXrayConfigJson(effectiveConfig, users)
        VlessUiState(
            config = effectiveConfig,
            status = status,
            users = users,
            connectedClients = clients.filter { it.serverType == ServerType.VLESS },
            localIp = NetworkUtils.getLocalIpAddress(),
            generatedJsonConfig = json
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        VlessUiState()
    )

    fun toggleServer(context: Context) {
        if (uiState.value.status == ServerStatus.RUNNING) {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_STOP_VLESS)
        } else {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_START_VLESS)
        }
    }

    fun restartServer(context: Context) {
        viewModelScope.launch {
            vlessEngine.restartServer(uiState.value.config)
        }
    }

    fun updatePort(port: Int) {
        viewModelScope.launch {
            val updated = uiState.value.config.copy(port = port)
            repository.saveConfig(updated)
        }
    }

    fun updateProtocolSettings(protocol: String, security: String) {
        viewModelScope.launch {
            val updated = uiState.value.config.copy(vlessProtocol = protocol, vlessSecurity = security)
            repository.saveConfig(updated)
        }
    }

    fun generateNewUuid(): String = UUID.randomUUID().toString()

    fun addUser(
        username: String,
        customUuid: String?,
        trafficLimitMb: Long = 0L,
        expiryTimestamp: Long = 0L
    ) {
        viewModelScope.launch {
            val uuid = if (customUuid.isNullOrBlank()) generateNewUuid() else customUuid.trim()
            val user = VlessUserEntity(
                uuid = uuid,
                username = username.ifBlank { "user_${uuid.take(6)}" },
                isEnabled = true,
                trafficLimitMb = trafficLimitMb,
                expiryTimestamp = expiryTimestamp
            )
            repository.insertVlessUser(user)
        }
    }

    fun updateUser(user: VlessUserEntity) {
        viewModelScope.launch {
            repository.updateVlessUser(user)
        }
    }

    fun deleteUser(uuid: String) {
        viewModelScope.launch {
            repository.deleteVlessUserByUuid(uuid)
        }
    }

    fun toggleUserEnabled(uuid: String, enabled: Boolean) {
        viewModelScope.launch {
            val user = repository.getVlessUser(uuid) ?: return@launch
            repository.updateVlessUser(user.copy(isEnabled = enabled))
        }
    }

    fun saveRawJson(jsonContent: String): Boolean {
        val (isValid, errorMsg) = ConfigGenerator.validateJson(jsonContent)
        if (!isValid) return false

        return try {
            val json = JSONObject(jsonContent)
            val inbounds = json.optJSONArray("inbounds")
            if (inbounds != null && inbounds.length() > 0) {
                val firstInbound = inbounds.getJSONObject(0)
                val port = firstInbound.optInt("port", uiState.value.config.port)
                updatePort(port)
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    class Factory(private val app: ServerApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return VlessViewModel(app) as T
        }
    }
}
