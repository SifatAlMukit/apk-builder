package com.example.ui.logs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ServerApplication
import com.example.data.model.LogLevel
import com.example.data.model.ServerLogEntity
import com.example.data.model.ServerType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LogsUiState(
    val logs: List<ServerLogEntity> = emptyList(),
    val searchQuery: String = "",
    val selectedServerFilter: ServerType? = null,
    val selectedLogLevel: LogLevel? = null
)

class LogsViewModel(private val app: ServerApplication) : ViewModel() {

    private val repository = app.serverRepository
    private val searchQueryFlow = MutableStateFlow("")
    private val selectedServerFilterFlow = MutableStateFlow<ServerType?>(null)
    private val selectedLogLevelFlow = MutableStateFlow<LogLevel?>(null)

    val uiState: StateFlow<LogsUiState> = combine(
        repository.recentLogs,
        searchQueryFlow,
        selectedServerFilterFlow,
        selectedLogLevelFlow
    ) { allLogs, query, serverFilter, levelFilter ->
        val filtered = allLogs.filter { log ->
            val matchesQuery = query.isBlank() || log.message.contains(query, ignoreCase = true) ||
                    (log.clientIp != null && log.clientIp.contains(query, ignoreCase = true))
            val matchesServer = serverFilter == null || log.serverType == serverFilter
            val matchesLevel = levelFilter == null || log.level == levelFilter
            matchesQuery && matchesServer && matchesLevel
        }
        LogsUiState(
            logs = filtered,
            searchQuery = query,
            selectedServerFilter = serverFilter,
            selectedLogLevel = levelFilter
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        LogsUiState()
    )

    fun setSearchQuery(query: String) {
        searchQueryFlow.value = query
    }

    fun setSelectedServerFilter(type: ServerType?) {
        selectedServerFilterFlow.value = type
    }

    fun setSelectedLogLevel(level: LogLevel?) {
        selectedLogLevelFlow.value = level
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs(selectedServerFilterFlow.value)
        }
    }

    fun getAllLogsFormatted(): String {
        val dateFormat = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.getDefault())
        return uiState.value.logs.joinToString("\n") { log ->
            val time = dateFormat.format(java.util.Date(log.timestamp))
            "[$time] [${log.serverType}] [${log.level}] ${log.message}${if (log.clientIp != null) " (IP: ${log.clientIp})" else ""}"
        }
    }

    class Factory(private val app: ServerApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LogsViewModel(app) as T
        }
    }
}
