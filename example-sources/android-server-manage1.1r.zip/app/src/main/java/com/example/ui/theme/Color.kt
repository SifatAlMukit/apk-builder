package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Cyan / Electric Slate Palette
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDim = Color(0xFF00B4D8)
val DarkBackground = Color(0xFF0B1015)
val DarkSurface = Color(0xFF131A21)
val DarkSurfaceVariant = Color(0xFF1B2530)
val DarkSurfaceHighlight = Color(0xFF243242)

val ElectricGreen = Color(0xFF00E676)
val ElectricGreenDim = Color(0xFF00B050)
val NeonAmber = Color(0xFFFFB300)
val CoralRed = Color(0xFFFF5252)

val TextPrimaryDark = Color(0xFFF0F4F8)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextMutedDark = Color(0xFF64748B)

// Light Theme equivalents
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightPrimary = Color(0xFF006875)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
