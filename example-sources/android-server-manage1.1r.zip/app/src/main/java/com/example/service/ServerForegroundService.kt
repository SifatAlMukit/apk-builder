package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.ServerApplication
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.server.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

class ServerForegroundService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var wakeLock: PowerManager.WakeLock? = null

    companion object {
        const val CHANNEL_ID = "server_manager_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START_ALL = "com.example.action.START_ALL"
        const val ACTION_STOP_ALL = "com.example.action.STOP_ALL"
        const val ACTION_RESTART_ALL = "com.example.action.RESTART_ALL"

        const val ACTION_START_SSH = "com.example.action.START_SSH"
        const val ACTION_STOP_SSH = "com.example.action.STOP_SSH"
        const val ACTION_START_VLESS = "com.example.action.START_VLESS"
        const val ACTION_STOP_VLESS = "com.example.action.STOP_VLESS"

        fun startService(context: Context, action: String = ACTION_START_ALL) {
            val intent = Intent(context, ServerForegroundService::class.java).apply {
                this.action = action
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, ServerForegroundService::class.java).apply {
                action = ACTION_STOP_ALL
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        acquireWakeLock()
        observeServerStatusAndNotify()
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ServerManager::WakeLock").apply {
            setReferenceCounted(false)
            acquire(24 * 60 * 60 * 1000L) // 24 hours max
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Server Foreground Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows real-time status of local SSH and VLESS servers"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun observeServerStatusAndNotify() {
        val app = application as ServerApplication
        serviceScope.launch {
            combine(
                app.serverRepository.sshServerStatus,
                app.serverRepository.vlessServerStatus
            ) { sshStatus, vlessStatus ->
                Pair(sshStatus, vlessStatus)
            }.collect { (sshStatus, vlessStatus) ->
                updateNotification(sshStatus, vlessStatus)
            }
        }
    }

    private fun buildNotification(sshStatus: ServerStatus, vlessStatus: ServerStatus): Notification {
        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val localIp = NetworkUtils.getLocalIpAddress()
        val contentText = buildString {
            append("IP: $localIp | ")
            append("SSH: ${if (sshStatus == ServerStatus.RUNNING) "ON" else "OFF"} | ")
            append("VLESS: ${if (vlessStatus == ServerStatus.RUNNING) "ON" else "OFF"}")
        }

        val stopAllIntent = Intent(this, ServerForegroundService::class.java).apply { action = ACTION_STOP_ALL }
        val stopAllPending = PendingIntent.getService(
            this, 1, stopAllIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val startAllIntent = Intent(this, ServerForegroundService::class.java).apply { action = ACTION_START_ALL }
        val startAllPending = PendingIntent.getService(
            this, 2, startAllIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restartAllIntent = Intent(this, ServerForegroundService::class.java).apply { action = ACTION_RESTART_ALL }
        val restartAllPending = PendingIntent.getService(
            this, 3, restartAllIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val isAnyRunning = sshStatus == ServerStatus.RUNNING || vlessStatus == ServerStatus.RUNNING

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Android Server Manager")
            .setContentText(contentText)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pendingIntent)
            .setOngoing(isAnyRunning)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        if (isAnyRunning) {
            builder.addAction(android.R.drawable.ic_media_pause, "Stop All", stopAllPending)
            builder.addAction(android.R.drawable.ic_popup_sync, "Restart", restartAllPending)
        } else {
            builder.addAction(android.R.drawable.ic_media_play, "Start All", startAllPending)
        }

        return builder.build()
    }

    private fun updateNotification(sshStatus: ServerStatus, vlessStatus: ServerStatus) {
        val notification = buildNotification(sshStatus, vlessStatus)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as ServerApplication
        startForeground(NOTIFICATION_ID, buildNotification(app.serverRepository.sshServerStatus.value, app.serverRepository.vlessServerStatus.value))

        val action = intent?.action ?: ACTION_START_ALL
        serviceScope.launch {
            when (action) {
                ACTION_START_ALL -> {
                    val sshConfig = app.serverRepository.getConfigDirect(ServerType.SSH)
                    val vlessConfig = app.serverRepository.getConfigDirect(ServerType.VLESS)
                    sshConfig?.let { app.sshServerEngine.startServer(it) }
                    vlessConfig?.let { app.vlessServerEngine.startServer(it) }
                }
                ACTION_STOP_ALL -> {
                    app.sshServerEngine.stopServer()
                    app.vlessServerEngine.stopServer()
                }
                ACTION_RESTART_ALL -> {
                    val sshConfig = app.serverRepository.getConfigDirect(ServerType.SSH)
                    val vlessConfig = app.serverRepository.getConfigDirect(ServerType.VLESS)
                    sshConfig?.let { app.sshServerEngine.restartServer(it) }
                    vlessConfig?.let { app.vlessServerEngine.restartServer(it) }
                }
                ACTION_START_SSH -> {
                    val sshConfig = app.serverRepository.getConfigDirect(ServerType.SSH)
                    sshConfig?.let { app.sshServerEngine.startServer(it) }
                }
                ACTION_STOP_SSH -> {
                    app.sshServerEngine.stopServer()
                }
                ACTION_START_VLESS -> {
                    val vlessConfig = app.serverRepository.getConfigDirect(ServerType.VLESS)
                    vlessConfig?.let { app.vlessServerEngine.startServer(it) }
                }
                ACTION_STOP_VLESS -> {
                    app.vlessServerEngine.stopServer()
                }
            }
        }

        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        wakeLock?.let {
            if (it.isHeld) it.release()
        }
    }
}
