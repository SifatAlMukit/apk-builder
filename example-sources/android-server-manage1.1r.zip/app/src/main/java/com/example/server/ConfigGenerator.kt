package com.example.server

import com.example.data.model.ServerConfigEntity
import com.example.data.model.VlessUserEntity
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder

object ConfigGenerator {

    fun generateXrayConfigJson(config: ServerConfigEntity, users: List<VlessUserEntity>): String {
        val root = JSONObject()

        // Log section
        val logObj = JSONObject()
        logObj.put("loglevel", "warning")
        root.put("log", logObj)

        // Inbounds section
        val inboundsArray = JSONArray()
        val inboundObj = JSONObject()
        inboundObj.put("port", config.port)
        inboundObj.put("protocol", "vless")

        val settingsObj = JSONObject()
        val clientsArray = JSONArray()
        for (user in users.filter { it.isEnabled }) {
            val clientObj = JSONObject()
            clientObj.put("id", user.uuid)
            clientObj.put("flow", "none")
            clientObj.put("email", user.username)
            clientObj.put("level", 0)
            clientsArray.put(clientObj)
        }
        settingsObj.put("clients", clientsArray)
        settingsObj.put("decryption", "none")
        inboundObj.put("settings", settingsObj)

        val streamSettingsObj = JSONObject()
        streamSettingsObj.put("network", config.vlessProtocol.ifEmpty { "tcp" })
        streamSettingsObj.put("security", config.vlessSecurity.ifEmpty { "none" })
        inboundObj.put("streamSettings", streamSettingsObj)
        inboundObj.put("tag", "vless-inbound")

        inboundsArray.put(inboundObj)
        root.put("inbounds", inboundsArray)

        // Outbounds section
        val outboundsArray = JSONArray()
        val directOutbound = JSONObject()
        directOutbound.put("protocol", "freedom")
        directOutbound.put("tag", "direct")
        outboundsArray.put(directOutbound)

        val blockOutbound = JSONObject()
        blockOutbound.put("protocol", "blackhole")
        blockOutbound.put("tag", "block")
        outboundsArray.put(blockOutbound)

        root.put("outbounds", outboundsArray)

        return root.toString(2)
    }

    fun validateJson(jsonString: String): Pair<Boolean, String?> {
        return try {
            JSONObject(jsonString)
            Pair(true, null)
        } catch (e: Exception) {
            Pair(false, e.message ?: "Invalid JSON syntax")
        }
    }

    fun generateVlessUri(user: VlessUserEntity, host: String, port: Int, serverName: String = "Android-VLESS"): String {
        val encodedTag = try {
            URLEncoder.encode(serverName, "UTF-8")
        } catch (_: Exception) {
            serverName
        }
        return "vless://${user.uuid}@$host:$port?security=none&type=tcp#$encodedTag"
    }

    fun generateSshUri(username: String, host: String, port: Int): String {
        return "ssh://$username@$host:$port"
    }

    fun generateWifiConfigUri(ssid: String, pass: String): String {
        return "WIFI:T:WPA;S:$ssid;P:$pass;;"
    }
}
