package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ServerType {
    SSH,
    VLESS
}

enum class ServerStatus {
    STOPPED,
    STARTING,
    RUNNING,
    ERROR
}

enum class LogLevel {
    INFO,
    WARN,
    ERROR,
    CONN
}

@Entity(tableName = "server_configs")
data class ServerConfigEntity(
    @PrimaryKey
    val serverType: ServerType,
    val isEnabled: Boolean = false,
    val port: Int,
    val autoStartOnBoot: Boolean = false,
    val lastStartedTimestamp: Long = 0L,
    val totalRxBytes: Long = 0L,
    val totalTxBytes: Long = 0L,
    // SSH specific
    val sshUsername: String = "admin",
    val sshPassword: String = "admin123",
    val sshPublicKeyAuthOnly: Boolean = false,
    // VLESS specific
    val vlessProtocol: String = "tcp",
    val vlessSecurity: String = "none",
    val vlessDecryption: String = "none"
)

@Entity(tableName = "vless_users")
data class VlessUserEntity(
    @PrimaryKey
    val uuid: String,
    val username: String,
    val isEnabled: Boolean = true,
    val trafficLimitMb: Long = 0L, // 0 = unlimited
    val usedBytes: Long = 0L,
    val expiryTimestamp: Long = 0L, // 0 = no expiration
    val isOnline: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ssh_keys")
data class SshKeyEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val name: String,
    val publicKey: String,
    val privateKeyAlias: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val isAuthorized: Boolean = true
)

@Entity(tableName = "server_logs")
data class ServerLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val timestamp: Long = System.currentTimeMillis(),
    val serverType: ServerType,
    val level: LogLevel,
    val message: String,
    val clientIp: String? = null
)

@Entity(tableName = "connection_history")
data class ConnectionHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val serverType: ServerType,
    val clientIp: String,
    val username: String? = null,
    val connectedAt: Long = System.currentTimeMillis(),
    val disconnectedAt: Long? = null,
    val totalBytesTransferred: Long = 0L
)

data class ConnectedClient(
    val id: String,
    val serverType: ServerType,
    val clientIp: String,
    val clientPort: Int,
    val connectedSince: Long,
    val username: String,
    val rxBytes: Long = 0L,
    val txBytes: Long = 0L
)

data class SystemStats(
    val cpuUsagePercent: Float = 0f,
    val ramUsedMb: Long = 0L,
    val ramTotalMb: Long = 0L,
    val batteryPercent: Int = 0,
    val batteryTemperatureC: Float = 0f,
    val isBatteryCharging: Boolean = false,
    val storageUsedGb: Float = 0f,
    val storageTotalGb: Float = 0f,
    val downloadSpeedKbps: Float = 0f,
    val uploadSpeedKbps: Float = 0f,
    val localIpAddress: String = "127.0.0.1",
    val gatewayAddress: String = "192.168.1.1",
    val subnetMask: String = "255.255.255.0",
    val networkInterfaceName: String = "wlan0",
    val wifiSsid: String = "Not Connected",
    val isWifiConnected: Boolean = false,
    val isHotspotActive: Boolean = false,
    val totalRunningSeconds: Long = 0L
)
