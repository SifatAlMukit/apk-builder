package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "server_manager_prefs")

enum class ThemeMode {
    SYSTEM,
    DARK,
    LIGHT
}

data class UserPreferences(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val dynamicColors: Boolean = true,
    val accentColorIndex: Int = 0,
    val language: String = "en", // "en" or "bn"
    val autoStartOnBoot: Boolean = false,
    val preventAccidentalStop: Boolean = true,
    val biometricLockEnabled: Boolean = false,
    val keepCpuAwake: Boolean = true
)

class PreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val DYNAMIC_COLORS = booleanPreferencesKey("dynamic_colors")
        val ACCENT_COLOR_INDEX = intPreferencesKey("accent_color_index")
        val LANGUAGE = stringPreferencesKey("app_language")
        val AUTO_START_ON_BOOT = booleanPreferencesKey("auto_start_on_boot")
        val PREVENT_ACCIDENTAL_STOP = booleanPreferencesKey("prevent_accidental_stop")
        val BIOMETRIC_LOCK = booleanPreferencesKey("biometric_lock")
        val KEEP_CPU_AWAKE = booleanPreferencesKey("keep_cpu_awake")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        val themeString = preferences[PreferencesKeys.THEME_MODE] ?: ThemeMode.DARK.name
        val themeMode = try {
            ThemeMode.valueOf(themeString)
        } catch (_: Exception) {
            ThemeMode.DARK
        }

        UserPreferences(
            themeMode = themeMode,
            dynamicColors = preferences[PreferencesKeys.DYNAMIC_COLORS] ?: true,
            accentColorIndex = preferences[PreferencesKeys.ACCENT_COLOR_INDEX] ?: 0,
            language = preferences[PreferencesKeys.LANGUAGE] ?: "en",
            autoStartOnBoot = preferences[PreferencesKeys.AUTO_START_ON_BOOT] ?: false,
            preventAccidentalStop = preferences[PreferencesKeys.PREVENT_ACCIDENTAL_STOP] ?: true,
            biometricLockEnabled = preferences[PreferencesKeys.BIOMETRIC_LOCK] ?: false,
            keepCpuAwake = preferences[PreferencesKeys.KEEP_CPU_AWAKE] ?: true
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.THEME_MODE] = mode.name
        }
    }

    suspend fun setDynamicColors(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.DYNAMIC_COLORS] = enabled
        }
    }

    suspend fun setAccentColorIndex(index: Int) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.ACCENT_COLOR_INDEX] = index
        }
    }

    suspend fun setLanguage(lang: String) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.LANGUAGE] = lang
        }
    }

    suspend fun setAutoStartOnBoot(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.AUTO_START_ON_BOOT] = enabled
        }
    }

    suspend fun setPreventAccidentalStop(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.PREVENT_ACCIDENTAL_STOP] = enabled
        }
    }

    suspend fun setBiometricLockEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.BIOMETRIC_LOCK] = enabled
        }
    }

    suspend fun setKeepCpuAwake(enabled: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[PreferencesKeys.KEEP_CPU_AWAKE] = enabled
        }
    }
}
