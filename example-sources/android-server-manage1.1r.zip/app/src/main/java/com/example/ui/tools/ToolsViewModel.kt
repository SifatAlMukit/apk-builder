package com.example.ui.tools

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ServerApplication
import com.example.data.model.ServerType
import com.example.data.repository.ThemeMode
import com.example.data.repository.UserPreferences
import com.example.server.DiscoveredDevice
import com.example.server.NetworkUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

data class ToolsUiState(
    val terminalOutput: String = "Android Server Manager Terminal Shell Ready.\nType any Linux command below and tap Run.\n",
    val terminalCommand: String = "",
    val isExecutingCommand: Boolean = false,
    val isScanningNetwork: Boolean = false,
    val discoveredDevices: List<DiscoveredDevice> = emptyList(),
    val preferences: UserPreferences = UserPreferences(),
    val backupJson: String? = null
)

class ToolsViewModel(private val app: ServerApplication) : ViewModel() {

    private val preferencesRepository = app.preferencesRepository
    private val serverRepository = app.serverRepository

    private val _terminalOutput = MutableStateFlow("Android Server Manager Terminal Shell Ready.\nType any Linux command below and tap Run.\n")
    private val _terminalCommand = MutableStateFlow("")
    private val _isExecuting = MutableStateFlow(false)
    private val _isScanning = MutableStateFlow(false)
    private val _discoveredDevices = MutableStateFlow<List<DiscoveredDevice>>(emptyList())
    private val _backupJson = MutableStateFlow<String?>(null)

    val preferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferences())

    private val _uiState = MutableStateFlow(ToolsUiState())
    val uiState: StateFlow<ToolsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            preferences.collect { prefs ->
                _uiState.value = _uiState.value.copy(preferences = prefs)
            }
        }
    }

    fun setTerminalCommand(cmd: String) {
        _terminalCommand.value = cmd
        _uiState.value = _uiState.value.copy(terminalCommand = cmd)
    }

    fun executeTerminalCommand(cmd: String) {
        val trimmed = cmd.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            _isExecuting.value = true
            _uiState.value = _uiState.value.copy(
                isExecutingCommand = true,
                terminalOutput = _uiState.value.terminalOutput + "\n$ $trimmed\n"
            )

            val output = withContext(Dispatchers.IO) {
                try {
                    val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", trimmed))
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    val errReader = BufferedReader(InputStreamReader(process.errorStream))
                    val sb = StringBuilder()

                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        sb.append(line).append("\n")
                    }
                    while (errReader.readLine().also { line = it } != null) {
                        sb.append(line).append("\n")
                    }
                    process.waitFor()
                    if (sb.isEmpty()) "(Command returned with exit code ${process.exitValue()})\n" else sb.toString()
                } catch (e: Exception) {
                    "Error executing command: ${e.message}\n"
                }
            }

            _isExecuting.value = false
            _uiState.value = _uiState.value.copy(
                isExecutingCommand = false,
                terminalOutput = _uiState.value.terminalOutput + output
            )
        }
    }

    fun clearTerminal() {
        _uiState.value = _uiState.value.copy(terminalOutput = "Terminal cleared.\n")
    }

    fun scanLocalNetwork() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isScanningNetwork = true)
            val ip = NetworkUtils.getLocalIpAddress()
            val devices = NetworkUtils.scanLocalSubnet(ip)
            _uiState.value = _uiState.value.copy(
                isScanningNetwork = false,
                discoveredDevices = devices
            )
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun setDynamicColors(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setDynamicColors(enabled)
        }
    }

    fun setLanguage(lang: String) {
        viewModelScope.launch {
            preferencesRepository.setLanguage(lang)
        }
    }

    fun setAutoStart(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setAutoStartOnBoot(enabled)
        }
    }

    fun setPreventAccidentalStop(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setPreventAccidentalStop(enabled)
        }
    }

    fun setKeepCpuAwake(enabled: Boolean) {
        viewModelScope.launch {
            preferencesRepository.setKeepCpuAwake(enabled)
        }
    }

    fun createBackupJson(onReady: (String) -> Unit) {
        viewModelScope.launch {
            val root = JSONObject()
            val sshConfig = serverRepository.getConfigDirect(ServerType.SSH)
            val vlessConfig = serverRepository.getConfigDirect(ServerType.VLESS)
            val users = serverRepository.allVlessUsers.firstOrNull() ?: emptyList()

            val serversObj = JSONObject()
            sshConfig?.let {
                val s = JSONObject()
                s.put("port", it.port)
                s.put("username", it.sshUsername)
                s.put("publicKeyAuthOnly", it.sshPublicKeyAuthOnly)
                serversObj.put("ssh", s)
            }
            vlessConfig?.let {
                val v = JSONObject()
                v.put("port", it.port)
                v.put("protocol", it.vlessProtocol)
                serversObj.put("vless", v)
            }
            root.put("servers", serversObj)

            val usersArr = JSONArray()
            for (u in users) {
                val uObj = JSONObject()
                uObj.put("uuid", u.uuid)
                uObj.put("username", u.username)
                uObj.put("trafficLimitMb", u.trafficLimitMb)
                usersArr.put(uObj)
            }
            root.put("users", usersArr)

            val json = root.toString(2)
            _uiState.value = _uiState.value.copy(backupJson = json)
            onReady(json)
        }
    }

    class Factory(private val app: ServerApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return ToolsViewModel(app) as T
        }
    }
}
