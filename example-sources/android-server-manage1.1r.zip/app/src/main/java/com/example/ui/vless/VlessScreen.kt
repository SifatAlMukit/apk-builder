package com.example.ui.vless

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ServerStatus
import com.example.data.model.VlessUserEntity
import com.example.server.ConfigGenerator
import com.example.ui.components.QrCodeDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CoralRed
import com.example.ui.theme.ElectricGreen
import com.example.ui.theme.NeonAmber

@Composable
fun VlessScreen(
    viewModel: VlessViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var showAddUserDialog by remember { mutableStateOf(false) }
    var qrDialogContent by remember { mutableStateOf<String?>(null) }
    var qrDialogTitle by remember { mutableStateOf("VLESS Share QR") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            // Server Header Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Surface(
                                color = NeonAmber.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.size(46.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.Dns, contentDescription = null, tint = NeonAmber)
                                }
                            }
                            Column {
                                Text(
                                    text = "VLESS (Xray-core)",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Port ${uiState.config.port} • ${uiState.users.size} Users Registered",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        StatusBadge(status = uiState.status)
                    }

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.toggleServer(context) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (uiState.status == ServerStatus.RUNNING) CoralRed else ElectricGreen
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("vless_toggle_button")
                        ) {
                            Icon(
                                if (uiState.status == ServerStatus.RUNNING) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (uiState.status == ServerStatus.RUNNING) Color.White else Color.Black,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                if (uiState.status == ServerStatus.RUNNING) "Stop" else "Start",
                                color = if (uiState.status == ServerStatus.RUNNING) Color.White else Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        FilledTonalButton(
                            onClick = { viewModel.restartServer(context) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Restart", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Section Tabs
        item {
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTabIndex == 0,
                    onClick = { selectedTabIndex = 0 },
                    text = { Text("Visual Config") }
                )
                Tab(
                    selected = selectedTabIndex == 1,
                    onClick = { selectedTabIndex = 1 },
                    text = { Text("Users (${uiState.users.size})") }
                )
                Tab(
                    selected = selectedTabIndex == 2,
                    onClick = { selectedTabIndex = 2 },
                    text = { Text("JSON Editor") }
                )
                Tab(
                    selected = selectedTabIndex == 3,
                    onClick = { selectedTabIndex = 3 },
                    text = { Text("Traffic") }
                )
            }
        }

        // TAB 0: Visual Config
        if (selectedTabIndex == 0) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        var portInput by remember(uiState.config.port) { mutableStateOf(uiState.config.port.toString()) }

                        OutlinedTextField(
                            value = portInput,
                            onValueChange = {
                                portInput = it
                                it.toIntOrNull()?.let { p -> viewModel.updatePort(p) }
                            },
                            label = { Text("Inbound Listen Port") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            OutlinedTextField(
                                value = uiState.config.vlessProtocol,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Transport Network") },
                                modifier = Modifier.weight(1f)
                            )

                            OutlinedTextField(
                                value = uiState.config.vlessSecurity,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Security Layer") },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("VLESS Protocol Summary", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                Text("VLESS is a lightweight, zero-overhead transmission protocol with no authentication encryption delay. Inbounds are dynamically matched against user UUIDs.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: User Management
        if (selectedTabIndex == 1) {
            item {
                Button(
                    onClick = { showAddUserDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_vless_user_button")
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Add VLESS User")
                }
            }

            if (uiState.users.isEmpty()) {
                item {
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                            Text("No Users Configured", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text("Add at least one user with a UUID to connect VLESS clients.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else {
                items(uiState.users) { user ->
                    val vlessUri = ConfigGenerator.generateVlessUri(user, uiState.localIp, uiState.config.port)

                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (user.isOnline) ElectricGreen.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outlineVariant
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(10.dp)
                                            .clip(CircleShape)
                                            .background(if (user.isOnline) ElectricGreen else Color.Gray)
                                    )
                                    Column {
                                        Text(user.username, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (user.isOnline) "ONLINE NOW" else if (user.isEnabled) "ACTIVE" else "DISABLED",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = if (user.isOnline) ElectricGreen else if (user.isEnabled) MaterialTheme.colorScheme.primary else Color.Gray
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = user.isEnabled,
                                        onCheckedChange = { viewModel.toggleUserEnabled(user.uuid, it) }
                                    )
                                    IconButton(onClick = { viewModel.deleteUser(user.uuid) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CoralRed)
                                    }
                                }
                            }

                            // UUID Box
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = user.uuid,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = FontFamily.Monospace,
                                        maxLines = 1,
                                        modifier = Modifier.weight(1f)
                                    )
                                    IconButton(
                                        onClick = { clipboard.setText(AnnotatedString(user.uuid)) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy UUID", modifier = Modifier.size(14.dp))
                                    }
                                }
                            }

                            // Quota usage
                            if (user.trafficLimitMb > 0) {
                                val usedMb = user.usedBytes / (1024 * 1024)
                                val progress = (usedMb.toFloat() / user.trafficLimitMb.toFloat()).coerceIn(0f, 1f)
                                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Traffic Quota", style = MaterialTheme.typography.labelSmall)
                                        Text("$usedMb / ${user.trafficLimitMb} MB", style = MaterialTheme.typography.labelSmall, fontFamily = FontFamily.Monospace)
                                    }
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(4.dp)
                                            .clip(RoundedCornerShape(2.dp)),
                                        color = if (progress > 0.9f) CoralRed else ElectricGreen
                                    )
                                }
                            }

                            // Action buttons for URI and QR
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = {
                                        clipboard.setText(AnnotatedString(vlessUri))
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Copy URI")
                                }

                                FilledTonalButton(
                                    onClick = {
                                        qrDialogTitle = "VLESS - ${user.username}"
                                        qrDialogContent = vlessUri
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("QR Code")
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: Advanced Raw JSON Editor
        if (selectedTabIndex == 2) {
            item {
                var jsonBuffer by remember(uiState.generatedJsonConfig) { mutableStateOf(uiState.generatedJsonConfig) }
                var validationStatus by remember { mutableStateOf<String?>(null) }
                var isSaveSuccess by remember { mutableStateOf(false) }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("XRAY CONFIG.JSON", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                FilledTonalButton(
                                    onClick = {
                                        val (isValid, errorMsg) = ConfigGenerator.validateJson(jsonBuffer)
                                        validationStatus = if (isValid) "JSON Syntax Valid!" else "Syntax Error: $errorMsg"
                                    }
                                ) {
                                    Text("Validate")
                                }
                                Button(
                                    onClick = {
                                        val saved = viewModel.saveRawJson(jsonBuffer)
                                        isSaveSuccess = saved
                                        validationStatus = if (saved) "Saved successfully!" else "Save failed: check syntax."
                                    }
                                ) {
                                    Text("Save")
                                }
                            }
                        }

                        validationStatus?.let {
                            Text(
                                text = it,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (it.contains("Valid") || it.contains("successfully")) ElectricGreen else CoralRed
                            )
                        }

                        OutlinedTextField(
                            value = jsonBuffer,
                            onValueChange = {
                                jsonBuffer = it
                                validationStatus = null
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(380.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                            shape = RoundedCornerShape(8.dp)
                        )
                    }
                }
            }
        }

        // TAB 3: Traffic & Connected Sessions
        if (selectedTabIndex == 3) {
            item {
                Text("VLESS CLIENT SESSIONS (${uiState.connectedClients.size})", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }

            if (uiState.connectedClients.isEmpty()) {
                item {
                    Text("No active VLESS client sessions connected.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                items(uiState.connectedClients) { client ->
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${client.clientIp}:${client.clientPort}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                Text("Client User: ${client.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Text("${client.rxBytes / 1024} KB", style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = ElectricGreen)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Add User Dialog
    if (showAddUserDialog) {
        var usernameInput by remember { mutableStateOf("") }
        var uuidInput by remember { mutableStateOf(viewModel.generateNewUuid()) }
        var trafficQuotaMbInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddUserDialog = false },
            title = { Text("Add VLESS User") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = usernameInput,
                        onValueChange = { usernameInput = it },
                        label = { Text("Username") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = uuidInput,
                            onValueChange = { uuidInput = it },
                            label = { Text("Client UUID") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        IconButton(onClick = { uuidInput = viewModel.generateNewUuid() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Generate UUID", tint = MaterialTheme.colorScheme.primary)
                        }
                    }

                    OutlinedTextField(
                        value = trafficQuotaMbInput,
                        onValueChange = { trafficQuotaMbInput = it },
                        label = { Text("Traffic Limit (MB, 0 for Unlimited)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val limit = trafficQuotaMbInput.toLongOrNull() ?: 0L
                        viewModel.addUser(
                            username = usernameInput,
                            customUuid = uuidInput,
                            trafficLimitMb = limit
                        )
                        showAddUserDialog = false
                    }
                ) {
                    Text("Add User")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddUserDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // QR Code Dialog
    qrDialogContent?.let { content ->
        QrCodeDialog(
            title = qrDialogTitle,
            content = content,
            onDismiss = { qrDialogContent = null }
        )
    }
}
