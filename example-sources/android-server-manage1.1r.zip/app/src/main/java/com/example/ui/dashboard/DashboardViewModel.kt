package com.example.ui.dashboard

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.ServerApplication
import com.example.data.model.ConnectedClient
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.data.model.SystemStats
import com.example.service.ServerForegroundService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class DashboardUiState(
    val stats: SystemStats = SystemStats(),
    val sshStatus: ServerStatus = ServerStatus.STOPPED,
    val sshPort: Int = 2222,
    val vlessStatus: ServerStatus = ServerStatus.STOPPED,
    val vlessPort: Int = 4433,
    val connectedClients: List<ConnectedClient> = emptyList(),
    val isAnyServerRunning: Boolean = false
)

class DashboardViewModel(private val app: ServerApplication) : ViewModel() {

    private val repository = app.serverRepository
    private val systemMonitor = app.systemMonitor

    private val serverStateFlow = combine(
        repository.sshServerStatus,
        repository.vlessServerStatus,
        repository.getConfig(ServerType.SSH),
        repository.getConfig(ServerType.VLESS)
    ) { sshStatus, vlessStatus, sshCfg, vlessCfg ->
        object {
            val sshStatus = sshStatus
            val vlessStatus = vlessStatus
            val sshPort = sshCfg?.port ?: 2222
            val vlessPort = vlessCfg?.port ?: 4433
        }
    }

    val uiState: StateFlow<DashboardUiState> = combine(
        systemMonitor.statsFlow,
        serverStateFlow,
        repository.connectedClients
    ) { stats, servers, clients ->
        DashboardUiState(
            stats = stats,
            sshStatus = servers.sshStatus,
            sshPort = servers.sshPort,
            vlessStatus = servers.vlessStatus,
            vlessPort = servers.vlessPort,
            connectedClients = clients,
            isAnyServerRunning = servers.sshStatus == ServerStatus.RUNNING || servers.vlessStatus == ServerStatus.RUNNING
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DashboardUiState()
    )

    fun startAll(context: Context) {
        ServerForegroundService.startService(context, ServerForegroundService.ACTION_START_ALL)
    }

    fun stopAll(context: Context) {
        ServerForegroundService.startService(context, ServerForegroundService.ACTION_STOP_ALL)
    }

    fun restartAll(context: Context) {
        ServerForegroundService.startService(context, ServerForegroundService.ACTION_RESTART_ALL)
    }

    fun toggleSshServer(context: Context) {
        if (uiState.value.sshStatus == ServerStatus.RUNNING) {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_STOP_SSH)
        } else {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_START_SSH)
        }
    }

    fun toggleVlessServer(context: Context) {
        if (uiState.value.vlessStatus == ServerStatus.RUNNING) {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_STOP_VLESS)
        } else {
            ServerForegroundService.startService(context, ServerForegroundService.ACTION_START_VLESS)
        }
    }

    class Factory(private val app: ServerApplication) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return DashboardViewModel(app) as T
        }
    }
}
