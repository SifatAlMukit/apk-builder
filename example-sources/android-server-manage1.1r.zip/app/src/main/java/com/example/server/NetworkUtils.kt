package com.example.server

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

data class DiscoveredDevice(
    val ip: String,
    val hostName: String,
    val isReachable: Boolean,
    val responseTimeMs: Long
)

object NetworkUtils {

    fun getLocalIpAddress(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            // Priority list: Wi-Fi or Hotspot interfaces first
            val preferredNames = listOf("wlan", "ap", "eth", "rndis", "rmnet")

            val allAddresses = mutableListOf<Pair<String, String>>()
            for (intf in interfaces) {
                if (!intf.isUp || intf.isLoopback) continue
                val addresses = Collections.list(intf.inetAddresses)
                for (addr in addresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        val hostAddress = addr.hostAddress ?: continue
                        allAddresses.add(Pair(intf.name, hostAddress))
                    }
                }
            }

            for (prefix in preferredNames) {
                val match = allAddresses.firstOrNull { it.first.startsWith(prefix, ignoreCase = true) }
                if (match != null) return match.second
            }

            if (allAddresses.isNotEmpty()) {
                return allAddresses.first().second
            }
        } catch (_: Exception) {
        }
        return "127.0.0.1"
    }

    fun getActiveInterfaceName(): String {
        try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            for (intf in interfaces) {
                if (!intf.isUp || intf.isLoopback) continue
                val addresses = Collections.list(intf.inetAddresses)
                for (addr in addresses) {
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        return intf.name
                    }
                }
            }
        } catch (_: Exception) {
        }
        return "wlan0"
    }

    fun getWifiInfo(context: Context): Pair<String, Boolean> {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork
            val capabilities = cm.getNetworkCapabilities(network)
            val isWifi = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

            if (isWifi) {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val info = wm.connectionInfo
                val ssid = info.ssid?.replace("\"", "") ?: "Connected"
                Pair(if (ssid.isEmpty() || ssid == "<unknown ssid>") "Wi-Fi Connected" else ssid, true)
            } else {
                Pair("Not on Wi-Fi", false)
            }
        } catch (_: Exception) {
            Pair("Network Available", false)
        }
    }

    fun getGatewayAndSubnet(ip: String): Pair<String, String> {
        val parts = ip.split(".")
        return if (parts.size == 4) {
            val gateway = "${parts[0]}.${parts[1]}.${parts[2]}.1"
            Pair(gateway, "255.255.255.0")
        } else {
            Pair("192.168.1.1", "255.255.255.0")
        }
    }

    suspend fun scanLocalSubnet(baseIp: String, timeoutMs: Int = 300): List<DiscoveredDevice> = withContext(Dispatchers.IO) {
        val parts = baseIp.split(".")
        if (parts.size != 4) return@withContext emptyList()
        val prefix = "${parts[0]}.${parts[1]}.${parts[2]}."

        val discovered = mutableListOf<DiscoveredDevice>()
        coroutineScope {
            // Scan first 30 common IPs in parallel for responsiveness
            val jobs = (1..30).map { host ->
                async {
                    val targetIp = "$prefix$host"
                    val startTime = System.currentTimeMillis()
                    try {
                        val inetAddress = InetAddress.getByName(targetIp)
                        val isReachable = inetAddress.isReachable(timeoutMs)
                        val elapsed = System.currentTimeMillis() - startTime
                        if (isReachable || targetIp == baseIp) {
                            DiscoveredDevice(
                                ip = targetIp,
                                hostName = if (targetIp == baseIp) "This Android Device (Server)" else inetAddress.canonicalHostName,
                                isReachable = true,
                                responseTimeMs = elapsed
                            )
                        } else null
                    } catch (_: Exception) {
                        null
                    }
                }
            }
            jobs.awaitAll().filterNotNull().forEach { discovered.add(it) }
        }
        discovered.sortedBy { it.ip }
    }
}
