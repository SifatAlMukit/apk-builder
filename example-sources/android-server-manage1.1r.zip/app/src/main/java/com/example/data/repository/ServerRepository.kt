package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.model.ConnectedClient
import com.example.data.model.ConnectionHistoryEntity
import com.example.data.model.LogLevel
import com.example.data.model.ServerConfigEntity
import com.example.data.model.ServerLogEntity
import com.example.data.model.ServerStatus
import com.example.data.model.ServerType
import com.example.data.model.SshKeyEntity
import com.example.data.model.VlessUserEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class ServerRepository(private val database: AppDatabase) {

    private val serverConfigDao = database.serverConfigDao()
    private val vlessUserDao = database.vlessUserDao()
    private val sshKeyDao = database.sshKeyDao()
    private val serverLogDao = database.serverLogDao()
    private val connectionHistoryDao = database.connectionHistoryDao()

    // Transient in-memory runtime states
    private val _sshServerStatus = MutableStateFlow(ServerStatus.STOPPED)
    val sshServerStatus = _sshServerStatus.asStateFlow()

    private val _vlessServerStatus = MutableStateFlow(ServerStatus.STOPPED)
    val vlessServerStatus = _vlessServerStatus.asStateFlow()

    private val _connectedClients = MutableStateFlow<List<ConnectedClient>>(emptyList())
    val connectedClients = _connectedClients.asStateFlow()

    // Configs
    val allConfigs: Flow<List<ServerConfigEntity>> = serverConfigDao.getAllConfigs()

    fun getConfig(type: ServerType): Flow<ServerConfigEntity?> = serverConfigDao.getConfigByType(type)

    suspend fun getConfigDirect(type: ServerType): ServerConfigEntity? = serverConfigDao.getConfigDirect(type)

    suspend fun saveConfig(config: ServerConfigEntity) {
        serverConfigDao.insertOrUpdate(config)
    }

    // Status updates
    fun setServerStatus(type: ServerType, status: ServerStatus) {
        when (type) {
            ServerType.SSH -> _sshServerStatus.value = status
            ServerType.VLESS -> _vlessServerStatus.value = status
        }
    }

    // Connected clients management
    fun addConnectedClient(client: ConnectedClient) {
        _connectedClients.update { current ->
            current.filterNot { it.id == client.id } + client
        }
    }

    fun removeConnectedClient(clientId: String) {
        _connectedClients.update { current ->
            current.filterNot { it.id == clientId }
        }
    }

    fun updateClientTraffic(clientId: String, rxBytes: Long, txBytes: Long) {
        _connectedClients.update { current ->
            current.map {
                if (it.id == clientId) it.copy(rxBytes = it.rxBytes + rxBytes, txBytes = it.txBytes + txBytes)
                else it
            }
        }
    }

    fun clearConnectedClients(type: ServerType? = null) {
        _connectedClients.update { current ->
            if (type == null) emptyList()
            else current.filterNot { it.serverType == type }
        }
    }

    // VLESS Users
    val allVlessUsers: Flow<List<VlessUserEntity>> = vlessUserDao.getAllUsers()

    suspend fun getAllVlessUsersDirect(): List<VlessUserEntity> = vlessUserDao.getAllUsersDirect()

    suspend fun getVlessUser(uuid: String): VlessUserEntity? = vlessUserDao.getUserByUuid(uuid)

    suspend fun insertVlessUser(user: VlessUserEntity) = vlessUserDao.insertUser(user)

    suspend fun updateVlessUser(user: VlessUserEntity) = vlessUserDao.updateUser(user)

    suspend fun deleteVlessUser(user: VlessUserEntity) = vlessUserDao.deleteUser(user)

    suspend fun deleteVlessUserByUuid(uuid: String) = vlessUserDao.deleteByUuid(uuid)

    suspend fun updateVlessUserOnline(uuid: String, isOnline: Boolean) = vlessUserDao.updateOnlineStatus(uuid, isOnline)

    suspend fun addVlessTraffic(uuid: String, bytes: Long) = vlessUserDao.addTrafficUsage(uuid, bytes)

    // SSH Keys
    val allSshKeys: Flow<List<SshKeyEntity>> = sshKeyDao.getAllKeys()

    suspend fun insertSshKey(key: SshKeyEntity): Long = sshKeyDao.insertKey(key)

    suspend fun deleteSshKey(key: SshKeyEntity) = sshKeyDao.deleteKey(key)

    suspend fun deleteSshKeyById(id: Long) = sshKeyDao.deleteKeyById(id)

    suspend fun setSshKeyAuthorized(id: Long, isAuthorized: Boolean) = sshKeyDao.updateAuthorized(id, isAuthorized)

    // Logs
    val recentLogs: Flow<List<ServerLogEntity>> = serverLogDao.getRecentLogs()

    fun getLogsByType(type: ServerType): Flow<List<ServerLogEntity>> = serverLogDao.getLogsByType(type)

    fun getLogsByLevel(level: LogLevel): Flow<List<ServerLogEntity>> = serverLogDao.getLogsByLevel(level)

    suspend fun addLog(type: ServerType, level: LogLevel, message: String, clientIp: String? = null) {
        serverLogDao.insertLog(
            ServerLogEntity(
                serverType = type,
                level = level,
                message = message,
                clientIp = clientIp
            )
        )
    }

    suspend fun clearLogs(type: ServerType? = null) {
        if (type == null) {
            serverLogDao.clearAllLogs()
        } else {
            serverLogDao.clearLogsByType(type)
        }
    }

    // Connection History
    val connectionHistory: Flow<List<ConnectionHistoryEntity>> = connectionHistoryDao.getRecentConnections()

    suspend fun recordConnection(conn: ConnectionHistoryEntity): Long = connectionHistoryDao.insertConnection(conn)

    suspend fun recordDisconnection(id: Long, disconnectedAt: Long, bytes: Long) {
        connectionHistoryDao.markDisconnected(id, disconnectedAt, bytes)
    }

    suspend fun clearHistory() = connectionHistoryDao.clearHistory()
}
