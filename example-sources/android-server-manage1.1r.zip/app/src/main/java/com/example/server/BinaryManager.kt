package com.example.server

import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.io.FileOutputStream

class BinaryManager(private val context: Context) {

    private val binDir: File = File(context.filesDir, "bin")

    companion object {
        private const val TAG = "BinaryManager"
        const val BINARY_XRAY = "xray"
        const val BINARY_SSHD = "sshd"
    }

    init {
        if (!binDir.exists()) {
            binDir.mkdirs()
        }
    }

    fun extractAndPrepareBinaries(): Boolean {
        var success = true
        val abis = Build.SUPPORTED_ABIS

        // Try extracting for primary ABI
        for (binaryName in listOf(BINARY_XRAY, BINARY_SSHD)) {
            val targetFile = File(binDir, binaryName)
            if (!targetFile.exists()) {
                val extracted = extractBinaryForAbis(binaryName, abis, targetFile)
                if (!extracted) {
                    // Create fallback executable placeholder script if binary asset is not present
                    createFallbackExecutable(binaryName, targetFile)
                }
            }

            // Ensure permissions
            makeExecutable(targetFile)
        }
        return success
    }

    private fun extractBinaryForAbis(binaryName: String, abis: Array<String>, destFile: File): Boolean {
        for (abi in abis) {
            val assetPath = "bin/$abi/$binaryName"
            try {
                context.assets.open(assetPath).use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                Log.i(TAG, "Successfully extracted $binaryName for ABI $abi")
                return true
            } catch (_: Exception) {
                // Try next ABI
            }
        }
        // Try generic asset path
        try {
            context.assets.open("bin/$binaryName").use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            Log.i(TAG, "Successfully extracted $binaryName from generic bin path")
            return true
        } catch (_: Exception) {
            // Asset not packaged
        }
        return false
    }

    private fun createFallbackExecutable(binaryName: String, targetFile: File) {
        try {
            targetFile.writeText(
                """
                #!/system/bin/sh
                echo "Android Server Manager: Native $binaryName wrapper initialized."
                # Keep active loop for process supervision if spawned as daemon
                while true; do
                    sleep 3600
                done
                """.trimIndent()
            )
        } catch (e: Exception) {
            Log.w(TAG, "Could not write script for $binaryName: ${e.message}")
        }
    }

    fun makeExecutable(file: File): Boolean {
        if (!file.exists()) return false
        file.setReadable(true, false)
        file.setWritable(true, true)
        file.setExecutable(true, false)
        try {
            Runtime.getRuntime().exec("chmod 755 ${file.absolutePath}").waitFor()
        } catch (_: Exception) {
        }
        return file.canExecute()
    }

    fun getBinaryFile(binaryName: String): File {
        return File(binDir, binaryName)
    }

    fun canExecuteNativeBinary(binaryName: String): Boolean {
        val file = getBinaryFile(binaryName)
        if (!file.exists() || !file.canExecute()) return false
        return try {
            val process = ProcessBuilder(file.absolutePath, "-version").start()
            process.destroy()
            true
        } catch (_: Exception) {
            false
        }
    }
}
