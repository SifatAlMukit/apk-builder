# Android Server Manager

A production-quality Android application that transforms any Android phone into a lightweight, high-performance, offline local networking server capable of hosting services such as **OpenSSH Server** and **VLESS (Xray-core)** without requiring root access.

---

## 🌟 Architecture Overview

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                Material 3 Jetpack Compose UI                           │
│  ┌─────────────────┬──────────────────┬──────────────────┬──────────────┬────────────┐ │
│  │ DashboardScreen │    SshScreen     │   VlessScreen    │  LogsScreen  │ToolsScreen │ │
│  └────────┬────────┴────────┬─────────┴────────┬─────────┴──────┬───────┴─────┬──────┘ │
└───────────┼─────────────────┼──────────────────┼────────────────┼─────────────┼────────┘
            ▼                 ▼                  ▼                ▼             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                    ViewModel Layer                                     │
│     (DashboardViewModel, SshViewModel, VlessViewModel, LogsViewModel, ToolsViewModel)  │
└───────────────────────────────────────────┬────────────────────────────────────────────┘
                                            │
               ┌────────────────────────────┴───────────────────────────┐
               ▼                                                        ▼
┌──────────────────────────────────────────────┐       ┌─────────────────────────────────┐
│        Server Foreground Service             │       │        Data Repositories        │
│   (Persistent Notification Quick Actions)    │       │     (Offline Single Source)     │
│  ┌────────────────────┬───────────────────┐  │       │  ┌───────────────────────────┐  │
│  │   SshServerEngine  │ VlessServerEngine │  │       │  │     ServerRepository      │  │
│  └─────────┬──────────┴─────────┬─────────┘  │       │  │   PreferencesRepository   │  │
│            │                    │            │       │  └─────────────┬─────────────┘  │
└────────────┼────────────────────┼────────────┘       └────────────────┼────────────────┘
             ▼                    ▼                                     │
┌──────────────────────────┐  ┌──────────────────────────┐              ▼
│  Binary Execution Manager│  │ Integrated Socket Engine │   ┌──────────────────────────┐
│  • Asset ELF extraction  │  │ • High-performance TCP   │   │  Room SQLite Database    │
│  • chmod 755 executable  │  │ • Zero-root fallback     │   │  • Server configurations │
│  • arm64-v8a / x86_64    │  │ • Protocol handshakes    │   │  • VLESS users & quotas  │
└──────────────────────────┘  └──────────────────────────┘   │  • SSH keys & history    │
                                                             │  • Real-time server logs │
                                                             └──────────────────────────┘
```

---

## 🚀 Key Features

### 1. Unified Dashboard
- **Host Information**: Live local IP address, Subnet Mask, Gateway, Interface name (`wlan0`, `ap0`), and Wi-Fi / Hotspot status.
- **Master Quick Controls**: One-tap `Start All`, `Stop All`, and `Restart All` actions.
- **Real-Time Telemetry**: Animated gauges for CPU usage %, RAM utilization (MB/GB), Battery percentage & temperature (°C), Storage space, and real-time Download/Upload speeds in KB/s.
- **Active Client Tracking**: Instant live view of currently connected SSH and VLESS clients.

### 2. OpenSSH Server
- Configurable port (default `2222`).
- Custom username and password authentication.
- **Public Key Authentication**: Built-in 2048-bit RSA keypair generator, public key import/export, and key management.
- Live connected sessions & connection history logs.
- Quick `ssh user@host -p port` copy and QR Code generation for seamless terminal pairing.

### 3. VLESS (Xray-core) Proxy Server
- Lightweight, zero-overhead VLESS protocol host.
- Configurable port (default `4433`).
- **Multi-User Management**: Add, remove, rename, enable/disable users with custom or auto-generated UUIDs, traffic limits (MB or unlimited), and expiration tracking.
- **Dual Mode Configuration Editor**:
  - Visual Config Editor: intuitive UI toggles.
  - Raw JSON Editor: syntax-validated JSON configuration generator.
- One-tap `vless://` URI generation & QR Code exporter for immediate client app importing (e.g., v2rayNG, Shadowrocket, Nekobox).

### 4. Real-Time Central Logs
- Live log streaming for all daemon activity (stdout, stderr, client handshakes).
- Search query filtering by IP, message, and timestamp.
- Log level chips: `ALL`, `INFO`, `WARN`, `ERROR`, `CONN`.
- One-tap clipboard copy and system share sheet export.

### 5. Built-in Terminal & Network Discovery
- **Local Linux Terminal**: Execute commands directly on Android (`ip addr`, `netstat`, `ping`, `uptime`, `whoami`, `df -h`) with output display.
- **Subnet Device Scanner**: Automatically discovers active devices on the local Wi-Fi subnet with ping latency.
- **Configuration Backup & Restore**: Export all settings and user databases as a portable JSON payload.

### 6. App Settings & Customization
- **Theme Modes**: Dark Mode, Light Mode, and System Theme.
- **Material You**: Dynamic wallpaper accent coloring.
- **Bilingual Support**: English & Bengali (বাংলা).
- **Daemon Protection**: Prevent accidental server stop toggle, Auto-start on device boot, and CPU WakeLock to keep servers listening indefinitely.

---

## 🛠️ Technology Stack
- **Language**: Kotlin 2.2
- **UI Toolkit**: Jetpack Compose with Material Design 3 (M3)
- **Architecture**: Clean Architecture / MVVM
- **Database**: Room Database (SQLite) + DataStore Preferences
- **QR Engine**: ZXing (`com.google.zxing:core`)
- **Networking**: Kotlin Coroutines, Channels, Java ServerSockets, ProcessBuilder
- **Min SDK**: 24 (Android 7.0 Nougat) | **Target SDK**: 36 (Android 16)
