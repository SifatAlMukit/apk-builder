package com.example

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ProfileEntity
import com.example.model.TunnelState
import com.example.ui.MainViewModel
import com.example.ui.screens.AddConfigurationDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LogsScreen
import com.example.ui.screens.ProfilesScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StatusScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: MainViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val appSettings by viewModel.appSettings.collectAsStateWithLifecycle()
            MyApplicationTheme(darkTheme = appSettings.isDarkTheme) {
                val context = LocalContext.current
                var currentTab by remember { mutableIntStateOf(0) }
                var isAddingProfile by remember { mutableStateOf(false) }
                var editingProfile by remember { mutableStateOf<ProfileEntity?>(null) }

                val tunnelState by viewModel.tunnelState.collectAsStateWithLifecycle()
                val tunnelStats by viewModel.tunnelStats.collectAsStateWithLifecycle()
                val allProfiles by viewModel.allProfiles.collectAsStateWithLifecycle()
                val activeProfile by viewModel.activeProfile.collectAsStateWithLifecycle()
                val logs by viewModel.recentLogs.collectAsStateWithLifecycle()
                val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
                val networkInfo by viewModel.networkInfo.collectAsStateWithLifecycle()
                val speedHistory by viewModel.speedHistory.collectAsStateWithLifecycle()
                val latencyHistory by viewModel.latencyHistory.collectAsStateWithLifecycle()
                val latencySummary by viewModel.latencySummary.collectAsStateWithLifecycle()
                val selectedSpeedWindow by viewModel.selectedSpeedWindow.collectAsStateWithLifecycle()

                // Toast event listener
                LaunchedEffect(Unit) {
                    viewModel.userMessage.collect { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                }

                // VPN permission launcher
                val vpnPrepareLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.StartActivityForResult()
                ) { result ->
                    if (result.resultCode == Activity.RESULT_OK) {
                        viewModel.toggleConnection(context)
                    } else {
                        Toast.makeText(context, "VPN permission denied", Toast.LENGTH_SHORT).show()
                    }
                }

                // Notification permission launcher for Android 13+
                val notifLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.RequestPermission()
                ) { _ -> }

                LaunchedEffect(Unit) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                            != PackageManager.PERMISSION_GRANTED
                        ) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }

                fun onToggleTunnel() {
                    if (tunnelState == TunnelState.CONNECTED || tunnelState == TunnelState.CONNECTING) {
                        viewModel.toggleConnection(context)
                    } else {
                        val prepareIntent = VpnService.prepare(context)
                        if (prepareIntent != null) {
                            vpnPrepareLauncher.launch(prepareIntent)
                        } else {
                            viewModel.toggleConnection(context)
                        }
                    }
                }

                // Handle back button when not on Home screen
                BackHandler(enabled = currentTab != 0 && !isAddingProfile && editingProfile == null) {
                    currentTab = 0
                }

                if (isAddingProfile || editingProfile != null) {
                    AddConfigurationDialog(
                        profile = editingProfile,
                        onDismiss = {
                            isAddingProfile = false
                            editingProfile = null
                        },
                        onSave = { savedProfile ->
                            viewModel.saveProfile(savedProfile)
                            isAddingProfile = false
                            editingProfile = null
                        },
                        onImportLink = { link ->
                            val success = viewModel.importFromLink(link)
                            if (success) {
                                isAddingProfile = false
                                editingProfile = null
                            }
                            success
                        }
                    )
                } else {
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        topBar = {
                            TopAppBar(
                                title = {
                                Text(
                                    text = when (currentTab) {
                                        0 -> "PulseTunnel"
                                        1 -> "Profiles"
                                        2 -> "Status"
                                        3 -> "Logs"
                                        4 -> "Settings"
                                        else -> "PulseTunnel"
                                    },
                                    style = MaterialTheme.typography.titleLarge
                                )
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.background,
                                titleContentColor = MaterialTheme.colorScheme.onBackground
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            tonalElevation = 4.dp
                        ) {
                            NavigationBarItem(
                                selected = currentTab == 0,
                                onClick = { currentTab = 0 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 0) Icons.Default.Shield else Icons.Outlined.Shield,
                                        contentDescription = "Home"
                                    )
                                },
                                label = { Text("Home") },
                                modifier = Modifier.testTag("nav_home")
                            )
                            NavigationBarItem(
                                selected = currentTab == 1,
                                onClick = { currentTab = 1 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 1) Icons.Default.Tune else Icons.Outlined.Tune,
                                        contentDescription = "Profiles"
                                    )
                                },
                                label = { Text("Profiles") },
                                modifier = Modifier.testTag("nav_profiles")
                            )
                            NavigationBarItem(
                                selected = currentTab == 2,
                                onClick = { currentTab = 2 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 2) Icons.Default.Speed else Icons.Outlined.Speed,
                                        contentDescription = "Status"
                                    )
                                },
                                label = { Text("Status") },
                                modifier = Modifier.testTag("nav_status")
                            )
                            NavigationBarItem(
                                selected = currentTab == 3,
                                onClick = { currentTab = 3 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 3) Icons.Default.Terminal else Icons.Outlined.Terminal,
                                        contentDescription = "Logs"
                                    )
                                },
                                label = { Text("Logs") },
                                modifier = Modifier.testTag("nav_logs")
                            )
                            NavigationBarItem(
                                selected = currentTab == 4,
                                onClick = { currentTab = 4 },
                                icon = {
                                    Icon(
                                        imageVector = if (currentTab == 4) Icons.Default.Settings else Icons.Outlined.Settings,
                                        contentDescription = "Settings"
                                    )
                                },
                                label = { Text("Settings") },
                                modifier = Modifier.testTag("nav_settings")
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (currentTab) {
                            0 -> HomeScreen(
                                tunnelState = tunnelState,
                                tunnelStats = tunnelStats,
                                activeProfile = activeProfile,
                                allProfiles = allProfiles,
                                onToggleTunnel = { onToggleTunnel() },
                                onSelectProfile = { id -> viewModel.selectActiveProfile(id) },
                                onPingActive = { activeProfile?.let { viewModel.pingProfile(it.id) } },
                                onNavigateToProfiles = { currentTab = 1 }
                            )
                            1 -> ProfilesScreen(
                                profiles = allProfiles,
                                activeProfileId = activeProfile?.id,
                                onSelectActiveProfile = { id -> viewModel.selectActiveProfile(id) },
                                onSaveProfile = { p -> viewModel.saveProfile(p) },
                                onDeleteProfile = { id -> viewModel.deleteProfile(id) },
                                onDuplicateProfile = { p -> viewModel.duplicateProfile(p) },
                                onPingProfile = { id -> viewModel.pingProfile(id) },
                                onImportLink = { link -> viewModel.importFromLink(link) },
                                onExportBackup = { pass -> viewModel.exportEncryptedBackup(pass) },
                                onImportBackup = { data, pass -> viewModel.importEncryptedBackup(data, pass) },
                                onAddProfile = { isAddingProfile = true },
                                onEditProfile = { profile -> editingProfile = profile }
                            )
                            2 -> StatusScreen(
                                tunnelState = tunnelState,
                                tunnelStats = tunnelStats,
                                networkInfo = networkInfo,
                                speedHistory = speedHistory,
                                latencyHistory = latencyHistory,
                                latencySummary = latencySummary,
                                selectedTimeWindow = selectedSpeedWindow,
                                onTimeWindowSelected = { w -> viewModel.setSpeedTimeWindow(w) },
                                onToggleMasking = { viewModel.toggleIpMasking() },
                                onRefreshNetworkInfo = { viewModel.refreshNetworkInfo() },
                                activeProfileName = activeProfile?.name
                            )
                            3 -> LogsScreen(
                                logs = logs,
                                onClearLogs = { viewModel.clearLogs() }
                            )
                            4 -> SettingsScreen(
                                settings = appSettings,
                                installedApps = installedApps,
                                onSaveSettings = { s -> viewModel.updateSettings(s) }
                            )
                        }
                    }
                }
            }
        }
    }
}
}
