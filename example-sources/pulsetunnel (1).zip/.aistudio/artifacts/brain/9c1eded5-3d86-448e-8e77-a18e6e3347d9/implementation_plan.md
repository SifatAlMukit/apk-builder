# Status Tab Implementation Plan (Live Network, Speed & Latency Metrics)

Implement a dedicated **Status** tab matching the design mockup in `/public/assets/aistudio/Status_tab_2x_a79e722b.png`, with event-driven IP tracking, 10-second speed & latency sampling, dual-line Canvas charts, and privacy masking.

## User Review & Critical Decisions

> [!IMPORTANT]
> - **Refresh Interval**: User selected **10 seconds** for battery-friendly updates.
> - **IP Privacy**: User selected **Masked by default** with an eye icon button toggle in the Network card header.
> - **Event-driven IP Discovery**: Zero periodic polling. Local IP listens directly to `ConnectivityManager.NetworkCallback.onLinkPropertiesChanged`. Public IP / ISP / Location uses a single HTTPS API request (`ipwho.is` with fallback) invoked strictly on connection state change, Wi-Fi ↔ Mobile handover, and pull-to-refresh, caching results for 15–30 minutes.

- **Confirmed Decision 1**: 5-tab navigation bar structure: `Home` (0), `Profiles` (1), `Status` (2), `Logs` (3), `Settings` (4).
- **Confirmed Decision 2**: Speed & Ping interval set to 10 seconds.
- **Confirmed Decision 3**: Eye icon toggle in Network card to show/mask Real and VPN IP addresses (`203.0.•••.•••` / `198.51.•••.•••`).

---

### 1. Overview & Core Concept

- **What It Does**: Provides a real-time, telemetry dashboard showing the user's active IP environment (Real IP, VPN IP, Local IP, Location, ISP), live bandwidth transfer graph with 1m/10m/1h time filters, and real-time ICMP/TCP ping latency graph with Min/Avg/Max/Jitter/Loss metrics.
- **Target Persona**: Power VPN users and network engineers who need to verify IP leak protection, diagnose network latency spikes, and monitor download/upload throughput.
- **Key Value**: Delivers complete transparency over network state with zero battery drain via event-driven callbacks instead of wasteful background polling.

---

### 2. User Experience & Visual Design

- **Key User Flows**:
  1. User selects the new **Status** tab (pulse/heartbeat icon) in the bottom navigation bar.
  2. The top bar displays connection status pill (`● Connected 02:14:09` or `Disconnected`).
  3. **Network Card**:
     - Displays Real IP (masked by default, e.g. `203.0.•••.•••`), VPN IP (`198.51.•••.•••` in cyan), Local IP (`192.168.1.x`), Location (`Singapore, SG`), and ISP name.
     - Tapping the top-right eye icon unmasks/masks the IPs immediately.
     - Tapping the refresh pill (`↻ 3m ago`) triggers an immediate single-call background update.
  4. **Speed Card**:
     - Shows current transfer rates: `↓ 2.41 MB/s` (Cyan) and `↑ 382 KB/s` (Orange).
     - Filter chips: `1m`, `10m`, `1h` toggle time zoom.
     - Custom Canvas chart draws smooth dual curves with gradient area fill, current value dots, and Y-axis scale markers (`2 MB/s`, `4 MB/s`).
  5. **Latency Card**:
     - Displays current ping (`● 42 ms` in green).
     - Custom Canvas chart plots latency history with a `100 ms` dashed threshold line and peak highlighting.
     - Bottom grid shows Min, Avg, Max, Jitter, and Loss % metrics.

- **Visual Theme & Styling**:
  - Dark-mode cohesive palette matching `PulseTunnel`: `surfaceVariant` cards with 16dp rounded corners, `primary` cyan accents (`#06B6D4`), and `amber` upload accents (`#F59E0B`).
  - Textbox outline contrast styling inherited from previous modernization.

---

### 3. Key Product Decisions & Trade-Offs

- **Decision 1: Event-driven IP Detection vs. Timed Polling**
  - *Chosen Approach*: `ConnectivityManager.NetworkCallback` for local network interface link changes, and single HTTPS API fetch on state transitions.
  - *Why*: Eliminates background battery drain and unnecessary data consumption while ensuring instant accuracy when switching networks.
  - *Cache Strategy*: Timestamped in-memory and persistent cache. Instant display from cache; if older than 15-30 minutes, refreshes asynchronously.

- **Decision 2: Native Jetpack Compose Canvas Charts vs. External Heavy Libraries**
  - *Chosen Approach*: Lightweight custom Jetpack Compose `Canvas` drawing components (`SpeedLineChart` and `LatencyLineChart`).
  - *Why*: Ultra-fast 60fps rendering, zero extra dependencies, compact APK size (< 5KB overhead), and exact pixel-level fidelity to the provided screenshot mockup.

- **Decision 3: Ping Measurement Engine**
  - *Chosen Approach*: Socket connection latency to configured profile server host (or Cloudflare/Google DNS fallback: `1.1.1.1` / `8.8.8.8` on port 53/443).
  - *Why*: Works across all Android versions without requiring root or shell `ping` command permissions which may fail on restricted SELinux devices.

---

### 4. Technical Architecture & Data Strategy

```
┌─────────────────────────────────────────────────────────────────┐
│                          MainActivity                           │
│  Navigation: Home(0) | Profiles(1) | Status(2) | Logs(3) | Set(4)│
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                          StatusScreen                           │
│  ├─ TopAppBar / Header Status Pill ("Connected 02:14:09")       │
│  ├─ NetworkCard (Event-based IP, Eye mask toggle, ↻ pill)       │
│  ├─ SpeedCard (10s sample, 1m/10m/1h chips, Dual-line Canvas)   │
│  └─ LatencyCard (Target, Current ms, Dashed graph, Min/Avg/Max) │
└────────────────────────────────┬────────────────────────────────┘
                                 │
                                 ▼
┌─────────────────────────────────────────────────────────────────┐
│                 MainViewModel & NetworkMonitor                  │
│  ├─ networkInfo: StateFlow<NetworkInfoState>                    │
│  ├─ speedHistory: StateFlow<List<SpeedSample>> (every 10s)      │
│  ├─ latencyHistory: StateFlow<List<LatencySample>>              │
│  ├─ ConnectivityManager.NetworkCallback (link & network events) │
│  └─ fetchPublicIpInfo(force: Boolean) [ipwho.is HTTPS call]     │
└─────────────────────────────────────────────────────────────────┘
```

- **Data Models**:
  - `NetworkInfoState`: `realIp`, `vpnIp`, `localIp`, `location`, `isp`, `lastFetchedEpochMs`, `isMasked`.
  - `SpeedSample`: `timestampMs`, `downloadBps`, `uploadBps`.
  - `LatencySample`: `timestampMs`, `latencyMs`.
  - `LatencyMetrics`: `minMs`, `avgMs`, `maxMs`, `jitterMs`, `lossPercent`.

- **Component & File Changes**:
  - `app/src/main/java/com/example/model/NetworkStatusModels.kt`: Data classes for IP info, Speed sample, Latency sample, and time filters.
  - `app/src/main/java/com/example/util/NetworkInfoManager.kt`: Event-driven `NetworkCallback` listener, `ipwho.is` HTTPS client, and cache manager.
  - `app/src/main/java/com/example/ui/screens/StatusScreen.kt`: The complete Compose screen with `NetworkCard`, `SpeedCard`, `LatencyCard`, and Canvas line charts.
  - `app/src/main/java/com/example/ui/MainViewModel.kt`: Integration of `NetworkInfoManager`, 10s sampling coroutine loop, and telemetry state flows.
  - `app/src/main/java/com/example/MainActivity.kt`: Addition of `Status` tab item into `NavigationBar` (5 items total) and screen routing.
